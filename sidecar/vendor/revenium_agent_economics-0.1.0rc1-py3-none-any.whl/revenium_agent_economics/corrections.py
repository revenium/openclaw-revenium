"""Corrections and the effective state they resolve into (ADR 0031).

A correction is an immutable record that names a past decision and the field
values that replace its own. :func:`resolve_effective` folds a record and its
corrections into one :class:`EffectiveAssessment`, field by field, without
touching the original or any correction (CORR-01, CORR-03). Evidence class is
never correctable, identity never changes, and reportability is never widened
(CORR-02, D-08, D-09). A corrected value is re-netted through
:func:`~revenium_agent_economics.costs.net_value` (D-11).

Every function here is sync and pure. Timestamps come only from the ``clock``
argument, and the core mints no id: a correction id is recomputed from its
target and the host's count (D-10).
"""

import dataclasses
import enum
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal
from types import MappingProxyType
from typing import ClassVar, Final

from revenium_agent_economics._bounded import (
    CORRECTION_ID_MAX_BYTES as CORRECTION_ID_MAX_BYTES,
)
from revenium_agent_economics._bounded import (
    IDENTIFIER_MAX_BYTES,
    NARRATIVE_CLAMP_BYTES,
    is_bounded_printable,
    normalize_text,
    serialized_byte_length,
)
from revenium_agent_economics._canonical import format_decimal, format_utc_timestamp
from revenium_agent_economics._version import __version__
from revenium_agent_economics.assessment import (
    SEQUENCE_MAX,
    AssessmentAbstention,
    JobAssessment,
    _require_normalized,
    _require_sequence,
)
from revenium_agent_economics.costs import (
    RoiOperands,
    SuppliedCosts,
    ValueSideState,
    cost_coverage,
    empty_supplied_costs,
    net_value,
)
from revenium_agent_economics.errors import ConfigurationError, RecordValidationError
from revenium_agent_economics.jobs import JobCandidate, JobOutcome, _require_job_id
from revenium_agent_economics.primitives import (
    Confidence,
    Money,
    _require_exact_type,
    _require_text,
    _require_tuple_of,
    quantize_money,
)
from revenium_agent_economics.protocols import Clock
from revenium_agent_economics.tasks import _require_utc
from revenium_agent_economics.taxonomy import is_valid_label, validate_label
from revenium_agent_economics.valuation import _quantized
from revenium_agent_economics.vocab import (
    COST_CATEGORIES,
    ECONOMIC_MECHANISM_UNKNOWN,
    UNCLASSIFIED_LABEL,
    ClaimBasis,
    Currency,
    EconomicMechanism,
    EvidenceAuthority,
    EvidenceClass,
    ReportabilityReason,
    ReportabilityStatus,
)

_ASSESSMENT_REF: Final = JobAssessment.SCHEMA_ID
_CANDIDATE_REF: Final = JobCandidate.SCHEMA_ID
_SEQUENCE_DIGITS: Final = len(str(SEQUENCE_MAX))
_PAIR_LENGTH: Final = 2
_MECHANISM_VALUES: Final[frozenset[str]] = frozenset(
    mechanism.value for mechanism in EconomicMechanism
)


class CorrectableField(enum.Enum):
    """The closed set of fields a correction may replace (ADR 0031 decision 1).

    A plain ``Enum`` with no ordering. No member names evidence class or its
    authority, so evidence class is not correctable by construction (CORR-02).
    Confidence, hours saved, costs, the metered AI cost, and identity have no
    member either.
    """

    JOB_TYPE = "job_type"
    JOB_STARTED_AT = "job_started_at"
    JOB_ENDED_AT = "job_ended_at"
    EXECUTION_STATUS = "execution_status"
    VALUE = "value"
    VALUE_LOW = "value_low"
    VALUE_HIGH = "value_high"
    CURRENCY = "currency"
    ECONOMIC_MECHANISM = "economic_mechanism"
    ATTRIBUTION_FRACTION = "attribution_fraction"
    ATTRIBUTION_BASIS = "attribution_basis"


_FIELD_ORDER: Final[tuple[CorrectableField, ...]] = tuple(CorrectableField)
_CANDIDATE_FIELDS: Final[frozenset[CorrectableField]] = frozenset(
    {
        CorrectableField.JOB_TYPE,
        CorrectableField.JOB_STARTED_AT,
        CorrectableField.JOB_ENDED_AT,
    }
)
# ADR 0031 decision 3: the two field sets are disjoint.
TARGET_FIELDS: Final[Mapping[str, frozenset[CorrectableField]]] = MappingProxyType(
    {
        _CANDIDATE_REF: _CANDIDATE_FIELDS,
        _ASSESSMENT_REF: frozenset(CorrectableField) - _CANDIDATE_FIELDS,
    }
)
# ADR 0031 decision 8: a correction to any of these rebuilds the ROI operands.
_VALUE_SIDE_FIELDS: Final[frozenset[CorrectableField]] = frozenset(
    {
        CorrectableField.VALUE,
        CorrectableField.VALUE_LOW,
        CorrectableField.VALUE_HIGH,
        CorrectableField.CURRENCY,
        CorrectableField.ECONOMIC_MECHANISM,
        CorrectableField.ATTRIBUTION_FRACTION,
        CorrectableField.ATTRIBUTION_BASIS,
    }
)


def _checked_now(clock: Clock, field_name: str) -> datetime:
    # Every injected-clock helper refuses a naive or non-UTC value. The
    # message names the field, never the value (T-05-13).
    now = clock.now()
    if type(now) is not datetime or now.utcoffset() != timedelta(0):
        raise ConfigurationError(
            f"{field_name} needs a clock that returns an aware UTC datetime"
        )
    return now


def _require_assessment_id_text(value: object, schema_id: str, field: str) -> None:
    # An ADR 0030 assessment id: f"{job_id}:{n}" with a canonical decimal n.
    _require_exact_type(value, str, schema_id, field)
    job_part, separator, number = str(value).rpartition(":")
    if (
        separator == ""
        or not number.isascii()
        or not number.isdigit()
        or len(number) > _SEQUENCE_DIGITS
        or (len(number) > 1 and number.startswith("0"))
        or int(number) > SEQUENCE_MAX
    ):
        raise RecordValidationError(
            schema_id, field, "must be an assessment id f'{job_id}:{sequence}'"
        )
    _require_job_id(job_part, schema_id, field)


def _require_bounded_identifier(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, str, schema_id, field)
    if not is_bounded_printable(str(value), IDENTIFIER_MAX_BYTES):
        raise RecordValidationError(
            schema_id,
            field,
            "must be non-empty printable text of at most "
            f"{IDENTIFIER_MAX_BYTES} serialized bytes",
        )


def _require_narrative_text(value: object, schema_id: str, field: str) -> None:
    # Non-empty, and in the shape normalize_text(..., NARRATIVE_CLAMP_BYTES)
    # produces: no IFS characters, no leading whitespace, within the bound.
    _require_text(value, schema_id, field)
    _require_normalized(value, schema_id, field, NARRATIVE_CLAMP_BYTES)


def _require_money_value(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, Decimal, schema_id, field)
    if not isinstance(value, Decimal) or not value.is_finite() or value < 0:
        raise RecordValidationError(
            schema_id, field, "must be a finite Decimal of at least 0"
        )


def _quantized_amount(amount: Decimal, currency: Currency) -> Decimal:
    # Callers pass only amounts a Correction or a record already accepted as
    # quantizable, so quantize_money cannot raise here.
    result = quantize_money(amount, currency)
    return result.copy_abs() if result.is_zero() else result


@dataclass(frozen=True, slots=True, kw_only=True)
class RecordRef:
    """A reference to the record a correction targets (ADR 0031 decision 1).

    ``JobAssessment`` and ``AssessmentAbstention`` share one assessment id
    space, so both are targeted as ``"rae.job_assessment"``.

    Attributes:
        schema_id: ``"rae.job_assessment"`` or ``"rae.job_candidate"``.
        record_id: An assessment id for the first and an ADR 0017 job id for
            the second.
    """

    SCHEMA_ID: ClassVar[str] = "rae.record_ref"
    SCHEMA_VERSION: ClassVar[int] = 1

    schema_id: str
    record_id: str

    def __post_init__(self) -> None:
        """Validate the target schema id and the record id it implies.

        Raises:
            RecordValidationError: If either field is invalid.
        """
        schema_id = RecordRef.SCHEMA_ID
        _require_exact_type(self.schema_id, str, schema_id, "schema_id")
        if self.schema_id == _ASSESSMENT_REF:
            _require_assessment_id_text(self.record_id, schema_id, "record_id")
        elif self.schema_id == _CANDIDATE_REF:
            _require_job_id(self.record_id, schema_id, "record_id")
        else:
            raise RecordValidationError(
                schema_id,
                "schema_id",
                f"must be {_ASSESSMENT_REF!r} or {_CANDIDATE_REF!r}",
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class CorrectionFields:
    """One optional value per :class:`CorrectableField` (ADR 0031 decision 1).

    The record checks the type and bounds of each attribute. The coupling
    rules between attributes are checked by :class:`Correction` on its
    ``fields``, so the same record can also describe standing values in
    ``Correction.expected_prior``.

    Attributes:
        job_type: A job type label.
        job_started_at: An aware UTC job start.
        job_ended_at: An aware UTC job end.
        execution_status: The job's outcome.
        value: The estimated value, a finite ``Decimal`` of at least 0.
        value_low: The low end of the value band, under the same rule.
        value_high: The high end of the value band, under the same rule.
        currency: The currency of the value.
        economic_mechanism: An economic mechanism's value text.
        attribution_fraction: A finite ``Decimal`` in [0, 1].
        attribution_basis: Non-empty text in ``normalize_text`` form, at most
            ``NARRATIVE_CLAMP_BYTES`` serialized bytes.
    """

    SCHEMA_ID: ClassVar[str] = "rae.correction_fields"
    SCHEMA_VERSION: ClassVar[int] = 1

    job_type: str | None = None
    job_started_at: datetime | None = None
    job_ended_at: datetime | None = None
    execution_status: JobOutcome | None = None
    value: Decimal | None = None
    value_low: Decimal | None = None
    value_high: Decimal | None = None
    currency: Currency | None = None
    economic_mechanism: str | None = None
    attribution_fraction: Decimal | None = None
    attribution_basis: str | None = None

    def __post_init__(self) -> None:
        """Validate each set attribute on its own.

        Raises:
            RecordValidationError: If any set attribute has the wrong type or
                is out of bounds.
        """
        schema_id = CorrectionFields.SCHEMA_ID
        if self.job_type is not None:
            _require_exact_type(self.job_type, str, schema_id, "job_type")
            if validate_label(self.job_type) != self.job_type:
                raise RecordValidationError(
                    schema_id, "job_type", "fails the label grammar"
                )
        for name in ("job_started_at", "job_ended_at"):
            if getattr(self, name) is not None:
                _require_utc(getattr(self, name), schema_id, name)
        if self.execution_status is not None:
            _require_exact_type(
                self.execution_status, JobOutcome, schema_id, "execution_status"
            )
        for name in ("value", "value_low", "value_high"):
            if getattr(self, name) is not None:
                _require_money_value(getattr(self, name), schema_id, name)
        if self.currency is not None:
            _require_exact_type(self.currency, Currency, schema_id, "currency")
        if self.economic_mechanism is not None:
            _require_text(self.economic_mechanism, schema_id, "economic_mechanism")
        fraction = self.attribution_fraction
        if fraction is not None:
            _require_exact_type(fraction, Decimal, schema_id, "attribution_fraction")
            if not fraction.is_finite() or not Decimal(0) <= fraction <= Decimal(1):
                raise RecordValidationError(
                    schema_id, "attribution_fraction", "must be finite and in [0, 1]"
                )
        if self.attribution_basis is not None:
            _require_narrative_text(
                self.attribution_basis, schema_id, "attribution_basis"
            )

    @property
    def named(self) -> tuple[CorrectableField, ...]:
        """The fields whose attribute is set, in :class:`CorrectableField` order."""
        return tuple(
            field for field in _FIELD_ORDER if getattr(self, field.value) is not None
        )


def correction_id(target: RecordRef, n: int) -> str:
    """Return the correction id ``f"{target.record_id}:c{n}"`` (D-10).

    The format is one-way: hosts persist it in their ``CorrectionStore``. The
    owner approved its exact bytes at the 05-01 Task 3 checkpoint (ADR 0031
    decision 2). The host counts ``n`` per target.

    Args:
        target: The record the correction targets.
        n: The host's count for this target, an exact ``int`` from 0 to
            ``2**63 - 1``. A ``bool`` is refused.

    Returns:
        The correction id, at most ``CORRECTION_ID_MAX_BYTES`` serialized
        bytes.

    Raises:
        RecordValidationError: If ``target`` is not a ``RecordRef`` or ``n``
            is a ``bool``, not an ``int``, or out of range.
    """
    schema_id = Correction.SCHEMA_ID
    _require_exact_type(target, RecordRef, schema_id, "target")
    _require_sequence(n, schema_id, "sequence")
    result = f"{target.record_id}:c{n}"
    if serialized_byte_length(result) > CORRECTION_ID_MAX_BYTES:  # pragma: no cover
        # Unreachable: an assessment id is at most 84 bytes and n at most 19
        # digits. Kept so the bound is checked where the id is minted.
        raise RecordValidationError(
            schema_id,
            "correction_id",
            f"must be at most {CORRECTION_ID_MAX_BYTES} serialized bytes",
        )
    return result


def _require_couplings(record: "Correction") -> None:
    # ADR 0031 decision 3, on the correction's own fields.
    schema_id = Correction.SCHEMA_ID
    fields = record.fields
    named = set(fields.named)
    if not named:
        raise RecordValidationError(schema_id, "fields", "must name at least one field")
    allowed = TARGET_FIELDS[record.target.schema_id]
    if not named <= allowed:
        raise RecordValidationError(
            schema_id, "fields", "names a field outside the target's field set"
        )
    has_value = CorrectableField.VALUE in named
    if has_value != (CorrectableField.CURRENCY in named):
        raise RecordValidationError(
            schema_id, "currency", "value and currency are named together"
        )
    bounds = {CorrectableField.VALUE_LOW, CorrectableField.VALUE_HIGH}
    if (bounds & named) != (bounds if has_value else set()):
        raise RecordValidationError(
            schema_id,
            "value_low",
            "value_low and value_high are named exactly when value is",
        )
    if fields.value is not None and fields.currency is not None:
        for name in ("value", "value_low", "value_high"):
            amount = getattr(fields, name)
            quantized = _quantized(amount, fields.currency)
            if quantized is None or quantized.amount != amount:
                raise RecordValidationError(
                    schema_id,
                    name,
                    "must be quantized to the currency minor unit",
                )
        if (
            fields.value_low is not None
            and fields.value_high is not None
            and (not fields.value_low <= fields.value <= fields.value_high)
        ):
            raise RecordValidationError(
                schema_id, "value_low", "must satisfy value_low <= value <= value_high"
            )
    attribution = {
        CorrectableField.ATTRIBUTION_FRACTION,
        CorrectableField.ATTRIBUTION_BASIS,
    }
    if (attribution & named) and (not attribution <= named or not has_value):
        raise RecordValidationError(
            schema_id,
            "attribution_fraction",
            "the attribution fraction and basis are named together, with value",
        )
    mechanism = fields.economic_mechanism
    if mechanism is not None and mechanism not in _MECHANISM_VALUES:
        raise RecordValidationError(
            schema_id, "economic_mechanism", "must be an EconomicMechanism value"
        )
    if fields.job_type == UNCLASSIFIED_LABEL:
        raise RecordValidationError(
            schema_id, "job_type", "must not be the unclassified label"
        )
    started = fields.job_started_at
    ended = fields.job_ended_at
    if started is not None and ended is not None and started > ended:
        raise RecordValidationError(
            schema_id, "job_ended_at", "must not be before job_started_at"
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class Correction:
    """An immutable replacement of some fields of one record (ADR 0031).

    Attributes:
        correction_id: ``correction_id(target, sequence)`` (D-10).
        target: The corrected record.
        sequence: The host's count for the target, from 0 to ``2**63 - 1``.
        fields: The replacement values, naming at least one field of the
            target's field set.
        expected_prior: The standing values the host expects the named
            fields to have, or ``None`` for no check.
        reason: Why the correction was filed, non-empty and in
            ``normalize_text`` form, at most ``NARRATIVE_CLAMP_BYTES``
            serialized bytes.
        provenance: Where the correction came from, for example
            ``"operator"``, as bounded printable text.
        actor: Who filed it, as bounded printable text, or ``None``. It is
            attribution, never authorization.
        recorded_at: When the correction was recorded, aware UTC.
    """

    SCHEMA_ID: ClassVar[str] = "rae.correction"
    SCHEMA_VERSION: ClassVar[int] = 1

    correction_id: str
    target: RecordRef
    sequence: int
    fields: CorrectionFields
    expected_prior: CorrectionFields | None = None
    reason: str
    provenance: str
    actor: str | None = None
    recorded_at: datetime

    def __post_init__(self) -> None:
        """Validate every field, the couplings, and the derived id.

        Raises:
            RecordValidationError: If any field is invalid or inconsistent.
        """
        schema_id = Correction.SCHEMA_ID
        _require_exact_type(self.correction_id, str, schema_id, "correction_id")
        _require_exact_type(self.target, RecordRef, schema_id, "target")
        _require_sequence(self.sequence, schema_id, "sequence")
        _require_exact_type(self.fields, CorrectionFields, schema_id, "fields")
        if self.expected_prior is not None:
            _require_exact_type(
                self.expected_prior, CorrectionFields, schema_id, "expected_prior"
            )
            prior = set(self.expected_prior.named)
            if not prior or not prior <= TARGET_FIELDS[self.target.schema_id]:
                raise RecordValidationError(
                    schema_id,
                    "expected_prior",
                    "must name at least one field, all in the target's field set",
                )
        _require_couplings(self)
        _require_narrative_text(self.reason, schema_id, "reason")
        _require_bounded_identifier(self.provenance, schema_id, "provenance")
        if self.actor is not None:
            _require_bounded_identifier(self.actor, schema_id, "actor")
        _require_utc(self.recorded_at, schema_id, "recorded_at")
        if self.correction_id != correction_id(self.target, self.sequence):
            raise RecordValidationError(
                schema_id,
                "correction_id",
                "must equal f'{target.record_id}:c{sequence}'",
            )


def build_correction(
    target: RecordRef,
    sequence: int,
    fields: CorrectionFields,
    *,
    reason: str,
    provenance: str,
    clock: Clock,
    actor: str | None = None,
    expected_prior: CorrectionFields | None = None,
) -> Correction:
    """Build a correction with its derived id and an injected timestamp.

    Args:
        target: The record to correct.
        sequence: The host's count for the target (D-10).
        fields: The replacement values. An omitted ``value_low`` or
            ``value_high`` is filled with ``value``, as Hermes
            ``correct-assessment.sh`` defaults them (L256-L259).
        reason: Why the correction is filed. It is normalized and clamped
            with ``normalize_text`` to ``NARRATIVE_CLAMP_BYTES``.
        provenance: Where the correction came from.
        clock: The source of ``recorded_at``.
        actor: Who filed the correction, if known.
        expected_prior: The standing values the host expects, if any.

    Returns:
        The validated correction.

    Raises:
        ConfigurationError: If the clock returns a naive or non-UTC value.
            The message names the field, never the value.
        RecordValidationError: If the correction is invalid.
    """
    schema_id = Correction.SCHEMA_ID
    _require_exact_type(fields, CorrectionFields, schema_id, "fields")
    if fields.value is not None:
        fields = dataclasses.replace(
            fields,
            value_low=fields.value if fields.value_low is None else fields.value_low,
            value_high=(
                fields.value if fields.value_high is None else fields.value_high
            ),
        )
    return Correction(
        correction_id=correction_id(target, sequence),
        target=target,
        sequence=sequence,
        fields=fields,
        expected_prior=expected_prior,
        reason=normalize_text(reason, max_bytes=NARRATIVE_CLAMP_BYTES),
        provenance=provenance,
        actor=actor,
        recorded_at=_checked_now(clock, "recorded_at"),
    )


class CorrectionRejectionReason(enum.Enum):
    """Why the fold did not apply a correction (ADR 0031 decision 4).

    Checked in member order; the first that fails is the one recorded.
    """

    DUPLICATE_ID_CONFLICT = "duplicate_id_conflict"
    STALE_EXPECTED_PRIOR = "stale_expected_prior"
    CURRENCY_CONFLICTS_WITH_COSTS = "currency_conflicts_with_costs"
    WINDOW_DISORDERED = "window_disordered"


@dataclass(frozen=True, slots=True, kw_only=True)
class CorrectionRejection:
    """A correction the fold refused, and why (ADR 0031 decision 1).

    Attributes:
        correction_id: The refused correction's id.
        reason: Why it was refused.
        field: The field the rejection is about, or ``None``.
        expected: A bounded rendering of the expected value, or ``None``.
        actual: A bounded rendering of the standing value, or ``None``.
    """

    SCHEMA_ID: ClassVar[str] = "rae.correction_rejection"
    SCHEMA_VERSION: ClassVar[int] = 1

    correction_id: str
    reason: CorrectionRejectionReason
    field: CorrectableField | None = None
    expected: str | None = None
    actual: str | None = None

    def __post_init__(self) -> None:
        """Validate every field.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = CorrectionRejection.SCHEMA_ID
        _require_text(self.correction_id, schema_id, "correction_id")
        if serialized_byte_length(self.correction_id) > CORRECTION_ID_MAX_BYTES:
            raise RecordValidationError(
                schema_id,
                "correction_id",
                f"must be at most {CORRECTION_ID_MAX_BYTES} serialized bytes",
            )
        _require_exact_type(self.reason, CorrectionRejectionReason, schema_id, "reason")
        if self.field is not None:
            _require_exact_type(self.field, CorrectableField, schema_id, "field")
        for name in ("expected", "actual"):
            if getattr(self, name) is not None:
                _require_normalized(
                    getattr(self, name), schema_id, name, NARRATIVE_CLAMP_BYTES
                )


def _require_field_sources(
    value: object, applied: tuple[str, ...], schema_id: str
) -> None:
    _require_exact_type(value, tuple, schema_id, "field_sources")
    positions: list[int] = []
    for index, item in enumerate(value if isinstance(value, tuple) else ()):
        if (
            type(item) is not tuple
            or len(item) != _PAIR_LENGTH
            or type(item[0]) is not CorrectableField
            or type(item[1]) is not str
        ):
            raise RecordValidationError(
                schema_id,
                "field_sources",
                f"element {index} must be a (CorrectableField, str) pair",
            )
        if item[1] not in applied:
            raise RecordValidationError(
                schema_id, "field_sources", "must name applied corrections"
            )
        positions.append(_FIELD_ORDER.index(item[0]))
    if positions != sorted(set(positions)):
        raise RecordValidationError(
            schema_id, "field_sources", "must be unique and in CorrectableField order"
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class EffectiveAssessment:
    """A record and its corrections, resolved field by field (ADR 0031).

    The original and every correction are kept unchanged. The effective
    identity and evidence class are always the original's, and the view is
    never more reportable than the original (D-08, D-09). Outcome-metric
    intents are built only from this record (D-16). Construction re-runs the
    fold, so a constructed or decoded view must equal
    ``resolve_effective(original, corrections)`` in every field except
    ``library_version`` (ADR 0031, CR-01 addendum).

    Attributes:
        original: The corrected record, untouched.
        corrections: Every distinct input correction,
            in fold order (sequence, recorded_at, correction_id).
        applied: The applied correction ids, in fold order.
        superseded: Applied ids none of whose field values survive.
        rejected: The corrections the fold refused.
        field_sources: Each corrected field with the id of the correction
            whose value stands, in ``CorrectableField`` order.
        assessment_id: The original's assessment id.
        job_id: The original's job id.
        double_counting_group: The original's group.
        job_type: The effective job type.
        job_started_at: The effective job start.
        job_ended_at: The effective job end.
        execution_status: The effective outcome.
        economic_mechanism: The effective mechanism's value text.
        value_low: The effective band's low end. Set exactly when VALUED.
        value_high: The effective band's high end. Set exactly when VALUED.
        roi: The effective value, costs, coverage, and net value. The
            effective value is ``roi.value``.
        attribution_fraction: The effective attribution fraction, or ``None``.
        attribution_basis: The effective attribution basis, or ``None``.
        confidence: The original's confidence, or ``None`` on an abstention.
            Never correctable.
        hours_saved: The original's ``assumptions.estimated_hours_saved``, or
            ``None`` on an abstention. Never correctable.
        evidence_class: The original's evidence class.
        evidence_class_authority: The original's evidence authority.
        reportability: The original's status, or narrower.
        reportability_reason: The rule that decided ``reportability``.
        library_version: The library version that resolved the view.
    """

    SCHEMA_ID: ClassVar[str] = "rae.effective_assessment"
    SCHEMA_VERSION: ClassVar[int] = 1

    original: JobAssessment | AssessmentAbstention
    corrections: tuple[Correction, ...]
    applied: tuple[str, ...]
    superseded: tuple[str, ...]
    rejected: tuple[CorrectionRejection, ...]
    field_sources: tuple[tuple[CorrectableField, str], ...]
    assessment_id: str
    job_id: str
    double_counting_group: str | None = None
    job_type: str
    job_started_at: datetime
    job_ended_at: datetime
    execution_status: JobOutcome
    economic_mechanism: str
    value_low: Decimal | None = None
    value_high: Decimal | None = None
    roi: RoiOperands
    attribution_fraction: Decimal | None = None
    attribution_basis: str | None = None
    confidence: Confidence | None = None
    hours_saved: Decimal | None = None
    evidence_class: EvidenceClass
    evidence_class_authority: EvidenceAuthority
    reportability: ReportabilityStatus
    reportability_reason: ReportabilityReason
    library_version: str

    def __post_init__(self) -> None:
        """Validate the view, then check that it is its own fold.

        The history, identity, evidence, field, money, and reportability
        checks run first. The fold of ``original`` and ``corrections`` is then
        re-run and compared by canonical text with every other field except
        ``library_version`` (ADR 0031, CR-01 addendum).

        Raises:
            RecordValidationError: If any field is invalid or inconsistent;
                naming ``corrections`` when they are not the distinct inputs
                in fold order; or naming the first field, in declaration
                order, that differs from
                ``resolve_effective(original, corrections)``.
        """
        schema_id = EffectiveAssessment.SCHEMA_ID
        original = self.original
        if type(original) is not JobAssessment and (
            type(original) is not AssessmentAbstention
        ):
            raise RecordValidationError(
                schema_id,
                "original",
                "JobAssessment or AssessmentAbstention required, got "
                f"{type(original).__name__}",
            )
        _require_history(self)
        _require_carried_from_original(self)
        _require_effective_fields(self)
        _require_effective_money(self)
        _require_effective_reportability(self)
        _require_folded(self)


def _target_refs(record: JobAssessment | AssessmentAbstention) -> tuple[RecordRef, ...]:
    return (
        RecordRef(schema_id=_ASSESSMENT_REF, record_id=record.assessment_id),
        RecordRef(schema_id=_CANDIDATE_REF, record_id=record.job_id),
    )


def _require_history(view: EffectiveAssessment) -> None:
    schema_id = EffectiveAssessment.SCHEMA_ID
    _require_tuple_of(view.corrections, Correction, schema_id, "corrections")
    _require_tuple_of(view.applied, str, schema_id, "applied")
    _require_tuple_of(view.superseded, str, schema_id, "superseded")
    _require_tuple_of(view.rejected, CorrectionRejection, schema_id, "rejected")
    _require_field_sources(view.field_sources, view.applied, schema_id)
    targets = _target_refs(view.original)
    if any(correction.target not in targets for correction in view.corrections):
        raise RecordValidationError(
            schema_id, "corrections", "every correction must target the original"
        )
    inputs = {correction.correction_id for correction in view.corrections}
    applied = set(view.applied)
    rejected = {rejection.correction_id for rejection in view.rejected}
    if len(applied) != len(view.applied):
        raise RecordValidationError(schema_id, "applied", "ids must be unique")
    if applied & rejected or applied | rejected != inputs:
        raise RecordValidationError(
            schema_id,
            "applied",
            "every correction id is in exactly one of applied and rejected",
        )
    standing = {correction_id for _, correction_id in view.field_sources}
    if view.superseded != tuple(i for i in view.applied if i not in standing):
        raise RecordValidationError(
            schema_id,
            "superseded",
            "must be the applied ids with no standing field value, in fold order",
        )


def _require_carried_from_original(view: EffectiveAssessment) -> None:
    schema_id = EffectiveAssessment.SCHEMA_ID
    original = view.original
    for name in (
        "assessment_id",
        "job_id",
        "double_counting_group",
        "evidence_class",
        "evidence_class_authority",
    ):
        if getattr(view, name) != getattr(original, name):
            raise RecordValidationError(schema_id, name, "must equal the original's")
    confidence = original.confidence if type(original) is JobAssessment else None
    hours = (
        original.assumptions.estimated_hours_saved
        if type(original) is JobAssessment
        else None
    )
    if view.confidence != confidence:
        raise RecordValidationError(
            schema_id, "confidence", "must be the original's, never corrected"
        )
    if view.hours_saved != hours or (
        hours is not None and type(view.hours_saved) is not Decimal
    ):
        raise RecordValidationError(
            schema_id, "hours_saved", "must be the original's, never corrected"
        )


def _require_effective_fields(view: EffectiveAssessment) -> None:
    schema_id = EffectiveAssessment.SCHEMA_ID
    _require_exact_type(view.job_type, str, schema_id, "job_type")
    if not is_valid_label(view.job_type):
        raise RecordValidationError(schema_id, "job_type", "fails the label grammar")
    _require_utc(view.job_started_at, schema_id, "job_started_at")
    _require_utc(view.job_ended_at, schema_id, "job_ended_at")
    if view.job_started_at > view.job_ended_at:
        raise RecordValidationError(
            schema_id, "job_ended_at", "must not be before job_started_at"
        )
    _require_exact_type(
        view.execution_status, JobOutcome, schema_id, "execution_status"
    )
    _require_exact_type(view.economic_mechanism, str, schema_id, "economic_mechanism")
    if view.economic_mechanism not in _MECHANISM_VALUES and (
        view.economic_mechanism != ECONOMIC_MECHANISM_UNKNOWN
    ):
        raise RecordValidationError(
            schema_id,
            "economic_mechanism",
            "must be a mechanism value or 'unknown'",
        )
    _require_text(view.library_version, schema_id, "library_version")


def _require_effective_money(view: EffectiveAssessment) -> None:
    # ADR 0031 decision 8 and ADR 0030 addendum item 8, on every VALUED view.
    schema_id = EffectiveAssessment.SCHEMA_ID
    roi = view.roi
    _require_exact_type(roi, RoiOperands, schema_id, "roi")
    valued = roi.value_state is ValueSideState.VALUED
    if view.execution_status is not JobOutcome.SUCCESS and (
        roi.value_state is not ValueSideState.ZERO_NOT_COMPLETED
    ):
        raise RecordValidationError(
            schema_id, "roi", "a non-SUCCESS view is zero_not_completed"
        )
    for name in ("value_low", "value_high"):
        if (getattr(view, name) is not None) != valued:
            raise RecordValidationError(
                schema_id, name, "is present exactly when the view is valued"
            )
    fraction = view.attribution_fraction
    basis = view.attribution_basis
    if (fraction is None) != (basis is None) or (fraction is not None and not valued):
        raise RecordValidationError(
            schema_id,
            "attribution_fraction",
            "the attribution pair is set together, and only on a valued view",
        )
    if fraction is not None:
        _require_exact_type(fraction, Decimal, schema_id, "attribution_fraction")
        if not fraction.is_finite() or not Decimal(0) <= fraction <= Decimal(1):
            raise RecordValidationError(
                schema_id, "attribution_fraction", "must be finite and in [0, 1]"
            )
        _require_narrative_text(basis, schema_id, "attribution_basis")
    value = roi.value
    if not valued or value is None:
        return
    for name, amount in (
        ("roi", value.amount),
        ("value_low", view.value_low),
        ("value_high", view.value_high),
    ):
        _require_money_value(amount, schema_id, name)
        quantized = _quantized(amount, value.currency) if amount is not None else None
        if quantized is None or quantized.amount != amount:
            raise RecordValidationError(
                schema_id, name, "must be quantized to the currency minor unit"
            )
    low = view.value_low
    high = view.value_high
    if low is None or high is None or not low <= value.amount <= high:
        raise RecordValidationError(
            schema_id, "value_low", "must satisfy value_low <= value <= value_high"
        )


def _require_effective_reportability(view: EffectiveAssessment) -> None:
    schema_id = EffectiveAssessment.SCHEMA_ID
    _require_exact_type(
        view.reportability, ReportabilityStatus, schema_id, "reportability"
    )
    _require_exact_type(
        view.reportability_reason,
        ReportabilityReason,
        schema_id,
        "reportability_reason",
    )
    if view.execution_status is not JobOutcome.SUCCESS and (
        view.reportability is not ReportabilityStatus.UNCOMPUTED
        or view.reportability_reason is not ReportabilityReason.ABSTAINED
    ):
        raise RecordValidationError(
            schema_id,
            "reportability",
            "a non-SUCCESS view is uncomputed for abstained",
        )
    if view.reportability is ReportabilityStatus.REPORTABLE and (
        view.original.reportability is not ReportabilityStatus.REPORTABLE
        or view.roi.value_state is not ValueSideState.VALUED
    ):
        raise RecordValidationError(
            schema_id,
            "reportability",
            "a view is reportable only when the original is, and only valued",
        )


def _standing_from(record: JobAssessment | AssessmentAbstention) -> CorrectionFields:
    # The original's value for every correctable field, the fold's start.
    standing = CorrectionFields(
        job_type=record.job_type,
        job_started_at=record.job_started_at,
        job_ended_at=record.job_ended_at,
        execution_status=record.execution_status,
        currency=record.roi.costs.currency,
        economic_mechanism=record.economic_mechanism,
    )
    if type(record) is not JobAssessment:
        return standing
    return dataclasses.replace(
        standing,
        value=record.value_base,
        value_low=record.value_low,
        value_high=record.value_high,
        attribution_fraction=record.attribution_fraction,
        attribution_basis=record.attribution_basis,
    )


@dataclass(frozen=True, slots=True, kw_only=True)
class _ValueSide:
    roi: RoiOperands
    value_low: Decimal | None = None
    value_high: Decimal | None = None
    attribution_fraction: Decimal | None = None
    attribution_basis: str | None = None
    reportability: ReportabilityStatus
    reportability_reason: ReportabilityReason


def _costs_are_empty(roi: RoiOperands) -> bool:
    # A6: every supplied cost is unknown and no metered AI cost is carried.
    return roi.metered_ai_cost is None and all(
        roi.costs.amount(category) is None for category in COST_CATEGORIES
    )


def _effective_costs(roi: RoiOperands, standing: CorrectionFields) -> SuppliedCosts:
    # A6: an applied currency correction that differs from the costs
    # currency is only ever folded over empty costs, which it re-denominates.
    currency = standing.currency
    if currency is None or currency is roi.costs.currency:
        return roi.costs
    return empty_supplied_costs(currency)


def _value_side(
    record: JobAssessment | AssessmentAbstention,
    standing: CorrectionFields,
    corrected: frozenset[CorrectableField],
) -> _ValueSide:
    # ADR 0031 decisions 6 and 8. The costs, coverage, and metered AI cost
    # are the original's, re-denominated only under A6.
    costs = _effective_costs(record.roi, standing)
    coverage = (
        record.roi.coverage if costs == record.roi.costs else cost_coverage(costs)
    )
    if standing.execution_status is not JobOutcome.SUCCESS:
        return _ValueSide(
            roi=RoiOperands(
                value_state=ValueSideState.ZERO_NOT_COMPLETED,
                costs=costs,
                coverage=coverage,
                metered_ai_cost=record.roi.metered_ai_cost,
            ),
            reportability=ReportabilityStatus.UNCOMPUTED,
            reportability_reason=ReportabilityReason.ABSTAINED,
        )
    if standing.value is None or standing.currency is None:
        roi = record.roi
        if roi.value_state is not ValueSideState.UNCOMPUTED or roi.costs != costs:
            roi = RoiOperands(
                value_state=ValueSideState.UNCOMPUTED,
                costs=costs,
                coverage=coverage,
                metered_ai_cost=roi.metered_ai_cost,
            )
        return _ValueSide(
            roi=roi,
            reportability=record.reportability,
            reportability_reason=record.reportability_reason,
        )
    if type(record) is JobAssessment:
        # A reportable original stays reportable under value corrections: the
        # pure fold cannot re-run the evidence decider (ADR 0031 decision 6).
        reportability = record.reportability
        reason = record.reportability_reason
    else:
        # A7: an operator's value on an abstention is never reportable.
        reportability = ReportabilityStatus.COMPUTED_NOT_REPORTABLE
        reason = record.reportability_reason
    currency = standing.currency
    amount = _quantized_amount(standing.value, currency)
    low = standing.value_low
    high = standing.value_high
    if type(record) is JobAssessment and not corrected & _VALUE_SIDE_FIELDS:
        roi = record.roi
    else:
        roi = RoiOperands(
            value_state=ValueSideState.VALUED,
            value=Money(amount=amount, currency=currency),
            value_basis=ClaimBasis.CORRECTED,
            costs=costs,
            coverage=coverage,
            metered_ai_cost=record.roi.metered_ai_cost,
            net_value=Money(
                amount=net_value(amount, costs, currency), currency=currency
            ),
        )
    return _ValueSide(
        roi=roi,
        value_low=amount if low is None else _quantized_amount(low, currency),
        value_high=amount if high is None else _quantized_amount(high, currency),
        attribution_fraction=standing.attribution_fraction,
        attribution_basis=standing.attribution_basis,
        reportability=reportability,
        reportability_reason=reason,
    )


def _text(value: object) -> str:
    # The canonical text form of one field value, as the codec writes it.
    # Every value reaching here passed CorrectionFields or record validation,
    # so the canonical formatters cannot raise.
    if type(value) is Decimal:
        return format_decimal(value)
    if type(value) is datetime:
        return format_utc_timestamp(value)
    if isinstance(value, enum.Enum):
        return str(value.value)
    return str(value)


def _rendering(value: object) -> str:
    # A bounded rendering for CorrectionRejection.expected and .actual.
    return normalize_text(_text(value), max_bytes=NARRATIVE_CLAMP_BYTES)


def _fields_key(fields: CorrectionFields | None) -> tuple[str, ...]:
    # "" marks an absent value and "=" prefixes a present one, so the key is
    # injective over the canonical text of every attribute.
    if fields is None:
        return ("",)
    return (
        "=",
        *(
            ""
            if getattr(fields, field.value) is None
            else "=" + _text(getattr(fields, field.value))
            for field in _FIELD_ORDER
        ),
    )


def _content_key(correction: Correction) -> tuple[tuple[str, ...], ...]:
    # The canonical content of a correction. Two corrections with one key
    # encode to the same bytes, so collapsing them loses nothing.
    return (
        (
            correction.correction_id,
            correction.target.schema_id,
            correction.target.record_id,
            str(correction.sequence),
        ),
        _fields_key(correction.fields),
        _fields_key(correction.expected_prior),
        (
            correction.reason,
            correction.provenance,
            "" if correction.actor is None else "=" + correction.actor,
            format_utc_timestamp(correction.recorded_at),
        ),
    )


def _order_key(
    correction: Correction,
) -> tuple[int, datetime, str, tuple[tuple[str, ...], ...]]:
    # ADR 0031 decision 4: (sequence, recorded_at, correction_id). The
    # content key only orders records that share one correction id, which
    # all reject as DUPLICATE_ID_CONFLICT, so it never changes what applies.
    return (
        correction.sequence,
        correction.recorded_at,
        correction.correction_id,
        _content_key(correction),
    )


def _stale(
    correction: Correction, standing: CorrectionFields
) -> CorrectionRejection | None:
    # A1: compare each expected field value with the standing value, in
    # CorrectableField order. A standing None never equals an expectation.
    prior = correction.expected_prior
    if prior is None:
        return None
    for field in prior.named:
        expected = getattr(prior, field.value)
        actual = getattr(standing, field.value)
        if actual is None or expected != actual:
            return CorrectionRejection(
                correction_id=correction.correction_id,
                reason=CorrectionRejectionReason.STALE_EXPECTED_PRIOR,
                field=field,
                expected=_rendering(expected),
                actual=None if actual is None else _rendering(actual),
            )
    return None


def _currency_conflict(
    correction: Correction, roi: RoiOperands
) -> CorrectionRejection | None:
    # A6 (ADR 0031 decision 8): a currency other than the costs currency is
    # accepted only over empty costs with no metered AI cost.
    currency = correction.fields.currency
    costs_currency = roi.costs.currency
    if currency is None or currency is costs_currency or _costs_are_empty(roi):
        return None
    return CorrectionRejection(
        correction_id=correction.correction_id,
        reason=CorrectionRejectionReason.CURRENCY_CONFLICTS_WITH_COSTS,
        field=CorrectableField.CURRENCY,
        expected=_rendering(currency),
        actual=_rendering(costs_currency),
    )


def _window_disordered(
    correction: Correction, standing: CorrectionFields
) -> CorrectionRejection | None:
    # A correction naming both ends is ordered at construction, so a
    # disordered result always comes from the one end it names.
    fields = correction.fields
    started = (
        standing.job_started_at
        if fields.job_started_at is None
        else fields.job_started_at
    )
    ended = (
        standing.job_ended_at if fields.job_ended_at is None else fields.job_ended_at
    )
    if started is None or ended is None or started <= ended:
        return None
    return CorrectionRejection(
        correction_id=correction.correction_id,
        reason=CorrectionRejectionReason.WINDOW_DISORDERED,
        field=(
            CorrectableField.JOB_STARTED_AT
            if fields.job_started_at is not None
            else CorrectableField.JOB_ENDED_AT
        ),
    )


def _rejection(
    correction: Correction,
    conflicting: bool,
    standing: CorrectionFields,
    roi: RoiOperands,
) -> CorrectionRejection | None:
    # ADR 0031 decision 4: the checks run in CorrectionRejectionReason order,
    # and the first that fails is the one rejection recorded.
    if conflicting:
        return CorrectionRejection(
            correction_id=correction.correction_id,
            reason=CorrectionRejectionReason.DUPLICATE_ID_CONFLICT,
        )
    stale = _stale(correction, standing)
    if stale is not None:
        return stale
    currency = _currency_conflict(correction, roi)
    if currency is not None:
        return currency
    return _window_disordered(correction, standing)


@dataclass(frozen=True, slots=True, kw_only=True)
class _Folded:
    # Every EffectiveAssessment field except original and library_version, in
    # declaration order: the fold's result before it becomes a view.
    corrections: tuple[Correction, ...]
    applied: tuple[str, ...]
    superseded: tuple[str, ...]
    rejected: tuple[CorrectionRejection, ...]
    field_sources: tuple[tuple[CorrectableField, str], ...]
    assessment_id: str
    job_id: str
    double_counting_group: str | None = None
    job_type: str
    job_started_at: datetime
    job_ended_at: datetime
    execution_status: JobOutcome
    economic_mechanism: str
    value_low: Decimal | None = None
    value_high: Decimal | None = None
    roi: RoiOperands
    attribution_fraction: Decimal | None = None
    attribution_basis: str | None = None
    confidence: Confidence | None = None
    hours_saved: Decimal | None = None
    evidence_class: EvidenceClass
    evidence_class_authority: EvidenceAuthority
    reportability: ReportabilityStatus
    reportability_reason: ReportabilityReason


def _fold(
    record: JobAssessment | AssessmentAbstention,
    corrections: tuple[Correction, ...],
) -> _Folded:
    # The one fold body (ADR 0031 decision 4), shared by resolve_effective and
    # EffectiveAssessment.__post_init__. The caller has already checked the
    # record type, the corrections container, and every target. It never
    # constructs an EffectiveAssessment, so it cannot recurse.
    schema_id = EffectiveAssessment.SCHEMA_ID
    # Identical records (equal canonical content) collapse to one; the rest
    # are kept, in fold order, so the view does not depend on input order.
    unique: dict[tuple[tuple[str, ...], ...], Correction] = {}
    for correction in corrections:
        unique.setdefault(_content_key(correction), correction)
    ordered = tuple(sorted(unique.values(), key=_order_key))
    id_counts: dict[str, int] = {}
    for correction in ordered:
        id_counts[correction.correction_id] = (
            id_counts.get(correction.correction_id, 0) + 1
        )
    standing = _standing_from(record)
    sources: dict[CorrectableField, str] = {}
    applied_ids: list[str] = []
    rejections: list[CorrectionRejection] = []
    for correction in ordered:
        rejection = _rejection(
            correction, id_counts[correction.correction_id] > 1, standing, record.roi
        )
        if rejection is not None:
            rejections.append(rejection)
            continue
        named = correction.fields.named
        standing = dataclasses.replace(
            standing,
            **{field.value: getattr(correction.fields, field.value) for field in named},
        )
        for field in named:
            sources[field] = correction.correction_id
        applied_ids.append(correction.correction_id)
    applied = tuple(applied_ids)
    field_sources = tuple(
        (field, sources[field]) for field in _FIELD_ORDER if field in sources
    )
    surviving = set(sources.values())
    side = _value_side(record, standing, frozenset(sources))
    job_type = standing.job_type
    started = standing.job_started_at
    ended = standing.job_ended_at
    status = standing.execution_status
    mechanism = standing.economic_mechanism
    if (
        job_type is None
        or started is None
        or ended is None
        or status is None
        or (mechanism is None)
    ):  # pragma: no cover - the standing values start from a validated record
        raise RecordValidationError(schema_id, "original", "has a missing field")
    return _Folded(
        corrections=ordered,
        applied=applied,
        superseded=tuple(i for i in applied if i not in surviving),
        rejected=tuple(rejections),
        field_sources=field_sources,
        assessment_id=record.assessment_id,
        job_id=record.job_id,
        double_counting_group=record.double_counting_group,
        job_type=job_type,
        job_started_at=started,
        job_ended_at=ended,
        execution_status=status,
        economic_mechanism=mechanism,
        value_low=side.value_low,
        value_high=side.value_high,
        roi=side.roi,
        attribution_fraction=side.attribution_fraction,
        attribution_basis=side.attribution_basis,
        confidence=record.confidence if type(record) is JobAssessment else None,
        hours_saved=(
            record.assumptions.estimated_hours_saved
            if type(record) is JobAssessment
            else None
        ),
        evidence_class=record.evidence_class,
        evidence_class_authority=record.evidence_class_authority,
        reportability=side.reportability,
        reportability_reason=side.reportability_reason,
    )


def _canonical_form(value: object) -> object:
    # The comparison form of one field value, by canonical text (ADR 0031,
    # CR-01 addendum item 2): Decimal("0.5") and Decimal("0.50") differ. It
    # runs only after the view's validators, so the formatters never meet a
    # non-finite Decimal or a naive datetime.
    if isinstance(value, Decimal):
        return ("Decimal", format_decimal(value))
    if isinstance(value, datetime):
        return ("datetime", format_utc_timestamp(value))
    if isinstance(value, enum.Enum):
        return (type(value).__name__, value.value)
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return (
            type(value).__name__,
            tuple(
                (field.name, _canonical_form(getattr(value, field.name)))
                for field in dataclasses.fields(value)
            ),
        )
    if isinstance(value, tuple):
        return ("tuple", tuple(_canonical_form(item) for item in value))
    return (type(value).__name__, value)


def _require_folded(view: EffectiveAssessment) -> None:
    # ADR 0031 CR-01 addendum and ADR 0036 decision 1: a view is exactly the
    # fold of its original and corrections, so no constructor or decoder path
    # can carry uncorrected, stale, or forged derived state to the metrics
    # builder. Nothing is repaired: a mismatch raises.
    schema_id = EffectiveAssessment.SCHEMA_ID
    folded = _fold(view.original, view.corrections)
    if tuple(_content_key(item) for item in view.corrections) != tuple(
        _content_key(item) for item in folded.corrections
    ):
        raise RecordValidationError(
            schema_id,
            "corrections",
            "must be the distinct inputs in fold order (sequence, recorded_at, "
            "correction_id), as resolve_effective(original, corrections) "
            "orders them",
        )
    for field in dataclasses.fields(folded)[1:]:
        if _canonical_form(getattr(view, field.name)) != _canonical_form(
            getattr(folded, field.name)
        ):
            raise RecordValidationError(
                schema_id,
                field.name,
                "must equal resolve_effective(original, corrections)",
            )


def resolve_effective(
    record: JobAssessment | AssessmentAbstention,
    corrections: tuple[Correction, ...],
) -> EffectiveAssessment:
    """Fold a record and its corrections into the effective view (D-06).

    Corrections are ordered by ``(sequence, recorded_at, correction_id)``,
    so the result does not depend on the input order. An identical duplicate
    folds once, and records that share one id with different content are
    each rejected as DUPLICATE_ID_CONFLICT. Each applied correction sets the
    fields it names and every other field keeps its standing value (per-field
    last writer wins), which carries Hermes' ``prior_value_*`` forward
    without a promotion step (CORR-04).

    - A correction whose ``expected_prior`` names a field whose standing
      value differs, or is None, is rejected as STALE_EXPECTED_PRIOR and not
      applied (A1). Every rejection is kept in ``rejected``, and every
      distinct input in ``corrections``, in fold order (CORR-03).
    - A currency other than the costs currency is rejected as
      CURRENCY_CONFLICTS_WITH_COSTS unless every supplied cost and the
      metered AI cost are None, when the empty costs are re-denominated
      (A6). A job end before the standing start, or a start after the
      standing end, is rejected as WINDOW_DISORDERED.
    - Identity, evidence class, confidence, and hours saved are copied from
      the original (D-09, CORR-02). A candidate-target correction changes
      only the effective job type and window.
    - A value, currency, mechanism, or attribution correction rebuilds the
      ROI operands with ``ClaimBasis.CORRECTED``, the original costs, and
      ``net_value`` recomputed through ``costs.net_value`` (D-11). A
      mechanism change to ``newly_enabled_work`` keeps the value (A11).
    - A non-SUCCESS effective status gives ZERO_NOT_COMPLETED, keeps the
      costs, and is UNCOMPUTED for ABSTAINED. Otherwise the original's
      reportability is carried, so the view is never wider (D-08). A value
      on an abstention is COMPUTED_NOT_REPORTABLE for ABSTAINED (A7).

    Args:
        record: The original assessment or abstention.
        corrections: The corrections filed against it or its candidate.

    Returns:
        The effective view, holding the original and every correction. The
        view re-validates against the fold on construction, so it can be
        stored and decoded (ADR 0031, CR-01 addendum).

    Raises:
        RecordValidationError: If ``record`` is not exactly a
            ``JobAssessment`` or ``AssessmentAbstention``, an element of
            ``corrections`` is not exactly a ``Correction``, a correction's
            target names neither the record's assessment nor its candidate
            (ADR 0031 decision 9), or ``corrections`` is not a tuple (ADR
            0031 addendum item 5).
    """
    schema_id = EffectiveAssessment.SCHEMA_ID
    if type(record) is not JobAssessment and type(record) is not AssessmentAbstention:
        raise RecordValidationError(
            schema_id,
            "original",
            "JobAssessment or AssessmentAbstention required, got "
            f"{type(record).__name__}",
        )
    _require_tuple_of(corrections, Correction, schema_id, "corrections")
    targets = _target_refs(record)
    if any(correction.target not in targets for correction in corrections):
        raise RecordValidationError(
            schema_id,
            "corrections",
            "a correction targets neither this assessment nor its candidate",
        )
    folded = _fold(record, corrections)
    return EffectiveAssessment(
        original=record,
        corrections=folded.corrections,
        applied=folded.applied,
        superseded=folded.superseded,
        rejected=folded.rejected,
        field_sources=folded.field_sources,
        assessment_id=folded.assessment_id,
        job_id=folded.job_id,
        double_counting_group=folded.double_counting_group,
        job_type=folded.job_type,
        job_started_at=folded.job_started_at,
        job_ended_at=folded.job_ended_at,
        execution_status=folded.execution_status,
        economic_mechanism=folded.economic_mechanism,
        value_low=folded.value_low,
        value_high=folded.value_high,
        roi=folded.roi,
        attribution_fraction=folded.attribution_fraction,
        attribution_basis=folded.attribution_basis,
        confidence=folded.confidence,
        hours_saved=folded.hours_saved,
        evidence_class=folded.evidence_class,
        evidence_class_authority=folded.evidence_class_authority,
        reportability=folded.reportability,
        reportability_reason=folded.reportability_reason,
        library_version=__version__,
    )
