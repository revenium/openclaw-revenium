"""The normalized activity envelope every host adapter emits (ADR 0015).

This module holds the envelope's enums, each with an explicit ``UNKNOWN`` where
ADR 0015 gives one (D-04), the members of the closed payload union (D-05),
:class:`ActivityIdentity`, :class:`ActivityEvent`, :class:`ActivityLog`, and
:func:`derive_dedupe_key` (D-06). ``streams.normalize_stream`` builds the log,
because the dedupe winner is defined on codec bytes (ADR 0016).

Frozen: the project owner selected option-a at the 03-01 checkpoint, so
``rae.activity_event`` schema version 1, its nested records (including every
payload member such as :class:`TextExcerpt`), and the dedupe-key definition are
frozen. From 0.1.0 on, a change to any field's name, type, bound, or meaning
needs a schema version bump and a registered migration (ADR 0003).

The module is pure: it reads no transcript and emits no diagnostics. A host
chooses the text and its cut; the record carries measurements of the original.
Caller identifiers are rejected, never clamped.
"""

import enum
import hashlib
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import ClassVar, Final, TypeAlias

from revenium_agent_economics._bounded import (
    HOST_NAME_MAX_BYTES,
    IDENTIFIER_MAX_BYTES,
    NARRATIVE_CLAMP_BYTES,
    is_bounded_printable,
    serialized_byte_length,
)
from revenium_agent_economics._canonical import (
    JsonValue,
    canonical_json,
    format_utc_timestamp,
)
from revenium_agent_economics.errors import ConfigurationError, RecordValidationError
from revenium_agent_economics.primitives import Money, _require_exact_type

# ADR 0015 decision 3: host-reported names in payloads (tool, model, reason).
_PAYLOAD_NAME_MAX_BYTES: Final = 64
# ADR 0015 decision 1: namespaced, lowercase attribute keys.
_ATTRIBUTE_KEY: Final = re.compile(r"[a-z0-9_]+(?:\.[a-z0-9_]+)+", re.ASCII)
_ATTRIBUTE_KEY_MAX_BYTES: Final = 64


class ActivityKind(enum.Enum):
    """What happened in a normalized activity event (ADR 0015 decision 2)."""

    SESSION_STARTED = "session_started"
    SESSION_ENDED = "session_ended"
    PROMPT_SUBMITTED = "prompt_submitted"
    TURN_STOPPED = "turn_stopped"
    TURN_FAILED = "turn_failed"
    TOOL_CALL_STARTED = "tool_call_started"
    TOOL_CALL_SUCCEEDED = "tool_call_succeeded"
    TOOL_CALL_FAILED = "tool_call_failed"
    DELEGATION_STARTED = "delegation_started"
    DELEGATION_STOPPED = "delegation_stopped"
    TASK_CREATED = "task_created"
    TASK_COMPLETION_ATTEMPTED = "task_completion_attempted"
    COMPACTION_STARTED = "compaction_started"
    COMPACTION_COMPLETED = "compaction_completed"
    USAGE_REPORTED = "usage_reported"
    HOST_OTHER = "host_other"


class SessionOrigin(enum.Enum):
    """How a session began, as the host reports it.

    The core never infers a value from absence. On Claude Code before v2.1.214
    a fork arrives as ``source="resume"`` and is recorded as ``RESUMED``.
    """

    NEW = "new"
    RESUMED = "resumed"
    FORKED = "forked"
    CLEARED = "cleared"
    COMPACTED = "compacted"
    UNKNOWN = "unknown"


class DelegationInitiator(enum.Enum):
    """Who started delegated work, as the host reports it (D-09)."""

    MODEL = "model"
    USER = "user"
    HOST_INTERNAL = "host_internal"
    UNKNOWN = "unknown"


class DelegationMode(enum.Enum):
    """Whether delegated work ran in the foreground or background (D-09).

    It stays ``UNKNOWN`` until the host reports it.
    """

    FOREGROUND = "foreground"
    BACKGROUND = "background"
    UNKNOWN = "unknown"


class EventSource(enum.Enum):
    """The host channel an activity event came from."""

    HOOK = "hook"
    OTEL = "otel"
    HOST_STATE = "host_state"
    SDK = "sdk"
    SYNTHETIC = "synthetic"


class PayloadKind(enum.Enum):
    """The member of the closed payload union a record belongs to (D-05)."""

    TEXT_EXCERPT = "text_excerpt"
    TOOL_OUTCOME = "tool_outcome"
    TASK_TRANSITION = "task_transition"
    USAGE_REPORT = "usage_report"
    COMPACTION_INFO = "compaction_info"
    SESSION_END_INFO = "session_end_info"
    DELEGATION_RESULT = "delegation_result"
    NO_PAYLOAD = "no_payload"


class CompactionTrigger(enum.Enum):
    """What started a context compaction, as the host reports it."""

    MANUAL = "manual"
    AUTO = "auto"
    UNKNOWN = "unknown"


def _require_count(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, int, schema_id, field)
    if isinstance(value, int) and value < 0:
        raise RecordValidationError(
            schema_id, field, f"must be at least 0, got {value!r}"
        )


def _require_optional_count(value: object, schema_id: str, field: str) -> None:
    if value is not None:
        _require_count(value, schema_id, field)


def _require_optional_bool(value: object, schema_id: str, field: str) -> None:
    if value is not None:
        _require_exact_type(value, bool, schema_id, field)


def _require_bounded(value: object, schema_id: str, field: str, max_bytes: int) -> None:
    _require_exact_type(value, str, schema_id, field)
    if not is_bounded_printable(str(value), max_bytes):
        raise RecordValidationError(
            schema_id,
            field,
            f"must be non-empty printable text within {max_bytes} serialized bytes",
        )


def _require_optional_bounded(
    value: object, schema_id: str, field: str, max_bytes: int
) -> None:
    if value is not None:
        _require_bounded(value, schema_id, field, max_bytes)


def _require_utc(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, datetime, schema_id, field)
    if not isinstance(value, datetime) or value.utcoffset() != timedelta(0):
        raise RecordValidationError(
            schema_id, field, "must be an aware datetime with a zero UTC offset"
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class TextExcerpt:
    """Character-bounded text a host supplies, with measurements of the original.

    A payload member of the frozen ``rae.activity_event`` version 1 (ADR 0015
    decision 3). Build one with :func:`text_excerpt`.

    Attributes:
        text: The kept text, a prefix of the original.
        original_char_length: The original's length in code points, at least
            ``len(text)``.
        original_serialized_bytes: The original's length as measured by
            ``_bounded.serialized_byte_length``, the project's single byte
            measure (research Pitfall 9).
        truncated: Whether the text was cut. It must equal
            ``original_char_length != len(text)``.
    """

    SCHEMA_ID: ClassVar[str] = "rae.text_excerpt"
    SCHEMA_VERSION: ClassVar[int] = 1
    PAYLOAD_KIND: ClassVar[PayloadKind] = PayloadKind.TEXT_EXCERPT

    text: str
    original_char_length: int
    original_serialized_bytes: int
    truncated: bool

    def __post_init__(self) -> None:
        """Validate exact types and the measurement invariants.

        Raises:
            RecordValidationError: If a field has the wrong type, a length is
                negative, the original is shorter than the text, or
                ``truncated`` disagrees with the lengths.
        """
        schema_id = TextExcerpt.SCHEMA_ID
        _require_exact_type(self.text, str, schema_id, "text")
        _require_count(self.original_char_length, schema_id, "original_char_length")
        _require_count(
            self.original_serialized_bytes, schema_id, "original_serialized_bytes"
        )
        _require_exact_type(self.truncated, bool, schema_id, "truncated")
        if self.original_char_length < len(self.text):
            raise RecordValidationError(
                schema_id,
                "original_char_length",
                f"must be at least len(text) = {len(self.text)}, "
                f"got {self.original_char_length!r}",
            )
        if self.truncated != (self.original_char_length != len(self.text)):
            raise RecordValidationError(
                schema_id,
                "truncated",
                "must be true exactly when original_char_length differs from len(text)",
            )


def text_excerpt(text: str, *, max_chars: int | None = None) -> TextExcerpt:
    """Keep at most ``max_chars`` code points of ``text`` and measure the original.

    Args:
        text: The original text.
        max_chars: The number of code points to keep, at least 0, or ``None``
            to keep the whole text.

    Returns:
        An excerpt of ``text[:max_chars]`` that records the original's length
        and serialized byte length, truncated exactly when text was cut.

    Raises:
        ConfigurationError: If ``max_chars`` is not ``None`` and not an exact
            ``int`` of at least 0.
        RecordValidationError: If ``text`` is not a ``str``.
    """
    if max_chars is not None and (type(max_chars) is not int or max_chars < 0):
        raise ConfigurationError(
            f"max_chars must be None or an int of at least 0, got {max_chars!r}"
        )
    _require_exact_type(text, str, TextExcerpt.SCHEMA_ID, "text")
    kept = text if max_chars is None else text[:max_chars]
    return TextExcerpt(
        text=kept,
        original_char_length=len(text),
        original_serialized_bytes=serialized_byte_length(text),
        truncated=len(kept) != len(text),
    )


@dataclass(frozen=True, slots=True, kw_only=True)
class ToolOutcome:
    """How one tool call ended, as the host reports it.

    A payload member of the frozen ``rae.activity_event`` version 1 (ADR 0015
    decision 3). The host's exception text is never recorded, because it can
    carry URLs or credentials (ADR 0012 decision 6).

    Attributes:
        tool_name: The host's tool name: non-empty printable text within 64
            serialized bytes, or ``None``.
        succeeded: Whether the call succeeded.
        interrupted: Whether the call was interrupted, if the host says.
    """

    SCHEMA_ID: ClassVar[str] = "rae.tool_outcome"
    SCHEMA_VERSION: ClassVar[int] = 1
    PAYLOAD_KIND: ClassVar[PayloadKind] = PayloadKind.TOOL_OUTCOME

    tool_name: str | None = None
    succeeded: bool
    interrupted: bool | None = None

    def __post_init__(self) -> None:
        """Validate exact types and the name bound.

        Raises:
            RecordValidationError: If a field is invalid.
        """
        schema_id = ToolOutcome.SCHEMA_ID
        _require_optional_bounded(
            self.tool_name, schema_id, "tool_name", _PAYLOAD_NAME_MAX_BYTES
        )
        _require_exact_type(self.succeeded, bool, schema_id, "succeeded")
        _require_optional_bool(self.interrupted, schema_id, "interrupted")


@dataclass(frozen=True, slots=True, kw_only=True)
class TaskTransition:
    """A host task changing state, with an optional summary.

    A payload member of the frozen ``rae.activity_event`` version 1 (ADR 0015
    decision 3).

    Attributes:
        summary: The host's summary of the task, if any.
    """

    SCHEMA_ID: ClassVar[str] = "rae.task_transition"
    SCHEMA_VERSION: ClassVar[int] = 1
    PAYLOAD_KIND: ClassVar[PayloadKind] = PayloadKind.TASK_TRANSITION

    summary: TextExcerpt | None = None

    def __post_init__(self) -> None:
        """Validate the summary type.

        Raises:
            RecordValidationError: If ``summary`` is not a ``TextExcerpt`` or
                ``None``.
        """
        if self.summary is not None:
            _require_exact_type(
                self.summary, TextExcerpt, TaskTransition.SCHEMA_ID, "summary"
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class UsageReport:
    """Token counts and cost the host reported for one request.

    A payload member of the frozen ``rae.activity_event`` version 1 (ADR 0015
    decision 3). The values are host facts; the core never estimates them.

    Attributes:
        input_tokens: Input tokens, an ``int`` of at least 0, never a ``bool``.
        output_tokens: Output tokens, an ``int`` of at least 0, never a
            ``bool``.
        cost: The reported cost, if any.
        model: The model name: non-empty printable text within 64 serialized
            bytes, or ``None``.
    """

    SCHEMA_ID: ClassVar[str] = "rae.usage_report"
    SCHEMA_VERSION: ClassVar[int] = 1
    PAYLOAD_KIND: ClassVar[PayloadKind] = PayloadKind.USAGE_REPORT

    input_tokens: int | None = None
    output_tokens: int | None = None
    cost: Money | None = None
    model: str | None = None

    def __post_init__(self) -> None:
        """Validate exact types, the counts, and the model bound.

        Raises:
            RecordValidationError: If a field is invalid.
        """
        schema_id = UsageReport.SCHEMA_ID
        _require_optional_count(self.input_tokens, schema_id, "input_tokens")
        _require_optional_count(self.output_tokens, schema_id, "output_tokens")
        if self.cost is not None:
            _require_exact_type(self.cost, Money, schema_id, "cost")
        _require_optional_bounded(
            self.model, schema_id, "model", _PAYLOAD_NAME_MAX_BYTES
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class CompactionInfo:
    """A context compaction, as the host reports it.

    A payload member of the frozen ``rae.activity_event`` version 1 (ADR 0015
    decision 3).

    Attributes:
        trigger: What started the compaction, ``UNKNOWN`` unless reported.
        pre_tokens: Context tokens before, an ``int`` of at least 0.
        post_tokens: Context tokens after, an ``int`` of at least 0.
        succeeded: Whether the compaction succeeded, if the host says.
    """

    SCHEMA_ID: ClassVar[str] = "rae.compaction_info"
    SCHEMA_VERSION: ClassVar[int] = 1
    PAYLOAD_KIND: ClassVar[PayloadKind] = PayloadKind.COMPACTION_INFO

    trigger: CompactionTrigger = CompactionTrigger.UNKNOWN
    pre_tokens: int | None = None
    post_tokens: int | None = None
    succeeded: bool | None = None

    def __post_init__(self) -> None:
        """Validate exact types and the counts.

        Raises:
            RecordValidationError: If a field is invalid.
        """
        schema_id = CompactionInfo.SCHEMA_ID
        _require_exact_type(self.trigger, CompactionTrigger, schema_id, "trigger")
        _require_optional_count(self.pre_tokens, schema_id, "pre_tokens")
        _require_optional_count(self.post_tokens, schema_id, "post_tokens")
        _require_optional_bool(self.succeeded, schema_id, "succeeded")


@dataclass(frozen=True, slots=True, kw_only=True)
class SessionEndInfo:
    """Why a session ended, as the host reports it.

    A payload member of the frozen ``rae.activity_event`` version 1 (ADR 0015
    decision 3). The reason is bounded text rather than an enum, so a new host
    reason does not break the contract.

    Attributes:
        reason: Non-empty printable text within 64 serialized bytes, or
            ``None``.
    """

    SCHEMA_ID: ClassVar[str] = "rae.session_end_info"
    SCHEMA_VERSION: ClassVar[int] = 1
    PAYLOAD_KIND: ClassVar[PayloadKind] = PayloadKind.SESSION_END_INFO

    reason: str | None = None

    def __post_init__(self) -> None:
        """Validate the reason bound.

        Raises:
            RecordValidationError: If ``reason`` is invalid.
        """
        _require_optional_bounded(
            self.reason, SessionEndInfo.SCHEMA_ID, "reason", _PAYLOAD_NAME_MAX_BYTES
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class DelegationResult:
    """How delegated work ended, as the host reports it.

    A payload member of the frozen ``rae.activity_event`` version 1 (ADR 0015
    decision 3).

    Attributes:
        summary: The host's summary of the result, if any.
        succeeded: Whether the delegated work succeeded, if the host says.
    """

    SCHEMA_ID: ClassVar[str] = "rae.delegation_result"
    SCHEMA_VERSION: ClassVar[int] = 1
    PAYLOAD_KIND: ClassVar[PayloadKind] = PayloadKind.DELEGATION_RESULT

    summary: TextExcerpt | None = None
    succeeded: bool | None = None

    def __post_init__(self) -> None:
        """Validate exact types.

        Raises:
            RecordValidationError: If a field is invalid.
        """
        schema_id = DelegationResult.SCHEMA_ID
        if self.summary is not None:
            _require_exact_type(self.summary, TextExcerpt, schema_id, "summary")
        _require_optional_bool(self.succeeded, schema_id, "succeeded")


@dataclass(frozen=True, slots=True, kw_only=True)
class NoPayload:
    """The payload of an event that carries nothing beyond its kind.

    A payload member of the frozen ``rae.activity_event`` version 1 (ADR 0015
    decision 3).
    """

    SCHEMA_ID: ClassVar[str] = "rae.no_payload"
    SCHEMA_VERSION: ClassVar[int] = 1
    PAYLOAD_KIND: ClassVar[PayloadKind] = PayloadKind.NO_PAYLOAD


ActivityPayload: TypeAlias = (
    TextExcerpt
    | ToolOutcome
    | TaskTransition
    | UsageReport
    | CompactionInfo
    | SessionEndInfo
    | DelegationResult
    | NoPayload
)
"""The closed payload union of ``rae.activity_event`` version 1 (D-05)."""

AttributeValue: TypeAlias = str | int | bool | None
"""An attribute scalar: a bounded ``str``, an ``int``, a ``bool``, or ``None``."""

_PAYLOAD_TYPES: Final[tuple[type, ...]] = (
    TextExcerpt,
    ToolOutcome,
    TaskTransition,
    UsageReport,
    CompactionInfo,
    SessionEndInfo,
    DelegationResult,
    NoPayload,
)
"""The eight payload record types, in ``PayloadKind`` order."""

_IDENTITY_TEXT_FIELDS: Final = (
    "session_id",
    "parent_session_id",
    "forked_from_session_id",
    "prompt_id",
    "turn_id",
    "task_id",
    "tool_call_id",
    "delegated_agent_id",
    "delegated_agent_type",
    "request_id",
)


@dataclass(frozen=True, slots=True, kw_only=True)
class ActivityIdentity:
    """Every identifier a host may know about one activity event (D-03, ENV-01).

    Frozen: ``rae.activity_identity`` version 1 is part of the frozen
    ``rae.activity_event`` contract (ADR 0015, option-a).

    Every field is optional, and an identity with none is valid. Each
    identifier, when present, is non-empty printable text within 128
    serialized bytes; anything else is rejected, never clamped. An adapter
    records an empty native value as ``None``. The three enums default to
    ``UNKNOWN`` and the core never infers them from absence (D-04).

    Attributes:
        session_id: The host session.
        parent_session_id: The session that spawned this one.
        session_origin: How the session began.
        forked_from_session_id: The session this one was forked from.
        prompt_id: Correlation metadata only, never a lineage or boundary key.
        turn_id: The host turn.
        task_id: The host task.
        tool_call_id: The tool call.
        delegated_agent_id: The delegated agent inside the session.
        delegated_agent_type: The delegated agent's type.
        delegation_initiator: Who started the delegated work.
        delegation_mode: Whether the delegated work ran in the foreground or
            background.
        request_id: The model request.
    """

    SCHEMA_ID: ClassVar[str] = "rae.activity_identity"
    SCHEMA_VERSION: ClassVar[int] = 1

    session_id: str | None = None
    parent_session_id: str | None = None
    session_origin: SessionOrigin = SessionOrigin.UNKNOWN
    forked_from_session_id: str | None = None
    prompt_id: str | None = None
    turn_id: str | None = None
    task_id: str | None = None
    tool_call_id: str | None = None
    delegated_agent_id: str | None = None
    delegated_agent_type: str | None = None
    delegation_initiator: DelegationInitiator = DelegationInitiator.UNKNOWN
    delegation_mode: DelegationMode = DelegationMode.UNKNOWN
    request_id: str | None = None

    def __post_init__(self) -> None:
        """Validate the identifier bounds and the enum types.

        Raises:
            RecordValidationError: If an identifier is not bounded printable
                text or an enum field has the wrong type.
        """
        schema_id = ActivityIdentity.SCHEMA_ID
        for field in _IDENTITY_TEXT_FIELDS:
            _require_optional_bounded(
                getattr(self, field), schema_id, field, IDENTIFIER_MAX_BYTES
            )
        _require_exact_type(
            self.session_origin, SessionOrigin, schema_id, "session_origin"
        )
        _require_exact_type(
            self.delegation_initiator,
            DelegationInitiator,
            schema_id,
            "delegation_initiator",
        )
        _require_exact_type(
            self.delegation_mode, DelegationMode, schema_id, "delegation_mode"
        )


def _identity_fields(identity: ActivityIdentity) -> dict[str, JsonValue]:
    fields: dict[str, JsonValue] = {
        field: value
        for field in _IDENTITY_TEXT_FIELDS
        if (value := getattr(identity, field)) is not None
    }
    fields["session_origin"] = identity.session_origin.value
    fields["delegation_initiator"] = identity.delegation_initiator.value
    fields["delegation_mode"] = identity.delegation_mode.value
    return fields


def _require_attributes(value: object, schema_id: str) -> None:
    field = "attributes"
    if type(value) is not tuple:
        raise RecordValidationError(
            schema_id, field, f"tuple required, got {type(value).__name__}"
        )
    previous: str | None = None
    for index, pair in enumerate(value):
        if type(pair) is not tuple or len(pair) != 2:
            raise RecordValidationError(
                schema_id, field, f"element {index} must be a (key, value) tuple"
            )
        key, item = pair
        if (
            type(key) is not str
            or _ATTRIBUTE_KEY.fullmatch(key) is None
            or serialized_byte_length(key) > _ATTRIBUTE_KEY_MAX_BYTES
        ):
            raise RecordValidationError(
                schema_id,
                field,
                f"element {index} key must be dotted lowercase segments within "
                f"{_ATTRIBUTE_KEY_MAX_BYTES} bytes",
            )
        if previous is not None and key <= previous:
            raise RecordValidationError(
                schema_id,
                field,
                f"element {index} key must sort after the previous key",
            )
        previous = key
        if type(item) is str:
            if serialized_byte_length(item) > NARRATIVE_CLAMP_BYTES:
                raise RecordValidationError(
                    schema_id,
                    field,
                    f"element {index} value exceeds {NARRATIVE_CLAMP_BYTES} "
                    "serialized bytes",
                )
        elif item is not None and type(item) is not int and type(item) is not bool:
            raise RecordValidationError(
                schema_id,
                field,
                f"element {index} value must be str, int, bool, or None, "
                f"got {type(item).__name__}",
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class ActivityEvent:
    """One normalized host activity event (D-03, ENV-01).

    Frozen: ``rae.activity_event`` version 1 (ADR 0015, option-a). From 0.1.0
    on, any change to a field's name, type, bound, or meaning needs a schema
    version bump and a registered migration.

    Attributes:
        kind: What happened.
        host: The host name: non-empty printable text within 64 serialized
            bytes.
        identity: Every identifier the host knows, possibly none.
        payload: One member of the closed payload union.
        observed_at: When the adapter saw the event, from its clock (UTC).
        occurred_at: When the host says the event happened (UTC), if it says.
        host_sequence: The host's sequence hint, an ``int`` of at least 0 and
            never a ``bool``. It only breaks ties, because Claude's
            ``event.sequence`` restarts per process.
        native_event_id: The host's own event id, a bounded identifier.
        dedupe_key: The identity of the event for deduplication, a bounded
            identifier. :func:`derive_dedupe_key` computes one.
        source: The host channel the event came from.
        attributes: ``(namespaced_key, scalar)`` pairs sorted by key, with
            unique keys. The core never branches on them.
    """

    SCHEMA_ID: ClassVar[str] = "rae.activity_event"
    SCHEMA_VERSION: ClassVar[int] = 1

    kind: ActivityKind
    host: str
    identity: ActivityIdentity
    payload: ActivityPayload
    observed_at: datetime
    occurred_at: datetime | None = None
    host_sequence: int | None = None
    native_event_id: str | None = None
    dedupe_key: str
    source: EventSource
    attributes: tuple[tuple[str, AttributeValue], ...] = ()

    def __post_init__(self) -> None:
        """Validate exact types, bounds, timestamps, and attributes.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = ActivityEvent.SCHEMA_ID
        _require_exact_type(self.kind, ActivityKind, schema_id, "kind")
        _require_bounded(self.host, schema_id, "host", HOST_NAME_MAX_BYTES)
        _require_exact_type(self.identity, ActivityIdentity, schema_id, "identity")
        if type(self.payload) not in _PAYLOAD_TYPES:
            raise RecordValidationError(
                schema_id,
                "payload",
                f"a payload record required, got {type(self.payload).__name__}",
            )
        _require_utc(self.observed_at, schema_id, "observed_at")
        if self.occurred_at is not None:
            _require_utc(self.occurred_at, schema_id, "occurred_at")
        _require_optional_count(self.host_sequence, schema_id, "host_sequence")
        _require_optional_bounded(
            self.native_event_id, schema_id, "native_event_id", IDENTIFIER_MAX_BYTES
        )
        _require_bounded(self.dedupe_key, schema_id, "dedupe_key", IDENTIFIER_MAX_BYTES)
        _require_exact_type(self.source, EventSource, schema_id, "source")
        _require_attributes(self.attributes, schema_id)

    @property
    def order_key(self) -> tuple[datetime, int, str]:
        """The event's position in a log (ADR 0015 decision 4, F-11).

        ``(occurred_at``, or ``observed_at`` when unknown, ``host_sequence``,
        or -1 when unknown, ``dedupe_key)``. A sequence of 0 is a real
        sequence, so it sorts after an unsequenced event at the same instant.
        """
        when = self.occurred_at if self.occurred_at is not None else self.observed_at
        sequence = -1 if self.host_sequence is None else self.host_sequence
        return (when, sequence, self.dedupe_key)


@dataclass(frozen=True, slots=True, kw_only=True)
class ActivityLog:
    """A deduplicated, totally ordered activity stream (D-06, ENV-02).

    Frozen with ``rae.activity_event`` version 1 (ADR 0015, option-a). Build
    one with ``streams.normalize_stream``.

    Attributes:
        events: Events in strictly increasing ``order_key`` order, with
            unique dedupe keys.
        collision_count: The number of dedupe keys whose events had two or
            more distinct encodings, an ``int`` of at least 0.
    """

    SCHEMA_ID: ClassVar[str] = "rae.activity_log"
    SCHEMA_VERSION: ClassVar[int] = 1

    events: tuple[ActivityEvent, ...] = ()
    collision_count: int = 0

    def __post_init__(self) -> None:
        """Validate the ordering, key uniqueness, and the count.

        Raises:
            RecordValidationError: If the events are not a tuple of
                ``ActivityEvent`` in strictly increasing ``order_key`` order
                with unique dedupe keys, or the count is invalid.
        """
        schema_id = ActivityLog.SCHEMA_ID
        if type(self.events) is not tuple:
            raise RecordValidationError(
                schema_id, "events", f"tuple required, got {type(self.events).__name__}"
            )
        for index, event in enumerate(self.events):
            if type(event) is not ActivityEvent:
                raise RecordValidationError(
                    schema_id,
                    "events",
                    f"element {index} must be ActivityEvent, "
                    f"got {type(event).__name__}",
                )
        keys = [event.order_key for event in self.events]
        if any(keys[index] <= keys[index - 1] for index in range(1, len(keys))):
            raise RecordValidationError(
                schema_id, "events", "must be in strictly increasing order_key order"
            )
        dedupe_keys = {event.dedupe_key for event in self.events}
        if len(dedupe_keys) != len(self.events):
            raise RecordValidationError(
                schema_id, "events", "must not repeat a dedupe_key"
            )
        _require_count(self.collision_count, schema_id, "collision_count")


def derive_dedupe_key(
    *,
    host: str,
    kind: ActivityKind,
    identity: ActivityIdentity,
    native_event_id: str | None = None,
    occurred_at: datetime | None = None,
) -> str:
    """Derive an event's dedupe key from its identifying facts (D-06).

    The key is the SHA-256 hex of ``canonical_json`` over an object with
    ``"host"``, ``"kind"`` (the enum value), and ``"identity"`` (the identity's
    codec fields, ``None`` fields omitted and enums by value), plus
    ``"native_event_id"`` and ``"occurred_at"`` (canonical UTC text), each only
    when not ``None``. These bytes are frozen (ADR 0015 decision 4).

    A host with no native event id must pass its receipt time as
    ``occurred_at`` or supply ``native_event_id``; otherwise two distinct
    events with equal host, kind, and identity get the same key and collapse.

    Args:
        host: The host name.
        kind: What happened.
        identity: The event's identifiers.
        native_event_id: The host's own event id, if any.
        occurred_at: When the event happened (UTC), if known.

    Returns:
        64 lowercase hex characters.

    Raises:
        RecordValidationError: If an argument would be invalid on an
            ``ActivityEvent``.
    """
    schema_id = ActivityEvent.SCHEMA_ID
    _require_bounded(host, schema_id, "host", HOST_NAME_MAX_BYTES)
    _require_exact_type(kind, ActivityKind, schema_id, "kind")
    _require_exact_type(identity, ActivityIdentity, schema_id, "identity")
    _require_optional_bounded(
        native_event_id, schema_id, "native_event_id", IDENTIFIER_MAX_BYTES
    )
    payload: dict[str, JsonValue] = {
        "host": host,
        "kind": kind.value,
        "identity": _identity_fields(identity),
    }
    if native_event_id is not None:
        payload["native_event_id"] = native_event_id
    if occurred_at is not None:
        _require_utc(occurred_at, schema_id, "occurred_at")
        payload["occurred_at"] = format_utc_timestamp(occurred_at)
    return hashlib.sha256(canonical_json(payload)).hexdigest()
