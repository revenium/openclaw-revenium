"""Ports the engine calls, and the provider-neutral completion records (ADR 0007).

Hosts implement these protocols structurally, without importing a base class.
Every record here is plain data. A host adapter converts its provider's
response into a :class:`CompletionResult` and runs any blocking client call
off the event loop itself.
"""

import enum
import math
import re
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import ClassVar, Final, Protocol, TypeVar

from revenium_agent_economics._bounded import (
    HOST_NAME_MAX_BYTES,
    IFS_CHARACTERS,
    JOB_ID_MAX_BYTES,
    JOB_NAME_MAX_BYTES,
    SUBJECT_REF_MAX_BYTES,
    finite_number,
    is_bounded_printable,
    normalize_text,
    serialized_byte_length,
)
from revenium_agent_economics._canonical import JsonValue
from revenium_agent_economics.diagnostics import Diagnostic
from revenium_agent_economics.envelope import TextExcerpt
from revenium_agent_economics.errors import RecordValidationError
from revenium_agent_economics.lineage import JobSubject
from revenium_agent_economics.primitives import (
    _COMPONENT_NAME_MAX_BYTES,
    Money,
    _require_exact_type,
    _require_text,
    _require_tuple_of,
)
from revenium_agent_economics.taxonomy import (
    JobTaxonomySnapshot,
    LabelProposal,
    TaskTaxonomySnapshot,
    TaxonomyNamespace,
    is_valid_label,
)
from revenium_agent_economics.vocab import (
    EVALUATOR_MECHANISMS,
    ClaimBasis,
    Currency,
    EconomicMechanism,
    EvidenceClass,
)

# Hermes classifier.py:L2126: _clamp_assessment_text(raw["inferred_role"], 60).
INFERRED_ROLE_MAX_BYTES: Final = 60
# ADR 0017 decision 1: the job id grammar. ``jobs`` re-exports the validator,
# so the job records and the outcome evaluator input share one rule.
_JOB_ID: Final = re.compile(r"[a-z0-9_-]{1,59}_[0-9a-f]{4}")


class MessageRole(enum.Enum):
    """Who speaks a completion message."""

    SYSTEM = "system"
    USER = "user"


class CompletionPurpose(enum.Enum):
    """Which library operation asked for a completion."""

    TASK_CLASSIFICATION = "task_classification"
    JOB_INFERENCE = "job_inference"
    OUTCOME_EVALUATION = "outcome_evaluation"


class FinishReason(enum.Enum):
    """Why the model stopped producing text, as reported by the host."""

    STOP = "stop"
    LENGTH = "length"
    REFUSAL = "refusal"
    UNKNOWN = "unknown"


class AddressClass(enum.Enum):
    """The network class of the inference endpoint, as reported by the host."""

    LOOPBACK = "loopback"
    PRIVATE = "private"
    PUBLIC = "public"
    UNSET = "unset"


@dataclass(frozen=True, slots=True, kw_only=True)
class CompletionMessage:
    """One message sent to the model.

    Attributes:
        role: The speaker.
        content: The message text.
    """

    SCHEMA_ID: ClassVar[str] = "rae.completion_message"
    SCHEMA_VERSION: ClassVar[int] = 1

    role: MessageRole
    content: str

    def __post_init__(self) -> None:
        """Validate exact types.

        Raises:
            RecordValidationError: If any field has the wrong type.
        """
        schema_id = CompletionMessage.SCHEMA_ID
        _require_exact_type(self.role, MessageRole, schema_id, "role")
        _require_exact_type(self.content, str, schema_id, "content")


@dataclass(frozen=True, slots=True, kw_only=True)
class CompletionRequest:
    """What the engine asks a :class:`ModelCompletion` port to complete.

    The request carries no timeout: the engine enforces its own deadline
    (D-02).

    Attributes:
        messages: The messages, in order. At least one.
        max_tokens: The completion token limit, at least 1.
        temperature: The sampling temperature, finite and at least 0.
        purpose: The library operation making the call.
    """

    SCHEMA_ID: ClassVar[str] = "rae.completion_request"
    SCHEMA_VERSION: ClassVar[int] = 1

    messages: tuple[CompletionMessage, ...]
    max_tokens: int
    temperature: float = 0.0
    purpose: CompletionPurpose

    def __post_init__(self) -> None:
        """Validate the messages, limits, and purpose.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = CompletionRequest.SCHEMA_ID
        _require_tuple_of(self.messages, CompletionMessage, schema_id, "messages")
        if not self.messages:
            raise RecordValidationError(schema_id, "messages", "must not be empty")
        _require_exact_type(self.max_tokens, int, schema_id, "max_tokens")
        if self.max_tokens < 1:
            raise RecordValidationError(
                schema_id, "max_tokens", f"must be at least 1, got {self.max_tokens!r}"
            )
        _require_exact_type(self.temperature, float, schema_id, "temperature")
        if not math.isfinite(self.temperature) or self.temperature < 0:
            raise RecordValidationError(
                schema_id,
                "temperature",
                f"must be finite and at least 0, got {self.temperature!r}",
            )
        _require_exact_type(self.purpose, CompletionPurpose, schema_id, "purpose")


@dataclass(frozen=True, slots=True, kw_only=True)
class TokenUsage:
    """Token counts the host reports for one completion.

    Attributes:
        input_tokens: Prompt tokens, at least 0.
        output_tokens: Completion tokens, at least 0.
    """

    SCHEMA_ID: ClassVar[str] = "rae.token_usage"
    SCHEMA_VERSION: ClassVar[int] = 1

    input_tokens: int
    output_tokens: int

    def __post_init__(self) -> None:
        """Validate exact int counts of at least 0.

        Raises:
            RecordValidationError: If a count is not an int or is negative.
        """
        schema_id = TokenUsage.SCHEMA_ID
        for field, value in (
            ("input_tokens", self.input_tokens),
            ("output_tokens", self.output_tokens),
        ):
            _require_exact_type(value, int, schema_id, field)
            if value < 0:
                raise RecordValidationError(
                    schema_id, field, f"must be at least 0, got {value!r}"
                )


@dataclass(frozen=True, slots=True, kw_only=True)
class CompletionResult:
    """What a :class:`ModelCompletion` port returns (D-01).

    ``served_model`` and ``provider`` are untrusted host text and accept any
    string. The library clamps them to 64 and 32 serialized bytes when it
    records inference provenance.

    Attributes:
        text: The model's raw output text.
        finish_reason: Why the model stopped. It never changes a decision
            (D-03).
        served_model: The model that actually served the call, if known.
        provider: The inference provider name, if known.
        address_class: The endpoint's network class, supplied by the host.
        usage: Token counts, if known.
        cost: The metered cost of the call, if known.
    """

    SCHEMA_ID: ClassVar[str] = "rae.completion_result"
    SCHEMA_VERSION: ClassVar[int] = 1

    text: str
    finish_reason: FinishReason = FinishReason.UNKNOWN
    served_model: str | None = None
    provider: str | None = None
    address_class: AddressClass = AddressClass.UNSET
    usage: TokenUsage | None = None
    cost: Money | None = None

    def __post_init__(self) -> None:
        """Validate exact types.

        Raises:
            RecordValidationError: If any field has the wrong type.
        """
        schema_id = CompletionResult.SCHEMA_ID
        _require_exact_type(self.text, str, schema_id, "text")
        _require_exact_type(
            self.finish_reason, FinishReason, schema_id, "finish_reason"
        )
        if self.served_model is not None:
            _require_exact_type(self.served_model, str, schema_id, "served_model")
        if self.provider is not None:
            _require_exact_type(self.provider, str, schema_id, "provider")
        _require_exact_type(
            self.address_class, AddressClass, schema_id, "address_class"
        )
        if self.usage is not None:
            _require_exact_type(self.usage, TokenUsage, schema_id, "usage")
        if self.cost is not None:
            _require_exact_type(self.cost, Money, schema_id, "cost")


@dataclass(frozen=True, slots=True, kw_only=True)
class ComponentDeclaration:
    """The identity and evidence class a component declares (D-19, ADR 0011).

    Attributes:
        name: The component name, non-empty printable text within 64
            serialized bytes that keeps a character other than spaces and
            ``|`` once normalized, because records state the normalized name
            as their evaluator (ADR 0011 decision 2, ADR 0030 addendum item
            5).
        version: The component version.
        evidence_class: The evidence class of the component's output.
        declared_mechanisms: The economic mechanisms the component declares,
            without repeats.
    """

    SCHEMA_ID: ClassVar[str] = "rae.component_declaration"
    SCHEMA_VERSION: ClassVar[int] = 1

    name: str
    version: str
    evidence_class: EvidenceClass
    declared_mechanisms: tuple[EconomicMechanism, ...] = ()

    def __post_init__(self) -> None:
        """Validate the name, version, evidence class, and mechanisms.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = ComponentDeclaration.SCHEMA_ID
        _require_exact_type(self.name, str, schema_id, "name")
        if not is_bounded_printable(self.name, _COMPONENT_NAME_MAX_BYTES):
            raise RecordValidationError(
                schema_id,
                "name",
                "must be non-empty printable text within "
                f"{_COMPONENT_NAME_MAX_BYTES} serialized bytes",
            )
        # ADR 0030 addendum item 5: refused once, here, so neither Engine
        # construction nor a hand-built proposal's evaluator can carry it.
        if normalize_text(self.name, max_bytes=_COMPONENT_NAME_MAX_BYTES) == "":
            raise RecordValidationError(
                schema_id,
                "name",
                "must keep a character other than spaces and '|' once normalized",
            )
        _require_text(self.version, schema_id, "version")
        _require_exact_type(
            self.evidence_class, EvidenceClass, schema_id, "evidence_class"
        )
        _require_tuple_of(
            self.declared_mechanisms,
            EconomicMechanism,
            schema_id,
            "declared_mechanisms",
        )
        if len(set(self.declared_mechanisms)) != len(self.declared_mechanisms):
            raise RecordValidationError(
                schema_id, "declared_mechanisms", "mechanisms must be unique"
            )


def _require_optional_text(value: object, schema_id: str, field: str) -> None:
    if value is not None:
        _require_exact_type(value, str, schema_id, field)


def _require_optional_subject_ref(value: object, schema_id: str) -> None:
    if value is None:
        return
    _require_exact_type(value, str, schema_id, "subject_ref")
    if not is_bounded_printable(str(value), SUBJECT_REF_MAX_BYTES):
        raise RecordValidationError(
            schema_id,
            "subject_ref",
            "must be non-empty printable text within "
            f"{SUBJECT_REF_MAX_BYTES} serialized bytes",
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class TaskClassificationInput:
    """What the engine passes to an injected :class:`TaskClassifier` (D-18).

    Attributes:
        user_message: The user's message, if any.
        assistant_response: The assistant's response, if any.
        snapshot: The task taxonomy the engine read for this call.
        subject_ref: The request's opaque host key: non-empty printable text
            within 128 serialized bytes.
    """

    SCHEMA_ID: ClassVar[str] = "rae.task_classification_input"
    SCHEMA_VERSION: ClassVar[int] = 1

    user_message: str | None = None
    assistant_response: str | None = None
    snapshot: TaskTaxonomySnapshot
    subject_ref: str | None = None

    def __post_init__(self) -> None:
        """Validate exact types and the subject reference bound.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = TaskClassificationInput.SCHEMA_ID
        _require_optional_text(self.user_message, schema_id, "user_message")
        _require_optional_text(self.assistant_response, schema_id, "assistant_response")
        _require_exact_type(self.snapshot, TaskTaxonomySnapshot, schema_id, "snapshot")
        _require_optional_subject_ref(self.subject_ref, schema_id)


def _require_label(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, str, schema_id, field)
    if not is_valid_label(str(value)):
        raise RecordValidationError(schema_id, field, "fails the label grammar")


@dataclass(frozen=True, slots=True, kw_only=True)
class JobSegmentationInput:
    """What the engine passes to an injected :class:`JobSegmenter` (D-19).

    Finalized by ADR 0018 decision 7. The core never reads a transcript: the
    host supplies the excerpt and chooses its cut (D-10).

    Attributes:
        transcript_sample: The host's excerpt of the activity to segment.
        snapshot: The job taxonomy the engine read for this call.
        subject: The lineage-resolved scope the call covers.
        host_display_name: The host's display name: non-empty printable text
            within 64 serialized bytes.
        subject_ref: The request's opaque host key: non-empty printable text
            within 128 serialized bytes.
    """

    SCHEMA_ID: ClassVar[str] = "rae.job_segmentation_input"
    SCHEMA_VERSION: ClassVar[int] = 1

    transcript_sample: TextExcerpt
    snapshot: JobTaxonomySnapshot
    subject: JobSubject
    host_display_name: str
    subject_ref: str | None = None

    def __post_init__(self) -> None:
        """Validate exact types and the host name and subject reference bounds.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = JobSegmentationInput.SCHEMA_ID
        _require_exact_type(
            self.transcript_sample, TextExcerpt, schema_id, "transcript_sample"
        )
        _require_exact_type(self.snapshot, JobTaxonomySnapshot, schema_id, "snapshot")
        _require_exact_type(self.subject, JobSubject, schema_id, "subject")
        _require_exact_type(self.host_display_name, str, schema_id, "host_display_name")
        if not is_bounded_printable(str(self.host_display_name), HOST_NAME_MAX_BYTES):
            raise RecordValidationError(
                schema_id,
                "host_display_name",
                "must be non-empty printable text within "
                f"{HOST_NAME_MAX_BYTES} serialized bytes",
            )
        _require_optional_subject_ref(self.subject_ref, schema_id)


def _require_job_id(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, str, schema_id, field)
    text = str(value)
    if (
        _JOB_ID.fullmatch(text) is None
        or text.startswith("-")
        or serialized_byte_length(text) > JOB_ID_MAX_BYTES
    ):
        raise RecordValidationError(
            schema_id,
            field,
            "must be a [a-z0-9_-] label of 1 to 59 characters not starting with "
            "'-', then '_' and 4 lowercase hexadecimal digits",
        )


def _require_operand_bound(value: object, schema_id: str, field: str) -> None:
    # The same rule as outcomes.OperandBounds: the int or float is kept as
    # given, so an evaluator sees 40.0 exactly as the prompt renders it.
    if (
        (type(value) is not int and type(value) is not float)
        or (number := finite_number(value)) is None
        or number <= 0
    ):
        raise RecordValidationError(
            schema_id,
            field,
            f"must be an int or float that is finite and above 0, got {value!r}",
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class OutcomeEvaluationInput:
    """What the engine passes to an injected :class:`OutcomeEvaluator` (ADR 0022).

    Finalized by ADR 0022 decision 4. ``propose_outcome`` builds it from the
    ``OutcomeRequest``: the candidate's identity and type, the host's
    transcript sample, the operand ceilings, and the currency. Every field is
    a layer 0-3 type, so this module stays at layer 4 (ADR 0026). The core
    never reads a transcript: the host supplies the excerpt (D-10).

    Attributes:
        job_id: The job being evaluated, in the ADR 0017 job id grammar.
        job_type: The job's label. It must pass the label grammar.
        job_name: The job's display text: ``""``, or text with no IFS
            characters within 200 serialized bytes, as on ``JobBoundary``.
        transcript_sample: The host's excerpt of the job's activity.
        max_hours_saved: The hours ceiling, an ``int`` or ``float`` that is
            finite and above 0. Its original type is kept.
        max_loaded_rate: The loaded-rate ceiling, with the same rule.
        currency: The currency the evaluator is asked to use.
        subject_ref: The request's opaque host key: non-empty printable text
            within 128 serialized bytes.
    """

    SCHEMA_ID: ClassVar[str] = "rae.outcome_evaluation_input"
    SCHEMA_VERSION: ClassVar[int] = 1

    job_id: str
    job_type: str
    job_name: str = ""
    transcript_sample: TextExcerpt
    max_hours_saved: int | float
    max_loaded_rate: int | float
    currency: Currency
    subject_ref: str | None = None

    def __post_init__(self) -> None:
        """Validate the id and label grammars, exact types, and every bound.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = OutcomeEvaluationInput.SCHEMA_ID
        _require_job_id(self.job_id, schema_id, "job_id")
        _require_label(self.job_type, schema_id, "job_type")
        _require_exact_type(self.job_name, str, schema_id, "job_name")
        name = str(self.job_name)
        if name != "" and (
            any(character in name for character in IFS_CHARACTERS)
            or serialized_byte_length(name) > JOB_NAME_MAX_BYTES
        ):
            raise RecordValidationError(
                schema_id,
                "job_name",
                "must have no IFS characters and be at most "
                f"{JOB_NAME_MAX_BYTES} serialized bytes",
            )
        _require_exact_type(
            self.transcript_sample, TextExcerpt, schema_id, "transcript_sample"
        )
        _require_operand_bound(self.max_hours_saved, schema_id, "max_hours_saved")
        _require_operand_bound(self.max_loaded_rate, schema_id, "max_loaded_rate")
        _require_exact_type(self.currency, Currency, schema_id, "currency")
        _require_optional_subject_ref(self.subject_ref, schema_id)


@dataclass(frozen=True, slots=True, kw_only=True)
class EvidenceQuery:
    """What a host asks its own evidence store about one job (ADR 0025, D-01).

    ADR 0025 decision 3. The engine never builds or sends one: ``assess_job``
    is sync and pure, so the host fetches evidence ahead of time through
    ``host_protocols.EvidenceSource.evidence(query)`` and hands the result to
    the library as plain data (``evidence.ResolvedEvidence`` on the
    ``AssessJobRequest``). This mirrors Hermes' split between
    ``valuation_sources.py``, which does the I/O, and the evidence
    registrants, which only decide. The engine's own question to an
    :class:`EvidenceResolver` is a :class:`ReportabilityQuery`.

    Attributes:
        job_id: The job the evidence is about, in the ADR 0017 job id grammar.
        job_type: The job's label. It must pass the label grammar.
        subject_ref: The opaque host key of the subject the job belongs to:
            non-empty printable text within 128 serialized bytes, or ``None``.
    """

    SCHEMA_ID: ClassVar[str] = "rae.evidence_query"
    SCHEMA_VERSION: ClassVar[int] = 1

    job_id: str
    job_type: str
    subject_ref: str | None = None

    def __post_init__(self) -> None:
        """Validate the id and label grammars and the subject reference bound.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = EvidenceQuery.SCHEMA_ID
        _require_job_id(self.job_id, schema_id, "job_id")
        _require_label(self.job_type, schema_id, "job_type")
        _require_optional_subject_ref(self.subject_ref, schema_id)


@dataclass(frozen=True, slots=True, kw_only=True)
class ReportabilityQuery:
    """What ``assess_job`` asks an :class:`EvidenceResolver` to decide.

    ADR 0025 decision 3. The plain data Hermes hands its evidence registrants
    (``{abstained, agentic_job_id, job_type}``, classifier.py:L3063-L3067),
    plus the host's resolved confirmation. Every field is a layer 0-3 type,
    so this module stays at layer 4 (ADR 0026).

    Attributes:
        abstained: Whether the record is an abstention, an exact ``bool``.
            Hermes' registrant input; rule 1 runs first, so the engine only
            ever passes ``False``.
        job_id: The job being decided, in the ADR 0017 job id grammar.
        job_type: The job's label. It must pass the label grammar.
        confirmed: The host's resolved confirmation for the job, from the
            request's ``ResolvedEvidence``: ``True``, ``False``, or ``None``
            when the host resolved none.
        subject_ref: The request's opaque host key: non-empty printable text
            within 128 serialized bytes.
    """

    SCHEMA_ID: ClassVar[str] = "rae.reportability_query"
    SCHEMA_VERSION: ClassVar[int] = 1

    abstained: bool
    job_id: str
    job_type: str
    confirmed: bool | None = None
    subject_ref: str | None = None

    def __post_init__(self) -> None:
        """Validate the exact types and the id and label grammars.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = ReportabilityQuery.SCHEMA_ID
        _require_exact_type(self.abstained, bool, schema_id, "abstained")
        _require_job_id(self.job_id, schema_id, "job_id")
        _require_label(self.job_type, schema_id, "job_type")
        if self.confirmed is not None:
            _require_exact_type(self.confirmed, bool, schema_id, "confirmed")
        _require_optional_subject_ref(self.subject_ref, schema_id)


@dataclass(frozen=True, slots=True, kw_only=True)
class ResolvedAssumptions:
    """The gated operands a valuation receives (ADR 0028 decision 2, VAL-03).

    Every field passed the operand gates of
    ``valuation.validate_proposal`` before it was built. It carries operands
    only: there is no total, value, or band field, so no policy and no
    evaluator can hand the library an amount.

    Attributes:
        job_type: The job's type label.
        economic_mechanism: The accepted evaluator mechanism.
        estimated_hours_saved: The gated hours, finite and above 0.
        assumed_loaded_rate: The gated loaded rate, finite and above 0.
        currency: The accepted currency.
        inferred_role: The role narrative clamped to 60 serialized bytes.
        hours_basis: Where the hours came from (ADR 0024).
        rate_basis: Where the rate came from (ADR 0024).
    """

    SCHEMA_ID: ClassVar[str] = "rae.resolved_assumptions"
    SCHEMA_VERSION: ClassVar[int] = 1

    job_type: str
    economic_mechanism: EconomicMechanism
    estimated_hours_saved: Decimal
    assumed_loaded_rate: Decimal
    currency: Currency
    inferred_role: str = ""
    hours_basis: ClaimBasis
    rate_basis: ClaimBasis

    def __post_init__(self) -> None:
        """Validate every field.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = ResolvedAssumptions.SCHEMA_ID
        _require_label(self.job_type, schema_id, "job_type")
        _require_exact_type(
            self.economic_mechanism,
            EconomicMechanism,
            schema_id,
            "economic_mechanism",
        )
        if self.economic_mechanism not in EVALUATOR_MECHANISMS:
            raise RecordValidationError(
                schema_id, "economic_mechanism", "must be an evaluator mechanism"
            )
        for field, value in (
            ("estimated_hours_saved", self.estimated_hours_saved),
            ("assumed_loaded_rate", self.assumed_loaded_rate),
        ):
            _require_exact_type(value, Decimal, schema_id, field)
            if not value.is_finite() or value <= 0:
                raise RecordValidationError(
                    schema_id, field, f"must be finite and above 0, got {value!r}"
                )
        _require_exact_type(self.currency, Currency, schema_id, "currency")
        _require_exact_type(self.inferred_role, str, schema_id, "inferred_role")
        role = str(self.inferred_role)
        if (
            any(character in role for character in IFS_CHARACTERS)
            or role != role.lstrip()
            or serialized_byte_length(role) > INFERRED_ROLE_MAX_BYTES
        ):
            raise RecordValidationError(
                schema_id,
                "inferred_role",
                "must be normalized text with no IFS characters and no leading "
                f"whitespace, at most {INFERRED_ROLE_MAX_BYTES} serialized bytes",
            )
        _require_exact_type(self.hours_basis, ClaimBasis, schema_id, "hours_basis")
        _require_exact_type(self.rate_basis, ClaimBasis, schema_id, "rate_basis")


class ModelCompletion(Protocol):
    """A host's model, called once per classification.

    Raise :class:`~revenium_agent_economics.errors.CompletionUnavailable` for a
    provider failure. Never swallow ``asyncio.CancelledError``.
    """

    async def complete(self, request: CompletionRequest) -> CompletionResult:
        """Complete ``request`` and return the model's text and metadata."""
        ...


_S_co = TypeVar("_S_co", covariant=True)


class TaxonomyReader(Protocol[_S_co]):
    """A host's read path for one taxonomy namespace.

    The engine's task slot is typed ``TaxonomyReader[TaskTaxonomySnapshot]``,
    so a reader of job snapshots is a type error there.
    """

    async def snapshot(self, namespace: TaxonomyNamespace) -> _S_co:
        """Return the current snapshot for ``namespace``."""
        ...


class Clock(Protocol):
    """A host's clock. Decisions take their timestamp from it."""

    def now(self) -> datetime:
        """Return the current time as an aware UTC datetime."""
        ...


class DiagnosticSink(Protocol):
    """A host's receiver for engine diagnostics (D-25).

    ``emit`` is sync and should return quickly. An exception it raises is
    isolated by the engine and never changes a decision.
    """

    def emit(self, diagnostic: Diagnostic) -> None:
        """Receive one diagnostic."""
        ...


class TaskClassifier(Protocol):
    """A host's replacement for the built-in model classifier (D-18, ADR 0011).

    Return a label candidate, or ``None`` to abstain. The engine validates the
    return value with the same rules as model output, so a non-string or
    malformed label becomes an abstention. Never swallow
    ``asyncio.CancelledError``.
    """

    @property
    def declaration(self) -> ComponentDeclaration:
        """The component's identity and evidence class, checked at construction."""
        ...

    async def classify(self, request: TaskClassificationInput) -> str | None:
        """Return a label candidate for ``request``, or ``None`` to abstain."""
        ...


class TaxonomyRecorder(Protocol):
    """A host's write path for label proposals (D-10, ADR 0009).

    The engine forwards a proposal only after its decision is final. A failure
    here is reported as a diagnostic and never changes the decision.
    """

    async def record(self, proposal: LabelProposal) -> None:
        """Record ``proposal`` in the host's taxonomy store."""
        ...


class JobSegmenter(Protocol):
    """A host's job boundary segmenter (ADR 0011, ADR 0018).

    Its declaration is checked at construction. The raw output is untrusted:
    the engine runs it through the same array coercion and per-job validation
    as model output (ADR 0018 decisions 4 and 5), so a malformed proposal is
    rejected, never trusted. Never swallow ``asyncio.CancelledError``.
    """

    @property
    def declaration(self) -> ComponentDeclaration:
        """The component's identity and evidence class, checked at construction."""
        ...

    async def segment(self, request: JobSegmentationInput) -> JsonValue | None:
        """Return raw job proposals for ``request``, or ``None`` to abstain."""
        ...


class OutcomeEvaluator(Protocol):
    """A host's outcome evaluator (ADR 0011, ADR 0022 decision 4).

    Its declaration is checked once at construction, and every proposal
    records that object. The engine calls ``evaluate`` from
    ``propose_outcome`` with an :class:`OutcomeEvaluationInput` and decides
    the raw output through ``outcomes.parse_outcome_response``: ``None``
    abstains, a non-object is ``NOT_AN_OBJECT``, and an object is coerced
    into the closed, untrusted proposal. Nothing returned here is money. A
    raised exception is ``EVALUATOR_FAILED`` and a ``TimeoutError`` is
    ``TIMED_OUT``; there is no fall-back to the built-in model. Never swallow
    ``asyncio.CancelledError``.
    """

    @property
    def declaration(self) -> ComponentDeclaration:
        """The component's identity and evidence class, checked at construction."""
        ...

    async def evaluate(self, request: OutcomeEvaluationInput) -> JsonValue | None:
        """Return a raw outcome proposal for ``request``, or ``None`` to abstain."""
        ...


class EvidenceResolver(Protocol):
    """A host's reportability decider, such as a confirmation workflow.

    ADR 0025 decision 3 (D-01). Its declaration is read once at construction
    and casts the evidence leg of the precedence walk. ``assess_job`` calls
    ``decide`` synchronously, through an isolation helper that records a
    raise by exception type name only, and only after reportability rules 1
    and 2 have passed: an abstention or a class outside
    ``REPORTABLE_EVIDENCE_CLASSES`` never reaches it. A MODEL_ESTIMATED
    record passes rule 2 only under the caller's model-estimate opt-in
    (ADR 0039), and even then ``assess_job`` never sends one here: the
    decider's own declaration sets the class through the evidence leg, and
    the engine refuses a MODEL_ESTIMATED declaration.

    The result is untrusted. It is accepted only when it is an object whose
    ``reportability_status`` is exactly ``"reportable"`` or ``"candidate"``.
    A raise, ``None``, a non-object, or any other status fails closed to
    COMPUTED_NOT_REPORTABLE (D-10) unless the caller selected
    ``DeciderFailureMode.HERMES_CONFIG_FALLBACK``.

    The decision must be pure: the host resolves evidence ahead of time (for
    example through ``host_protocols.EvidenceSource``) and hands it in as
    plain data. There is no deadline: threads are banned in the core, so a
    sync port cannot be bounded, and the host owns the risk that its decider
    hangs. Never swallow ``asyncio.CancelledError``.
    """

    @property
    def declaration(self) -> ComponentDeclaration:
        """The component's identity and evidence class, checked at construction."""
        ...

    def decide(self, query: ReportabilityQuery) -> JsonValue | None:
        """Return ``{"reportability_status": ...}`` for ``query``, or ``None``."""
        ...


class ValuationPolicy(Protocol):
    """A host's valuation policy, the only port that may declare mechanisms.

    Its declared mechanisms must come from the operator-only set (ADR 0011
    rule 4). ``assess_job`` calls ``value`` synchronously, through an
    isolation helper that records a raise by exception type name only, when
    ``AssessmentPolicy.method`` is ``INJECTED`` (ADR 0028 decision 5).

    The output is untrusted operands, never a total. The engine reads:

    - ``quantity`` and ``unit_value``, both required, gated, and multiplied
      by the engine itself, which re-checks the product against the active
      ceiling;
    - ``currency``, required, which must equal the policy currency code
      exactly. An absent or different value is refused as
      VALUATION_CURRENCY_MISMATCH (ADR 0028 decision 5);
    - ``economic_mechanism``, ``basis``, and the attribution pair, all
      optional.

    Keys named ``estimated_value`` or ``total`` are ignored.

    There is no deadline: threads are banned in the core (ADR 0025 decision
    3), so a sync port cannot be bounded, and the host owns the risk that its
    policy hangs. Never swallow ``asyncio.CancelledError``.
    """

    @property
    def declaration(self) -> ComponentDeclaration:
        """The component's identity, evidence class, and declared mechanisms."""
        ...

    def value(self, assumptions: ResolvedAssumptions) -> JsonValue | None:
        """Return raw operands for ``assumptions``, or ``None`` to decline."""
        ...


class IdGenerator(Protocol):
    """A host's source of identifier suffixes (ADR 0017, D-18).

    The port is settled: job inference calls ``suffix(4)`` once per accepted
    job. A deterministic generator gives deterministic job ids.
    """

    def suffix(self, n_hex: int) -> str:
        """Return exactly ``n_hex`` lowercase hexadecimal digits."""
        ...
