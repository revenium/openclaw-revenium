"""Engine configuration with the Hermes reference defaults.

``EngineConfig`` sits below the task module because the pure prompt builder
takes it, and below the engine because the engine holds it (ADR 0012).
"""

import enum
import math
from dataclasses import dataclass
from typing import Final

from revenium_agent_economics._bounded import is_bounded_printable
from revenium_agent_economics.errors import ConfigurationError

_HOST_DISPLAY_NAME_MAX_BYTES: Final = 64


class PreviewClip(enum.Enum):
    """How a prompt cuts a transcript sample to its preview limit (ADR 0042).

    ``HEAD`` keeps the first characters, the historic cut of job prompt
    versions 1 and 2. ``HEAD_TAIL`` keeps one third of the room for the head
    and the rest for the tail, joined by the elision marker, as Hermes
    ``_clip_head_tail`` does at 44bad57 (ADR 0042 decision 1). It lives here,
    not in ``jobs``, because ``EngineConfig`` holds the outcome clip and this
    module may not import ``jobs``.
    """

    HEAD = "head"
    HEAD_TAIL = "head_tail"


@dataclass(frozen=True, slots=True, kw_only=True)
class EngineConfig:
    """Timeouts, call parameters, and prompt limits for one engine.

    Every default equals the Hermes reference value (D-14, ADR 0010). This is
    configuration, not a schema record, so it has no schema id.

    Attributes:
        task_timeout_seconds: The deadline for one classification call
            (Hermes ``_CLASSIFY_TIMEOUT_SECONDS = 20.0``, classifier.py:L89 at
            44bad57, ADR 0042 decision 6).
        taxonomy_timeout_seconds: The deadline for one taxonomy read.
        recorder_timeout_seconds: The deadline for forwarding one proposal.
        max_tokens: The completion token limit (Hermes ``max_tokens=64``).
        temperature: The sampling temperature (Hermes ``temperature=0.0``).
        preview_max_chars: The character limit for each conversation preview.
        labels_block_max_chars: The character limit for the rendered label
            list before ``" ... [truncated]"`` is appended.
        host_display_name: The host name rendered into the prompt and recorded
            on every decision.
        job_timeout_seconds: The deadline for one job inference call (Hermes
            ``timeout=20.0``, ADR 0018 decision 7).
        job_max_tokens: The job completion token limit (Hermes
            ``max_tokens=512``).
        job_temperature: The job sampling temperature (Hermes
            ``temperature=0.0``).
        job_labels_block_max_chars: The character limit for the rendered job
            label list before ``" ... [truncated]"`` is appended (ADR 0019).
        job_prompt_version: The job prompt template version. Version 3 is the
            Hermes 44bad57 default, whose preview is clipped head and tail
            (ADR 0042 decision 3); the job prompt builder rejects a version it
            does not know (ADR 0019 decision 3).
        outcome_timeout_seconds: The deadline for one outcome evaluation call
            (Hermes ``_EVAL_TIMEOUT_SECONDS = 15.0``, classifier.py:L614,
            ADR 0022 decision 5).
        outcome_max_tokens: The outcome completion token limit (Hermes
            ``_EVAL_MAX_TOKENS = 512``, classifier.py:L613).
        outcome_temperature: The outcome sampling temperature (Hermes
            ``temperature=0.0``).
        outcome_transcript_max_chars: How many characters of the transcript
            sample the outcome prompt keeps (Hermes
            ``_EVAL_TRANSCRIPT_LIMIT = 6000``, classifier.py:L617).
        outcome_transcript_clip: How the outcome prompt cuts the transcript
            sample to ``outcome_transcript_max_chars``. The default,
            ``PreviewClip.HEAD_TAIL``, is Hermes
            ``_clip_head_tail(transcript, _EVAL_TRANSCRIPT_LIMIT)`` at
            classifier.py:L1354 at 44bad57; ``PreviewClip.HEAD`` restores the
            head-only cut. The clip is configuration, not an outcome prompt
            version, so the outcome version keeps matching Hermes
            ``PROMPT_VERSION = 1`` (ADR 0042 decision 4).
        outcome_prompt_version: The outcome prompt template version. The
            outcome prompt builder rejects a version it does not know
            (ADR 0022 decision 5).

    Every job field is prefixed ``job_`` and every outcome field
    ``outcome_``, so no task field changes name or default (research
    Pitfall 6).
    """

    task_timeout_seconds: float = 20.0
    taxonomy_timeout_seconds: float = 5.0
    recorder_timeout_seconds: float = 5.0
    max_tokens: int = 64
    temperature: float = 0.0
    preview_max_chars: int = 800
    labels_block_max_chars: int = 1024
    host_display_name: str = "Hermes"
    job_timeout_seconds: float = 20.0
    job_max_tokens: int = 512
    job_temperature: float = 0.0
    job_labels_block_max_chars: int = 1024
    job_prompt_version: int = 3
    outcome_timeout_seconds: float = 15.0
    outcome_max_tokens: int = 512
    outcome_temperature: float = 0.0
    outcome_transcript_max_chars: int = 6000
    outcome_transcript_clip: PreviewClip = PreviewClip.HEAD_TAIL
    outcome_prompt_version: int = 1

    def __post_init__(self) -> None:
        """Reject values the engine or prompt builder cannot honor.

        Raises:
            ConfigurationError: If any field has the wrong type or range.
        """
        for name in (
            "task_timeout_seconds",
            "taxonomy_timeout_seconds",
            "recorder_timeout_seconds",
            "job_timeout_seconds",
            "outcome_timeout_seconds",
        ):
            value = getattr(self, name)
            if not _is_real(value) or not math.isfinite(value) or value <= 0:
                raise ConfigurationError(
                    f"{name} must be a finite number greater than 0, got {value!r}"
                )
        for name in (
            "max_tokens",
            "preview_max_chars",
            "labels_block_max_chars",
            "job_max_tokens",
            "job_labels_block_max_chars",
            "job_prompt_version",
            "outcome_max_tokens",
            "outcome_transcript_max_chars",
            "outcome_prompt_version",
        ):
            value = getattr(self, name)
            if type(value) is not int or value < 1:
                raise ConfigurationError(
                    f"{name} must be an int of at least 1, got {value!r}"
                )
        for name in ("temperature", "job_temperature", "outcome_temperature"):
            temperature = getattr(self, name)
            if (
                not _is_real(temperature)
                or not math.isfinite(temperature)
                or temperature < 0
            ):
                raise ConfigurationError(
                    f"{name} must be a finite number of at least 0, got {temperature!r}"
                )
        clip = self.outcome_transcript_clip
        if type(clip) is not PreviewClip:
            raise ConfigurationError(
                f"outcome_transcript_clip must be a PreviewClip, got {clip!r}"
            )
        host = self.host_display_name
        if type(host) is not str or not is_bounded_printable(
            host, _HOST_DISPLAY_NAME_MAX_BYTES
        ):
            raise ConfigurationError(
                "host_display_name must be non-empty printable text within "
                f"{_HOST_DISPLAY_NAME_MAX_BYTES} serialized bytes, got {host!r}"
            )


def _is_real(value: object) -> bool:
    return type(value) is int or type(value) is float
