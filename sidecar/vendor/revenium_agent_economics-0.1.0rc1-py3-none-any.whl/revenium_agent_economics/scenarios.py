"""Record types for conformance scenarios and their results (ADR 0037, D-24).

A :class:`Scenario` is Python-constructed data: a host-shaped stream held as
canonical JSON texts, the inference cuts, the taxonomies, the scripted model
texts, a named policy preset, the clock and id seeds, and typed
:class:`ScenarioExpectation` values (D-01). The records hold data only. The
runner, the fakes, the host-shape adapters, and the scenario instances live in
``revenium_agent_economics.conformance`` (ADR 0037 decision 1).

This module sits at layer 12, above ``metrics`` and below ``serialization``,
so ``serialization`` can register every record here in ``SCHEMA_IDS`` without
the core importing the kit. It imports none of ``engine``,
``host_protocols``, ``serialization``, ``streams``, or ``conformance`` (ADR
0037 decision 9).

Raw host payloads are stored as canonical JSON texts, never as mutable
objects, so a scenario stays frozen all the way down (FOUND-03).
"""

import enum
import re
from dataclasses import dataclass
from datetime import datetime
from typing import ClassVar, Final

from revenium_agent_economics._bounded import (
    NARRATIVE_CLAMP_BYTES,
    is_bounded_printable,
    serialized_byte_length,
)
from revenium_agent_economics._canonical import parse_json_strict
from revenium_agent_economics.assessment import _require_normalized
from revenium_agent_economics.corrections import _require_bounded_identifier
from revenium_agent_economics.errors import CanonicalizationError, RecordValidationError
from revenium_agent_economics.jobs import DoubleCountingScope
from revenium_agent_economics.primitives import (
    _require_exact_type,
    _require_text,
    _require_tuple_of,
)
from revenium_agent_economics.tasks import _require_utc
from revenium_agent_economics.taxonomy import is_valid_label

# ADR 0037 decision 3: a scenario name is [a-z0-9_], non-empty, at most 64
# bytes. The text is ASCII, so bytes and characters agree.
SCENARIO_NAME_MAX_BYTES: Final = 64
# ADR 0037 decision 3: each expectation value is at most 200 serialized bytes.
EXPECTATION_VALUE_MAX_BYTES: Final = 200
# ADR 0037 decision 3 says "bounded text" for scripted model texts without a
# number. 16 KiB holds any scripted job or outcome response a scenario needs.
MODEL_RESPONSE_MAX_BYTES: Final = 16384
_SCENARIO_NAME: Final = re.compile(
    rf"[a-z0-9_]{{1,{SCENARIO_NAME_MAX_BYTES}}}", re.ASCII
)


class HostShape(enum.Enum):
    """The host stream shape a scenario is written in (ADR 0037 decision 2)."""

    CLAUDE_CODE = "claude_code"
    HERMES = "hermes"


class JobSource(enum.Enum):
    """Where a scenario's job boundaries come from (ADR 0037 decision 2).

    ``KEYWORD_SEGMENTER`` uses the kit's keyword reference segmenter.
    ``SCRIPTED_MODEL`` sends segmentation to the scenario's scripted model
    texts.
    """

    KEYWORD_SEGMENTER = "keyword_segmenter"
    SCRIPTED_MODEL = "scripted_model"


class PolicyPreset(enum.Enum):
    """A named policy configuration for a scenario (ADR 0037 decision 2).

    ``AssessmentPolicy`` is configuration, not a schema record, so a scenario
    names a preset instead of holding one. ``DEFAULT`` means the default
    ``AssessmentPolicy``, one ``conformance-1`` USD ``EconomicsContract`` per
    job label with the four required metrics, and the default
    ``MetricsPolicy``.
    """

    DEFAULT = "default"


class ExpectationKind(enum.Enum):
    """What one scenario expectation checks (ADR 0037 decision 2).

    ADR 0037 decision 2 defines how the runner computes each kind's actual
    values. Every value is text.
    """

    JOB_COUNT = "job_count"
    JOB_TYPES = "job_types"
    JOB_OUTCOMES = "job_outcomes"
    ATTRIBUTION_BASES = "attribution_bases"
    SUPERSEDED_COUNT = "superseded_count"
    TASK_DECISION = "task_decision"
    SESSION_ORIGINS = "session_origins"
    DELEGATION_MODES = "delegation_modes"
    LINEAGE_ROOT_COUNT = "lineage_root_count"
    DOUBLE_COUNTING_GROUP_COUNT = "double_counting_group_count"
    REPORTABILITY = "reportability"
    VALUE_STATES = "value_states"
    METRIC_OUTCOMES = "metric_outcomes"
    MODEL_CALL_COUNT = "model_call_count"
    INVARIANT_WITHOUT_EVENT = "invariant_without_event"
    REPLAY_INVARIANT = "replay_invariant"
    DEDUPE_COLLISION_COUNT = "dedupe_collision_count"


def _require_scenario_name(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, str, schema_id, field)
    if _SCENARIO_NAME.fullmatch(str(value)) is None:
        raise RecordValidationError(
            schema_id,
            field,
            "must be non-empty [a-z0-9_] text of at most "
            f"{SCENARIO_NAME_MAX_BYTES} bytes",
        )


def _require_expectation_values(
    value: tuple[str, ...], schema_id: str, field: str
) -> None:
    _require_tuple_of(value, str, schema_id, field)
    for index, item in enumerate(value):
        if not is_bounded_printable(item, EXPECTATION_VALUE_MAX_BYTES):
            raise RecordValidationError(
                schema_id,
                field,
                f"element {index} must be non-empty printable text of at most "
                f"{EXPECTATION_VALUE_MAX_BYTES} serialized bytes",
            )


def _require_canonical_objects(
    value: tuple[str, ...], schema_id: str, field: str
) -> None:
    # Each element must be the canonical_json text of a JSON object, so the
    # record holds immutable text and never a mutable payload (FOUND-03).
    _require_tuple_of(value, str, schema_id, field)
    for index, item in enumerate(value):
        if not item.isascii():
            raise RecordValidationError(
                schema_id, field, f"element {index} is not canonical JSON text"
            )
        try:
            decoded = parse_json_strict(item.encode("ascii"))
        except CanonicalizationError as error:
            raise RecordValidationError(
                schema_id,
                field,
                f"element {index} is not canonical JSON text: {error}",
            ) from error
        if type(decoded) is not dict:
            raise RecordValidationError(
                schema_id, field, f"element {index} must decode to a JSON object"
            )


def _require_labels(value: tuple[str, ...], schema_id: str, field: str) -> None:
    _require_tuple_of(value, str, schema_id, field)
    if not value:
        raise RecordValidationError(schema_id, field, "must not be empty")
    for index, label in enumerate(value):
        if not is_valid_label(label):
            raise RecordValidationError(
                schema_id, field, f"element {index} fails the label grammar"
            )
    if len(set(value)) != len(value):
        raise RecordValidationError(schema_id, field, "labels must be unique")


def _require_inference_cuts(
    cuts: tuple[int, ...], stream_length: int, schema_id: str
) -> None:
    _require_tuple_of(cuts, int, schema_id, "inference_cuts")
    if not cuts:
        raise RecordValidationError(schema_id, "inference_cuts", "must not be empty")
    previous = 0
    for cut in cuts:
        if cut <= previous:
            raise RecordValidationError(
                schema_id,
                "inference_cuts",
                "must be strictly increasing prefix lengths of at least 1",
            )
        previous = cut
    if cuts[-1] != stream_length:
        raise RecordValidationError(
            schema_id,
            "inference_cuts",
            f"the last cut must equal len(host_stream), {stream_length}",
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class ScenarioExpectation:
    """One typed expectation of a scenario (ADR 0037 decision 3).

    Attributes:
        kind: What the expectation checks.
        values: The expected values as text, each non-empty printable text of
            at most 200 serialized bytes. Empty exactly for
            ``REPLAY_INVARIANT``, which carries no expected values.
    """

    SCHEMA_ID: ClassVar[str] = "rae.scenario_expectation"
    SCHEMA_VERSION: ClassVar[int] = 1

    kind: ExpectationKind
    values: tuple[str, ...]

    def __post_init__(self) -> None:
        """Validate the kind and the values.

        Raises:
            RecordValidationError: If either field is invalid, or the values
                are empty for any kind but ``REPLAY_INVARIANT`` or non-empty
                for it.
        """
        schema_id = ScenarioExpectation.SCHEMA_ID
        _require_exact_type(self.kind, ExpectationKind, schema_id, "kind")
        _require_expectation_values(self.values, schema_id, "values")
        if (not self.values) != (self.kind is ExpectationKind.REPLAY_INVARIANT):
            raise RecordValidationError(
                schema_id,
                "values",
                "must be empty exactly for REPLAY_INVARIANT",
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class Scenario:
    """One synthetic conformance scenario (ADR 0037 decision 3, D-01, D-24).

    Attributes:
        name: The scenario name, non-empty ``[a-z0-9_]`` text of at most 64
            bytes.
        host_shape: The host stream shape.
        summary: What the scenario proves, normalized text of at most 500
            serialized bytes.
        host_stream: The raw host payloads, each the ``canonical_json`` text
            of a JSON object. Non-empty.
        inference_cuts: Strictly increasing prefix lengths of ``host_stream``,
            each at least 1. The last equals ``len(host_stream)``.
        task_labels: The task taxonomy labels, non-empty and unique.
        job_labels: The job taxonomy labels, non-empty and unique.
        taxonomy_version: The taxonomy version, non-empty printable text of
            at most 128 serialized bytes.
        job_source: Where the job boundaries come from.
        model_responses: The scripted model texts in call order, each at most
            16384 serialized bytes. Empty when the scenario makes no model
            call.
        policy: The named policy preset.
        reportable_evidence: Whether the evidence decider answers reportable
            and the evidence is confirmed.
        clock_start: The fixed clock's first instant, an aware UTC datetime.
        id_start: The sequential id generator's first value, at least 0.
        expectations: The typed expectations, non-empty.
        double_counting_scope: The scope every job inference request uses
            (ADR 0044). The canonical form omits the default, ``INFERENCE``.
    """

    SCHEMA_ID: ClassVar[str] = "rae.scenario"
    SCHEMA_VERSION: ClassVar[int] = 1

    name: str
    host_shape: HostShape
    summary: str
    host_stream: tuple[str, ...]
    inference_cuts: tuple[int, ...]
    task_labels: tuple[str, ...]
    job_labels: tuple[str, ...]
    taxonomy_version: str
    job_source: JobSource
    model_responses: tuple[str, ...]
    policy: PolicyPreset
    reportable_evidence: bool
    clock_start: datetime
    id_start: int
    expectations: tuple[ScenarioExpectation, ...]
    double_counting_scope: DoubleCountingScope = DoubleCountingScope.INFERENCE

    def __post_init__(self) -> None:
        """Validate every field.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = Scenario.SCHEMA_ID
        _require_scenario_name(self.name, schema_id, "name")
        _require_exact_type(self.host_shape, HostShape, schema_id, "host_shape")
        _require_normalized(self.summary, schema_id, "summary", NARRATIVE_CLAMP_BYTES)
        _require_canonical_objects(self.host_stream, schema_id, "host_stream")
        if not self.host_stream:
            raise RecordValidationError(schema_id, "host_stream", "must not be empty")
        _require_inference_cuts(self.inference_cuts, len(self.host_stream), schema_id)
        _require_labels(self.task_labels, schema_id, "task_labels")
        _require_labels(self.job_labels, schema_id, "job_labels")
        _require_bounded_identifier(
            self.taxonomy_version, schema_id, "taxonomy_version"
        )
        _require_exact_type(self.job_source, JobSource, schema_id, "job_source")
        _require_tuple_of(self.model_responses, str, schema_id, "model_responses")
        for index, response in enumerate(self.model_responses):
            if serialized_byte_length(response) > MODEL_RESPONSE_MAX_BYTES:
                raise RecordValidationError(
                    schema_id,
                    "model_responses",
                    f"element {index} exceeds {MODEL_RESPONSE_MAX_BYTES} "
                    "serialized bytes",
                )
        _require_exact_type(self.policy, PolicyPreset, schema_id, "policy")
        _require_exact_type(
            self.reportable_evidence, bool, schema_id, "reportable_evidence"
        )
        _require_utc(self.clock_start, schema_id, "clock_start")
        _require_exact_type(self.id_start, int, schema_id, "id_start")
        if self.id_start < 0:
            raise RecordValidationError(
                schema_id, "id_start", f"must be at least 0, got {self.id_start!r}"
            )
        _require_tuple_of(
            self.expectations, ScenarioExpectation, schema_id, "expectations"
        )
        if not self.expectations:
            raise RecordValidationError(schema_id, "expectations", "must not be empty")
        _require_exact_type(
            self.double_counting_scope,
            DoubleCountingScope,
            schema_id,
            "double_counting_scope",
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class ExpectationVerdict:
    """The verdict on one scenario expectation (ADR 0037 decision 3).

    Attributes:
        kind: The expectation kind the verdict is about.
        expected: The expected values, each non-empty printable text of at
            most 200 serialized bytes.
        actual: The values the run produced, under the same rule.
        passed: Whether ``expected == actual``. The record refuses any other
            value, so a verdict can never claim a pass it did not earn.
    """

    SCHEMA_ID: ClassVar[str] = "rae.expectation_verdict"
    SCHEMA_VERSION: ClassVar[int] = 1

    kind: ExpectationKind
    expected: tuple[str, ...]
    actual: tuple[str, ...]
    passed: bool

    def __post_init__(self) -> None:
        """Validate every field and the passed flag.

        Raises:
            RecordValidationError: If any field is invalid, or ``passed``
                differs from ``expected == actual``.
        """
        schema_id = ExpectationVerdict.SCHEMA_ID
        _require_exact_type(self.kind, ExpectationKind, schema_id, "kind")
        _require_expectation_values(self.expected, schema_id, "expected")
        _require_expectation_values(self.actual, schema_id, "actual")
        _require_exact_type(self.passed, bool, schema_id, "passed")
        if self.passed != (self.expected == self.actual):
            raise RecordValidationError(
                schema_id, "passed", "must equal expected == actual"
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class ScenarioResult:
    """The outcome of running one scenario (ADR 0037 decision 3, CONF-05).

    ``encode_record`` of a result is the run's bytes, so two runs of the same
    scenario must encode identically.

    Attributes:
        scenario: The scenario name, under the ``Scenario.name`` rule.
        host_shape: The host shape the scenario ran in.
        records: The ``canonical_json`` text of every decision record the
            run produced, in chain order. Each text decodes to a JSON object,
            so the result holds no mutable record.
        verdicts: One verdict per expectation, in the scenario's expectation
            order. Non-empty, because a scenario has at least one
            expectation.
        passed: Whether every verdict passed. The record refuses any other
            value.
        library_version: The library version that ran the scenario.
    """

    SCHEMA_ID: ClassVar[str] = "rae.scenario_result"
    SCHEMA_VERSION: ClassVar[int] = 1

    scenario: str
    host_shape: HostShape
    records: tuple[str, ...]
    verdicts: tuple[ExpectationVerdict, ...]
    passed: bool
    library_version: str

    def __post_init__(self) -> None:
        """Validate every field and the passed flag.

        Raises:
            RecordValidationError: If any field is invalid, ``verdicts`` is
                empty, or ``passed`` differs from every verdict passing.
        """
        schema_id = ScenarioResult.SCHEMA_ID
        _require_scenario_name(self.scenario, schema_id, "scenario")
        _require_exact_type(self.host_shape, HostShape, schema_id, "host_shape")
        _require_canonical_objects(self.records, schema_id, "records")
        _require_tuple_of(self.verdicts, ExpectationVerdict, schema_id, "verdicts")
        if not self.verdicts:
            raise RecordValidationError(schema_id, "verdicts", "must not be empty")
        _require_exact_type(self.passed, bool, schema_id, "passed")
        if self.passed != all(verdict.passed for verdict in self.verdicts):
            raise RecordValidationError(
                schema_id, "passed", "must equal every verdict passing"
            )
        _require_text(self.library_version, schema_id, "library_version")
