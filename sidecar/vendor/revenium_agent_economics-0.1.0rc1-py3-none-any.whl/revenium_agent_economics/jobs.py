"""The job prompt as data, the pure job parser and validator, and job records.

The engine and a sync host call the same :func:`build_job_prompt` and
:func:`parse_job_response`, so both render and decide identical bytes (D-24,
ADR 0018 decision 10). The version 1 template renders byte-identically to the
Hermes job prompt at ``5c2bfea8`` (D-22, ADR 0019), and version 3, the default,
to the head-and-tail clipped prompt at ``44bad57`` (ADR 0042).

A model or segmenter answer becomes one :class:`JobInference`. Every proposal
is accounted for as exactly one :class:`JobCandidate` or one
:class:`RejectedJobProposal`, and "could not infer" is an abstention that can
never be read as zero jobs (D-11, D-13, ADR 0018).
"""

import enum
import hashlib
import json
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, replace
from datetime import datetime
from types import MappingProxyType
from typing import ClassVar, Final

from revenium_agent_economics._bounded import (
    DOUBLE_COUNTING_GROUP_MAX_BYTES,
    FAILURE_REASON_CLAMP_BYTES,
    IDENTIFIER_MAX_BYTES,
    IFS_CHARACTERS,
    JOB_ID_MAX_BYTES,
    JOB_NAME_MAX_BYTES,
    NARRATIVE_CLAMP_BYTES,
    clamp_bytes,
    is_bounded_printable,
    normalize_text,
    serialized_byte_length,
)
from revenium_agent_economics._canonical import canonical_json
from revenium_agent_economics._version import __version__
from revenium_agent_economics.config import EngineConfig, PreviewClip
from revenium_agent_economics.envelope import (
    ActivityLog,
    DelegationInitiator,
    DelegationMode,
    TextExcerpt,
)
from revenium_agent_economics.errors import ConfigurationError, RecordValidationError
from revenium_agent_economics.lineage import JobSubject, LineageNode, node_of
from revenium_agent_economics.primitives import (
    _require_exact_type,
    _require_text,
    _require_tuple_of,
)
from revenium_agent_economics.protocols import (
    CompletionMessage,
    CompletionPurpose,
    CompletionRequest,
    ComponentDeclaration,
    IdGenerator,
    MessageRole,
)
from revenium_agent_economics.protocols import _require_job_id as _require_job_id
from revenium_agent_economics.tasks import (
    _SLOT,
    InferenceProvenance,
    PromptRef,
    _render,
    _require_subject_ref,
    _require_utc,
    _resolve_host_display_name,
)
from revenium_agent_economics.taxonomy import (
    ClassificationAbstentionReason,
    JobTaxonomySnapshot,
    LabelProposal,
    TaxonomyNamespace,
    TaxonomyRef,
    is_valid_label,
    validate_label,
)
from revenium_agent_economics.vocab import (
    TRIVIAL_LABELS,
    UNCLASSIFIED_LABEL,
    EvidenceClass,
)


class JobOutcome(enum.Enum):
    """How an inferred job ended (D-01, ADR 0014).

    The three Hermes statuses keep their uppercase wire literals. A
    model-reported ``CANCELLED`` is recorded as ``UNRESOLVED``, so with prompt
    version 1 ``UNRESOLVED`` means "the model said CANCELLED", not "the work
    was abandoned". ``CANCELLED`` is reserved for host lifecycle evidence, and
    no Phase 3 path produces it.
    """

    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    UNRESOLVED = "UNRESOLVED"


class JobRejectionReason(enum.Enum):
    """Why one job proposal was rejected (D-16, ADR 0018 decision 5).

    The members follow the Hermes check order: the object, then
    ``agentic_job_id``, then ``job_type``, then ``status``.
    """

    NOT_AN_OBJECT = "not_an_object"
    AGENTIC_JOB_ID_MISSING = "agentic_job_id_missing"
    AGENTIC_JOB_ID_INVALID = "agentic_job_id_invalid"
    JOB_ID_UNSAFE = "job_id_unsafe"
    JOB_TYPE_MISSING = "job_type_missing"
    JOB_TYPE_INVALID_TYPE = "job_type_invalid_type"
    JOB_TYPE_EMPTY = "job_type_empty"
    JOB_TYPE_TRIVIAL = "job_type_trivial"
    JOB_TYPE_REJECTED = "job_type_rejected"
    JOB_TYPE_RESERVED = "job_type_reserved"
    STATUS_MISSING = "status_missing"
    STATUS_INVALID_TYPE = "status_invalid_type"
    STATUS_UNKNOWN = "status_unknown"


class JobInferenceAbstentionReason(enum.Enum):
    """Why a job inference produced no proposals at all (D-11, ADR 0018).

    A plain ``Enum``, separate from the task reasons, so a job reason can
    never be mistaken for a task reason or a label.
    """

    ABSTAINED = "abstained"
    EMPTY_RESPONSE = "empty_response"
    UNPARSEABLE = "unparseable"
    UNAVAILABLE = "unavailable"
    TIMED_OUT = "timed_out"
    NOT_CONFIGURED = "not_configured"
    TAXONOMY_UNAVAILABLE = "taxonomy_unavailable"


JOB_MODEL_SIDE_REASONS: Final[frozenset[JobInferenceAbstentionReason]] = frozenset(
    {
        JobInferenceAbstentionReason.ABSTAINED,
        JobInferenceAbstentionReason.EMPTY_RESPONSE,
        JobInferenceAbstentionReason.UNPARSEABLE,
    }
)
JOB_PROVIDER_SIDE_REASONS: Final[frozenset[JobInferenceAbstentionReason]] = frozenset(
    {
        JobInferenceAbstentionReason.UNAVAILABLE,
        JobInferenceAbstentionReason.TIMED_OUT,
        JobInferenceAbstentionReason.NOT_CONFIGURED,
        JobInferenceAbstentionReason.TAXONOMY_UNAVAILABLE,
    }
)


class AttributionBasis(enum.Enum):
    """How a candidate came to exist (ADR 0018 decisions 3 and 11).

    ``INFERRED`` candidates come from one model or segmenter proposal.
    ``LINEAGE_ROOT`` candidates attach delegated work to its root's job.
    """

    INFERRED = "inferred"
    LINEAGE_ROOT = "lineage_root"


class DoubleCountingScope(enum.Enum):
    """Which candidates of one inference share a double-counting group.

    ``INFERENCE``, the default, gives every candidate of one inference the
    resolved group (ADR 0020 decision 1). ``JOB`` gives each job a group of
    its own, keyed on the resolved group and the job's label base, so a job
    and its revisions stay grouped while unrelated jobs do not (ADR 0044).
    The host chooses ``JOB`` when the jobs of one session serve independent
    outcomes.
    """

    INFERENCE = "inference"
    JOB = "job"


_SYSTEM_SLOTS: Final = ("host_display_name",)
_USER_SLOTS: Final = ("host_display_name", "labels", "transcript_preview")
_NO_LABELS: Final = "(no existing labels yet)"
_TRUNCATED: Final = " ... [truncated]"
# Hermes classifier.py:L490 at 5c2bfea8; ADR 0019 decision 2. Byte-identical to
# _TRANSCRIPT_ELISION_MARKER (classifier.py:L589 at 44bad57; ADR 0042 decision 2).
_SAMPLE_MARKER: Final = "\n... [transcript truncated \u2014 middle omitted] ...\n"
_SUFFIX: Final = re.compile(r"[0-9a-f]{4}")
# ADR 0017 decision 1: the label is cut so label + "_" + 4 hex fits 64 bytes.
_JOB_LABEL_MAX_CHARS: Final = JOB_ID_MAX_BYTES - 5
_KEPT_ID_CHARACTERS: Final = frozenset("abcdefghijklmnopqrstuvwxyz0123456789_-")
_IDENTITY_CHARACTERS: Final = frozenset("abcdefghijklmnopqrstuvwxyz0123456789")
_UNSAFE_RAW_IDS: Final = frozenset({".", ".."})
# Hermes classifier.py:L1281-L1283; CANCELLED maps to UNRESOLVED (ADR 0014).
_STATUS_OUTCOMES: Final[Mapping[str, JobOutcome]] = MappingProxyType(
    {
        "SUCCESS": JobOutcome.SUCCESS,
        "FAILED": JobOutcome.FAILED,
        "CANCELLED": JobOutcome.UNRESOLVED,
    }
)
_LABEL_REJECTIONS: Final[
    Mapping[ClassificationAbstentionReason, JobRejectionReason]
] = MappingProxyType(
    {
        ClassificationAbstentionReason.INVALID_LABEL_TYPE: (
            JobRejectionReason.JOB_TYPE_INVALID_TYPE
        ),
        ClassificationAbstentionReason.EMPTY_RESPONSE: (
            JobRejectionReason.JOB_TYPE_EMPTY
        ),
        ClassificationAbstentionReason.LABEL_TRIVIAL: (
            JobRejectionReason.JOB_TYPE_TRIVIAL
        ),
        ClassificationAbstentionReason.LABEL_REJECTED: (
            JobRejectionReason.JOB_TYPE_REJECTED
        ),
    }
)
_NO_TAXONOMY_REASONS: Final[frozenset[JobInferenceAbstentionReason]] = frozenset(
    {
        JobInferenceAbstentionReason.NOT_CONFIGURED,
        JobInferenceAbstentionReason.TAXONOMY_UNAVAILABLE,
    }
)
_MISSING_REPR: Final = "<missing>"
_REPR_STR_MAX_CHARS: Final = 1000
# repr() of an int this size is at most 309 digits, below every limit
# sys.set_int_max_str_digits accepts, so it can never raise.
_REPR_INT_MAX_BITS: Final = 1024


@dataclass(frozen=True, slots=True, kw_only=True)
class JobPromptTemplate:
    """A versioned job prompt held as data (D-22, ADR 0019 decision 1).

    Slots are written ``{{name}}``. The system text has exactly the
    ``host_display_name`` slot, and the user text has exactly the
    ``host_display_name``, ``labels``, and ``transcript_preview`` slots, each
    once. The preview limit and clip are part of the template, so they are
    covered by the hash (A-12, ADR 0042 decision 3). This is configuration,
    not a schema record.

    Attributes:
        name: The template family name.
        version: The prompt version, at least 1.
        system: The system message template.
        user: The user message template.
        transcript_preview_max_chars: How many characters of the transcript
            sample the prompt keeps, at least 1.
        transcript_preview_clip: How the sample is cut to that limit:
            ``PreviewClip.HEAD`` keeps the first characters, and
            ``PreviewClip.HEAD_TAIL`` keeps one third head and two thirds tail
            around the elision marker (ADR 0042 decision 2).
    """

    name: str
    version: int
    system: str
    user: str
    transcript_preview_max_chars: int
    transcript_preview_clip: PreviewClip = PreviewClip.HEAD

    def __post_init__(self) -> None:
        """Validate the name, version, slot sets, preview limit, and clip.

        Raises:
            ConfigurationError: If any field is invalid.
        """
        if type(self.name) is not str or self.name == "":
            raise ConfigurationError(f"name must be non-empty text, got {self.name!r}")
        if type(self.version) is not int or self.version < 1:
            raise ConfigurationError(
                f"version must be an int of at least 1, got {self.version!r}"
            )
        for field, text, expected in (
            ("system", self.system, _SYSTEM_SLOTS),
            ("user", self.user, _USER_SLOTS),
        ):
            if type(text) is not str:
                raise ConfigurationError(f"{field} must be text, got {text!r}")
            found = tuple(sorted(_SLOT.findall(text)))
            if found != expected:
                raise ConfigurationError(
                    f"{field} must use each of the slots {expected!r} exactly once, "
                    f"found {found!r}"
                )
        limit = self.transcript_preview_max_chars
        if type(limit) is not int or limit < 1:
            raise ConfigurationError(
                "transcript_preview_max_chars must be an int of at least 1, "
                f"got {limit!r}"
            )
        clip = self.transcript_preview_clip
        if type(clip) is not PreviewClip:
            raise ConfigurationError(
                f"transcript_preview_clip must be a PreviewClip, got {clip!r}"
            )

    @property
    def template_hash(self) -> str:
        """The lowercase hexadecimal SHA-256 of the template, limit, and clip.

        The payload names the clip only when it is not ``PreviewClip.HEAD``, so
        the pinned version 1 and version 2 hashes are unchanged (ADR 0042
        decision 3).
        """
        payload: dict[str, str | int] = {
            "name": self.name,
            "system": self.system,
            "transcript_preview_max_chars": self.transcript_preview_max_chars,
            "user": self.user,
        }
        if self.transcript_preview_clip is not PreviewClip.HEAD:
            payload["transcript_preview_clip"] = self.transcript_preview_clip.value
        return hashlib.sha256(canonical_json(payload)).hexdigest()

    def render_system(self, host_display_name: str) -> str:
        """Render the system message.

        Args:
            host_display_name: The host name for the ``host_display_name`` slot.

        Returns:
            The system message text.
        """
        return _render(self.system, {"host_display_name": host_display_name})

    def render_user(
        self, *, host_display_name: str, labels: str, transcript_preview: str
    ) -> str:
        """Render the user message.

        Args:
            host_display_name: The host name.
            labels: The rendered job label list.
            transcript_preview: The transcript sample, already cut to the
                template's preview limit with its clip.

        Returns:
            The user message text.
        """
        return _render(
            self.user,
            {
                "host_display_name": host_display_name,
                "labels": labels,
                "transcript_preview": transcript_preview,
            },
        )


JOB_PROMPT_NAME: Final = "job_inference"

# Hermes classifier.py:L840-L841 (system) and the string content of
# L530-L556 (user, without the comment lines L534-L537) at
# 5c2bfea8f9013e7b4521eb2153e62bd435d2bc17, with "Hermes" replaced by the
# host_display_name slot and the two interpolations replaced by slots.
JOB_PROMPT_V1: Final[JobPromptTemplate] = JobPromptTemplate(
    name=JOB_PROMPT_NAME,
    version=1,
    system=(
        "You analyze {{host_display_name}} agent session transcripts to identify "
        "completed task arcs. Output only a JSON array."
    ),
    user=(
        "You are analyzing a {{host_display_name}} AI agent session to identify "
        "the discrete task arcs completed by the agent. A task arc is a "
        "goal-directed sequence of turns with a single objective; follow-up "
        "fixes to the same goal are part of the same arc.\n\n"
        "Output ONLY a JSON array of job objects. Each object must have:\n"
        "  - agentic_job_id: a SPECIFIC, DESCRIPTIVE snake_case business label "
        "naming the concrete work, not its category (2-4 words joined by "
        "underscores)\n"
        "  - job_name: a short human-readable name (sentence case, max 60 chars)\n"
        "  - job_type: a snake_case category label matching "
        "^[a-z][a-z0-9_]{1,47}$\n"
        "  - status: one of SUCCESS, FAILED, or CANCELLED\n"
        "  - failure_reason: ONLY when status is FAILED, a brief (max ~200 char) "
        "plain-text explanation of what went wrong (e.g. 'tests failed: 3 "
        "assertion errors in auth module'). OMIT this field for SUCCESS and "
        "CANCELLED.\n\n"
        "Status guidance:\n"
        "  SUCCESS: only when there is clear evidence the goal was achieved.\n"
        "  FAILED: only when there is explicit evidence of failure. Always "
        "include failure_reason.\n"
        "  CANCELLED: use when uncertain — this is the uncertainty-bias "
        "catch-all.\n\n"
        "Mint a SPECIFIC agentic_job_id. You MAY reuse one of the existing "
        "job_type labels, but only if it is an exact match. If no existing "
        "label fits, mint a new one.\n\n"
        "Existing job_type labels (for reference): {{labels}}\n\n"
        "Session transcript:\n{{transcript_preview}}\n\n"
        "JSON array:"
    ),
    transcript_preview_max_chars=6000,
)
# ADR 0019 decision 3: the version 1 text with a preview that keeps the whole
# default 8000-character sample, so the tail reaches the model. Opt-in.
JOB_PROMPT_V2: Final[JobPromptTemplate] = JobPromptTemplate(
    name=JOB_PROMPT_NAME,
    version=2,
    system=JOB_PROMPT_V1.system,
    user=JOB_PROMPT_V1.user,
    transcript_preview_max_chars=8000,
)
# ADR 0042 decision 3: the version 1 text with the 6000-character preview
# clipped head and tail, as Hermes classifier.py:L638 at 44bad57 does. Default.
JOB_PROMPT_V3: Final[JobPromptTemplate] = JobPromptTemplate(
    name=JOB_PROMPT_NAME,
    version=3,
    system=JOB_PROMPT_V1.system,
    user=JOB_PROMPT_V1.user,
    transcript_preview_max_chars=6000,
    transcript_preview_clip=PreviewClip.HEAD_TAIL,
)
DEFAULT_JOB_PROMPT: Final[JobPromptTemplate] = JOB_PROMPT_V3
JOB_PROMPTS: Final[Mapping[tuple[str, int], JobPromptTemplate]] = MappingProxyType(
    {
        (JOB_PROMPT_NAME, 1): JOB_PROMPT_V1,
        (JOB_PROMPT_NAME, 2): JOB_PROMPT_V2,
        (JOB_PROMPT_NAME, 3): JOB_PROMPT_V3,
    }
)
JOB_PROMPT_HASHES: Final[Mapping[tuple[str, int], str]] = MappingProxyType(
    {
        (JOB_PROMPT_NAME, 1): JOB_PROMPT_V1.template_hash,
        (JOB_PROMPT_NAME, 2): JOB_PROMPT_V2.template_hash,
        (JOB_PROMPT_NAME, 3): JOB_PROMPT_V3.template_hash,
    }
)

# The Hermes "llm" registrant serves both the task and the job path
# (classifier.py:L1038, L1098-L1099); ADR 0018 decision 7.
BUILTIN_JOB_SEGMENTER: Final[ComponentDeclaration] = ComponentDeclaration(
    name="llm", version="1", evidence_class=EvidenceClass.MODEL_ESTIMATED
)


def _require_clamped_text(
    value: object, schema_id: str, field: str, max_bytes: int
) -> None:
    _require_text(value, schema_id, field)
    text = str(value)
    if (
        any(character in text for character in IFS_CHARACTERS)
        or serialized_byte_length(text) > max_bytes
    ):
        raise RecordValidationError(
            schema_id,
            field,
            f"must have no IFS characters and be at most {max_bytes} serialized bytes",
        )


def _require_members(
    value: tuple[LineageNode, ...], schema_id: str, field: str
) -> None:
    _require_tuple_of(value, LineageNode, schema_id, field)
    keys = [member.sort_key for member in value]
    if not keys or keys != sorted(set(keys)):
        raise RecordValidationError(
            schema_id,
            field,
            "must be non-empty and sorted by sort_key without duplicates",
        )


def _require_job_taxonomy(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, TaxonomyRef, schema_id, field)
    if (
        not isinstance(value, TaxonomyRef)
        or value.namespace is not TaxonomyNamespace.JOB
    ):
        raise RecordValidationError(schema_id, field, "must reference a job taxonomy")


@dataclass(frozen=True, slots=True, kw_only=True)
class JobBoundary:
    """Where one job sits: its identity and the lineage scope it covers (D-12).

    Attributes:
        job_id: The normalized label, ``"_"``, and a 4-digit suffix from the
            injected ``IdGenerator`` (ADR 0017). At most 64 bytes, from
            ``[a-z0-9_-]``, never starting with ``-``.
        job_name: Display text, normalized and clamped to 200 serialized
            bytes. ``""`` when the proposal had none.
        root: The lineage root of the inferred subject.
        members: The lineage nodes in scope, sorted by ``sort_key``, without
            duplicates, and never empty.
        evidence_refs: Dedupe keys of the activity events that bound the job,
            unique and bounded.
        supersedes: The ``job_id`` of the prior candidate this one revises, if
            any. It never equals ``job_id``. :func:`resolve_current` resolves
            it to one record of the same lineage scope and job type
            (ADR 0021).
    """

    SCHEMA_ID: ClassVar[str] = "rae.job_boundary"
    SCHEMA_VERSION: ClassVar[int] = 1

    job_id: str
    job_name: str = ""
    root: LineageNode
    members: tuple[LineageNode, ...]
    evidence_refs: tuple[str, ...] = ()
    supersedes: str | None = None

    def __post_init__(self) -> None:
        """Validate the id grammar, the name bound, and the lineage scope.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = JobBoundary.SCHEMA_ID
        _require_job_id(self.job_id, schema_id, "job_id")
        _require_exact_type(self.job_name, str, schema_id, "job_name")
        if self.job_name != "":
            _require_clamped_text(
                self.job_name, schema_id, "job_name", JOB_NAME_MAX_BYTES
            )
        _require_exact_type(self.root, LineageNode, schema_id, "root")
        _require_members(self.members, schema_id, "members")
        _require_tuple_of(self.evidence_refs, str, schema_id, "evidence_refs")
        for index, ref in enumerate(self.evidence_refs):
            if not is_bounded_printable(ref, IDENTIFIER_MAX_BYTES):
                raise RecordValidationError(
                    schema_id,
                    "evidence_refs",
                    f"element {index} must be non-empty printable text within "
                    f"{IDENTIFIER_MAX_BYTES} serialized bytes",
                )
        if len(set(self.evidence_refs)) != len(self.evidence_refs):
            raise RecordValidationError(
                schema_id, "evidence_refs", "must not repeat a reference"
            )
        if self.supersedes is not None:
            _require_job_id(self.supersedes, schema_id, "supersedes")
            if self.supersedes == self.job_id:
                raise RecordValidationError(
                    schema_id, "supersedes", "must not equal job_id"
                )


@dataclass(frozen=True, slots=True, kw_only=True)
class JobTypeAssignment:
    """The job type label, kept apart from the boundary (D-12, JOB-02).

    Attributes:
        job_type: The validated label. Never trivial and never the reserved
            ``"unclassified"``.
        taxonomy: The job taxonomy the label was chosen against.
        proposal: Set when the label is not in the taxonomy.
    """

    SCHEMA_ID: ClassVar[str] = "rae.job_type_assignment"
    SCHEMA_VERSION: ClassVar[int] = 1

    job_type: str
    taxonomy: TaxonomyRef
    proposal: LabelProposal | None = None

    def __post_init__(self) -> None:
        """Validate the label, the taxonomy namespace, and the proposal.

        Raises:
            RecordValidationError: If any field is invalid or inconsistent.
        """
        schema_id = JobTypeAssignment.SCHEMA_ID
        _require_exact_type(self.job_type, str, schema_id, "job_type")
        if not is_valid_label(self.job_type):
            raise RecordValidationError(
                schema_id, "job_type", "fails the label grammar"
            )
        if self.job_type in TRIVIAL_LABELS or self.job_type == UNCLASSIFIED_LABEL:
            raise RecordValidationError(
                schema_id, "job_type", "must not be trivial or the reserved label"
            )
        _require_job_taxonomy(self.taxonomy, schema_id, "taxonomy")
        if self.proposal is not None:
            _require_exact_type(self.proposal, LabelProposal, schema_id, "proposal")
            if (
                self.proposal.label != self.job_type
                or self.proposal.taxonomy != self.taxonomy
            ):
                raise RecordValidationError(
                    schema_id,
                    "proposal",
                    "must carry the assignment's label and taxonomy",
                )


@dataclass(frozen=True, slots=True, kw_only=True)
class JobCandidate:
    """One inferred or attributed job, revisable by later inferences (D-12).

    Attributes:
        boundary: The job's identity and lineage scope.
        type_assignment: The job's type label.
        outcome: How the job ended.
        failure_reason: Why it failed: set only for ``FAILED``, normalized
            and clamped to 500 serialized bytes (D-02).
        proposal_index: The proposal's index in the answer. Set for
            ``INFERRED`` candidates and ``None`` for ``LINEAGE_ROOT``.
        attribution_basis: Whether the candidate was inferred or attributed
            to its lineage root.
        parent_job_id: The root job an attribution attaches to. Set exactly
            for ``LINEAGE_ROOT``, where it equals ``boundary.job_id``.
        delegation_initiator: Who started the subject's delegated work.
        delegation_mode: How the subject's delegated work ran.
        double_counting_group: The group Phase 5 enforcement will key on,
            clamped to 64 serialized bytes (ADR 0020).
    """

    SCHEMA_ID: ClassVar[str] = "rae.job_candidate"
    SCHEMA_VERSION: ClassVar[int] = 1

    boundary: JobBoundary
    type_assignment: JobTypeAssignment
    outcome: JobOutcome
    failure_reason: str | None = None
    proposal_index: int | None
    attribution_basis: AttributionBasis = AttributionBasis.INFERRED
    parent_job_id: str | None = None
    delegation_initiator: DelegationInitiator = DelegationInitiator.UNKNOWN
    delegation_mode: DelegationMode = DelegationMode.UNKNOWN
    double_counting_group: str | None = None

    def __post_init__(self) -> None:
        """Validate exact types and the outcome and attribution invariants.

        Raises:
            RecordValidationError: If any field is invalid or inconsistent.
        """
        schema_id = JobCandidate.SCHEMA_ID
        _require_exact_type(self.boundary, JobBoundary, schema_id, "boundary")
        _require_exact_type(
            self.type_assignment, JobTypeAssignment, schema_id, "type_assignment"
        )
        _require_exact_type(self.outcome, JobOutcome, schema_id, "outcome")
        if self.failure_reason is not None:
            if self.outcome is not JobOutcome.FAILED:
                raise RecordValidationError(
                    schema_id, "failure_reason", "is set only for a FAILED outcome"
                )
            _require_clamped_text(
                self.failure_reason,
                schema_id,
                "failure_reason",
                FAILURE_REASON_CLAMP_BYTES,
            )
        _require_exact_type(
            self.attribution_basis, AttributionBasis, schema_id, "attribution_basis"
        )
        if self.attribution_basis is AttributionBasis.LINEAGE_ROOT:
            if self.proposal_index is not None or self.parent_job_id is None:
                raise RecordValidationError(
                    schema_id,
                    "attribution_basis",
                    "lineage_root requires parent_job_id and no proposal_index",
                )
            _require_job_id(self.parent_job_id, schema_id, "parent_job_id")
            if self.parent_job_id != self.boundary.job_id:
                raise RecordValidationError(
                    schema_id, "parent_job_id", "must equal boundary.job_id"
                )
        else:
            if self.parent_job_id is not None:
                raise RecordValidationError(
                    schema_id, "parent_job_id", "is set only for lineage_root"
                )
            _require_exact_type(self.proposal_index, int, schema_id, "proposal_index")
            if isinstance(self.proposal_index, int) and self.proposal_index < 0:
                raise RecordValidationError(
                    schema_id, "proposal_index", "must be at least 0"
                )
        _require_exact_type(
            self.delegation_initiator,
            DelegationInitiator,
            schema_id,
            "delegation_initiator",
        )
        _require_exact_type(
            self.delegation_mode, DelegationMode, schema_id, "delegation_mode"
        )
        if self.double_counting_group is not None:
            _require_clamped_text(
                self.double_counting_group,
                schema_id,
                "double_counting_group",
                DOUBLE_COUNTING_GROUP_MAX_BYTES,
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class RejectedJobProposal:
    """A proposal that failed validation, kept visible (D-13, JOB-06).

    Attributes:
        index: The proposal's index in the answer, at least 0.
        reason: The first check it failed.
        value_repr: A bounded repr of the offending value: ``"<missing>"``
            for a missing key, never the raw value itself.
    """

    SCHEMA_ID: ClassVar[str] = "rae.rejected_job_proposal"
    SCHEMA_VERSION: ClassVar[int] = 1

    index: int
    reason: JobRejectionReason
    value_repr: str

    def __post_init__(self) -> None:
        """Validate the index, the reason, and the repr bound.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = RejectedJobProposal.SCHEMA_ID
        _require_exact_type(self.index, int, schema_id, "index")
        if self.index < 0:
            raise RecordValidationError(schema_id, "index", "must be at least 0")
        _require_exact_type(self.reason, JobRejectionReason, schema_id, "reason")
        _require_text(self.value_repr, schema_id, "value_repr")
        if serialized_byte_length(self.value_repr) > NARRATIVE_CLAMP_BYTES:
            raise RecordValidationError(
                schema_id,
                "value_repr",
                f"must be at most {NARRATIVE_CLAMP_BYTES} serialized bytes",
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class JobInferenceAbstention:
    """Why no proposal could be obtained or read (D-11).

    Attributes:
        reason: The abstention reason.
    """

    SCHEMA_ID: ClassVar[str] = "rae.job_inference_abstention"
    SCHEMA_VERSION: ClassVar[int] = 1

    reason: JobInferenceAbstentionReason

    def __post_init__(self) -> None:
        """Validate the reason.

        Raises:
            RecordValidationError: If the reason is not a member.
        """
        _require_exact_type(
            self.reason,
            JobInferenceAbstentionReason,
            JobInferenceAbstention.SCHEMA_ID,
            "reason",
        )

    @property
    def is_model_side(self) -> bool:
        """Whether an answer arrived but held no readable proposals."""
        return self.reason in JOB_MODEL_SIDE_REASONS

    @property
    def is_provider_side(self) -> bool:
        """Whether no answer was obtained."""
        return self.reason in JOB_PROVIDER_SIDE_REASONS


@dataclass(frozen=True, slots=True, kw_only=True)
class JobInference:
    """The result of one job inference, and everything needed to audit it (D-11).

    "Zero jobs found" is empty ``candidates`` with no abstention. "Could not
    infer" is an abstention, which never comes with candidates or rejected
    proposals.

    Attributes:
        candidates: The accepted and attributed jobs.
        rejected: The rejected proposals, in ascending index order.
        abstention: Why nothing could be inferred, if so.
        taxonomy: The job taxonomy read. ``None`` exactly for
            ``NOT_CONFIGURED`` and ``TAXONOMY_UNAVAILABLE``.
        prompt: The prompt, on the model path.
        inference: The completion metadata, once a model result was received.
        segmenter: The component that produced the proposals.
        subject: The lineage scope inferred.
        inferred_at: When the decision was made, from the injected clock.
        subject_ref: The request's subject reference, echoed.
        library_version: The library version that made the decision.
    """

    SCHEMA_ID: ClassVar[str] = "rae.job_inference"
    SCHEMA_VERSION: ClassVar[int] = 1

    candidates: tuple[JobCandidate, ...] = ()
    rejected: tuple[RejectedJobProposal, ...] = ()
    abstention: JobInferenceAbstention | None = None
    taxonomy: TaxonomyRef | None
    prompt: PromptRef | None = None
    inference: InferenceProvenance | None = None
    segmenter: ComponentDeclaration | None = None
    subject: JobSubject
    inferred_at: datetime
    subject_ref: str | None = None
    library_version: str

    def __post_init__(self) -> None:
        """Validate the references, the abstention rule, and index conservation.

        Inferred job ids must be unique: two ``INFERRED`` candidates never
        share a ``job_id``. A ``LINEAGE_ROOT`` attribution shares its head's
        id and is excluded (ADR 0021 decision 2).

        Raises:
            RecordValidationError: If any field is invalid or inconsistent.
        """
        schema_id = JobInference.SCHEMA_ID
        _require_tuple_of(self.candidates, JobCandidate, schema_id, "candidates")
        _require_tuple_of(self.rejected, RejectedJobProposal, schema_id, "rejected")
        if self.abstention is not None:
            _require_exact_type(
                self.abstention, JobInferenceAbstention, schema_id, "abstention"
            )
            if self.candidates or self.rejected:
                raise RecordValidationError(
                    schema_id,
                    "abstention",
                    "must not come with candidates or rejected proposals",
                )
        if self.taxonomy is not None:
            _require_job_taxonomy(self.taxonomy, schema_id, "taxonomy")
        no_taxonomy = (
            self.abstention is not None
            and self.abstention.reason in _NO_TAXONOMY_REASONS
        )
        if (self.taxonomy is None) != no_taxonomy:
            raise RecordValidationError(
                schema_id,
                "taxonomy",
                "must be unset exactly for not_configured and taxonomy_unavailable",
            )
        if self.prompt is not None:
            _require_exact_type(self.prompt, PromptRef, schema_id, "prompt")
            if self.taxonomy is None:
                raise RecordValidationError(schema_id, "prompt", "requires a taxonomy")
        if self.inference is not None:
            _require_exact_type(
                self.inference, InferenceProvenance, schema_id, "inference"
            )
            if self.prompt is None:
                raise RecordValidationError(schema_id, "inference", "requires a prompt")
        if self.segmenter is not None:
            _require_exact_type(
                self.segmenter, ComponentDeclaration, schema_id, "segmenter"
            )
            if self.taxonomy is None:
                raise RecordValidationError(
                    schema_id, "segmenter", "requires a taxonomy"
                )
        rejected_indices = [rejected.index for rejected in self.rejected]
        if rejected_indices != sorted(set(rejected_indices)):
            raise RecordValidationError(
                schema_id, "rejected", "must be in ascending index order"
            )
        indices = [
            candidate.proposal_index
            for candidate in self.candidates
            if candidate.proposal_index is not None
        ] + rejected_indices
        if sorted(indices) != list(range(len(indices))):
            raise RecordValidationError(
                schema_id,
                "candidates",
                "proposal indices and rejected indices must together be exactly "
                "range(n) with no repeats",
            )
        inferred_ids = [
            candidate.boundary.job_id
            for candidate in self.candidates
            if candidate.attribution_basis is AttributionBasis.INFERRED
        ]
        if len(set(inferred_ids)) != len(inferred_ids):
            raise RecordValidationError(
                schema_id, "candidates", "inferred job ids must be unique"
            )
        for candidate in self.candidates:
            if (
                candidate.attribution_basis is AttributionBasis.INFERRED
                and candidate.type_assignment.taxonomy != self.taxonomy
            ):
                raise RecordValidationError(
                    schema_id,
                    "candidates",
                    "an inferred candidate must use the inference's taxonomy",
                )
        _require_exact_type(self.subject, JobSubject, schema_id, "subject")
        _require_utc(self.inferred_at, schema_id, "inferred_at")
        _require_subject_ref(self.subject_ref, schema_id)
        _require_text(self.library_version, schema_id, "library_version")


@dataclass(frozen=True, slots=True, kw_only=True)
class JobInferenceRequest:
    """One activity scope a host asks the engine to infer jobs for (D-10).

    The core never reads a transcript: the host supplies the sample and
    chooses its cut.

    Attributes:
        transcript_sample: The host's excerpt of the activity.
        subject: The lineage scope to infer jobs for.
        prior_candidates: The scope's earlier candidates, in the order the
            inferences ran. They drive supersession and delegated
            attribution, and no newly minted ``job_id`` repeats one of theirs
            (ADR 0021).
        subject_ref: An opaque host key echoed on the decision: non-empty
            printable text within 128 serialized bytes.
        double_counting_group: A caller grouping that overrides the lineage
            root default (ADR 0020). Non-empty text when set.
        double_counting_scope: Whether every candidate shares the group or
            each job gets its own (ADR 0044).
        activity_log: The normalized activity stream for the scope, if the
            host has one. Its events bound each candidate's
            ``evidence_refs``, and a non-zero ``collision_count`` is reported
            as ``envelope.dedupe_collision``.
    """

    SCHEMA_ID: ClassVar[str] = "rae.job_inference_request"
    SCHEMA_VERSION: ClassVar[int] = 1

    transcript_sample: TextExcerpt
    subject: JobSubject
    prior_candidates: tuple[JobCandidate, ...] = ()
    subject_ref: str | None = None
    double_counting_group: str | None = None
    double_counting_scope: DoubleCountingScope = DoubleCountingScope.INFERENCE
    activity_log: ActivityLog | None = None

    def __post_init__(self) -> None:
        """Validate exact types and the bounds.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = JobInferenceRequest.SCHEMA_ID
        _require_exact_type(
            self.transcript_sample, TextExcerpt, schema_id, "transcript_sample"
        )
        _require_exact_type(self.subject, JobSubject, schema_id, "subject")
        _require_tuple_of(
            self.prior_candidates, JobCandidate, schema_id, "prior_candidates"
        )
        _require_subject_ref(self.subject_ref, schema_id)
        if self.double_counting_group is not None:
            _require_text(
                self.double_counting_group, schema_id, "double_counting_group"
            )
        _require_exact_type(
            self.double_counting_scope,
            DoubleCountingScope,
            schema_id,
            "double_counting_scope",
        )
        if self.activity_log is not None:
            _require_exact_type(
                self.activity_log, ActivityLog, schema_id, "activity_log"
            )


def boundary_evidence(log: ActivityLog | None, subject: JobSubject) -> tuple[str, ...]:
    """Return the dedupe keys of the events that bound a subject's activity.

    An event is in scope when ``node_of(event.identity)`` is one of
    ``subject.members``. The first and last in-scope events in log order bound
    the job (D-12, ADR 0018).

    Args:
        log: The normalized activity stream, or ``None``.
        subject: The lineage scope inferred.

    Returns:
        ``(first, last)`` dedupe keys, one key when a single event is in
        scope, and ``()`` with no log or no event in scope.

    Raises:
        ConfigurationError: If ``log`` or ``subject`` has the wrong type.
    """
    if type(subject) is not JobSubject:
        raise ConfigurationError(f"JobSubject required, got {type(subject).__name__!r}")
    if log is None:
        return ()
    if type(log) is not ActivityLog:
        raise ConfigurationError(f"ActivityLog required, got {type(log).__name__!r}")
    members = frozenset(subject.members)
    in_scope = [
        event.dedupe_key for event in log.events if node_of(event.identity) in members
    ]
    if not in_scope:
        return ()
    if len(in_scope) == 1:
        return (in_scope[0],)
    return (in_scope[0], in_scope[-1])


def sample_transcript(
    messages: Iterable[tuple[str, str | None]],
    *,
    max_chars: int = 8000,
    per_msg_cap: int = 500,
    final_answer_cap: int = 2500,
) -> TextExcerpt:
    """Sample a transcript's head and tail, as Hermes does (D-23, ADR 0019).

    This ports the pure body of Hermes ``_read_session_transcript``
    (classifier.py:L499-L583 at ``44bad57``) line for line. The SQLite read
    and the ``ORDER BY timestamp ASC`` stay in the host: pass the messages
    already in chronological order. The core never reads a transcript.

    A message whose content is ``None`` or ``""`` is skipped, as the Hermes
    SQL filter does. Each other message becomes ``f"{role}: {content[:cap]}"``,
    so the cap applies to the content, not the role prefix (A-04). The cap is
    ``per_msg_cap``, except for the last kept message whose role is exactly
    ``"assistant"``: it carries the delivered result, so its cap is
    ``max(per_msg_cap, final_answer_cap)``, as Hermes
    ``_FINAL_ASSISTANT_MSG_CHARS`` does (ADR 0042 decision 5). Skipped
    messages are never the last assistant. The lines are joined with
    newlines. Text of at most ``max_chars`` characters is kept
    whole. Longer text keeps as many whole lines from the start as fit half
    the budget left after the elision marker, then as many whole lines from
    the end as fit the rest, joined by the marker. With no tail line, the head
    is returned alone; with no head line, the sample starts with the marker.

    Args:
        messages: ``(role, content)`` tuples in chronological order.
        max_chars: The character budget for the sample, at least 0.
        per_msg_cap: How many characters of each message's content to keep,
            at least 1.
        final_answer_cap: How many characters of the last assistant
            message's content to keep, at least 1. A value below
            ``per_msg_cap`` keeps ``per_msg_cap``.

    Returns:
        The sample. Its original lengths and ``truncated`` flag describe the
        joined text before sampling.

    Raises:
        ConfigurationError: If a limit is not an exact ``int`` in range, a
            message is not a 2-tuple, a role is not a ``str``, or a content is
            neither a ``str`` nor ``None``.
    """
    if type(max_chars) is not int or max_chars < 0:
        raise ConfigurationError(
            f"max_chars must be an int of at least 0, got {max_chars!r}"
        )
    if type(per_msg_cap) is not int or per_msg_cap < 1:
        raise ConfigurationError(
            f"per_msg_cap must be an int of at least 1, got {per_msg_cap!r}"
        )
    if type(final_answer_cap) is not int or final_answer_cap < 1:
        raise ConfigurationError(
            f"final_answer_cap must be an int of at least 1, got {final_answer_cap!r}"
        )
    kept: list[tuple[str, str]] = []
    for position, message in enumerate(messages):
        if type(message) is not tuple or len(message) != 2:
            raise ConfigurationError(
                f"message {position} must be a (role, content) tuple, "
                f"got {type(message).__name__!r}"
            )
        role, content = message
        if type(role) is not str:
            raise ConfigurationError(
                f"message {position} role must be text, got {type(role).__name__!r}"
            )
        if content is None:
            continue
        if type(content) is not str:
            raise ConfigurationError(
                f"message {position} content must be text or None, "
                f"got {type(content).__name__!r}"
            )
        if content == "":
            continue
        kept.append((role, content))
    last_answer = max(
        (index for index, (role, _content) in enumerate(kept) if role == "assistant"),
        default=-1,
    )
    answer_cap = max(per_msg_cap, final_answer_cap)
    lines = [
        f"{role}: {content[: answer_cap if index == last_answer else per_msg_cap]}"
        for index, (role, content) in enumerate(kept)
    ]
    full = "\n".join(lines)
    return TextExcerpt(
        text=_head_and_tail(lines, full, max_chars),
        original_char_length=len(full),
        original_serialized_bytes=serialized_byte_length(full),
        truncated=len(full) > max_chars,
    )


def _head_and_tail(lines: list[str], full: str, max_chars: int) -> str:
    # Hermes classifier.py:L486-L509, including its research Pitfall 3 rules:
    # each line costs len(line) + 1, and the tail budget is budget - head_len.
    if len(full) <= max_chars:
        return full
    budget = max(0, max_chars - len(_SAMPLE_MARKER))
    head_budget = budget // 2
    head_parts: list[str] = []
    head_len = 0
    head_idx = 0
    for index, line in enumerate(lines):
        if head_len + len(line) + 1 > head_budget:
            break
        head_parts.append(line)
        head_len += len(line) + 1
        head_idx = index + 1
    tail_parts: list[str] = []
    tail_len = 0
    for index in range(len(lines) - 1, head_idx - 1, -1):
        line = lines[index]
        if tail_len + len(line) + 1 > budget - head_len:
            break
        tail_parts.append(line)
        tail_len += len(line) + 1
    tail_parts.reverse()
    if not tail_parts:
        return "\n".join(head_parts)
    return "\n".join(head_parts) + _SAMPLE_MARKER + "\n".join(tail_parts)


def _clip_head_tail(text: str, limit: int) -> str:
    # Hermes _clip_head_tail, classifier.py:L592-L619 at 44bad57 (ADR 0042
    # decision 2): one third of the room after the marker is head, the rest is
    # tail, and the clip counts characters, not lines.
    if len(text) <= limit:
        return text
    budget = max(0, limit - len(_SAMPLE_MARKER))
    head = budget // 3
    tail = budget - head
    return text[:head] + _SAMPLE_MARKER + (text[len(text) - tail :] if tail else "")


def _transcript_preview(text: str, limit: int, clip: PreviewClip) -> str:
    # ADR 0042 decision 2: the job and outcome prompts share this cut.
    if clip is PreviewClip.HEAD_TAIL:
        return _clip_head_tail(text, limit)
    return text[:limit]


def _require_job_snapshot(snapshot: object) -> JobTaxonomySnapshot:
    if type(snapshot) is JobTaxonomySnapshot:
        return snapshot
    raise ConfigurationError(
        f"JobTaxonomySnapshot required, got {type(snapshot).__name__!r}"
    )


def _resolve_template(
    config: EngineConfig, prompt_version: int | None
) -> JobPromptTemplate:
    if type(config) is not EngineConfig:
        raise ConfigurationError(
            f"EngineConfig required, got {type(config).__name__!r}"
        )
    version = config.job_prompt_version if prompt_version is None else prompt_version
    template = (
        JOB_PROMPTS.get((JOB_PROMPT_NAME, version)) if type(version) is int else None
    )
    if template is None:
        raise ConfigurationError(
            f"unknown job prompt version {version!r}; known versions are "
            f"{sorted(known for _, known in JOB_PROMPTS)!r}"
        )
    return template


def job_prompt_ref(
    *,
    config: EngineConfig,
    host_display_name: str | None = None,
    prompt_version: int | None = None,
) -> PromptRef:
    """Return the reference for a job prompt version under a host framing.

    Args:
        config: The engine configuration.
        host_display_name: The host name, or ``None`` for
            ``config.host_display_name``.
        prompt_version: The prompt version, or ``None`` for
            ``config.job_prompt_version``.

    Returns:
        The prompt reference a decision records.

    Raises:
        ConfigurationError: If ``config``, ``host_display_name``, or the
            prompt version is invalid.
    """
    template = _resolve_template(config, prompt_version)
    host = _resolve_host_display_name(config, host_display_name)
    return PromptRef(
        name=template.name,
        version=template.version,
        template_hash=template.template_hash,
        host_display_name=host,
    )


def build_job_prompt(
    sample: TextExcerpt,
    snapshot: JobTaxonomySnapshot,
    *,
    config: EngineConfig,
    host_display_name: str | None = None,
    prompt_version: int | None = None,
) -> CompletionRequest:
    """Render the job inference request for one transcript sample (D-22, D-24).

    Truncation is character-based, as in Hermes. The preview cuts the sample
    to the template's ``transcript_preview_max_chars``: version 3, the
    default, keeps one third head and two thirds tail around the elision
    marker, as Hermes 44bad57 does (ADR 0042 decision 3), and versions 1 and 2
    keep the first characters. A label list longer than
    ``config.job_labels_block_max_chars`` is cut to that length plus
    ``" ... [truncated]"``.

    Args:
        sample: The host's transcript excerpt.
        snapshot: The job taxonomy, rendered in its own order.
        config: The engine configuration.
        host_display_name: The host name, or ``None`` for
            ``config.host_display_name``.
        prompt_version: The prompt version, or ``None`` for
            ``config.job_prompt_version``.

    Returns:
        The system and user messages with the configured job call parameters.

    Raises:
        ConfigurationError: If ``sample`` is not exactly a ``TextExcerpt``,
            ``snapshot`` is not exactly a ``JobTaxonomySnapshot``, the prompt
            version is unknown, or another argument is invalid.
    """
    if type(sample) is not TextExcerpt:
        raise ConfigurationError(f"TextExcerpt required, got {type(sample).__name__!r}")
    job_snapshot = _require_job_snapshot(snapshot)
    template = _resolve_template(config, prompt_version)
    host = _resolve_host_display_name(config, host_display_name)
    labels = ", ".join(job_snapshot.labels) if job_snapshot.labels else _NO_LABELS
    if len(labels) > config.job_labels_block_max_chars:
        labels = labels[: config.job_labels_block_max_chars] + _TRUNCATED
    return CompletionRequest(
        messages=(
            CompletionMessage(
                role=MessageRole.SYSTEM, content=template.render_system(host)
            ),
            CompletionMessage(
                role=MessageRole.USER,
                content=template.render_user(
                    host_display_name=host,
                    labels=labels,
                    transcript_preview=_transcript_preview(
                        sample.text,
                        template.transcript_preview_max_chars,
                        template.transcript_preview_clip,
                    ),
                ),
            ),
        ),
        max_tokens=config.job_max_tokens,
        temperature=float(config.job_temperature),
        purpose=CompletionPurpose.JOB_INFERENCE,
    )


def parse_job_array(raw: object) -> tuple[object, ...] | JobInferenceAbstentionReason:
    """Read model text as job proposals, or say why it cannot be read (D-15).

    The steps follow Hermes ``_parse_job_array`` (classifier.py:L803-L818):
    strip, remove a leading fence with an optional language tag and a closing
    fence, strip again, and ``json.loads``. Parsing is Hermes-permissive, so
    ``NaN``, ``Infinity``, and duplicate keys are accepted. Non-object items
    stay proposals and are rejected later, so none disappears.

    Args:
        raw: The model's output text.

    Returns:
        The proposals (a lone object is one proposal), or ``UNPARSEABLE`` for
        non-text, undecodable, or non-array output, or ``EMPTY_RESPONSE``
        for blank text.
    """
    if type(raw) is not str:
        return JobInferenceAbstentionReason.UNPARSEABLE
    text = raw.strip()
    if text == "":
        return JobInferenceAbstentionReason.EMPTY_RESPONSE
    text = re.sub(r"^```[a-zA-Z0-9]*\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    text = text.strip()
    try:
        parsed: object = json.loads(text)
    except (ValueError, RecursionError):
        # For str input these are the only errors json.loads raises; the
        # broad handler stays in the engine (ADR 0012, ADR 0018 decision 4).
        return JobInferenceAbstentionReason.UNPARSEABLE
    return coerce_job_array(parsed)


def coerce_job_array(
    value: object,
) -> tuple[object, ...] | JobInferenceAbstentionReason:
    """Read an injected segmenter's value as job proposals (D-15, F-16).

    Exact types only: a ``dict`` is one proposal and a ``list`` gives its
    items. Anything else, including text, is ``UNPARSEABLE``; the text parser
    never runs here, so a segmenter has exactly one output format.

    Args:
        value: The segmenter's raw output, not ``None``.

    Returns:
        The proposals, or ``UNPARSEABLE``.
    """
    if type(value) is dict:
        return (value,)
    if type(value) is list:
        return tuple(value)
    return JobInferenceAbstentionReason.UNPARSEABLE


def _bounded_repr(value: object) -> str:
    # repr() runs only for exact JSON scalar types, so a hostile __repr__ on
    # a segmenter value never runs (ADR 0018 decision 5, research Pattern 4).
    value_type = type(value)
    if value_type is str:
        text = repr(str(value)[:_REPR_STR_MAX_CHARS])
    elif value is None or value_type is bool or value_type is float:
        text = repr(value)
    elif value_type is int and isinstance(value, int):
        text = (
            repr(value)
            if value.bit_length() <= _REPR_INT_MAX_BITS
            else f"<{value_type.__qualname__}>"
        )
    elif value_type is list and isinstance(value, list):
        text = f"<list of {len(value)}>"
    elif value_type is dict and isinstance(value, dict):
        text = f"<object with {len(value)} keys>"
    else:
        text = f"<{value_type.__qualname__}>"
    return clamp_bytes(text, max_bytes=NARRATIVE_CLAMP_BYTES)


def _reject(
    index: int, reason: JobRejectionReason, value: object
) -> RejectedJobProposal:
    return RejectedJobProposal(
        index=index, reason=reason, value_repr=_bounded_repr(value)
    )


def _missing(index: int, reason: JobRejectionReason) -> RejectedJobProposal:
    return RejectedJobProposal(index=index, reason=reason, value_repr=_MISSING_REPR)


def _normalize_job_label(stripped: str) -> str:
    # ADR 0017 decision 1: ASCII A-Z lowers, [a-z0-9_-] stays, and every other
    # code point becomes exactly one "_". No Unicode casefolding.
    return "".join(
        character.lower()
        if "A" <= character <= "Z"
        else character
        if character in _KEPT_ID_CHARACTERS
        else "_"
        for character in stripped
    )


def _mint_suffix(ids: IdGenerator) -> str:
    # ADR 0017 decision 2: the only broad handler outside the engine. It is
    # sync, awaits nothing, and never names CancelledError; only the
    # exception's type name is kept, never its message or chain.
    try:
        suffix: object = ids.suffix(4)
    except Exception as error:  # noqa: BLE001 - A-09: a raising IdGenerator is a host configuration error
        raise ConfigurationError(
            f"IdGenerator.suffix raised {type(error).__qualname__}"
        ) from None
    if type(suffix) is not str or _SUFFIX.fullmatch(str(suffix)) is None:
        raise ConfigurationError(
            "IdGenerator.suffix(4) must return exactly 4 lowercase hexadecimal "
            f"digits, got a {type(suffix).__qualname__}"
        )
    return str(suffix)


def _unique_job_id(
    candidate: JobCandidate, taken: set[str], ids: IdGenerator
) -> JobCandidate:
    # ADR 0021 decision 1: a minted id never repeats one in prior_candidates,
    # one a prior pointer names, or an earlier candidate of the same
    # inference; the caller puts all of those in taken. A repeat is redrawn from
    # the same generator, keeping the label, at most B times, where B counts
    # the taken ids sharing the label base: B + 1 draws with at most B taken
    # means an injective generator always finds a free id. Redraws go through
    # _mint_suffix, so no new broad handler is added (A-09).
    job_id = candidate.boundary.job_id
    if job_id not in taken:
        return candidate
    label = _label_base(job_id)
    bound = sum(1 for other in taken if _label_base(other) == label)
    for _ in range(bound):
        redrawn = f"{label}_{_mint_suffix(ids)}"
        if redrawn not in taken:
            return replace(
                candidate, boundary=replace(candidate.boundary, job_id=redrawn)
            )
    # T-03-47: the message names no label and no id, as the A-09 messages do.
    raise ConfigurationError(
        f"IdGenerator.suffix(4) returned a suffix on all {bound + 1} draws that "
        "repeated a job id already in or named by prior_candidates, or in this "
        "inference"
    )


def _resolve_group(double_counting_group: object, subject: JobSubject) -> str | None:
    source = (
        double_counting_group
        if type(double_counting_group) is str and double_counting_group != ""
        else subject.root.session_id
    )
    return normalize_text(source, max_bytes=DOUBLE_COUNTING_GROUP_MAX_BYTES) or None


# ADR 0044 decision 2: the hex characters of sha256(base) that key a JOB group.
_JOB_GROUP_DIGEST_CHARS: Final = 16


def _job_group(base: str | None, job_id: str) -> str | None:
    # ADR 0044 decision 2: a job's own group is its base's digest and its
    # label base, which every revision of the job shares (ADR 0021 decision
    # 4). A label base with no identity keeps the base group, which fails safe.
    if base is None or not _carries_identity(job_id):
        return base
    digest = hashlib.sha256(base.encode("utf-8")).hexdigest()
    source = f"{digest[:_JOB_GROUP_DIGEST_CHARS]}:{_label_base(job_id)}"
    return normalize_text(source, max_bytes=DOUBLE_COUNTING_GROUP_MAX_BYTES) or None


def _require_scope(scope: object) -> DoubleCountingScope:
    if type(scope) is not DoubleCountingScope:
        raise ConfigurationError(
            f"DoubleCountingScope required, got {type(scope).__name__!r}"
        )
    return scope


def validate_job(
    proposal: object,
    snapshot: JobTaxonomySnapshot,
    *,
    ids: IdGenerator,
    index: int,
    subject: JobSubject,
    evidence_refs: tuple[str, ...] = (),
    double_counting_group: str | None = None,
    double_counting_scope: DoubleCountingScope = DoubleCountingScope.INFERENCE,
) -> JobCandidate | RejectedJobProposal:
    """Accept one proposal as a candidate, or reject it with its first failure.

    The checks follow Hermes ``_validate_job`` (classifier.py:L1258-L1315):
    the object, ``agentic_job_id``, ``job_type``, then ``status``. The id is
    normalized per ADR 0017, ``failure_reason`` is kept only for ``FAILED``
    (ADR 0014), and ``job_name`` is normalized or ``""``. The suffix is minted
    once, after every check passes, so a rejected proposal never consumes
    one (research Pitfall 4).

    Args:
        proposal: One raw proposal.
        snapshot: The job taxonomy the proposal was produced against.
        ids: The suffix source.
        index: The proposal's index in the answer.
        subject: The lineage scope inferred.
        evidence_refs: The boundary evidence every candidate records.
        double_counting_group: A caller group override. The lineage root's
            session id is used when it is not non-empty text (ADR 0020).
        double_counting_scope: ``JOB`` keys the group on the job's label
            base too, so each job gets its own (ADR 0044).

    Returns:
        A candidate, or a rejection carrying a bounded repr of the offending
        value.

    Raises:
        ConfigurationError: If ``snapshot``, ``subject``, or
            ``double_counting_scope`` has the wrong type, or ``ids`` returns
            a malformed suffix or raises.
    """
    job_snapshot = _require_job_snapshot(snapshot)
    scope = _require_scope(double_counting_scope)
    if type(subject) is not JobSubject:
        raise ConfigurationError(f"JobSubject required, got {type(subject).__name__!r}")
    if type(proposal) is not dict or not isinstance(proposal, dict):
        return _reject(index, JobRejectionReason.NOT_AN_OBJECT, proposal)

    if "agentic_job_id" not in proposal:
        return _missing(index, JobRejectionReason.AGENTIC_JOB_ID_MISSING)
    raw_id: object = proposal["agentic_job_id"]
    if type(raw_id) is not str or str(raw_id).strip() == "":
        return _reject(index, JobRejectionReason.AGENTIC_JOB_ID_INVALID, raw_id)
    stripped_id = str(raw_id).strip()
    label = _normalize_job_label(stripped_id)
    if stripped_id in _UNSAFE_RAW_IDS or label.startswith("-"):
        return _reject(index, JobRejectionReason.JOB_ID_UNSAFE, raw_id)
    label = label[:_JOB_LABEL_MAX_CHARS]

    if "job_type" not in proposal:
        return _missing(index, JobRejectionReason.JOB_TYPE_MISSING)
    raw_type: object = proposal["job_type"]
    checked = validate_label(raw_type)
    if type(checked) is ClassificationAbstentionReason:
        return _reject(index, _LABEL_REJECTIONS[checked], raw_type)
    job_type = str(checked)
    if job_type == UNCLASSIFIED_LABEL:
        return _reject(index, JobRejectionReason.JOB_TYPE_RESERVED, raw_type)

    if "status" not in proposal:
        return _missing(index, JobRejectionReason.STATUS_MISSING)
    raw_status: object = proposal["status"]
    if type(raw_status) is not str:
        return _reject(index, JobRejectionReason.STATUS_INVALID_TYPE, raw_status)
    outcome = _STATUS_OUTCOMES.get(str(raw_status).strip().upper())
    if outcome is None:
        return _reject(index, JobRejectionReason.STATUS_UNKNOWN, raw_status)

    raw_reason: object = proposal.get("failure_reason")
    failure_reason = (
        normalize_text(raw_reason, max_bytes=FAILURE_REASON_CLAMP_BYTES) or None
        if outcome is JobOutcome.FAILED and type(raw_reason) is str
        else None
    )
    raw_name: object = proposal.get("job_name")
    job_name = (
        normalize_text(raw_name, max_bytes=JOB_NAME_MAX_BYTES)
        if type(raw_name) is str
        else ""
    )

    suffix = _mint_suffix(ids)
    ref = job_snapshot.ref
    proposal_record = (
        None
        if job_type in job_snapshot.labels
        else LabelProposal(
            namespace=TaxonomyNamespace.JOB, label=job_type, taxonomy=ref
        )
    )
    job_id = f"{label}_{suffix}"
    group = _resolve_group(double_counting_group, subject)
    return JobCandidate(
        boundary=JobBoundary(
            job_id=job_id,
            job_name=job_name,
            root=subject.root,
            members=subject.members,
            evidence_refs=evidence_refs,
            supersedes=None,
        ),
        type_assignment=JobTypeAssignment(
            job_type=job_type, taxonomy=ref, proposal=proposal_record
        ),
        outcome=outcome,
        failure_reason=failure_reason,
        proposal_index=index,
        attribution_basis=AttributionBasis.INFERRED,
        parent_job_id=None,
        delegation_initiator=subject.delegation_initiator,
        delegation_mode=subject.delegation_mode,
        double_counting_group=_job_group(group, job_id)
        if scope is DoubleCountingScope.JOB
        else group,
    )


def parse_job_response(
    raw: object,
    snapshot: JobTaxonomySnapshot,
    *,
    ids: IdGenerator,
    prompt_ref: PromptRef | None,
    inferred_at: datetime,
    provenance: InferenceProvenance | None,
    subject: JobSubject,
    prior_candidates: tuple[JobCandidate, ...] = (),
    segmenter: ComponentDeclaration = BUILTIN_JOB_SEGMENTER,
    subject_ref: str | None = None,
    double_counting_group: str | None = None,
    double_counting_scope: DoubleCountingScope = DoubleCountingScope.INFERENCE,
    activity_log: ActivityLog | None = None,
) -> JobInference:
    """Turn raw model or segmenter output into a job inference (D-24).

    ``provenance`` set selects the text path (:func:`parse_job_array`), and
    ``None`` selects the segmenter path: ``None`` output is ``ABSTAINED`` and
    anything else goes through :func:`coerce_job_array`. Each proposal is then
    validated with :func:`validate_job` in index order and lands in exactly
    one of ``candidates`` or ``rejected``.

    Args:
        raw: The model text or the segmenter's value.
        snapshot: The job taxonomy the output was produced against.
        ids: The suffix source.
        prompt_ref: The prompt reference, on the model path.
        inferred_at: The decision time, from the injected clock.
        provenance: The completion metadata, on the model path.
        subject: The lineage scope inferred.
        prior_candidates: Earlier candidates, in the order the inferences
            ran: the scope's full history, or the output of
            :func:`resolve_current` over it. An accepted candidate whose
            ``job_id`` repeats one of theirs, one their ``supersedes``
            pointers name, or an earlier candidate's of this inference, gets
            its suffix redrawn from ``ids``. Each accepted candidate, in index order,
            then supersedes the first unclaimed current prior head with the
            subject's exact scope, its label base, and its ``job_type``. A
            label base with no ASCII letter or digit is never claimed
            (ADR 0021). Prior candidates are never mutated.
        segmenter: The component that produced ``raw``.
        subject_ref: The request's subject reference.
        double_counting_group: A caller group override (ADR 0020).
        double_counting_scope: ``JOB`` gives each job its own group
            (ADR 0044).
        activity_log: The normalized activity stream. Every candidate records
            :func:`boundary_evidence` of it as ``evidence_refs``.

    Returns:
        The inference: candidates and rejections, or a model-side abstention.

    Raises:
        ConfigurationError: If ``snapshot``, ``subject``, ``activity_log``,
            ``double_counting_scope``, or ``prior_candidates`` has the wrong
            type, ``ids`` returns a
            malformed suffix or raises, or ``ids`` keeps returning a suffix
            whose job id already appears in, or is named by,
            ``prior_candidates``, or appears in this inference.
    """
    job_snapshot = _require_job_snapshot(snapshot)
    if type(subject) is not JobSubject:
        raise ConfigurationError(f"JobSubject required, got {type(subject).__name__!r}")
    # Checked before any early return, so an empty answer cannot hide a bad
    # setting (PR #11 review).
    _require_scope(double_counting_scope)
    evidence_refs = boundary_evidence(activity_log, subject)
    prior = _require_prior_candidates(prior_candidates)
    if provenance is not None:
        proposals = parse_job_array(raw)
    elif raw is None:
        proposals = JobInferenceAbstentionReason.ABSTAINED
    else:
        proposals = coerce_job_array(raw)
    if isinstance(proposals, JobInferenceAbstentionReason):
        return JobInference(
            abstention=JobInferenceAbstention(reason=proposals),
            taxonomy=job_snapshot.ref,
            prompt=prompt_ref,
            inference=provenance,
            segmenter=segmenter,
            subject=subject,
            inferred_at=inferred_at,
            subject_ref=subject_ref,
            library_version=__version__,
        )
    # ADR 0021 decision 1: a minted id also avoids every id a prior pointer
    # names. A host that compacts to the current set keeps pointers whose
    # targets it dropped; minting one of those ids would let the stale
    # pointer latch onto the new record (review CR-01).
    taken = {candidate.boundary.job_id for candidate in prior} | {
        candidate.boundary.supersedes
        for candidate in prior
        if candidate.boundary.supersedes is not None
    }
    candidates: list[JobCandidate] = []
    rejected: list[RejectedJobProposal] = []
    for index, proposal in enumerate(proposals):
        decided = validate_job(
            proposal,
            job_snapshot,
            ids=ids,
            index=index,
            subject=subject,
            evidence_refs=evidence_refs,
            double_counting_group=double_counting_group,
            double_counting_scope=double_counting_scope,
        )
        if type(decided) is JobCandidate:
            unique = _unique_job_id(decided, taken, ids)
            taken.add(unique.boundary.job_id)
            candidates.append(unique)
        elif type(decided) is RejectedJobProposal:
            rejected.append(decided)
    return JobInference(
        candidates=_supersede(tuple(candidates), prior, subject),
        rejected=tuple(rejected),
        abstention=None,
        taxonomy=job_snapshot.ref,
        prompt=prompt_ref,
        inference=provenance,
        segmenter=segmenter,
        subject=subject,
        inferred_at=inferred_at,
        subject_ref=subject_ref,
        library_version=__version__,
    )


def _require_prior_candidates(prior_candidates: object) -> tuple[JobCandidate, ...]:
    if type(prior_candidates) is not tuple:
        raise ConfigurationError(
            f"prior_candidates must be a tuple, got {type(prior_candidates).__name__!r}"
        )
    checked: list[JobCandidate] = []
    for index, candidate in enumerate(prior_candidates):
        if type(candidate) is not JobCandidate:
            raise ConfigurationError(
                f"prior_candidates element {index} must be a JobCandidate, "
                f"got {type(candidate).__name__!r}"
            )
        checked.append(candidate)
    return tuple(checked)


def _carries_identity(job_id: str) -> bool:
    # ADR 0021 decision 5: a label base with no ASCII letter or digit (a
    # label written entirely in another script, or only punctuation) is still
    # a valid id (A-08, ADR 0017 option-a) but never an identity.
    return any(character in _IDENTITY_CHARACTERS for character in _label_base(job_id))


def _names(reviser: JobCandidate, target: JobCandidate) -> bool:
    # ADR 0021 decision 3: a pointer can name only an INFERRED record with
    # the pointed-to job_id, the reviser's exact lineage scope and job_type,
    # and an identity-bearing label base.
    return (
        target.attribution_basis is AttributionBasis.INFERRED
        and target.boundary.job_id == reviser.boundary.supersedes
        and target.boundary.root == reviser.boundary.root
        and target.boundary.members == reviser.boundary.members
        and target.type_assignment.job_type == reviser.type_assignment.job_type
        and _carries_identity(target.boundary.job_id)
    )


def _revision_targets(items: tuple[JobCandidate, ...]) -> dict[int, int]:
    # ADR 0021 decision 3 (D-14): each INFERRED reviser's pointer, in input
    # order, names at most one position. With one match it is that record,
    # wherever it sits; with several (an id repeated across histories whose
    # minting never saw each other), the earliest match before the reviser
    # that no earlier pointer named; otherwise none. Positions are indexed by
    # job_id, so the cost is linear in the input plus the matches for each
    # pointer (T-03-49).
    by_id: dict[str, list[int]] = {}
    for position, candidate in enumerate(items):
        if candidate.attribution_basis is AttributionBasis.INFERRED:
            by_id.setdefault(candidate.boundary.job_id, []).append(position)
    targets: dict[int, int] = {}
    named: set[int] = set()
    for position, reviser in enumerate(items):
        pointer = reviser.boundary.supersedes
        if reviser.attribution_basis is not AttributionBasis.INFERRED or (
            pointer is None
        ):
            continue
        matches = [
            target
            for target in by_id.get(pointer, ())
            if _names(reviser, items[target])
        ]
        if len(matches) == 1:
            targets[position] = matches[0]
            named.add(matches[0])
            continue
        for target in matches:
            if target >= position:
                break
            if target not in named:
                targets[position] = target
                named.add(target)
                break
    return targets


def _cycle_latest(targets: dict[int, int]) -> frozenset[int]:
    # Each reviser names at most one record, so the pointers form a
    # functional graph. Walk it once from every reviser, in input order; a
    # walk that returns to a position it visited has found a cycle, and the
    # cycle's latest position is recorded. Every position is visited once,
    # so the cost is linear in the number of pointers.
    latest: set[int] = set()
    walk_of: dict[int, int] = {}
    for start in targets:
        path: list[int] = []
        position = start
        while position in targets and position not in walk_of:
            walk_of[position] = start
            path.append(position)
            position = targets[position]
        if walk_of.get(position) == start:
            latest.add(max(path[path.index(position) :]))
    return frozenset(latest)


def _superseded_positions(items: tuple[JobCandidate, ...]) -> frozenset[int]:
    # ADR 0021 decision 3, cycle rule (owner, 2026-09-30): a pointer
    # supersedes the record _revision_targets resolves it to, except that the
    # latest record of a supersession cycle, by input position, is never
    # superseded by an earlier record. That drops the cycle's one pointer
    # into it, which breaks a cycle of any length and keeps that record
    # current, and any other earlier pointer that names it. A later record
    # can still revise it. With no cycle, every pointer supersedes the record
    # it names. A compacted store resolved with priors that omit it can form
    # a cycle (review CR-01 and the Phase 3 verifier's residual).
    targets = _revision_targets(items)
    latest = _cycle_latest(targets)
    return frozenset(
        target
        for reviser, target in targets.items()
        if target not in latest or reviser > target
    )


def _delegation_head(
    subject: JobSubject, prior_candidates: tuple[JobCandidate, ...]
) -> JobCandidate | None:
    # ADR 0021 decision 6: the last INFERRED prior candidate, in the caller's
    # order, whose root is the subject's root and whose position no pointer
    # supersedes. Latest wins, as in Hermes _root_agentic_job_id_for
    # (classifier.py:L4591-L4608). _superseded_positions applies the cycle
    # rule, so a history whose records name each other in a cycle of any
    # length still has a head.
    if subject.node == subject.root:
        return None
    superseded = _superseded_positions(prior_candidates)
    head: JobCandidate | None = None
    for position, candidate in enumerate(prior_candidates):
        if (
            candidate.attribution_basis is AttributionBasis.INFERRED
            and candidate.boundary.root == subject.root
            and position not in superseded
        ):
            head = candidate
    return head


def delegated_attribution(
    subject: JobSubject,
    prior_candidates: tuple[JobCandidate, ...],
    *,
    inferred_at: datetime,
    subject_ref: str | None = None,
    activity_log: ActivityLog | None = None,
) -> JobInference | None:
    """Attach a delegated subject's work to its root's job (D-20, A-07).

    The head is the last ``INFERRED`` candidate in ``prior_candidates``
    whose boundary root is the subject's root and that no pointer among
    ``prior_candidates`` supersedes, resolved as :func:`resolve_current`
    does (ADR 0021 decision 6). No model, segmenter, taxonomy,
    or ID generator is involved, which matches Hermes skipping subagent
    sessions (classifier.py:L5068). The subject's delegation initiator and
    mode are copied as reported, so ``UNKNOWN`` stays ``UNKNOWN``: the core
    never assumes a user delegated the work (D-09).

    Args:
        subject: The lineage scope inferred.
        prior_candidates: Earlier candidates, in the caller's order.
        inferred_at: The decision time, from the injected clock.
        subject_ref: The request's subject reference.
        activity_log: The normalized activity stream. The attribution
            records :func:`boundary_evidence` of it for the subject.

    Returns:
        ``None`` when the subject is its own root or no head exists.
        Otherwise one ``LINEAGE_ROOT`` candidate that reuses the head's
        ``job_id``, name, type, outcome, failure reason, and group, with
        ``parent_job_id`` set to the head's ``job_id``. The inference's
        taxonomy is the head's, and its prompt, provenance, and segmenter are
        ``None``.

    Raises:
        ConfigurationError: If ``subject``, ``prior_candidates``, or
            ``activity_log`` has the wrong type.
    """
    if type(subject) is not JobSubject:
        raise ConfigurationError(f"JobSubject required, got {type(subject).__name__!r}")
    head = _delegation_head(subject, _require_prior_candidates(prior_candidates))
    if head is None:
        return None
    assignment = head.type_assignment
    candidate = JobCandidate(
        boundary=JobBoundary(
            job_id=head.boundary.job_id,
            job_name=head.boundary.job_name,
            root=subject.root,
            members=subject.members,
            evidence_refs=boundary_evidence(activity_log, subject),
            supersedes=None,
        ),
        type_assignment=JobTypeAssignment(
            job_type=assignment.job_type, taxonomy=assignment.taxonomy, proposal=None
        ),
        outcome=head.outcome,
        failure_reason=head.failure_reason,
        proposal_index=None,
        attribution_basis=AttributionBasis.LINEAGE_ROOT,
        parent_job_id=head.boundary.job_id,
        delegation_initiator=subject.delegation_initiator,
        delegation_mode=subject.delegation_mode,
        double_counting_group=head.double_counting_group,
    )
    return JobInference(
        candidates=(candidate,),
        rejected=(),
        abstention=None,
        taxonomy=assignment.taxonomy,
        prompt=None,
        inference=None,
        segmenter=None,
        subject=subject,
        inferred_at=inferred_at,
        subject_ref=subject_ref,
        library_version=__version__,
    )


def _label_base(job_id: str) -> str:
    # ADR 0018 decision 9, ADR 0021: the job_id without "_" and its 4-digit
    # suffix.
    return job_id[:-5]


def _supersede(
    candidates: tuple[JobCandidate, ...],
    prior_candidates: tuple[JobCandidate, ...],
    subject: JobSubject,
) -> tuple[JobCandidate, ...]:
    # ADR 0021 decision 4 (D-14, ENV-04). Heads are the INFERRED priors with
    # the subject's exact scope at positions no pointer supersedes, by the
    # same resolution resolve_current uses. Each new candidate, in index
    # order, claims the first unclaimed head with its label base and its
    # job_type whose label base carries identity (decision 5). No head shares
    # the candidate's job_id: _unique_job_id already redrew it.
    superseded = _superseded_positions(prior_candidates)
    heads = [
        candidate
        for position, candidate in enumerate(prior_candidates)
        if candidate.attribution_basis is AttributionBasis.INFERRED
        and position not in superseded
        and candidate.boundary.root == subject.root
        and candidate.boundary.members == subject.members
    ]
    claimed: set[int] = set()
    revised: list[JobCandidate] = []
    for candidate in candidates:
        job_id = candidate.boundary.job_id
        job_type = candidate.type_assignment.job_type
        for position, head in enumerate(heads):
            head_id = head.boundary.job_id
            if (
                position in claimed
                or _label_base(head_id) != _label_base(job_id)
                or head.type_assignment.job_type != job_type
                or not _carries_identity(head_id)
            ):
                continue
            claimed.add(position)
            candidate = replace(
                candidate, boundary=replace(candidate.boundary, supersedes=head_id)
            )
            break
        revised.append(candidate)
    return tuple(revised)


def _require_candidates(candidates: Iterable[JobCandidate]) -> tuple[JobCandidate, ...]:
    items = tuple(candidates)
    for index, candidate in enumerate(items):
        if type(candidate) is not JobCandidate:
            raise ConfigurationError(
                f"candidate {index} must be a JobCandidate, "
                f"got {type(candidate).__name__!r}"
            )
    return items


def resolve_current(candidates: Iterable[JobCandidate]) -> tuple[JobCandidate, ...]:
    """Return the candidates that are current, in input order (ADR 0021).

    Each ``INFERRED`` candidate that sets ``supersedes`` (the reviser), in
    input order, can name only an ``INFERRED`` candidate at another position
    with that ``job_id``, the reviser's boundary ``root`` and ``members``,
    the reviser's ``job_type``, and a label base holding an ASCII letter or
    digit. With exactly one such candidate, the pointer names it wherever it
    sits. With several, it names the earliest one before the reviser that no
    earlier pointer named; if none precedes the reviser, it names nothing. A
    pointer names at most one candidate, and that candidate is superseded,
    with one exception. Pointers can form a cycle of any length, in which
    every candidate names another. The latest candidate of each cycle, by
    input position, is never superseded by an earlier candidate, so it stays
    current unless a later candidate revises it. Resolution therefore never
    returns an empty tuple for a non-empty input, and every group of
    candidates linked by pointers keeps a current member.

    Pass candidates in the order the inferences ran, each inference's
    candidates after the prior candidates it was given. Order matters only
    when a ``job_id`` repeats within one scope and job type.

    The input may be compacted. A host may keep only this function's
    output, pass it as the next inference's ``prior_candidates``, and
    resolve that output followed by the new candidates. Each such step
    returns what the full history would, because minting never reuses an
    id that a prior candidate holds or a prior pointer names. That holds
    only when each inference's priors are the stored current set or the
    full history. With priors that omit the store, such as the last run
    only or none, a stale pointer can still name a newer candidate that
    reproduces its id. That candidate is then superseded, unless it is the
    latest candidate of a cycle, and the store can differ from the full
    history's resolution (ADR 0021).

    Every ``LINEAGE_ROOT`` attribution is current: it shares its root's
    ``job_id``, but a root revision never supersedes it (research F-15). An
    attribution stays current even when its head is superseded, so its
    ``parent_job_id`` can name a candidate that is not current.

    Args:
        candidates: Candidates from any number of inferences.

    Returns:
        The current candidates, in input order.

    Raises:
        ConfigurationError: If an element is not a ``JobCandidate``.
    """
    items = _require_candidates(candidates)
    superseded = _superseded_positions(items)
    return tuple(
        candidate
        for position, candidate in enumerate(items)
        if candidate.attribution_basis is AttributionBasis.LINEAGE_ROOT
        or position not in superseded
    )


def group_members(
    candidates: Iterable[JobCandidate],
) -> Mapping[str, tuple[JobCandidate, ...]]:
    """Group candidates by double-counting group (ADR 0020 decision 3).

    This only groups. Phase 3 never refuses, flags, sums, or allocates value
    across a group; that is OD-10's job in Phase 5.

    Args:
        candidates: Candidates from any number of inferences.

    Returns:
        A read-only mapping with sorted keys. Each group keeps its
        candidates in input order. Candidates whose group is ``None`` are
        omitted.

    Raises:
        ConfigurationError: If an element is not a ``JobCandidate``.
    """
    groups: dict[str, list[JobCandidate]] = {}
    for candidate in _require_candidates(candidates):
        group = candidate.double_counting_group
        if group is not None:
            groups.setdefault(group, []).append(candidate)
    return MappingProxyType({key: tuple(groups[key]) for key in sorted(groups)})
