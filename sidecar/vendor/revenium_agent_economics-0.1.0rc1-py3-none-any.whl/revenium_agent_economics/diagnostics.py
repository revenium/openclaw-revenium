"""Closed diagnostic codes and escaped diagnostic records (D-25, ADR 0012).

The engine reports what happened on each classification through an injected
sink. Every field value is the ``repr()`` of its source, clamped to 500
serialized bytes, so untrusted text such as a model label can never start a
new log line in a host's pipeline (Hermes T-28-07). Exception messages are
never recorded, only exception type names.
"""

import enum
import re
from dataclasses import dataclass
from typing import ClassVar, Final

from revenium_agent_economics._bounded import (
    NARRATIVE_CLAMP_BYTES,
    clamp_bytes,
    serialized_byte_length,
)
from revenium_agent_economics.errors import RecordValidationError
from revenium_agent_economics.primitives import _require_exact_type

_FIELD_KEY: Final = re.compile(r"[a-z][a-z0-9_]{0,63}")


class DiagnosticCode(enum.StrEnum):
    """The stable dotted codes the engine emits. The set is closed."""

    TASK_NOT_CONFIGURED = "task.not_configured"
    TASK_PROVIDER_FAILED = "task.provider_failed"
    TASK_CLASSIFIER_FAILED = "task.classifier_failed"
    TASK_TIMED_OUT = "task.timed_out"
    TASK_LABEL_REJECTED = "task.label_rejected"
    TASK_LABEL_TYPE_INVALID = "task.label_type_invalid"
    TAXONOMY_READ_FAILED = "taxonomy.read_failed"
    TAXONOMY_RECORD_FAILED = "taxonomy.record_failed"
    JOB_NOT_CONFIGURED = "job.not_configured"
    JOB_PROVIDER_FAILED = "job.provider_failed"
    JOB_SEGMENTER_FAILED = "job.segmenter_failed"
    JOB_TIMED_OUT = "job.timed_out"
    JOB_LABEL_REJECTED = "job.label_rejected"
    JOB_UNPARSEABLE = "job.unparseable"
    OUTCOME_NOT_CONFIGURED = "outcome.not_configured"
    OUTCOME_PROVIDER_FAILED = "outcome.provider_failed"
    OUTCOME_EVALUATOR_FAILED = "outcome.evaluator_failed"
    OUTCOME_TIMED_OUT = "outcome.timed_out"
    OUTCOME_INVALID = "outcome.invalid"
    OUTCOME_ROLE_VOCABULARY_TRUNCATED = "outcome.role_vocabulary_truncated"
    ASSESSMENT_NO_PROPOSAL = "assessment.no_proposal"
    ASSESSMENT_REJECTED = "assessment.rejected"
    VALUATION_POLICY_FAILED = "valuation.policy_failed"
    EVIDENCE_DECIDER_FAILED = "evidence.decider_failed"
    LINEAGE_CYCLE_DETECTED = "lineage.cycle_detected"
    LINEAGE_DEPTH_EXCEEDED = "lineage.depth_exceeded"
    LINEAGE_PARENT_CONFLICT = "lineage.parent_conflict"
    ENVELOPE_DEDUPE_COLLISION = "envelope.dedupe_collision"


class DiagnosticLevel(enum.StrEnum):
    """How serious a diagnostic is."""

    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


@dataclass(frozen=True, slots=True, kw_only=True)
class Diagnostic:
    """One structured, escaped event from the engine.

    Build it with :meth:`create`, which escapes and clamps every value.

    Attributes:
        code: The closed diagnostic code.
        level: The severity.
        fields: Key and value pairs sorted by key. Keys are lowercase
            identifiers of at most 64 characters, and values are printable
            text within 500 serialized bytes.
    """

    SCHEMA_ID: ClassVar[str] = "rae.diagnostic"
    SCHEMA_VERSION: ClassVar[int] = 1

    code: DiagnosticCode
    level: DiagnosticLevel
    fields: tuple[tuple[str, str], ...] = ()

    def __post_init__(self) -> None:
        """Validate the code, level, and every field.

        Raises:
            RecordValidationError: If a type is wrong, a key is malformed,
                keys repeat or are unsorted, or a value is not printable or
                exceeds 500 serialized bytes.
        """
        schema_id = Diagnostic.SCHEMA_ID
        _require_exact_type(self.code, DiagnosticCode, schema_id, "code")
        _require_exact_type(self.level, DiagnosticLevel, schema_id, "level")
        _require_exact_type(self.fields, tuple, schema_id, "fields")
        previous: str | None = None
        for index, pair in enumerate(self.fields):
            if type(pair) is not tuple or len(pair) != 2:
                raise RecordValidationError(
                    schema_id, "fields", f"element {index} must be a (key, value) tuple"
                )
            key, value = pair
            if type(key) is not str or _FIELD_KEY.fullmatch(key) is None:
                raise RecordValidationError(
                    schema_id,
                    "fields",
                    f"element {index} key must be a lowercase identifier",
                )
            if previous is not None and key <= previous:
                raise RecordValidationError(
                    schema_id,
                    "fields",
                    f"element {index} key must sort after the previous key",
                )
            previous = key
            if type(value) is not str or not value.isprintable():
                raise RecordValidationError(
                    schema_id, "fields", f"element {index} value must be printable text"
                )
            if serialized_byte_length(value) > NARRATIVE_CLAMP_BYTES:
                raise RecordValidationError(
                    schema_id,
                    "fields",
                    f"element {index} value exceeds {NARRATIVE_CLAMP_BYTES} "
                    "serialized bytes",
                )

    @classmethod
    def create(
        cls, code: DiagnosticCode, level: DiagnosticLevel, **fields: object
    ) -> "Diagnostic":
        """Build a diagnostic, escaping and clamping every field value.

        Each value is stored as ``repr(value)`` clamped to 500 serialized
        bytes. The ``repr`` of a ``str`` is always printable. A non-string
        whose ``repr`` is not printable is escaped once more through
        ``repr``.

        Args:
            code: The diagnostic code.
            level: The severity.
            **fields: The untrusted values to record, by key.

        Returns:
            The diagnostic, with fields sorted by key.
        """
        pairs: list[tuple[str, str]] = []
        for key in sorted(fields):
            text = repr(fields[key])
            if not text.isprintable():
                text = repr(text)
            pairs.append((key, clamp_bytes(text, max_bytes=NARRATIVE_CLAMP_BYTES)))
        return cls(code=code, level=level, fields=tuple(pairs))


@dataclass(frozen=True, slots=True)
class NullDiagnostics:
    """The default sink. It discards every diagnostic."""

    def emit(self, diagnostic: Diagnostic) -> None:
        """Discard ``diagnostic``.

        Args:
            diagnostic: The diagnostic to discard.
        """
