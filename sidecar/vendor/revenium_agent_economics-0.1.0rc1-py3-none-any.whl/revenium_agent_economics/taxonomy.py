"""Namespace-typed taxonomy snapshots, references, proposals, and label validation.

Task and job labels are separate vocabularies, so each has its own snapshot
type (D-07, ADR 0009). A snapshot's content hash identifies the exact ordered
label list a decision was made against. Label validation runs the fixed D-15
order shared by every classification path (ADR 0013).
"""

import enum
import hashlib
import re
from dataclasses import dataclass
from typing import ClassVar, Final

from revenium_agent_economics._bounded import is_bounded_printable
from revenium_agent_economics._canonical import canonical_json
from revenium_agent_economics.errors import RecordValidationError
from revenium_agent_economics.primitives import _require_exact_type, _require_tuple_of
from revenium_agent_economics.vocab import (
    LABEL_PATTERN,
    TRIVIAL_LABELS,
    UNCLASSIFIED_LABEL,
)

_LABEL: Final = re.compile(LABEL_PATTERN)
_SHA256_HEX: Final = re.compile(r"[0-9a-f]{64}")
_VERSION_MAX_BYTES: Final = 64


class TaxonomyNamespace(enum.Enum):
    """The vocabulary a taxonomy belongs to."""

    TASK = "task"
    JOB = "job"


class ClassificationAbstentionReason(enum.Enum):
    """Why a task classification returned no label (D-04, ADR 0008).

    A plain ``Enum`` rather than ``StrEnum`` so a reason is never a ``str``
    and can never be mistaken for a label.
    """

    ABSTAINED = "abstained"
    EMPTY_RESPONSE = "empty_response"
    INVALID_LABEL_TYPE = "invalid_label_type"
    LABEL_TRIVIAL = "label_trivial"
    LABEL_REJECTED = "label_rejected"
    UNAVAILABLE = "unavailable"
    TIMED_OUT = "timed_out"
    NOT_CONFIGURED = "not_configured"
    TAXONOMY_UNAVAILABLE = "taxonomy_unavailable"


MODEL_SIDE_REASONS: Final[frozenset[ClassificationAbstentionReason]] = frozenset(
    {
        ClassificationAbstentionReason.ABSTAINED,
        ClassificationAbstentionReason.EMPTY_RESPONSE,
        ClassificationAbstentionReason.INVALID_LABEL_TYPE,
        ClassificationAbstentionReason.LABEL_TRIVIAL,
        ClassificationAbstentionReason.LABEL_REJECTED,
    }
)
PROVIDER_SIDE_REASONS: Final[frozenset[ClassificationAbstentionReason]] = frozenset(
    {
        ClassificationAbstentionReason.UNAVAILABLE,
        ClassificationAbstentionReason.TIMED_OUT,
        ClassificationAbstentionReason.NOT_CONFIGURED,
        ClassificationAbstentionReason.TAXONOMY_UNAVAILABLE,
    }
)


def is_valid_label(text: str) -> bool:
    """Return whether ``text`` matches the label grammar in full.

    The grammar is ``vocab.LABEL_PATTERN`` applied with ``fullmatch``, so a
    trailing newline never makes a label valid (D-16).

    Args:
        text: The candidate label.

    Returns:
        ``True`` when ``text`` is a ``str`` that matches the whole grammar.
    """
    return type(text) is str and _LABEL.fullmatch(text) is not None


def validate_label(raw: object) -> str | ClassificationAbstentionReason:
    """Clean an untrusted label or say why it is unusable (D-15, ADR 0013).

    The checks run in this order: exact ``str`` type, empty, strip, ASCII,
    lowercase, trivial blocklist, grammar. The function is pure and returns
    the reserved label ``"unclassified"`` unchanged.

    Args:
        raw: The classifier or model output.

    Returns:
        The cleaned label, or the model-side reason it was refused.
    """
    if type(raw) is not str:
        return ClassificationAbstentionReason.INVALID_LABEL_TYPE
    if raw == "":
        return ClassificationAbstentionReason.EMPTY_RESPONSE
    stripped = raw.strip()
    if not stripped.isascii():
        return ClassificationAbstentionReason.LABEL_REJECTED
    cleaned = stripped.lower()
    if cleaned in TRIVIAL_LABELS:
        return ClassificationAbstentionReason.LABEL_TRIVIAL
    if not is_valid_label(cleaned):
        return ClassificationAbstentionReason.LABEL_REJECTED
    return cleaned


def _require_version_text(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, str, schema_id, field)
    if not is_bounded_printable(str(value), _VERSION_MAX_BYTES):
        raise RecordValidationError(
            schema_id,
            field,
            "must be non-empty printable text within "
            f"{_VERSION_MAX_BYTES} serialized bytes",
        )


def _require_content_hash(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, str, schema_id, field)
    if _SHA256_HEX.fullmatch(str(value)) is None:
        raise RecordValidationError(
            schema_id, field, "must be 64 lowercase hexadecimal characters"
        )


def _validate_snapshot(
    schema_id: str, version: object, labels: tuple[str, ...]
) -> None:
    _require_version_text(version, schema_id, "version")
    _require_tuple_of(labels, str, schema_id, "labels")
    seen: set[str] = set()
    for index, label in enumerate(labels):
        if not is_valid_label(label):
            raise RecordValidationError(
                schema_id, "labels", f"element {index} fails the label grammar"
            )
        if label == UNCLASSIFIED_LABEL:
            raise RecordValidationError(
                schema_id, "labels", f"element {index} is the reserved label"
            )
        if label in seen:
            raise RecordValidationError(
                schema_id, "labels", f"element {index} duplicates an earlier label"
            )
        seen.add(label)


def _content_hash(
    namespace: TaxonomyNamespace, version: str, labels: tuple[str, ...]
) -> str:
    return hashlib.sha256(
        canonical_json(
            {"labels": list(labels), "namespace": namespace.value, "version": version}
        )
    ).hexdigest()


@dataclass(frozen=True, slots=True, kw_only=True)
class TaxonomyRef:
    """Which taxonomy a decision was made against (D-08).

    Attributes:
        namespace: The taxonomy's vocabulary.
        version: The caller-supplied snapshot version.
        content_hash: The snapshot's lowercase hexadecimal SHA-256 content hash.
    """

    SCHEMA_ID: ClassVar[str] = "rae.taxonomy_ref"
    SCHEMA_VERSION: ClassVar[int] = 1

    namespace: TaxonomyNamespace
    version: str
    content_hash: str

    def __post_init__(self) -> None:
        """Validate exact types, the version text, and the hash shape.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = TaxonomyRef.SCHEMA_ID
        _require_exact_type(self.namespace, TaxonomyNamespace, schema_id, "namespace")
        _require_version_text(self.version, schema_id, "version")
        _require_content_hash(self.content_hash, schema_id, "content_hash")


@dataclass(frozen=True, slots=True, kw_only=True)
class TaskTaxonomySnapshot:
    """An immutable, ordered task label list supplied by the host (D-07).

    Attributes:
        version: The caller's version for this label list.
        labels: Labels in the order the prompt renders them. Each passes the
            grammar, none is the reserved label, and none repeats.
    """

    SCHEMA_ID: ClassVar[str] = "rae.task_taxonomy_snapshot"
    SCHEMA_VERSION: ClassVar[int] = 1
    NAMESPACE: ClassVar[TaxonomyNamespace] = TaxonomyNamespace.TASK

    version: str
    labels: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        """Validate the version and every label.

        Raises:
            RecordValidationError: If the version or any label is invalid.
        """
        _validate_snapshot(TaskTaxonomySnapshot.SCHEMA_ID, self.version, self.labels)

    @property
    def content_hash(self) -> str:
        """The SHA-256 of the canonical namespace, version, and ordered labels."""
        return _content_hash(self.NAMESPACE, self.version, self.labels)

    @property
    def ref(self) -> TaxonomyRef:
        """The reference a decision records for this snapshot."""
        return TaxonomyRef(
            namespace=self.NAMESPACE,
            version=self.version,
            content_hash=self.content_hash,
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class JobTaxonomySnapshot:
    """An immutable, ordered job label list supplied by the host (D-07).

    A separate type from :class:`TaskTaxonomySnapshot`, not a subclass, so a
    job snapshot can never stand in for a task snapshot.

    Attributes:
        version: The caller's version for this label list.
        labels: Labels in the order the prompt renders them. Each passes the
            grammar, none is the reserved label, and none repeats.
    """

    SCHEMA_ID: ClassVar[str] = "rae.job_taxonomy_snapshot"
    SCHEMA_VERSION: ClassVar[int] = 1
    NAMESPACE: ClassVar[TaxonomyNamespace] = TaxonomyNamespace.JOB

    version: str
    labels: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        """Validate the version and every label.

        Raises:
            RecordValidationError: If the version or any label is invalid.
        """
        _validate_snapshot(JobTaxonomySnapshot.SCHEMA_ID, self.version, self.labels)

    @property
    def content_hash(self) -> str:
        """The SHA-256 of the canonical namespace, version, and ordered labels."""
        return _content_hash(self.NAMESPACE, self.version, self.labels)

    @property
    def ref(self) -> TaxonomyRef:
        """The reference a decision records for this snapshot."""
        return TaxonomyRef(
            namespace=self.NAMESPACE,
            version=self.version,
            content_hash=self.content_hash,
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class LabelProposal:
    """A validated label that the snapshot does not contain yet (D-10).

    The core never writes it anywhere. A host may record it through its own
    taxonomy write path.

    Attributes:
        namespace: The vocabulary the label is proposed for.
        label: The proposed label.
        taxonomy: The snapshot the label was missing from.
    """

    SCHEMA_ID: ClassVar[str] = "rae.label_proposal"
    SCHEMA_VERSION: ClassVar[int] = 1

    namespace: TaxonomyNamespace
    label: str
    taxonomy: TaxonomyRef

    def __post_init__(self) -> None:
        """Validate the label and that the namespaces agree.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = LabelProposal.SCHEMA_ID
        _require_exact_type(self.namespace, TaxonomyNamespace, schema_id, "namespace")
        _require_exact_type(self.label, str, schema_id, "label")
        _require_exact_type(self.taxonomy, TaxonomyRef, schema_id, "taxonomy")
        if not is_valid_label(self.label):
            raise RecordValidationError(schema_id, "label", "fails the label grammar")
        if self.label == UNCLASSIFIED_LABEL:
            raise RecordValidationError(schema_id, "label", "is the reserved label")
        if self.namespace is not self.taxonomy.namespace:
            raise RecordValidationError(
                schema_id, "namespace", "must equal the taxonomy namespace"
            )
