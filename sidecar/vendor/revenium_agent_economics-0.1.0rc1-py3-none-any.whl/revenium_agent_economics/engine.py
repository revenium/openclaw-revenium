"""The immutable engine: composes injected ports and runs task classification.

This is the only module that imports ``asyncio``, and it uses only
``asyncio.timeout`` (D-24, ADR 0012). Every async port call goes through
:func:`_call_port`, which binds its deadline before the ``try`` so
``deadline.expired()`` can tell the engine's timeout from a port's own
``TimeoutError`` and catch a late return (ADR 0007). Every sync port call goes
through :func:`_call_sync_port`, which has no deadline because threads are
banned (ADR 0025 decision 3). ``CancelledError`` is never caught.
"""

import asyncio
from collections.abc import Awaitable, Callable, Coroutine
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Final, Generic, TypeVar

from revenium_agent_economics._version import __version__
from revenium_agent_economics.assessment import (
    AssessJobRequest,
    AssessmentAbstention,
    AssessmentPolicy,
    JobAssessment,
    _abstention,
    _assessed_outcome,
    _Frame,
    _frame,
    _served_model,
    _valued,
)
from revenium_agent_economics.config import EngineConfig
from revenium_agent_economics.costs import empty_supplied_costs
from revenium_agent_economics.diagnostics import (
    Diagnostic,
    DiagnosticCode,
    DiagnosticLevel,
    NullDiagnostics,
)
from revenium_agent_economics.errors import ConfigurationError, RecordValidationError
from revenium_agent_economics.evidence import (
    ReportabilityPolicy,
    decider_failure_reportability,
    interpret_decider_result,
    reportability_before_decider,
    reportability_without_decider,
    resolve_evidence_class,
)
from revenium_agent_economics.jobs import (
    BUILTIN_JOB_SEGMENTER,
    AttributionBasis,
    JobInference,
    JobInferenceAbstention,
    JobInferenceAbstentionReason,
    JobInferenceRequest,
    JobOutcome,
    JobRejectionReason,
    _delegation_head,
    build_job_prompt,
    delegated_attribution,
    job_prompt_ref,
    parse_job_response,
)
from revenium_agent_economics.lineage import JobSubject
from revenium_agent_economics.outcomes import (
    BUILTIN_OUTCOME_EVALUATOR,
    OUTCOME_ABSTENTION_REASONS,
    OutcomeAbstention,
    OutcomeAbstentionReason,
    OutcomeProposal,
    OutcomeRequest,
    _effective_outcome,
    _outcome_abstention,
    build_outcome_prompt,
    outcome_prompt_ref,
    parse_outcome_response,
    render_role_vocabulary,
)
from revenium_agent_economics.protocols import (
    Clock,
    CompletionResult,
    ComponentDeclaration,
    DiagnosticSink,
    EvidenceResolver,
    IdGenerator,
    JobSegmentationInput,
    JobSegmenter,
    ModelCompletion,
    OutcomeEvaluationInput,
    OutcomeEvaluator,
    ReportabilityQuery,
    ResolvedAssumptions,
    TaskClassificationInput,
    TaskClassifier,
    TaxonomyReader,
    TaxonomyRecorder,
    ValuationPolicy,
)
from revenium_agent_economics.tasks import (
    BUILTIN_TASK_CLASSIFIER,
    ClassificationAbstention,
    PromptRef,
    TaskClassification,
    TaskClassificationRequest,
    build_task_prompt,
    inference_provenance,
    parse_task_response,
    task_prompt_ref,
)
from revenium_agent_economics.taxonomy import (
    ClassificationAbstentionReason,
    JobTaxonomySnapshot,
    LabelProposal,
    TaskTaxonomySnapshot,
    TaxonomyNamespace,
    TaxonomyRef,
)
from revenium_agent_economics.valuation import (
    MechanismAbstains,
    PolicyErrorMode,
    ValuationMethod,
    ValuationResult,
    _accepted_confidence,
    _text,
    builtin_declaration,
    builtin_plan,
    check_valuation_amount,
    hours_times_rate_result,
    parse_policy_output,
    price_builtin,
    validate_proposal,
)
from revenium_agent_economics.vocab import (
    DECLARABLE_EVIDENCE_CLASSES,
    ECONOMIC_MECHANISM_UNKNOWN,
    EVALUATOR_MECHANISMS,
    OPERATOR_ONLY_MECHANISMS,
    AbstentionReason,
    AssessmentRefusal,
    EconomicMechanism,
    EvidenceAuthority,
    EvidenceClass,
    ReportabilityReason,
    ReportabilityStatus,
)

# Diagnostic field values. "engine" means the engine's own deadline fired or
# the port returned after it; "port" means the port raised.
_ENGINE: Final = "engine"
_PORT: Final = "port"
_MODEL_STAGE: Final = "model"
_CLASSIFIER_STAGE: Final = "classifier"
_SEGMENTER_STAGE: Final = "segmenter"
_EVALUATOR_STAGE: Final = "evaluator"
# task.not_configured "missing" values.
_MISSING_READER: Final = "task_taxonomy"
_MISSING_CLASSIFIER: Final = "model_or_task_classifier"
# job.not_configured "missing" values, checked in this order (ADR 0018).
_MISSING_JOB_READER: Final = "job_taxonomy"
_MISSING_IDS: Final = "ids"
_MISSING_SEGMENTER: Final = "model_or_job_segmenter"
# outcome.not_configured "missing" value (ADR 0022 decision 4).
_MISSING_EVALUATOR: Final = "model_or_outcome_evaluator"
# The only slot whose declaration may name mechanisms (ADR 0011 rule 4).
_MECHANISM_SLOT: Final = "valuation_policy"

_T = TypeVar("_T")
_EVALUATOR_MECHANISM_VALUES: Final[frozenset[str]] = frozenset(
    mechanism.value for mechanism in EVALUATOR_MECHANISMS
)


def _resolved_mechanism(proposal: OutcomeProposal) -> str:
    # Hermes _resolve_economic_mechanism (classifier.py:L1748-L1784) for the
    # rejected record: the stripped text when it is an evaluator mechanism.
    # The gate's own TEXT read strips it, so a hand-built padded mechanism
    # records the same value Hermes does, and an OTHER-kind operand never
    # resolves.
    value = _text(proposal.economic_mechanism)
    if value is not None and value in _EVALUATOR_MECHANISM_VALUES:
        return value
    return ECONOMIC_MECHANISM_UNKNOWN


@dataclass(frozen=True, slots=True, kw_only=True, eq=False)
class EngineDependencies:
    """The host ports an engine calls.

    Only ``clock`` is required (research assumption A5). An engine without a
    task taxonomy reader, or without both a model and a task classifier, still
    constructs, and ``classify_task`` returns ``NOT_CONFIGURED``. Likewise,
    ``infer_jobs`` returns ``NOT_CONFIGURED`` without a job taxonomy reader,
    an ID generator, or either a model or a job segmenter (ADR 0018), and
    ``propose_outcome`` returns ``NOT_CONFIGURED`` without either an outcome
    evaluator or a model (ADR 0022). ``assess_job`` calls the valuation
    policy when ``AssessmentPolicy.method`` is ``INJECTED`` (ADR 0028), and
    the evidence decider for reportability rule 3 once rules 1 and 2 have
    passed (ADR 0025).

    Attributes:
        clock: The source of every decision timestamp.
        model: The model completion port for the built-in task classifier,
            the built-in job segmenter, and the built-in outcome evaluator.
        task_taxonomy: The task taxonomy read path.
        task_classifier: A host classifier. When set, it replaces the built-in
            model classifier.
        taxonomy_recorder: The host's write path for label proposals.
        job_taxonomy: The job taxonomy read path.
        job_segmenter: A host job segmenter. When set, it replaces the
            built-in model job segmenter.
        outcome_evaluator: A host outcome evaluator. When set, it replaces
            the built-in model evaluator.
        evidence_resolver: A host reportability decider. Its declaration
            casts the evidence leg of the precedence walk.
        valuation_policy: A host valuation policy.
        ids: The job id suffix source.
        diagnostics: The sink for engine diagnostics. The default discards
            them.
    """

    clock: Clock
    model: ModelCompletion | None = None
    task_taxonomy: TaxonomyReader[TaskTaxonomySnapshot] | None = None
    task_classifier: TaskClassifier | None = None
    taxonomy_recorder: TaxonomyRecorder | None = None
    job_taxonomy: TaxonomyReader[JobTaxonomySnapshot] | None = None
    job_segmenter: JobSegmenter | None = None
    outcome_evaluator: OutcomeEvaluator | None = None
    evidence_resolver: EvidenceResolver | None = None
    valuation_policy: ValuationPolicy | None = None
    ids: IdGenerator | None = None
    diagnostics: DiagnosticSink = field(default_factory=NullDiagnostics)

    def __post_init__(self) -> None:
        """Require a clock and a diagnostics sink.

        Raises:
            ConfigurationError: If ``clock`` or ``diagnostics`` is ``None``.
        """
        if self.clock is None:
            raise ConfigurationError("clock is required")
        if self.diagnostics is None:
            raise ConfigurationError(
                "diagnostics must be a sink; omit it for NullDiagnostics"
            )


@dataclass(frozen=True, slots=True)
class _PortFailure:
    exception_type: str
    source: str
    timed_out: bool


@dataclass(frozen=True, slots=True)
class _Returned(Generic[_T]):
    value: _T


async def _call_port(
    seconds: float, call: Callable[[], Awaitable[_T]]
) -> _Returned[_T] | _PortFailure:
    # The coroutine is created inside the deadline, so a port that raises
    # before its first await is bounded and caught like any other failure.
    deadline = asyncio.timeout(seconds)
    try:
        async with deadline:
            value = await call()
    except TimeoutError:
        return _PortFailure(
            TimeoutError.__qualname__,
            _ENGINE if deadline.expired() else _PORT,
            timed_out=True,
        )
    except Exception as error:  # noqa: BLE001 - D-02: a port failure is an abstention, never a crash
        # Only the type name is kept: messages can carry URLs or keys (T-02-10).
        return _PortFailure(type(error).__qualname__, _PORT, timed_out=False)
    if deadline.expired():
        # The port swallowed the cancellation and returned late; the deadline
        # is authoritative and the late result is discarded.
        return _PortFailure(TimeoutError.__qualname__, _ENGINE, timed_out=True)
    return _Returned(value)


def _call_sync_port(call: Callable[[], _T]) -> _Returned[_T] | _PortFailure:
    # ADR 0026 decision 5, ADR 0028 decision 5: a sync port has no deadline
    # (threads are banned), so a raise is the only failure it can report.
    # CancelledError and every other BaseException propagate.
    try:
        value = call()
    except Exception as error:  # noqa: BLE001 - D-11: a sync port failure is an abstention, never a crash
        # Only the type name is kept: messages can carry URLs or keys.
        return _PortFailure(type(error).__qualname__, _PORT, timed_out=False)
    if isinstance(value, Coroutine):
        # An async def where a sync port is required: close the coroutine so
        # it never runs, and let the caller refuse the unusable result.
        value.close()
    return _Returned(value)


def _read_declaration(slot: str, port: object) -> ComponentDeclaration:
    try:
        declaration = getattr(port, "declaration", None)
    except Exception:  # noqa: BLE001 - D-02/D-19: a raising declaration counts as missing
        declaration = None
    if type(declaration) is not ComponentDeclaration:
        raise ConfigurationError(
            f"{slot}: missing declaration; a ComponentDeclaration is required"
        )
    return declaration


def _validate_declarations(
    ports: tuple[tuple[str, object], ...], *, builtin_active: bool
) -> dict[str, ComponentDeclaration]:
    """Apply the five ADR 0011 rules to each injected port, in slot order.

    Args:
        ports: ``(slot_name, port)`` pairs in the fixed slot order.
        builtin_active: Whether the built-in model task classifier, job
            segmenter, or outcome evaluator can run, so their shared name
            counts toward uniqueness.

    Returns:
        The declaration read once and checked for each injected slot, keyed
        by slot name. A slot whose port is None has no entry.

    Raises:
        ConfigurationError: Naming the first offending slot.
    """
    builtin_names = {
        BUILTIN_TASK_CLASSIFIER.name,
        BUILTIN_JOB_SEGMENTER.name,
        BUILTIN_OUTCOME_EVALUATOR.name,
    }
    names: set[str] = builtin_names if builtin_active else set()
    checked: dict[str, ComponentDeclaration] = {}
    for slot, port in ports:
        if port is None:
            continue
        declaration = _read_declaration(slot, port)
        name = declaration.name
        evidence_class = declaration.evidence_class
        if evidence_class not in DECLARABLE_EVIDENCE_CLASSES:
            raise ConfigurationError(
                f"{slot}: component {name!r} declares the study evidence class "
                f"{evidence_class.value}, which no component may declare"
            )
        if evidence_class is EvidenceClass.MODEL_ESTIMATED:
            raise ConfigurationError(
                f"{slot}: component {name!r} declares MODEL_ESTIMATED, which "
                "is reserved for the built-in model classifier"
            )
        mechanisms = declaration.declared_mechanisms
        if slot == _MECHANISM_SLOT:
            undeclarable = [
                mechanism.value
                for mechanism in mechanisms
                if mechanism not in OPERATOR_ONLY_MECHANISMS
            ]
            if undeclarable:
                raise ConfigurationError(
                    f"{slot}: component {name!r} declares mechanisms "
                    f"{undeclarable!r} outside the operator-only set"
                )
        elif mechanisms:
            raise ConfigurationError(
                f"{slot}: component {name!r} declares mechanisms, which only a "
                "valuation policy may declare"
            )
        if name in names:
            raise ConfigurationError(
                f"{slot}: component name {name!r} duplicates another active component"
            )
        names.add(name)
        checked[slot] = declaration
    return checked


@dataclass(frozen=True, slots=True, eq=False)
class Engine:
    """Classifies turns against a host's taxonomy with the host's model.

    Frozen and compared by identity. Build one engine per host configuration
    and share it; there is no global state and no registry (D-21). Every
    injected component's declaration is checked at construction (D-19).

    Attributes:
        dependencies: The injected ports.
        config: Timeouts, call parameters, and prompt limits.
    """

    dependencies: EngineDependencies
    config: EngineConfig = field(default_factory=EngineConfig)
    _classifier_declaration: ComponentDeclaration | None = field(
        init=False, default=None, repr=False
    )
    _segmenter_declaration: ComponentDeclaration | None = field(
        init=False, default=None, repr=False
    )
    _evaluator_declaration: ComponentDeclaration | None = field(
        init=False, default=None, repr=False
    )
    _valuation_declaration: ComponentDeclaration | None = field(
        init=False, default=None, repr=False
    )
    _evidence_declaration: ComponentDeclaration | None = field(
        init=False, default=None, repr=False
    )

    def __post_init__(self) -> None:
        """Validate the composition and every component declaration.

        Each injected port's declaration is read exactly once.

        Raises:
            ConfigurationError: If either field has the wrong type, or an
                injected component's declaration breaks an ADR 0011 rule.
        """
        if type(self.dependencies) is not EngineDependencies:
            raise ConfigurationError(
                f"EngineDependencies required, got {type(self.dependencies).__name__!r}"
            )
        if type(self.config) is not EngineConfig:
            raise ConfigurationError(
                f"EngineConfig required, got {type(self.config).__name__!r}"
            )
        dependencies = self.dependencies
        # ADR 0011's fixed slot order: the first offending slot is reported.
        checked = _validate_declarations(
            (
                ("task_classifier", dependencies.task_classifier),
                ("job_segmenter", dependencies.job_segmenter),
                ("outcome_evaluator", dependencies.outcome_evaluator),
                ("evidence_resolver", dependencies.evidence_resolver),
                ("valuation_policy", dependencies.valuation_policy),
            ),
            # The built-in task classifier, job segmenter, and outcome
            # evaluator (BUILTIN_OUTCOME_EVALUATOR) all record the name "llm"
            # (ADR 0018 decision 7, ADR 0022 decision 9), so it is reserved
            # while any one of them can run beside a model (F-12).
            builtin_active=(
                (
                    dependencies.task_classifier is None
                    or dependencies.job_segmenter is None
                    or dependencies.outcome_evaluator is None
                )
                and dependencies.model is not None
            ),
        )
        if dependencies.task_classifier is not None:
            # Store the object read once and checked above, never a fresh
            # read, so a later change on the port can never alter what a
            # decision records.
            object.__setattr__(
                self, "_classifier_declaration", checked["task_classifier"]
            )
        if dependencies.job_segmenter is not None:
            # The same rule for the segmenter: a decision records the object
            # checked here, never a later read of the port (ADR 0018).
            object.__setattr__(self, "_segmenter_declaration", checked["job_segmenter"])
        if dependencies.outcome_evaluator is not None:
            # The same rule for the outcome evaluator (ADR 0011, ADR 0030
            # decision 8): records name the object checked here.
            object.__setattr__(
                self, "_evaluator_declaration", checked["outcome_evaluator"]
            )
        if dependencies.valuation_policy is not None:
            # The same rule for the valuation policy (ADR 0028 decision 5):
            # the evidence vote and the declared mechanisms come from the
            # object checked here, never a later read of the port.
            object.__setattr__(
                self, "_valuation_declaration", checked["valuation_policy"]
            )
        if dependencies.evidence_resolver is not None:
            # The same rule for the evidence decider (ADR 0025 decision 3):
            # the evidence vote and the decider diagnostic name the object
            # checked here, never a later read of the port.
            object.__setattr__(
                self, "_evidence_declaration", checked["evidence_resolver"]
            )

    async def classify_task(
        self, request: TaskClassificationRequest
    ) -> TaskClassification | ClassificationAbstention:
        """Classify one turn, or say why no label was produced (TASK-01).

        Reads the task taxonomy once. An injected task classifier takes
        precedence over the built-in model classifier. The built-in path
        renders the prompt with
        :func:`~revenium_agent_economics.tasks.build_task_prompt` and calls the
        model. Either path decides with
        :func:`~revenium_agent_economics.tasks.parse_task_response`. A new
        label's proposal is then forwarded to the taxonomy recorder, if one is
        injected; the returned decision never depends on the recorder.

        Args:
            request: The turn to classify.

        Returns:
            A classification, or an abstention carrying every reference that
            was reached.

        Raises:
            RecordValidationError: If ``request`` is not a
                ``TaskClassificationRequest``.
            ConfigurationError: If the reader returns anything other than a
                ``TaskTaxonomySnapshot``.
        """
        if type(request) is not TaskClassificationRequest:
            raise RecordValidationError(
                TaskClassificationRequest.SCHEMA_ID,
                "$",
                f"TaskClassificationRequest required, got {type(request).__name__}",
            )
        dependencies = self.dependencies
        reader = dependencies.task_taxonomy
        model = dependencies.model
        classifier = dependencies.task_classifier
        if reader is None or (model is None and classifier is None):
            self._warn(
                DiagnosticCode.TASK_NOT_CONFIGURED,
                missing=_MISSING_READER if reader is None else _MISSING_CLASSIFIER,
            )
            return self._abstain(ClassificationAbstentionReason.NOT_CONFIGURED, request)

        read = await _call_port(
            self.config.taxonomy_timeout_seconds,
            lambda: reader.snapshot(TaxonomyNamespace.TASK),
        )
        if isinstance(read, _PortFailure):
            # D-09: no fail-open to an empty taxonomy.
            self._warn(
                DiagnosticCode.TAXONOMY_READ_FAILED,
                exception_type=read.exception_type,
                source=read.source,
            )
            return self._abstain(
                ClassificationAbstentionReason.TAXONOMY_UNAVAILABLE, request
            )
        snapshot: object = read.value
        if type(snapshot) is not TaskTaxonomySnapshot:
            raise ConfigurationError(
                "task taxonomy reader must return TaskTaxonomySnapshot, "
                f"got {type(snapshot).__name__!r}"
            )

        if classifier is not None and self._classifier_declaration is not None:
            decision = await self._classify_with_classifier(
                classifier, self._classifier_declaration, request, snapshot
            )
        elif model is not None:
            decision = await self._classify_with_model(model, request, snapshot)
        else:  # pragma: no cover - excluded by the not-configured check above
            raise ConfigurationError("no task classifier or model is configured")

        recorder = dependencies.taxonomy_recorder
        if (
            recorder is not None
            and type(decision) is TaskClassification
            and decision.proposal is not None
        ):
            await self._forward_proposal(recorder, decision.proposal)
        return decision

    async def infer_jobs(self, request: JobInferenceRequest) -> JobInference:
        """Infer zero or more jobs for one lineage scope, or say why not (JOB-01).

        Reads the job taxonomy once. An injected job segmenter takes
        precedence over the built-in model segmenter. The built-in path
        renders the prompt with
        :func:`~revenium_agent_economics.jobs.build_job_prompt` and calls the
        model. Either path decides with
        :func:`~revenium_agent_economics.jobs.parse_job_response`, so every
        proposal becomes exactly one candidate or one rejection (ADR 0018).
        A request whose activity log counted dedupe collisions first emits
        ``envelope.dedupe_collision``, and every candidate records the log's
        boundary evidence. Each lineage flag on the subject emits its
        ``lineage.*`` diagnostic. A delegated subject whose root already has a head
        among ``prior_candidates`` returns its
        :func:`~revenium_agent_economics.jobs.delegated_attribution` before
        any port call. The head is resolved as
        :func:`~revenium_agent_economics.jobs.resolve_current` resolves it, so
        prior candidates whose pointers form a cycle of any length still
        yield one (ADR 0021). Each distinct new ``job_type`` label is then
        forwarded to the taxonomy recorder, if one is injected, once and in
        first-occurrence order; the returned inference never depends on the
        recorder.

        Args:
            request: The transcript sample and lineage scope.

        Returns:
            The inference. On any failure it carries an abstention and every
            reference that was reached; it never raises for a port failure.

        Raises:
            RecordValidationError: If ``request`` is not a
                ``JobInferenceRequest``.
            ConfigurationError: If the reader returns anything other than a
                ``JobTaxonomySnapshot``, the ID generator returns a malformed
                suffix or raises, or the ID generator keeps returning a
                suffix whose job id already appears in, or is named by a
                ``supersedes`` pointer of, ``prior_candidates``, or appears in
                the same inference.
        """
        if type(request) is not JobInferenceRequest:
            raise RecordValidationError(
                JobInferenceRequest.SCHEMA_ID,
                "$",
                f"JobInferenceRequest required, got {type(request).__name__}",
            )
        log = request.activity_log
        if log is not None and log.collision_count > 0:
            # D-06: a dedupe collision between non-identical events is never
            # silent; the log counts it and the engine reports it.
            self._warn(
                DiagnosticCode.ENVELOPE_DEDUPE_COLLISION, count=log.collision_count
            )
        self._report_lineage(request.subject)
        dependencies = self.dependencies
        if _delegation_head(request.subject, request.prior_candidates) is not None:
            # ADR 0018 decision 11: delegated work with a root head attaches to
            # it before any port call, as Hermes skips subagent sessions. The
            # clock is read here only when an attribution is returned.
            attributed = delegated_attribution(
                request.subject,
                request.prior_candidates,
                inferred_at=dependencies.clock.now(),
                subject_ref=request.subject_ref,
                activity_log=request.activity_log,
            )
            if attributed is not None:
                return attributed
        reader = dependencies.job_taxonomy
        ids = dependencies.ids
        model = dependencies.model
        segmenter = dependencies.job_segmenter
        if reader is None or ids is None or (model is None and segmenter is None):
            missing = (
                _MISSING_JOB_READER
                if reader is None
                else _MISSING_IDS
                if ids is None
                else _MISSING_SEGMENTER
            )
            self._warn(DiagnosticCode.JOB_NOT_CONFIGURED, missing=missing)
            return self._abstain_jobs(
                JobInferenceAbstentionReason.NOT_CONFIGURED, request
            )

        read = await _call_port(
            self.config.taxonomy_timeout_seconds,
            lambda: reader.snapshot(TaxonomyNamespace.JOB),
        )
        if isinstance(read, _PortFailure):
            # D-09: no fail-open to an empty taxonomy.
            self._warn(
                DiagnosticCode.TAXONOMY_READ_FAILED,
                exception_type=read.exception_type,
                source=read.source,
            )
            return self._abstain_jobs(
                JobInferenceAbstentionReason.TAXONOMY_UNAVAILABLE, request
            )
        snapshot: object = read.value
        if type(snapshot) is not JobTaxonomySnapshot:
            raise ConfigurationError(
                "job taxonomy reader must return JobTaxonomySnapshot, "
                f"got {type(snapshot).__name__!r}"
            )
        if segmenter is not None and self._segmenter_declaration is not None:
            inference = await self._infer_with_segmenter(
                segmenter, self._segmenter_declaration, ids, request, snapshot
            )
            source = _SEGMENTER_STAGE
        elif model is not None:
            inference = await self._infer_with_model(model, ids, request, snapshot)
            source = _MODEL_STAGE
        else:  # pragma: no cover - excluded by the not-configured check above
            raise ConfigurationError("no job segmenter or model is configured")
        self._report_job_proposals(inference, source)

        recorder = dependencies.taxonomy_recorder
        if recorder is not None and inference.abstention is None:
            await self._forward_job_proposals(recorder, inference)
        return inference

    async def propose_outcome(
        self, request: OutcomeRequest
    ) -> OutcomeProposal | OutcomeAbstention:
        """Ask the outcome evaluator about one job, or say why not (ADR 0022).

        A job whose effective outcome is not SUCCESS is never evaluated: the
        assertion's outcome, when one is set, replaces the candidate's, and
        a non-SUCCESS outcome returns ``NOT_EVALUATED_NON_SUCCESS`` before
        any port call (OUT-02, D-04). An injected outcome evaluator takes
        precedence over the built-in model evaluator and receives an
        :class:`~revenium_agent_economics.protocols.OutcomeEvaluationInput`.
        That input has no role vocabulary, so an injected evaluator never
        sees ``request.role_vocabulary``, and no diagnostic says so. A host
        that sets both must give the vocabulary to its evaluator itself.
        The built-in path renders the prompt with
        :func:`~revenium_agent_economics.outcomes.build_outcome_prompt` and
        calls the model. Either path decides with
        :func:`~revenium_agent_economics.outcomes.parse_outcome_response`.
        The result is untrusted: nothing in it is money until ``assess_job``
        gates it. ``asyncio.CancelledError`` is never caught.

        Args:
            request: The job and transcript sample to evaluate.

        Returns:
            The untrusted proposal, or an abstention carrying the evaluator
            and every reference that was reached. A port failure never
            raises.

        Raises:
            RecordValidationError: If ``request`` is not an ``OutcomeRequest``.
            ConfigurationError: If the configured outcome prompt version is
                unknown.
        """
        if type(request) is not OutcomeRequest:
            raise RecordValidationError(
                OutcomeRequest.SCHEMA_ID,
                "$",
                f"OutcomeRequest required, got {type(request).__name__}",
            )
        model = self.dependencies.model
        if _effective_outcome(request) is not JobOutcome.SUCCESS:
            # ADR 0022 decision 3, Hermes classifier.py:L5147-L5150: no port
            # is called. The record names the evaluator that would have run
            # (ADR 0030 decision 8).
            evaluator = self._evaluator_declaration
            if evaluator is None and model is not None:
                evaluator = BUILTIN_OUTCOME_EVALUATOR
            return self._abstain_outcome(
                OutcomeAbstentionReason.NOT_EVALUATED_NON_SUCCESS,
                request,
                evaluator=evaluator,
            )
        evaluator_port = self.dependencies.outcome_evaluator
        declaration = self._evaluator_declaration
        if evaluator_port is not None and declaration is not None:
            return await self._propose_with_evaluator(
                evaluator_port, declaration, request
            )
        if model is not None:
            return await self._propose_with_model(model, request)
        self._warn(DiagnosticCode.OUTCOME_NOT_CONFIGURED, missing=_MISSING_EVALUATOR)
        return self._abstain_outcome(OutcomeAbstentionReason.NOT_CONFIGURED, request)

    async def _propose_with_evaluator(
        self,
        evaluator: OutcomeEvaluator,
        declaration: ComponentDeclaration,
        request: OutcomeRequest,
    ) -> OutcomeProposal | OutcomeAbstention:
        # ADR 0022 decision 4: the reshaped port input, built only from the
        # request. The record names the declaration checked at construction.
        candidate = request.candidate
        evaluation_input = OutcomeEvaluationInput(
            job_id=candidate.boundary.job_id,
            job_type=candidate.type_assignment.job_type,
            job_name=candidate.boundary.job_name,
            transcript_sample=request.transcript_sample,
            max_hours_saved=request.bounds.max_hours_saved,
            max_loaded_rate=request.bounds.max_loaded_rate,
            currency=request.currency,
            subject_ref=request.subject_ref,
        )
        outcome = await _call_port(
            self.config.outcome_timeout_seconds,
            lambda: evaluator.evaluate(evaluation_input),
        )
        if isinstance(outcome, _PortFailure):
            # No fall-back to the built-in model (ADR 0011, ADR 0022
            # decision 8). Only the type name and a fixed source label are
            # kept (T-02-10).
            if outcome.timed_out:
                self._warn(
                    DiagnosticCode.OUTCOME_TIMED_OUT,
                    exception_type=outcome.exception_type,
                    source=outcome.source,
                    stage=_EVALUATOR_STAGE,
                )
                reason = OutcomeAbstentionReason.TIMED_OUT
            else:
                self._warn(
                    DiagnosticCode.OUTCOME_EVALUATOR_FAILED,
                    exception_type=outcome.exception_type,
                    source=outcome.source,
                )
                reason = OutcomeAbstentionReason.EVALUATOR_FAILED
            return self._abstain_outcome(reason, request, evaluator=declaration)

        decision = parse_outcome_response(
            outcome.value,
            request=request,
            evaluator=declaration,
            prompt_ref=None,
            provenance=None,
            proposed_at=self.dependencies.clock.now(),
            subject_ref=request.subject_ref,
        )
        if (
            type(decision) is OutcomeAbstention
            and decision.reason is OutcomeAbstentionReason.NOT_AN_OBJECT
        ):
            # The job path's analog is job.unparseable: an injected port's
            # unusable answer is reported, never silent. The bounded repr
            # stays on the record, not in the diagnostic.
            self._warn(DiagnosticCode.OUTCOME_INVALID, source=_EVALUATOR_STAGE)
        return decision

    async def _propose_with_model(
        self, model: ModelCompletion, request: OutcomeRequest
    ) -> OutcomeProposal | OutcomeAbstention:
        # Built before the port call, so an unknown prompt version raises
        # instead of reading as a provider failure.
        completion_request = build_outcome_prompt(request, config=self.config)
        prompt_ref = outcome_prompt_ref(config=self.config, request=request)
        if request.role_vocabulary is not None:
            # Hermes' counts-only truncation warning (classifier.py:L822-L826
            # at ed1fa952): never a role, never an amount (ADR 0022 Phase 6
            # gap-closure addendum, decision 7). The render is pure and
            # equals the one the builder used.
            rendered = render_role_vocabulary(request.role_vocabulary)
            if rendered.omitted > 0:
                self._warn(
                    DiagnosticCode.OUTCOME_ROLE_VOCABULARY_TRUNCATED,
                    offered=rendered.offered,
                    omitted=rendered.omitted,
                )
        outcome = await _call_port(
            self.config.outcome_timeout_seconds,
            lambda: model.complete(completion_request),
        )
        if isinstance(outcome, _PortFailure):
            if outcome.timed_out:
                self._warn(
                    DiagnosticCode.OUTCOME_TIMED_OUT,
                    exception_type=outcome.exception_type,
                    source=outcome.source,
                    stage=_MODEL_STAGE,
                )
                reason = OutcomeAbstentionReason.TIMED_OUT
            else:
                # Ledger ID-31: a provider failure is UNAVAILABLE, never
                # Hermes' "abstained" (classifier.py:L951-L956, ADR 0008).
                self._warn(
                    DiagnosticCode.OUTCOME_PROVIDER_FAILED,
                    exception_type=outcome.exception_type,
                    source=outcome.source,
                )
                reason = OutcomeAbstentionReason.UNAVAILABLE
            return self._abstain_outcome(
                reason,
                request,
                evaluator=BUILTIN_OUTCOME_EVALUATOR,
                prompt=prompt_ref,
            )
        result: object = outcome.value
        if type(result) is not CompletionResult:
            self._warn(
                DiagnosticCode.OUTCOME_PROVIDER_FAILED,
                result_type=type(result).__qualname__,
                source=_PORT,
            )
            return self._abstain_outcome(
                OutcomeAbstentionReason.UNAVAILABLE,
                request,
                evaluator=BUILTIN_OUTCOME_EVALUATOR,
                prompt=prompt_ref,
            )

        decision = parse_outcome_response(
            result.text,
            request=request,
            evaluator=BUILTIN_OUTCOME_EVALUATOR,
            prompt_ref=prompt_ref,
            provenance=inference_provenance(result),
            proposed_at=self.dependencies.clock.now(),
            subject_ref=request.subject_ref,
        )
        if (
            type(decision) is OutcomeAbstention
            and decision.reason is OutcomeAbstentionReason.INVALID
        ):
            self._warn(DiagnosticCode.OUTCOME_INVALID, source=_MODEL_STAGE)
        return decision

    def assess_job(
        self, request: AssessJobRequest, *, policy: AssessmentPolicy
    ) -> JobAssessment | AssessmentAbstention:
        """Turn one job's outcome proposal into an assessment (ADR 0030).

        Sync and pure: it awaits nothing and calls only pure stage functions
        (D-01). The branches run in Hermes order (ADR 0030 decision 4): a
        non-SUCCESS job, no usable proposal, newly enabled work, the operand
        gates, valuation, the evidence walk, reportability, then the band,
        costs, and ROI. Every branch keeps identity, provenance, costs, and
        coverage. Only the last returns a value: HoursTimesRate of the gated
        operands by default; a built-in RateCard, RevenueCard, or Baselines
        priced from ``request.figures``, whose delegation runs its
        ``FallbackPolicy`` fallback with ``produced_by`` set by the library;
        or, with ``method=INJECTED``, the product of the injected policy's
        gated ``quantity`` and ``unit_value`` operands. A policy that raises
        or returns unusable output gives a typed abstention under
        ``PolicyErrorMode.STRICT`` and never raises here (D-11). An injected
        evidence decider is called for a valued record only, after
        reportability rules 1 and 2, with a ``ReportabilityQuery`` built from
        the request; a decider that raises or returns anything but a known
        status fails closed to COMPUTED_NOT_REPORTABLE unless the caller
        chose ``DeciderFailureMode.HERMES_CONFIG_FALLBACK`` (D-10).

        A host's ``outcome_assertion`` sets the effective outcome before the
        proposal is read, so an asserted FAILED, CANCELLED, or UNRESOLVED job
        keeps its costs with a ZERO_NOT_COMPLETED value side and no port is
        called (D-04, VAL-06). ``metered_ai_cost`` rides on every record's
        ROI operands and never enters ``net_value`` (D-02, OD-18).

        Constructing the ``AssessJobRequest`` already refused a proposal or
        outcome abstention for another job id or job type, and a negative
        metered AI cost (ADR 0030 addendum item 1(a)). Every other
        request-valid input returns a record on every branch; nothing here
        catches an exception to return a record in its place.

        Args:
            request: The job, its proposal, and the host-resolved inputs.
            policy: The money policy. Keyword-only and required.

        Returns:
            A valued ``JobAssessment``, or an ``AssessmentAbstention`` saying
            why no value was recorded.

        Raises:
            RecordValidationError: Only when ``request`` is not exactly an
                ``AssessJobRequest``, its costs or metered AI cost are in
                another currency than the policy, or an outcome abstention
                with reason ``not_evaluated_non_success`` meets an effective
                SUCCESS outcome (ADR 0030 addendum item 1(b)).
            ConfigurationError: Only when ``policy`` is not exactly an
                ``AssessmentPolicy``, its method is ``INJECTED`` and the
                engine has no valuation policy, or the clock's ``now()`` is
                not an aware datetime with a zero UTC offset.
        """
        if type(request) is not AssessJobRequest:
            raise RecordValidationError(
                AssessJobRequest.SCHEMA_ID,
                "$",
                f"AssessJobRequest required, got {type(request).__name__}",
            )
        if type(policy) is not AssessmentPolicy:
            raise ConfigurationError(
                f"AssessmentPolicy required, got {type(policy).__name__!r}"
            )
        injected = policy.method is ValuationMethod.INJECTED
        if injected and self._valuation_declaration is None:
            raise ConfigurationError(
                "method injected requires EngineDependencies.valuation_policy"
            )
        # IN-05 (ADR 0030 Phase 6 addendum): the clock is read once and
        # checked before the window derivation compares it with a supplied
        # end, so a naive clock is a configuration error, never a TypeError.
        assessed_at = self.dependencies.clock.now()
        if type(assessed_at) is not datetime or assessed_at.utcoffset() != timedelta(0):
            raise ConfigurationError("clock.now() must return an aware UTC datetime")
        currency = policy.currency
        costs = (
            empty_supplied_costs(currency) if request.costs is None else request.costs
        )
        if costs.currency is not currency:
            raise RecordValidationError(
                AssessJobRequest.SCHEMA_ID,
                "costs",
                f"currency {costs.currency.value} must equal the policy currency "
                f"{currency.value}",
            )
        metered = request.metered_ai_cost
        if metered is not None and metered.currency is not currency:
            # D-02, ADR 0029 decision 4: a call-contract error, like costs.
            raise RecordValidationError(
                AssessJobRequest.SCHEMA_ID,
                "metered_ai_cost",
                f"currency {metered.currency.value} must equal the policy "
                f"currency {currency.value}",
            )
        proposal = request.proposal
        # ADR 0030 decision 4: the host's assertion, when present, replaces
        # the candidate's outcome before the proposal is read (D-04).
        effective = _assessed_outcome(request)
        if (
            type(proposal) is OutcomeAbstention
            and proposal.reason is OutcomeAbstentionReason.NOT_EVALUATED_NON_SUCCESS
            and effective is JobOutcome.SUCCESS
        ):
            raise RecordValidationError(
                AssessJobRequest.SCHEMA_ID,
                "proposal",
                "not_evaluated_non_success disagrees with a SUCCESS outcome",
            )
        frame = _frame(
            request,
            policy=policy,
            costs=costs,
            assessed_at=assessed_at,
            evaluator=self._provenance_evaluator(proposal),
            prompt_version=self.config.outcome_prompt_version,
        )
        plan = builtin_plan(policy.method)
        # ADR 0025 decision 2: abstention records walk the configured
        # components (Hermes L3409-L3437). HoursTimesRate and Baselines are
        # non-votes, the rate and revenue cards vote with their built-in
        # declarations, an injected policy votes with its stored
        # declaration, and an injected decider votes first with its stored
        # declaration (Hermes walks the configured evidence name too).
        abstained_evidence = resolve_evidence_class(
            evidence=self._evidence_declaration,
            valuation=(
                self._valuation_declaration
                if plan is None
                else builtin_declaration(plan.primary)
            ),
            evaluator=self._evaluator_declaration,
        )

        if effective is not JobOutcome.SUCCESS:
            # Hermes classifier.py:L5147-L5150, L5213-L5221: raw is None.
            return _abstention(
                frame,
                reason=AbstentionReason.NOT_EVALUATED_NON_SUCCESS,
                evidence=abstained_evidence,
            )
        if proposal is None:
            self._warn(DiagnosticCode.ASSESSMENT_NO_PROPOSAL, job_id=frame.job_id)
            return _abstention(
                frame,
                reason=AbstentionReason.UNKNOWN_EVALUATOR,
                evidence=abstained_evidence,
            )
        if type(proposal) is OutcomeAbstention:
            reason = OUTCOME_ABSTENTION_REASONS[proposal.reason]
            if proposal.reason is OutcomeAbstentionReason.NOT_AN_OBJECT:
                return self._rejected(
                    frame,
                    AssessmentRefusal.NOT_AN_OBJECT,
                    model=_served_model(proposal),
                    evidence=abstained_evidence,
                )
            return _abstention(frame, reason=reason, evidence=abstained_evidence)
        if type(proposal) is not OutcomeProposal:  # pragma: no cover - request-checked
            raise RecordValidationError(
                AssessJobRequest.SCHEMA_ID, "proposal", "unexpected proposal type"
            )

        model = _served_model(proposal)
        gated = validate_proposal(proposal, bounds=policy.bounds, currency=currency)
        if type(gated) is MechanismAbstains:
            # Hermes L4831-L4848: the only abstention that keeps raw.
            return _abstention(
                frame,
                reason=AbstentionReason.MECHANISM_ABSTAINS_FROM_VALUE,
                proposal=proposal,
                economic_mechanism=EconomicMechanism.NEWLY_ENABLED_WORK.value,
                model=model,
                evidence=abstained_evidence,
            )
        if type(gated) is AssessmentRefusal:
            return self._rejected(
                frame,
                gated,
                proposal=proposal,
                economic_mechanism=_resolved_mechanism(proposal),
                model=model,
                evidence=abstained_evidence,
            )
        if type(gated) is not ResolvedAssumptions:  # pragma: no cover
            raise RecordValidationError(
                AssessJobRequest.SCHEMA_ID, "proposal", "unexpected gate result"
            )

        valuation = (
            self._injected_valuation(gated, policy=policy, request=request)
            if plan is None
            else price_builtin(
                plan,
                gated,
                request.figures,
                attribution_certain=request.attribution_certain,
            )
        )
        if type(valuation) is AssessmentRefusal:
            return self._rejected(
                frame,
                valuation,
                proposal=proposal,
                economic_mechanism=gated.economic_mechanism.value,
                model=model,
                evidence=abstained_evidence,
            )
        if type(valuation) is not ValuationResult:  # pragma: no cover
            raise RecordValidationError(
                AssessJobRequest.SCHEMA_ID, "proposal", "unexpected valuation"
            )
        refusal = check_valuation_amount(
            valuation.amount,
            currency=currency,
            # ADR 0027 decision 4: the revenue ceiling applies only when a
            # declared operator mechanism was accepted (L2328-L2337).
            ceiling=policy.valuation_ceiling(
                declared_mechanism=valuation.declared_mechanism is not None
            ),
            # Hermes L2364-L2371: `>= 0` for HoursTimesRate, `> 0` for every
            # other producer.
            inclusive_zero=valuation.produced_by is ValuationMethod.HOURS_TIMES_RATE,
        )
        if refusal is not None or valuation.amount is None:
            return self._rejected(
                frame,
                refusal or AssessmentRefusal.VALUATION_AMOUNT_INVALID,
                proposal=proposal,
                economic_mechanism=gated.economic_mechanism.value,
                model=model,
                evidence=abstained_evidence,
            )
        # ADR 0025 decision 2: the evaluator leg votes only when the
        # proposal's recorded evaluator is the stored, construction-checked
        # declaration. The built-in "llm" and a hand-built proposal naming a
        # stronger declaration are non-votes. The valuation leg follows the
        # library-set produced_by (ADR 0028 decision 4): HoursTimesRate,
        # a delegation included, and Baselines are non-votes, the rate and
        # revenue cards vote only when they produced the value, and INJECTED
        # votes with the stored valuation_policy declaration. The evidence
        # leg is the stored decider declaration, when one is injected.
        stored = self._evaluator_declaration
        evidence = resolve_evidence_class(
            evidence=self._evidence_declaration,
            valuation=(
                self._valuation_declaration
                if valuation.produced_by is ValuationMethod.INJECTED
                else builtin_declaration(valuation.produced_by)
            ),
            evaluator=stored
            if stored is not None and stored == proposal.evaluator
            else None,
        )
        reportability = self._reportability(
            evidence[0], request=request, policy=policy.reportability
        )
        return _valued(
            frame,
            proposal=proposal,
            assumptions=gated,
            valuation=valuation,
            amount=valuation.amount,
            confidence=_accepted_confidence(proposal),
            band=policy.band,
            evidence=evidence,
            reportability=reportability,
        )

    def _reportability(
        self,
        evidence_class: EvidenceClass,
        *,
        request: AssessJobRequest,
        policy: ReportabilityPolicy,
    ) -> tuple[ReportabilityStatus, ReportabilityReason]:
        # ADR 0025 decision 4: Hermes' rules in order (L2973-L3089). Rules 1
        # and 2 run before any decider is consulted, so a decider can never
        # make an abstained record reportable, and a model-estimated one
        # passes rule 2 only under the caller's model-estimate opt-in
        # (ADR 0039).
        decider = self.dependencies.evidence_resolver
        declaration = self._evidence_declaration
        if decider is None or declaration is None:
            return reportability_without_decider(
                abstained=False, evidence_class=evidence_class, policy=policy
            )
        decided = reportability_before_decider(
            abstained=False, evidence_class=evidence_class, policy=policy
        )
        if decided is not None:
            return decided
        candidate = request.candidate
        job_id = candidate.boundary.job_id
        query = ReportabilityQuery(
            abstained=False,
            job_id=job_id,
            job_type=candidate.type_assignment.job_type,
            confirmed=request.evidence.confirmed,
            subject_ref=request.subject_ref,
        )
        # Rule 3, through the sync isolation helper (ADR 0025 decision 3).
        called = _call_sync_port(lambda: decider.decide(query))
        if isinstance(called, _PortFailure):
            # D-10: a raising decider fails closed unless the caller chose
            # Hermes' config fallback. Only the type name is kept.
            self._warn(
                DiagnosticCode.EVIDENCE_DECIDER_FAILED,
                job_id=job_id,
                component=declaration.name,
                exception_type=called.exception_type,
            )
            return decider_failure_reportability(policy=policy)
        status, reason, result_type = interpret_decider_result(
            called.value, policy=policy
        )
        if result_type is not None:
            # Only the type name: the result itself is never logged.
            self._warn(
                DiagnosticCode.EVIDENCE_DECIDER_FAILED,
                job_id=job_id,
                component=declaration.name,
                result_type=result_type,
            )
        return status, reason

    def _injected_valuation(
        self,
        assumptions: ResolvedAssumptions,
        *,
        policy: AssessmentPolicy,
        request: AssessJobRequest,
    ) -> ValuationResult | AssessmentRefusal:
        # ADR 0028 decisions 5 and 6: the host policy receives only the gated
        # assumptions, through _call_sync_port, and its output is parsed as
        # untrusted operands.
        port = self.dependencies.valuation_policy
        declaration = self._valuation_declaration
        if port is None or declaration is None:  # pragma: no cover - checked
            raise ConfigurationError(
                "method injected requires EngineDependencies.valuation_policy"
            )
        job_id = request.candidate.boundary.job_id
        called = _call_sync_port(lambda: port.value(assumptions))
        if isinstance(called, _PortFailure):
            self._warn(
                DiagnosticCode.VALUATION_POLICY_FAILED,
                job_id=job_id,
                component=declaration.name,
                exception_type=called.exception_type,
            )
            if policy.on_policy_error is PolicyErrorMode.FALLBACK_HOURS_TIMES_RATE:
                # Hermes L2184-L2196: the raise is replaced by HoursTimesRate,
                # with no mechanism or attribution re-check.
                return hours_times_rate_result(assumptions)
            return AssessmentRefusal.VALUATION_POLICY_FAILED
        parsed = parse_policy_output(
            called.value,
            declaration=declaration,
            currency=policy.currency,
            attribution_certain=request.attribution_certain,
        )
        if parsed is AssessmentRefusal.VALUATION_POLICY_FAILED:
            # Only the type name: the output itself is never logged.
            self._warn(
                DiagnosticCode.VALUATION_POLICY_FAILED,
                job_id=job_id,
                component=declaration.name,
                result_type=type(called.value).__qualname__,
            )
        return parsed

    def _provenance_evaluator(
        self, proposal: OutcomeProposal | OutcomeAbstention | None
    ) -> ComponentDeclaration | None:
        # ADR 0030 decision 8: the recorded evaluator, else the configured
        # one that would have run.
        if proposal is not None and proposal.evaluator is not None:
            return proposal.evaluator
        if self._evaluator_declaration is not None:
            return self._evaluator_declaration
        if self.dependencies.model is not None:
            return BUILTIN_OUTCOME_EVALUATOR
        return None

    def _rejected(
        self,
        frame: _Frame,
        refusal: AssessmentRefusal,
        *,
        proposal: OutcomeProposal | None = None,
        economic_mechanism: str = ECONOMIC_MECHANISM_UNKNOWN,
        model: str,
        evidence: tuple[EvidenceClass, EvidenceAuthority],
    ) -> AssessmentAbstention:
        self._warn(
            DiagnosticCode.ASSESSMENT_REJECTED,
            job_id=frame.job_id,
            refusal=refusal.value,
        )
        return _abstention(
            frame,
            reason=AbstentionReason.REJECTED,
            refusal=refusal,
            proposal=proposal,
            economic_mechanism=economic_mechanism,
            model=model,
            evidence=evidence,
        )

    def _report_lineage(self, subject: JobSubject) -> None:
        # D-08, ADR 0018 decision 8: each lineage flag the subject carries is
        # reported once, naming the node; Diagnostic.create escapes the ids.
        node = subject.node
        fields: dict[str, object] = {"session_id": node.session_id}
        if node.agent_id is not None:
            fields["agent_id"] = node.agent_id
        for flagged, code in (
            (subject.cycle_detected, DiagnosticCode.LINEAGE_CYCLE_DETECTED),
            (subject.depth_exceeded, DiagnosticCode.LINEAGE_DEPTH_EXCEEDED),
            (subject.parent_conflict, DiagnosticCode.LINEAGE_PARENT_CONFLICT),
        ):
            if flagged:
                self._warn(code, **fields)

    async def _forward_job_proposals(
        self, recorder: TaxonomyRecorder, inference: JobInference
    ) -> None:
        # ADR 0018 decision 3: once per distinct new label, in first-occurrence
        # candidate order, after the decision is final (research Pitfall 8).
        forwarded: set[str] = set()
        for candidate in inference.candidates:
            if candidate.attribution_basis is not AttributionBasis.INFERRED:
                continue
            proposal = candidate.type_assignment.proposal
            if proposal is None or proposal.label in forwarded:
                continue
            forwarded.add(proposal.label)
            await self._forward_proposal(recorder, proposal)

    def _report_job_proposals(self, inference: JobInference, source: str) -> None:
        # ADR 0018 decision 5: a rejected job_type label and an unreadable
        # answer are reported. Every other rejection is visible only in the
        # record, as on the task path (ADR 0013 decision 4).
        for rejection in inference.rejected:
            if rejection.reason is JobRejectionReason.JOB_TYPE_REJECTED:
                self._warn(
                    DiagnosticCode.JOB_LABEL_REJECTED,
                    index=rejection.index,
                    value=rejection.value_repr,
                )
        abstention = inference.abstention
        if (
            abstention is not None
            and abstention.reason is JobInferenceAbstentionReason.UNPARSEABLE
        ):
            self._warn(DiagnosticCode.JOB_UNPARSEABLE, source=source)

    async def _infer_with_segmenter(
        self,
        segmenter: JobSegmenter,
        declaration: ComponentDeclaration,
        ids: IdGenerator,
        request: JobInferenceRequest,
        snapshot: JobTaxonomySnapshot,
    ) -> JobInference:
        segmenter_input = JobSegmentationInput(
            transcript_sample=request.transcript_sample,
            snapshot=snapshot,
            subject=request.subject,
            host_display_name=self.config.host_display_name,
            subject_ref=request.subject_ref,
        )
        outcome = await _call_port(
            self.config.job_timeout_seconds,
            lambda: segmenter.segment(segmenter_input),
        )
        if isinstance(outcome, _PortFailure):
            # No fall-back to the built-in model (ADR 0011, ADR 0018).
            if outcome.timed_out:
                self._warn(
                    DiagnosticCode.JOB_TIMED_OUT,
                    exception_type=outcome.exception_type,
                    source=outcome.source,
                    stage=_SEGMENTER_STAGE,
                )
                reason = JobInferenceAbstentionReason.TIMED_OUT
            else:
                self._warn(
                    DiagnosticCode.JOB_SEGMENTER_FAILED,
                    component=declaration.name,
                    exception_type=outcome.exception_type,
                )
                reason = JobInferenceAbstentionReason.UNAVAILABLE
            return self._abstain_jobs(
                reason, request, taxonomy=snapshot.ref, segmenter=declaration
            )

        raw: object = outcome.value
        return parse_job_response(
            raw,
            snapshot,
            ids=ids,
            prompt_ref=None,
            inferred_at=self.dependencies.clock.now(),
            provenance=None,
            subject=request.subject,
            prior_candidates=request.prior_candidates,
            segmenter=declaration,
            subject_ref=request.subject_ref,
            double_counting_group=request.double_counting_group,
            double_counting_scope=request.double_counting_scope,
            activity_log=request.activity_log,
        )

    async def _infer_with_model(
        self,
        model: ModelCompletion,
        ids: IdGenerator,
        request: JobInferenceRequest,
        snapshot: JobTaxonomySnapshot,
    ) -> JobInference:
        completion_request = build_job_prompt(
            request.transcript_sample, snapshot, config=self.config
        )
        prompt_ref = job_prompt_ref(config=self.config)
        taxonomy_ref = snapshot.ref

        outcome = await _call_port(
            self.config.job_timeout_seconds,
            lambda: model.complete(completion_request),
        )
        if isinstance(outcome, _PortFailure):
            if outcome.timed_out:
                self._warn(
                    DiagnosticCode.JOB_TIMED_OUT,
                    exception_type=outcome.exception_type,
                    source=outcome.source,
                    stage=_MODEL_STAGE,
                )
                reason = JobInferenceAbstentionReason.TIMED_OUT
            else:
                self._warn(
                    DiagnosticCode.JOB_PROVIDER_FAILED,
                    exception_type=outcome.exception_type,
                    source=outcome.source,
                )
                reason = JobInferenceAbstentionReason.UNAVAILABLE
            return self._abstain_jobs(
                reason,
                request,
                taxonomy=taxonomy_ref,
                prompt=prompt_ref,
                segmenter=BUILTIN_JOB_SEGMENTER,
            )
        result: object = outcome.value
        if type(result) is not CompletionResult:
            self._warn(
                DiagnosticCode.JOB_PROVIDER_FAILED,
                result_type=type(result).__qualname__,
                source=_PORT,
            )
            return self._abstain_jobs(
                JobInferenceAbstentionReason.UNAVAILABLE,
                request,
                taxonomy=taxonomy_ref,
                prompt=prompt_ref,
                segmenter=BUILTIN_JOB_SEGMENTER,
            )

        return parse_job_response(
            result.text,
            snapshot,
            ids=ids,
            prompt_ref=prompt_ref,
            inferred_at=self.dependencies.clock.now(),
            provenance=inference_provenance(result),
            subject=request.subject,
            prior_candidates=request.prior_candidates,
            segmenter=BUILTIN_JOB_SEGMENTER,
            subject_ref=request.subject_ref,
            double_counting_group=request.double_counting_group,
            double_counting_scope=request.double_counting_scope,
            activity_log=request.activity_log,
        )

    async def _classify_with_classifier(
        self,
        classifier: TaskClassifier,
        declaration: ComponentDeclaration,
        request: TaskClassificationRequest,
        snapshot: TaskTaxonomySnapshot,
    ) -> TaskClassification | ClassificationAbstention:
        classifier_input = TaskClassificationInput(
            user_message=request.user_message,
            assistant_response=request.assistant_response,
            snapshot=snapshot,
            subject_ref=request.subject_ref,
        )
        outcome = await _call_port(
            self.config.task_timeout_seconds,
            lambda: classifier.classify(classifier_input),
        )
        if isinstance(outcome, _PortFailure):
            # D-18: no fall-back to the built-in model (ADR 0011).
            if outcome.timed_out:
                self._warn(
                    DiagnosticCode.TASK_TIMED_OUT,
                    exception_type=outcome.exception_type,
                    source=outcome.source,
                    stage=_CLASSIFIER_STAGE,
                )
                reason = ClassificationAbstentionReason.TIMED_OUT
            else:
                self._warn(
                    DiagnosticCode.TASK_CLASSIFIER_FAILED,
                    component=declaration.name,
                    exception_type=outcome.exception_type,
                )
                reason = ClassificationAbstentionReason.UNAVAILABLE
            return self._abstain(
                reason, request, taxonomy=snapshot.ref, classifier=declaration
            )

        raw: object = outcome.value
        decision = parse_task_response(
            raw,
            snapshot,
            prompt_ref=None,
            classified_at=self.dependencies.clock.now(),
            provenance=None,
            classifier=declaration,
            subject_ref=request.subject_ref,
        )
        if type(decision) is ClassificationAbstention:
            if decision.reason is ClassificationAbstentionReason.INVALID_LABEL_TYPE:
                self._warn(
                    DiagnosticCode.TASK_LABEL_TYPE_INVALID,
                    type_name=type(raw).__qualname__,
                )
            elif decision.reason is ClassificationAbstentionReason.LABEL_REJECTED:
                # The classifier path validates unstripped output (ADR 0013).
                self._warn(DiagnosticCode.TASK_LABEL_REJECTED, label=raw)
        return decision

    async def _classify_with_model(
        self,
        model: ModelCompletion,
        request: TaskClassificationRequest,
        snapshot: TaskTaxonomySnapshot,
    ) -> TaskClassification | ClassificationAbstention:
        completion_request = build_task_prompt(
            request.user_message,
            request.assistant_response,
            snapshot,
            config=self.config,
        )
        prompt_ref = task_prompt_ref(config=self.config)
        taxonomy_ref = snapshot.ref

        outcome = await _call_port(
            self.config.task_timeout_seconds,
            lambda: model.complete(completion_request),
        )
        if isinstance(outcome, _PortFailure):
            if outcome.timed_out:
                self._warn(
                    DiagnosticCode.TASK_TIMED_OUT,
                    exception_type=outcome.exception_type,
                    source=outcome.source,
                    stage=_MODEL_STAGE,
                )
                reason = ClassificationAbstentionReason.TIMED_OUT
            else:
                self._warn(
                    DiagnosticCode.TASK_PROVIDER_FAILED,
                    exception_type=outcome.exception_type,
                    source=outcome.source,
                )
                reason = ClassificationAbstentionReason.UNAVAILABLE
            return self._abstain(
                reason,
                request,
                taxonomy=taxonomy_ref,
                prompt=prompt_ref,
                classifier=BUILTIN_TASK_CLASSIFIER,
            )
        result: object = outcome.value
        if type(result) is not CompletionResult:
            self._warn(
                DiagnosticCode.TASK_PROVIDER_FAILED,
                result_type=type(result).__qualname__,
                source=_PORT,
            )
            return self._abstain(
                ClassificationAbstentionReason.UNAVAILABLE,
                request,
                taxonomy=taxonomy_ref,
                prompt=prompt_ref,
                classifier=BUILTIN_TASK_CLASSIFIER,
            )

        decision = parse_task_response(
            result.text,
            snapshot,
            prompt_ref=prompt_ref,
            classified_at=self.dependencies.clock.now(),
            provenance=inference_provenance(result),
            subject_ref=request.subject_ref,
        )
        if (
            type(decision) is ClassificationAbstention
            and decision.reason is ClassificationAbstentionReason.LABEL_REJECTED
        ):
            # The model path strips before validating, so the label recorded
            # is exactly the text validate_label saw (D-17).
            self._warn(DiagnosticCode.TASK_LABEL_REJECTED, label=result.text.strip())
        return decision

    async def _forward_proposal(
        self, recorder: TaxonomyRecorder, proposal: LabelProposal
    ) -> None:
        # D-10: the decision is already final; this step only reports.
        outcome = await _call_port(
            self.config.recorder_timeout_seconds,
            lambda: recorder.record(proposal),
        )
        if isinstance(outcome, _PortFailure):
            self._warn(
                DiagnosticCode.TAXONOMY_RECORD_FAILED,
                exception_type=outcome.exception_type,
                source=outcome.source,
                label=proposal.label,
            )

    def _warn(self, code: DiagnosticCode, **fields: object) -> None:
        self._emit(Diagnostic.create(code, DiagnosticLevel.WARNING, **fields))

    def _emit(self, diagnostic: Diagnostic) -> None:
        try:
            self.dependencies.diagnostics.emit(diagnostic)
        except Exception:  # noqa: BLE001 - A6/D-02: a failing sink never changes a decision
            return

    def _abstain(
        self,
        reason: ClassificationAbstentionReason,
        request: TaskClassificationRequest,
        *,
        taxonomy: TaxonomyRef | None = None,
        prompt: PromptRef | None = None,
        classifier: ComponentDeclaration | None = None,
    ) -> ClassificationAbstention:
        return ClassificationAbstention(
            reason=reason,
            taxonomy=taxonomy,
            prompt=prompt,
            inference=None,
            classifier=classifier,
            classified_at=self.dependencies.clock.now(),
            subject_ref=request.subject_ref,
            library_version=__version__,
        )

    def _abstain_outcome(
        self,
        reason: OutcomeAbstentionReason,
        request: OutcomeRequest,
        *,
        evaluator: ComponentDeclaration | None = None,
        prompt: PromptRef | None = None,
    ) -> OutcomeAbstention:
        return _outcome_abstention(
            reason,
            request,
            abstained_at=self.dependencies.clock.now(),
            evaluator=evaluator,
            prompt=prompt,
        )

    def _abstain_jobs(
        self,
        reason: JobInferenceAbstentionReason,
        request: JobInferenceRequest,
        *,
        taxonomy: TaxonomyRef | None = None,
        prompt: PromptRef | None = None,
        segmenter: ComponentDeclaration | None = None,
    ) -> JobInference:
        return JobInference(
            abstention=JobInferenceAbstention(reason=reason),
            taxonomy=taxonomy,
            prompt=prompt,
            inference=None,
            segmenter=segmenter,
            subject=request.subject,
            inferred_at=self.dependencies.clock.now(),
            subject_ref=request.subject_ref,
            library_version=__version__,
        )
