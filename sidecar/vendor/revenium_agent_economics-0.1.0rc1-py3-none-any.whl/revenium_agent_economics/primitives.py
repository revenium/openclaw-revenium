"""Value records shared by every decision record, and context-proof money math.

Records are frozen, slotted, keyword-only dataclasses. Each validates exact
runtime types in ``__post_init__`` and carries a schema id and version that are
independent of the package version.

Money arithmetic never reads the ambient thread-local decimal context: every
operation goes through ``_MONEY_CONTEXT`` or passes ``rounding=`` explicitly.
"""

import decimal
import math
from collections.abc import Mapping
from dataclasses import dataclass
from decimal import Decimal
from types import MappingProxyType
from typing import ClassVar, Final

from revenium_agent_economics._bounded import (
    IFS_CHARACTERS,
    NARRATIVE_CLAMP_BYTES,
    STUDY_ID_MAX_BYTES,
    serialized_byte_length,
)
from revenium_agent_economics.errors import RecordValidationError
from revenium_agent_economics.vocab import AbstentionReason, Currency

_MONEY_CONTEXT: Final = decimal.Context(
    prec=28,
    rounding=decimal.ROUND_HALF_UP,
    Emin=-999999,
    Emax=999999,
    capitals=1,
    clamp=0,
    flags=[],
    traps=[decimal.InvalidOperation, decimal.Overflow, decimal.DivisionByZero],
)
MINOR_UNITS: Final[Mapping[Currency, int]] = MappingProxyType(
    dict.fromkeys(Currency, 2)
)
_COMPONENT_NAME_MAX_BYTES: Final = 64
_MONEY_SCHEMA_ID: Final = "rae.money"


def decimal_from_float(value: int | float) -> Decimal:
    """Convert a host number to ``Decimal`` through its shortest ``repr``.

    ``Decimal(repr(33.33))`` is ``Decimal("33.33")``, whereas ``Decimal(33.33)``
    is the float's exact binary expansion, which would reproduce float
    behavior instead of the documented rounding rule.

    Args:
        value: A finite ``int`` or ``float``. ``bool`` is rejected.

    Returns:
        The decimal value of ``repr(value)``.

    Raises:
        RecordValidationError: If ``value`` is a bool, not an int or float, or
            not finite.
    """
    if type(value) is not int and type(value) is not float:
        raise RecordValidationError(
            _MONEY_SCHEMA_ID,
            "amount",
            f"int or float required, got {type(value).__name__}",
        )
    if not math.isfinite(value):
        raise RecordValidationError(
            _MONEY_SCHEMA_ID, "amount", f"finite value required: {value!r}"
        )
    return Decimal(repr(value))


def money_multiply(a: Decimal, b: Decimal) -> Decimal:
    """Multiply two money operands under the module money context.

    Args:
        a: The first operand.
        b: The second operand.

    Returns:
        The product at 28 significant digits, independent of the ambient context.
    """
    return _MONEY_CONTEXT.multiply(a, b)


def quantize_money(amount: Decimal, currency: Currency) -> Decimal:
    """Quantize ``amount`` to the minor unit of ``currency`` with ``ROUND_HALF_UP``.

    Args:
        amount: The unrounded amount.
        currency: The currency whose minor unit sets the exponent.

    Returns:
        The quantized amount, independent of the ambient context.
    """
    quantum = Decimal((0, (1,), -MINOR_UNITS[currency]))
    return amount.quantize(
        quantum, rounding=decimal.ROUND_HALF_UP, context=_MONEY_CONTEXT
    )


def _require_minor_unit_scale(
    amount: Decimal, currency: Currency, schema_id: str, field: str
) -> None:
    # ADR 0030 Phase 6 owner-decision addendum (Phase 4 WR-08): a recorded
    # money amount carries exactly the currency's minor-unit exponent, so two
    # equal records always encode to equal bytes. Numeric equality is not
    # enough: Decimal("300") == Decimal("300.00"). The message names the
    # rule, never the value.
    places = MINOR_UNITS[currency]
    if amount.as_tuple().exponent != -places:
        raise RecordValidationError(
            schema_id,
            field,
            f"must have exactly {places} decimal places, the currency minor unit",
        )


def _require_exact_type(
    value: object, expected: type, schema_id: str, field: str
) -> None:
    if type(value) is not expected:
        raise RecordValidationError(
            schema_id,
            field,
            f"{expected.__name__} required, got {type(value).__name__}",
        )


def _require_tuple_of(
    value: object, element_type: type, schema_id: str, field: str
) -> None:
    if type(value) is not tuple:
        raise RecordValidationError(
            schema_id, field, f"tuple required, got {type(value).__name__}"
        )
    for index, element in enumerate(value):
        if type(element) is not element_type:
            raise RecordValidationError(
                schema_id,
                field,
                f"element {index} must be {element_type.__name__}, "
                f"got {type(element).__name__}",
            )


def _require_text(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, str, schema_id, field)
    if value == "":
        raise RecordValidationError(schema_id, field, "must not be empty")


def _require_version_number(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, int, schema_id, field)
    if isinstance(value, int) and value < 1:
        raise RecordValidationError(
            schema_id, field, f"must be at least 1, got {value!r}"
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class Money:
    """An exact decimal amount in a supported currency.

    Attributes:
        amount: A finite ``Decimal``. Quantization happens only at documented
            derivation points, so the amount is not forced to the minor unit.
        currency: The currency of ``amount``.
    """

    SCHEMA_ID: ClassVar[str] = "rae.money"
    SCHEMA_VERSION: ClassVar[int] = 1

    amount: Decimal
    currency: Currency

    def __post_init__(self) -> None:
        """Reject non-Decimal or non-finite amounts and non-Currency currencies."""
        _require_exact_type(self.amount, Decimal, Money.SCHEMA_ID, "amount")
        if not self.amount.is_finite():
            raise RecordValidationError(
                Money.SCHEMA_ID, "amount", f"finite Decimal required: {self.amount!r}"
            )
        _require_exact_type(self.currency, Currency, Money.SCHEMA_ID, "currency")


@dataclass(frozen=True, slots=True, kw_only=True)
class Confidence:
    """A confidence score in the closed unit interval.

    Attributes:
        value: A finite ``float`` from 0.0 to 1.0 inclusive.
    """

    SCHEMA_ID: ClassVar[str] = "rae.confidence"
    SCHEMA_VERSION: ClassVar[int] = 1

    value: float

    def __post_init__(self) -> None:
        """Reject non-float, non-finite, or out-of-range values."""
        _require_exact_type(self.value, float, Confidence.SCHEMA_ID, "value")
        if not 0.0 <= self.value <= 1.0:
            raise RecordValidationError(
                Confidence.SCHEMA_ID,
                "value",
                f"must be within [0.0, 1.0]: {self.value!r}",
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class ComponentVersion:
    """The declared version of one injected component.

    Attributes:
        name: The component name, at most 64 serialized bytes.
        version: The version the component declares.
    """

    SCHEMA_ID: ClassVar[str] = "rae.component_version"
    SCHEMA_VERSION: ClassVar[int] = 1

    name: str
    version: str

    def __post_init__(self) -> None:
        """Reject empty or oversized names and empty versions."""
        _require_text(self.name, ComponentVersion.SCHEMA_ID, "name")
        if serialized_byte_length(self.name) > _COMPONENT_NAME_MAX_BYTES:
            raise RecordValidationError(
                ComponentVersion.SCHEMA_ID,
                "name",
                f"must be at most {_COMPONENT_NAME_MAX_BYTES} serialized bytes",
            )
        _require_text(self.version, ComponentVersion.SCHEMA_ID, "version")


@dataclass(frozen=True, slots=True, kw_only=True)
class VersionStamp:
    """Every version that produced a decision record.

    Attributes:
        schema_id: The schema id of the stamped record.
        schema_version: The schema version of the stamped record, at least 1.
        library_version: The package version that produced the record.
        taxonomy_version: The taxonomy snapshot version, if one was used.
        prompt_version: The prompt version, at least 1, if a prompt was used.
        policy_version: The caller policy version, if a policy was used.
        component_versions: Declared versions of injected components, with
            unique names.
    """

    SCHEMA_ID: ClassVar[str] = "rae.version_stamp"
    SCHEMA_VERSION: ClassVar[int] = 1

    schema_id: str
    schema_version: int
    library_version: str
    taxonomy_version: str | None = None
    prompt_version: int | None = None
    policy_version: str | None = None
    component_versions: tuple[ComponentVersion, ...] = ()

    def __post_init__(self) -> None:
        """Reject invalid scalars, non-tuple components, and duplicate names."""
        schema_id = VersionStamp.SCHEMA_ID
        _require_text(self.schema_id, schema_id, "schema_id")
        _require_version_number(self.schema_version, schema_id, "schema_version")
        _require_text(self.library_version, schema_id, "library_version")
        if self.taxonomy_version is not None:
            _require_text(self.taxonomy_version, schema_id, "taxonomy_version")
        if self.prompt_version is not None:
            _require_version_number(self.prompt_version, schema_id, "prompt_version")
        if self.policy_version is not None:
            _require_text(self.policy_version, schema_id, "policy_version")
        _require_tuple_of(
            self.component_versions, ComponentVersion, schema_id, "component_versions"
        )
        names = [component.name for component in self.component_versions]
        if len(set(names)) != len(names):
            raise RecordValidationError(
                schema_id, "component_versions", "component names must be unique"
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class Abstention:
    """A component's explicit refusal to decide.

    Attributes:
        reason: Why the component abstained.
        detail: Optional narrative: non-empty, free of IFS characters and
            leading whitespace, and at most ``NARRATIVE_CLAMP_BYTES``
            serialized bytes. Trailing whitespace is allowed because a
            narrative clamp that cuts after a space keeps it.
    """

    SCHEMA_ID: ClassVar[str] = "rae.abstention"
    SCHEMA_VERSION: ClassVar[int] = 1

    reason: AbstentionReason
    detail: str | None = None

    def __post_init__(self) -> None:
        """Reject non-member reasons and empty or out-of-bounds details."""
        _require_exact_type(
            self.reason, AbstentionReason, Abstention.SCHEMA_ID, "reason"
        )
        if self.detail is None:
            return
        _require_text(self.detail, Abstention.SCHEMA_ID, "detail")
        if (
            any(character in self.detail for character in IFS_CHARACTERS)
            or self.detail != self.detail.lstrip()
            or serialized_byte_length(self.detail) > NARRATIVE_CLAMP_BYTES
        ):
            raise RecordValidationError(
                Abstention.SCHEMA_ID,
                "detail",
                "must have no IFS characters or leading whitespace and be "
                f"at most {NARRATIVE_CLAMP_BYTES} serialized bytes",
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class StudyReference:
    """A host's reference to the study its jobs relate to (ADR 0026, D-14).

    Its documented home is ``revenium_agent_economics.studies``, which also
    holds the :func:`~revenium_agent_economics.studies.study_reference`
    factory. It is defined here, one layer below ``evidence`` and
    ``assessment``, so those modules can type a study field without
    importing ``studies``. A reference never changes an evidence class.

    The record accepts exactly the shape the factory produces, a port of
    Hermes ``_resolve_study_reference`` (classifier.py:L3105-L3168).

    Attributes:
        study_id: The study id, normalized like Hermes
            ``_clamp_assessment_text``: not blank, no IFS characters, no
            leading whitespace, and at most ``STUDY_ID_MAX_BYTES``
            serialized bytes. Trailing whitespace is allowed because a clamp
            that cuts after a space keeps it.
        study_version: The study version, an ``int`` of at least 1. A
            ``bool`` is rejected.
    """

    SCHEMA_ID: ClassVar[str] = "rae.study_reference"
    SCHEMA_VERSION: ClassVar[int] = 1

    study_id: str
    study_version: int

    def __post_init__(self) -> None:
        """Reject a blank, unnormalized, or oversized id and a bad version.

        Raises:
            RecordValidationError: If either field is invalid.
        """
        schema_id = StudyReference.SCHEMA_ID
        _require_exact_type(self.study_id, str, schema_id, "study_id")
        if self.study_id.strip() == "":
            raise RecordValidationError(schema_id, "study_id", "must not be blank")
        if (
            any(character in self.study_id for character in IFS_CHARACTERS)
            or self.study_id != self.study_id.lstrip()
            or serialized_byte_length(self.study_id) > STUDY_ID_MAX_BYTES
        ):
            raise RecordValidationError(
                schema_id,
                "study_id",
                "must be normalized text with no IFS characters and no leading "
                f"whitespace, at most {STUDY_ID_MAX_BYTES} serialized bytes",
            )
        _require_version_number(self.study_version, schema_id, "study_version")
