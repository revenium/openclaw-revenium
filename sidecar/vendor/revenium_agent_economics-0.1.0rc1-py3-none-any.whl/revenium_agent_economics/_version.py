"""The package version, importable by core modules below the package root."""

from typing import Final

__version__: Final = "0.1.0rc1"
