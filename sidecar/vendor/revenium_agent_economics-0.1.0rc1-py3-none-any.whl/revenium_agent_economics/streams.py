"""Normalize a host activity stream into a deterministic log (ADR 0015 decision 4).

:func:`normalize_stream` sits at layer 8, above ``serialization``, because the
dedupe winner is defined on codec bytes (ADR 0016 decision 2). The module is
pure: it counts dedupe collisions on the log and never emits diagnostics; the
engine reports them as ``envelope.dedupe_collision``.
"""

from collections.abc import Iterable

from revenium_agent_economics.envelope import ActivityEvent, ActivityLog
from revenium_agent_economics.errors import RecordValidationError
from revenium_agent_economics.serialization import encode_record


def normalize_stream(events: Iterable[ActivityEvent]) -> ActivityLog:
    """Deduplicate and totally order activity events (D-06, ENV-02).

    Events are grouped by ``dedupe_key``. Each group keeps the event whose
    ``encode_record`` bytes are lowest, and a group whose events have two or
    more distinct encodings counts as one collision. The kept events are
    sorted by ``ActivityEvent.order_key``.

    Duplicating or reordering the input never changes the output: the winner,
    the collision count, and the order depend only on the set of distinct
    events.

    Args:
        events: The events, in any order, possibly repeated.

    Returns:
        The log, with ``collision_count`` set.

    Raises:
        RecordValidationError: If an element is not an ``ActivityEvent``.
    """
    materialized = tuple(events)
    encodings: dict[str, dict[bytes, ActivityEvent]] = {}
    for index, event in enumerate(materialized):
        if type(event) is not ActivityEvent:
            raise RecordValidationError(
                ActivityLog.SCHEMA_ID,
                "events",
                f"element {index} must be ActivityEvent, got {type(event).__name__}",
            )
        encodings.setdefault(event.dedupe_key, {})[encode_record(event)] = event
    kept = [group[min(group)] for group in encodings.values()]
    collisions = sum(1 for group in encodings.values() if len(group) > 1)
    kept.sort(key=lambda event: event.order_key)
    return ActivityLog(events=tuple(kept), collision_count=collisions)
