"""Study references: the typed pointer from a job to a study (ADR 0026, D-14).

This module is the documented home of :class:`StudyReference` and the
:func:`study_reference` factory. The class itself is defined in
``primitives`` so the records can type their study field without importing
this module.

Three rules hold here:

- A study reference never changes an evidence class. The class comes only
  from the precedence walk over engine-checked declarations, and a record
  with a study evidence class (ASSOCIATIONAL, QUASI_EXPERIMENTAL_IMPACT,
  EXPERIMENTAL_IMPACT) is refused without a reference.
- ``assessment``, ``evidence``, ``valuation``, ``costs``, and ``outcomes``
  may not import this module (``FORBIDDEN_EDGES`` in the layering test), so
  no value claim can inherit causal evidence from a study.
- Study computation is deferred (D-14). The Hermes contracts that validate
  and compute studies, ``impact_study.validate`` and ``cohort_impact``, are
  not ported, and this module will hold them when they are.
"""

from revenium_agent_economics._bounded import (
    STUDY_ID_MAX_BYTES as STUDY_ID_MAX_BYTES,
)
from revenium_agent_economics._bounded import normalize_text
from revenium_agent_economics.primitives import StudyReference as StudyReference

__all__ = ["STUDY_ID_MAX_BYTES", "StudyReference", "study_reference"]


def study_reference(study_id: object, study_version: object) -> StudyReference | None:
    """Resolve a caller-supplied study id and version, all or none.

    A port of Hermes ``_resolve_study_reference`` (classifier.py:L3105-L3168).
    The id must be a ``str`` that is not blank after ``strip()``; it is then
    normalized and clamped, not rejected, to ``STUDY_ID_MAX_BYTES``
    serialized bytes (L3096). The version must be an ``int`` of at least 1,
    and a ``bool`` is rejected. If either check fails, or the id normalizes
    to nothing, there is no reference at all. Hermes records that absence
    as ``("", 0)``. The function never raises.

    Args:
        study_id: The caller's study id.
        study_version: The caller's study version.

    Returns:
        The reference, or ``None`` when either value is unusable.
    """
    if not isinstance(study_id, str) or not study_id.strip():
        return None
    if (
        isinstance(study_version, bool)
        or not isinstance(study_version, int)
        or study_version < 1
    ):
        return None
    normalized = normalize_text(study_id, max_bytes=STUDY_ID_MAX_BYTES)
    if not normalized:
        return None
    # An int subclass becomes a plain int, which the record requires.
    return StudyReference(study_id=normalized, study_version=int(study_version))
