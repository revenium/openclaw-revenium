"""Deterministic fakes for the engine's ports (D-30).

They import only the package root, never pytest or asyncio, so host test
suites and the library's own tests can use them. Fakes that hang or sleep
belong in a test suite, where event-loop APIs are allowed.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Final, Generic, TypeVar, cast

from revenium_agent_economics import (
    CompletionRequest,
    CompletionResult,
    CompletionUnavailable,
    ComponentDeclaration,
    ConfigurationError,
    Diagnostic,
    EconomicMechanism,
    EvidenceClass,
    JobSegmentationInput,
    JobTaxonomySnapshot,
    JsonValue,
    LabelProposal,
    OutcomeEvaluationInput,
    ReportabilityQuery,
    ResolvedAssumptions,
    TaskClassificationInput,
    TaskTaxonomySnapshot,
    TaxonomyNamespace,
)

_SnapshotT = TypeVar("_SnapshotT", TaskTaxonomySnapshot, JobTaxonomySnapshot)


@dataclass(frozen=True, slots=True)
class FixedClock:
    """A clock that always returns the same aware UTC instant.

    Attributes:
        instant: The time :meth:`now` returns.
    """

    instant: datetime

    def __post_init__(self) -> None:
        """Require an aware datetime with a zero UTC offset.

        Raises:
            ConfigurationError: If ``instant`` is naive or not UTC.
        """
        if type(self.instant) is not datetime or self.instant.utcoffset() != timedelta(
            0
        ):
            raise ConfigurationError(
                f"FixedClock needs an aware UTC datetime, got {self.instant!r}"
            )

    def now(self) -> datetime:
        """Return the fixed instant."""
        return self.instant


class ScriptedModel:
    """A model that returns or raises queued items in order.

    Each call records its request in :attr:`requests`, then takes the next
    script item: a :class:`CompletionResult` is returned and an exception is
    raised. An exhausted script raises :class:`CompletionUnavailable`.

    Attributes:
        requests: Every request received, in call order.
    """

    def __init__(self, *script: CompletionResult | BaseException) -> None:
        """Queue the script.

        Args:
            *script: Results to return and exceptions to raise, in order.
        """
        self._script: list[CompletionResult | BaseException] = list(script)
        self.requests: list[CompletionRequest] = []

    async def complete(self, request: CompletionRequest) -> CompletionResult:
        """Record ``request`` and play the next script item.

        Args:
            request: The completion request.

        Returns:
            The next scripted result.

        Raises:
            CompletionUnavailable: If the script is exhausted.
        """
        self.requests.append(request)
        if not self._script:
            raise CompletionUnavailable("ScriptedModel script is exhausted")
        item = self._script.pop(0)
        if isinstance(item, BaseException):
            raise item
        return item


# Mirrors Hermes keyword_classification_fixture: version "1", ACTIVITY_MEASURED
# (classification.py:L367-L372 at 5c2bfea8f9013e7b4521eb2153e62bd435d2bc17).
SCRIPTED_CLASSIFIER_DECLARATION: Final[ComponentDeclaration] = ComponentDeclaration(
    name="scripted_task_classifier",
    version="1",
    evidence_class=EvidenceClass.ACTIVITY_MEASURED,
)


class ScriptedTaskClassifier:
    """A task classifier that returns or raises queued items in order.

    Each call records its request in :attr:`requests`, then takes the next
    script item: an exception is raised and anything else is returned as is.
    Items are deliberately untyped, so a test can return a non-string and
    prove the engine refuses it (ID-14). An exhausted script raises
    :class:`LookupError`.

    Attributes:
        requests: Every request received, in call order.
    """

    def __init__(
        self,
        *script: object,
        declaration: ComponentDeclaration = SCRIPTED_CLASSIFIER_DECLARATION,
    ) -> None:
        """Queue the script and hold the declaration.

        Args:
            *script: Values to return and exceptions to raise, in order.
            declaration: The declaration the engine checks at construction.
        """
        self._script: list[object] = list(script)
        self._declaration: ComponentDeclaration = declaration
        self.requests: list[TaskClassificationInput] = []

    @property
    def declaration(self) -> ComponentDeclaration:
        """The component declaration, fixed at construction."""
        return self._declaration

    async def classify(self, request: TaskClassificationInput) -> str | None:
        """Record ``request`` and play the next script item.

        Args:
            request: The classification input.

        Returns:
            The next scripted value, which may deliberately not be a string.

        Raises:
            LookupError: If the script is exhausted.
        """
        self.requests.append(request)
        if not self._script:
            raise LookupError("ScriptedTaskClassifier script is exhausted")
        item = self._script.pop(0)
        if isinstance(item, BaseException):
            raise item
        # Untyped on purpose: the engine must validate whatever comes back.
        return cast("str | None", item)


# A host segmenter measured from activity, the job-path analog of the
# scripted classifier (ADR 0018 decision 7).
SCRIPTED_SEGMENTER_DECLARATION: Final[ComponentDeclaration] = ComponentDeclaration(
    name="scripted_job_segmenter",
    version="1",
    evidence_class=EvidenceClass.ACTIVITY_MEASURED,
)


class ScriptedJobSegmenter:
    """A job segmenter that returns or raises queued items in order.

    Each call records its request in :attr:`requests`, then takes the next
    script item: an exception is raised and anything else is returned as is.
    Items are deliberately untyped, so a test can return a string or another
    non-array and prove the engine refuses it (ADR 0018 decision 4). An
    exhausted script raises :class:`LookupError`.

    Attributes:
        requests: Every request received, in call order.
    """

    def __init__(
        self,
        *script: object,
        declaration: ComponentDeclaration = SCRIPTED_SEGMENTER_DECLARATION,
    ) -> None:
        """Queue the script and hold the declaration.

        Args:
            *script: Values to return and exceptions to raise, in order.
            declaration: The declaration the engine checks at construction.
        """
        self._script: list[object] = list(script)
        self._declaration: ComponentDeclaration = declaration
        self.requests: list[JobSegmentationInput] = []

    @property
    def declaration(self) -> ComponentDeclaration:
        """The component declaration, fixed at construction."""
        return self._declaration

    async def segment(self, request: JobSegmentationInput) -> JsonValue | None:
        """Record ``request`` and play the next script item.

        Args:
            request: The segmentation input.

        Returns:
            The next scripted value, which may deliberately not be an array.

        Raises:
            LookupError: If the script is exhausted.
        """
        self.requests.append(request)
        if not self._script:
            raise LookupError("ScriptedJobSegmenter script is exhausted")
        item = self._script.pop(0)
        if isinstance(item, BaseException):
            raise item
        # Untyped on purpose: the engine must validate whatever comes back.
        return cast("JsonValue | None", item)


# A host evaluator that observes outcomes, the outcome-path analog of the
# scripted segmenter (ADR 0022 decision 4).
SCRIPTED_EVALUATOR_DECLARATION: Final[ComponentDeclaration] = ComponentDeclaration(
    name="scripted_evaluator",
    version="1",
    evidence_class=EvidenceClass.OUTCOME_OBSERVED,
)


class ScriptedOutcomeEvaluator:
    """An outcome evaluator that returns or raises queued items in order.

    Each call records its request in :attr:`requests`, then takes the next
    script item: an exception is raised and anything else is returned as is.
    Items are deliberately untyped, so a test can return a list or another
    non-object and prove the engine refuses it (ADR 0022 decision 6). An
    exhausted script raises :class:`LookupError`.

    Attributes:
        requests: Every request received, in call order. The tuple is
            rebuilt on each call; nothing is shared between instances.
    """

    def __init__(
        self,
        *script: JsonValue | BaseException | None,
        declaration: ComponentDeclaration = SCRIPTED_EVALUATOR_DECLARATION,
    ) -> None:
        """Queue the script and hold the declaration.

        Args:
            *script: Values to return and exceptions to raise, in order.
            declaration: The declaration the engine checks at construction.
        """
        self._script: list[JsonValue | BaseException | None] = list(script)
        self._declaration: ComponentDeclaration = declaration
        self.requests: tuple[OutcomeEvaluationInput, ...] = ()

    @property
    def declaration(self) -> ComponentDeclaration:
        """The component declaration, fixed at construction."""
        return self._declaration

    async def evaluate(self, request: OutcomeEvaluationInput) -> JsonValue | None:
        """Record ``request`` and play the next script item.

        Args:
            request: The evaluation input.

        Returns:
            The next scripted value, which may deliberately not be an object.

        Raises:
            LookupError: If the script is exhausted.
        """
        self.requests = (*self.requests, request)
        if not self._script:
            raise LookupError("ScriptedOutcomeEvaluator script is exhausted")
        item = self._script.pop(0)
        if isinstance(item, BaseException):
            raise item
        return item


# A host valuation policy configured by an accountable operator. It is the
# only slot that may declare mechanisms, and only operator-only ones
# (ADR 0011 rule 4, ADR 0028 decision 5).
SCRIPTED_VALUATION_DECLARATION: Final[ComponentDeclaration] = ComponentDeclaration(
    name="scripted_valuation",
    version="1",
    evidence_class=EvidenceClass.CUSTOMER_CONFIGURED,
    declared_mechanisms=(EconomicMechanism.RISK_AVOIDANCE,),
)


class ScriptedValuationPolicy:
    """A sync valuation policy that returns or raises queued items in order.

    Each call records the :class:`ResolvedAssumptions` it received in
    :attr:`received`, then takes the next script item: an exception is raised
    and anything else is returned as is. Items are deliberately untyped, so a
    test can return a non-object, a malformed operand, or a ``total`` key and
    prove the engine refuses or ignores it (ADR 0028 decision 5). An
    exhausted script raises :class:`LookupError`, which the engine treats as
    a failing policy.

    Attributes:
        received: Every input received, in call order. The tuple is rebuilt
            on each call; nothing is shared between instances.
    """

    def __init__(
        self,
        *script: JsonValue | BaseException | None,
        declaration: ComponentDeclaration = SCRIPTED_VALUATION_DECLARATION,
    ) -> None:
        """Queue the script and hold the declaration.

        Args:
            *script: Values to return and exceptions to raise, in order.
            declaration: The declaration the engine checks at construction.
        """
        self._script: list[JsonValue | BaseException | None] = list(script)
        self._declaration: ComponentDeclaration = declaration
        self.received: tuple[ResolvedAssumptions, ...] = ()

    @property
    def declaration(self) -> ComponentDeclaration:
        """The component declaration, fixed at construction."""
        return self._declaration

    def value(self, assumptions: ResolvedAssumptions) -> JsonValue | None:
        """Record ``assumptions`` and play the next script item.

        Args:
            assumptions: The gated operands the engine passes.

        Returns:
            The next scripted value, which may deliberately be unusable.

        Raises:
            LookupError: If the script is exhausted.
        """
        self.received = (*self.received, assumptions)
        if not self._script:
            raise LookupError("ScriptedValuationPolicy script is exhausted")
        item = self._script.pop(0)
        if isinstance(item, BaseException):
            raise item
        return item


# A host confirmation workflow, shaped like Hermes'
# _confirmation_workflow_evidence_fixture: the honest claim is that a customer
# confirmed the outcome, not that a model estimated it (ADR 0025).
SCRIPTED_DECIDER_DECLARATION: Final[ComponentDeclaration] = ComponentDeclaration(
    name="scripted_decider",
    version="1",
    evidence_class=EvidenceClass.CUSTOMER_CONFIRMED,
)


class ScriptedEvidenceDecider:
    """A sync reportability decider that returns or raises queued items in order.

    Each call records the :class:`ReportabilityQuery` it received in
    :attr:`received`, then takes the next script item: an exception is raised
    and anything else is returned as is. Items are deliberately untyped, so a
    test can return ``None``, a non-object, or an unknown status and prove
    the engine fails closed (ADR 0025 decision 4, D-10). An exhausted script
    raises :class:`LookupError`, which the engine treats as a failing
    decider.

    Attributes:
        received: Every query received, in call order. The tuple is rebuilt
            on each call; nothing is shared between instances.
    """

    def __init__(
        self,
        *script: JsonValue | BaseException | None,
        declaration: ComponentDeclaration = SCRIPTED_DECIDER_DECLARATION,
    ) -> None:
        """Queue the script and hold the declaration.

        Args:
            *script: Values to return and exceptions to raise, in order.
            declaration: The declaration the engine checks at construction.
        """
        self._script: list[JsonValue | BaseException | None] = list(script)
        self._declaration: ComponentDeclaration = declaration
        self.received: tuple[ReportabilityQuery, ...] = ()

    @property
    def declaration(self) -> ComponentDeclaration:
        """The component declaration, fixed at construction."""
        return self._declaration

    def decide(self, query: ReportabilityQuery) -> JsonValue | None:
        """Record ``query`` and play the next script item.

        Args:
            query: The plain data the engine passes after rules 1 and 2.

        Returns:
            The next scripted value, which may deliberately be unusable.

        Raises:
            LookupError: If the script is exhausted.
        """
        self.received = (*self.received, query)
        if not self._script:
            raise LookupError("ScriptedEvidenceDecider script is exhausted")
        item = self._script.pop(0)
        if isinstance(item, BaseException):
            raise item
        return item


class InMemoryTaxonomy(Generic[_SnapshotT]):
    """A taxonomy reader and recorder that serves one snapshot.

    The snapshot is never replaced or altered. Recording only appends the
    proposal to :attr:`recorded`.

    Attributes:
        reads: How many times :meth:`snapshot` was called.
        read_error: When set, every read raises it.
        recorded: Every proposal passed to :meth:`record`, in call order.
        record_error: When set, each ``record`` appends the proposal and then
            raises it.
    """

    def __init__(
        self,
        snapshot: _SnapshotT,
        *,
        read_error: BaseException | None = None,
        record_error: BaseException | None = None,
    ) -> None:
        """Hold the snapshot to serve.

        Args:
            snapshot: The task or job snapshot.
            read_error: An exception every read raises instead, if set.
            record_error: An exception every record raises after appending,
                if set.
        """
        self._snapshot: _SnapshotT = snapshot
        self.read_error: BaseException | None = read_error
        self.record_error: BaseException | None = record_error
        self.reads: int = 0
        self.recorded: list[LabelProposal] = []

    async def snapshot(self, namespace: TaxonomyNamespace) -> _SnapshotT:
        """Return the snapshot when ``namespace`` matches it.

        Args:
            namespace: The namespace the engine reads.

        Returns:
            The held snapshot.

        Raises:
            LookupError: If ``namespace`` is not the snapshot's namespace.
        """
        self.reads += 1
        if self.read_error is not None:
            raise self.read_error
        if namespace is not self._snapshot.NAMESPACE:
            raise LookupError(f"no snapshot for namespace {namespace.value!r}")
        return self._snapshot

    async def record(self, proposal: LabelProposal) -> None:
        """Append ``proposal``, then raise :attr:`record_error` if it is set.

        Args:
            proposal: The label proposal the engine forwards.
        """
        self.recorded.append(proposal)
        if self.record_error is not None:
            raise self.record_error


class SequentialIds:
    """An ID generator that counts up from ``start`` in lowercase hexadecimal.

    Provisional with the :class:`~revenium_agent_economics.IdGenerator` port
    until Phase 3 settles OD-14.
    """

    def __init__(self, start: int = 1) -> None:
        """Start the counter.

        Args:
            start: The first value returned, at least 0.

        Raises:
            ValueError: If ``start`` is not an int of at least 0.
        """
        if type(start) is not int or start < 0:
            raise ValueError(f"start must be an int of at least 0, got {start!r}")
        self._next: int = start

    def suffix(self, n_hex: int) -> str:
        """Return the counter as exactly ``n_hex`` hex digits, then increment it.

        Args:
            n_hex: The number of digits, at least 1.

        Returns:
            The zero-padded lowercase hexadecimal counter.

        Raises:
            ValueError: If ``n_hex`` is below 1 or the counter needs more than
                ``n_hex`` digits. The counter is not advanced.
        """
        if type(n_hex) is not int or n_hex < 1:
            raise ValueError(f"n_hex must be an int of at least 1, got {n_hex!r}")
        text = format(self._next, f"0{n_hex}x")
        if len(text) > n_hex:
            raise ValueError(
                f"counter {self._next} does not fit in {n_hex} hexadecimal digits"
            )
        self._next += 1
        return text


class RecordingDiagnostics:
    """A diagnostic sink that keeps every diagnostic it receives.

    Attributes:
        diagnostics: Every emitted diagnostic, in order.
        error: When set, each ``emit`` records the diagnostic and then raises
            it, so tests can prove a failing sink is isolated.
    """

    def __init__(self, *, error: BaseException | None = None) -> None:
        """Start with no diagnostics.

        Args:
            error: An exception every ``emit`` raises after recording, if set.
        """
        self.diagnostics: list[Diagnostic] = []
        self.error: BaseException | None = error

    def emit(self, diagnostic: Diagnostic) -> None:
        """Record ``diagnostic``, then raise :attr:`error` if it is set.

        Args:
            diagnostic: The diagnostic to record.
        """
        self.diagnostics.append(diagnostic)
        if self.error is not None:
            raise self.error
