"""Keyword reference task classifier and job segmenter (CONF-01).

These are ports of the Hermes ``keyword_classification_fixture``: a
deterministic keyword-overlap classifier with no model, no network, and no
clock. They give the conformance kit a classifier and a segmenter whose
output follows from the scenario text alone, so a scenario's expected job
types and task label can be read off its stream.

Ported from ``skills/revenium/plugins/revenium-classifier/classification.py``
in ``revenium/hermes-revenium`` at the Phase 7 pin
``44bad572914485087acb92ef99a9e12fe79b8fd5`` (``compat/reference.json``):
``KEYWORD_FIXTURE_VERSION`` L223, ``_MAX_INFERRED_JOBS`` L229, ``_PUNCTUATION``
L231, ``_tokenize`` L234-L248, ``_best_label`` L251-L264,
``_keyword_task_type`` L267-L291, and ``_keyword_jobs`` L294-L321, with the
registration at L367-L372 (version ``"1"``, ``ACTIVITY_MEASURED``).

Two Hermes details stay with the engine instead of the port. Hermes clamps
``agentic_job_id`` and ``job_name`` with ``_clamp_text``; here the engine
normalizes every segmenter proposal (ADR 0017, ADR 0018 decision 5). Hermes
wraps the jobs as ``{"jobs": [...]}``; a ``JobSegmenter`` returns the array
itself (ADR 0018 decision 4).

Both ports hold no mutable state, so one instance can serve any number of
calls and runs.
"""

from collections.abc import Iterable
from typing import Final

from revenium_agent_economics import (
    ComponentDeclaration,
    EvidenceClass,
    JobSegmentationInput,
    JsonValue,
    TaskClassificationInput,
)

MAX_INFERRED_JOBS: Final = 5
"""At most this many jobs per call (Hermes ``_MAX_INFERRED_JOBS``)."""

FALLBACK_JOB_TYPE: Final = "general_activity"
"""The job type of a paragraph no job label scores on."""

JOB_NAME_MAX_CHARS: Final = 60
"""How many characters of a paragraph's first line become its job name."""

# classification.py:L231 at the pin, character for character.
_PUNCTUATION: Final = ".,!?;:()[]{}\"'`~@#$%^&*+=|\\/<>\n\t\r"

# classification.py:L367-L372 at the pin: version "1", ACTIVITY_MEASURED. The
# label comes from tokens observed in the turn's own text, never a model.
KEYWORD_CLASSIFIER_DECLARATION: Final[ComponentDeclaration] = ComponentDeclaration(
    name="keyword_task_classifier",
    version="1",
    evidence_class=EvidenceClass.ACTIVITY_MEASURED,
)

KEYWORD_SEGMENTER_DECLARATION: Final[ComponentDeclaration] = ComponentDeclaration(
    name="keyword_job_segmenter",
    version="1",
    evidence_class=EvidenceClass.ACTIVITY_MEASURED,
)


def tokenize(text: str) -> frozenset[str]:
    """Return the lowercase word tokens of ``text`` (Hermes ``_tokenize``).

    Each whitespace-separated word is lowercased and stripped of surrounding
    punctuation, then split on ``-`` and ``_``, so a label's own
    underscore-separated tokens compare directly.

    Args:
        text: The text to tokenize.

    Returns:
        The non-empty tokens.
    """
    tokens: set[str] = set()
    for word in text.lower().split():
        stripped = word.strip(_PUNCTUATION)
        tokens.update(part for part in stripped.replace("-", "_").split("_") if part)
    return frozenset(tokens)


def best_label(tokens: frozenset[str], labels: Iterable[str]) -> str | None:
    """Return the label whose tokens overlap ``tokens`` most (Hermes ``_best_label``).

    A label scores one point per underscore-separated token of its own that
    appears in ``tokens``. The first label with the highest score wins, and
    no label wins on a score of zero, so the result is an honest abstention
    instead of an invented guess.

    Args:
        tokens: The tokens of the text being classified.
        labels: The candidate labels, in taxonomy order.

    Returns:
        The best label, or ``None`` when nothing scores above zero.
    """
    best: str | None = None
    best_score = 0
    for label in labels:
        if not label:
            continue
        score = sum(1 for part in label.lower().split("_") if part and part in tokens)
        if score > best_score:
            best, best_score = label, score
    return best


class KeywordTaskClassifier:
    """A ``TaskClassifier`` that picks the label with the most keyword overlap.

    Ports Hermes ``_keyword_task_type``: the user message and the assistant
    response are tokenized together, and the best label of the snapshot is
    returned, or ``None`` when no label scores.
    """

    @property
    def declaration(self) -> ComponentDeclaration:
        """The component declaration, version ``"1"``, ``ACTIVITY_MEASURED``."""
        return KEYWORD_CLASSIFIER_DECLARATION

    async def classify(self, request: TaskClassificationInput) -> str | None:
        """Return the best label for the turn, or ``None`` to abstain.

        Args:
            request: The turn and the task taxonomy snapshot.

        Returns:
            The best-scoring snapshot label, or ``None``.
        """
        message = request.user_message or ""
        preview = request.assistant_response or ""
        tokens = tokenize(f"{message} {preview}")
        if not tokens:
            return None
        return best_label(tokens, request.snapshot.labels)


class KeywordJobSegmenter:
    """A ``JobSegmenter`` that makes one job per transcript paragraph.

    Ports Hermes ``_keyword_jobs``: the transcript sample is split on blank
    lines, and each non-empty paragraph, up to :data:`MAX_INFERRED_JOBS`,
    becomes a ``SUCCESS`` job typed with the paragraph's best job label, or
    :data:`FALLBACK_JOB_TYPE` when none scores.
    """

    @property
    def declaration(self) -> ComponentDeclaration:
        """The component declaration, version ``"1"``, ``ACTIVITY_MEASURED``."""
        return KEYWORD_SEGMENTER_DECLARATION

    async def segment(self, request: JobSegmentationInput) -> JsonValue | None:
        """Return one raw job proposal per paragraph, or ``None`` to abstain.

        Args:
            request: The transcript sample and the job taxonomy snapshot.

        Returns:
            A list of job proposal objects with ``agentic_job_id``
            ``keyword_job_<n>``, ``job_name`` the paragraph's first line cut
            to 60 characters, ``job_type``, and ``status`` ``"SUCCESS"``; or
            ``None`` when the sample has no non-blank text.
        """
        transcript = request.transcript_sample.text
        if not transcript.strip():
            return None
        paragraphs = [
            stripped
            for paragraph in transcript.split("\n\n")
            if (stripped := paragraph.strip())
        ]
        jobs: list[JsonValue] = []
        for index, paragraph in enumerate(paragraphs[:MAX_INFERRED_JOBS]):
            job_type = (
                best_label(tokenize(paragraph), request.snapshot.labels)
                or FALLBACK_JOB_TYPE
            )
            lines = paragraph.splitlines()
            first_line = lines[0] if lines else paragraph
            jobs.append(
                {
                    "agentic_job_id": f"keyword_job_{index + 1}",
                    "job_name": first_line[:JOB_NAME_MAX_CHARS] or f"Job {index + 1}",
                    "job_type": job_type,
                    "status": "SUCCESS",
                }
            )
        return jobs
