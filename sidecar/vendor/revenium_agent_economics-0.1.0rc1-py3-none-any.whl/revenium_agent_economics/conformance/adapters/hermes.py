"""Hermes-shaped hook payloads to envelope events.

This is a synthetic reference adapter for conformance only, not a production
integration (D-06). It shows how a Hermes host maps its plugin hooks onto the
activity envelope, so the conformance kit can run the same core over a
Hermes-shaped stream. A real Hermes integration lives in the host and owns its
own adapter.

Each native item is a dict of one of two shapes:

- A hook payload: ``"hook"`` names the hook that fired, one of the four that
  ``plugin.yaml`` registers in ``revenium/hermes-revenium`` at the pin in
  ``compat/reference.json``, and the other keys are that hook's keyword
  arguments.
- A host-state row: ``{"source": "host_state", "session_id": child,
  "parent_session_id": parent}``, the parent link a Hermes host keeps in
  ``state.db`` ``sessions.parent_session_id``. Hermes runs a subagent as a
  separate session, so this row is the only link between the two.

The mapping:

- ``post_llm_call`` becomes ``PROMPT_SUBMITTED`` (an excerpt of
  ``user_message``) then ``TURN_STOPPED`` (an excerpt of
  ``assistant_response``). Each is omitted when its text is absent.
- ``post_api_request`` becomes ``USAGE_REPORTED``. Its ``UsageReport`` takes
  token counts from the documented ``usage`` keys only when they are exact
  ``int`` values of at least 0, and ``model`` only when it is valid model
  text. Anything else is ignored, never coerced.
- ``on_session_end`` becomes ``SESSION_ENDED`` with the bool attributes
  ``hermes.completed`` and ``hermes.interrupted``.
- ``on_session_finalize`` becomes ``SESSION_ENDED`` with the ``reason``
  kwarg, and on a reset the ``hermes.old_session_id`` and
  ``hermes.new_session_id`` attributes. Hermes documents no resume, so a reset
  is a new session, never a resumed one.
- A host-state row becomes ``HOST_OTHER`` from ``EventSource.HOST_STATE``
  carrying ``session_id`` and ``parent_session_id``.
- Every other hook becomes ``HOST_OTHER``.

Identity comes only from the ``[[field]]`` rows of
``compat/envelope_field_sources.toml`` whose ``hermes`` column names a hook
keyword argument (:data:`HERMES_IDENTITY_KWARGS`), plus the host-state parent
link. The adapter invents no session origin, delegation initiator, delegation
mode, or outcome (D-26): a child session's mode stays ``UNKNOWN``, and neither
lifecycle hook sets an outcome or closes a job (ENV-04).

All values the builders emit are synthetic ("sess-hermes-1", "turn-1", ...).
"""

from collections.abc import Iterable, Mapping, Sequence
from datetime import datetime, timedelta
from types import MappingProxyType
from typing import Final, TypeAlias

from revenium_agent_economics import (
    ActivityEvent,
    ActivityIdentity,
    ActivityKind,
    ActivityPayload,
    AttributeValue,
    EventSource,
    NoPayload,
    RecordValidationError,
    SessionEndInfo,
    TextExcerpt,
    UsageReport,
    derive_dedupe_key,
    text_excerpt,
)

HookPayload: TypeAlias = Mapping[str, object]
HermesTurn: TypeAlias = tuple[str, str]
"""One completed turn: ``(user_message, assistant_response)``."""
_Mapped: TypeAlias = tuple[
    ActivityKind, ActivityPayload, tuple[tuple[str, AttributeValue], ...]
]

HERMES_HOST: Final = "hermes"
HOOK_KEY: Final = "hook"
SOURCE_KEY: Final = "source"
HOST_STATE_SOURCE: Final = "host_state"
HOST_STATE_EVENT: Final = "sessions"
"""The ``[[hermes_native]]`` event name of a host-state row: ``state.db``'s
``sessions`` table."""
# The host chooses the cut; the excerpt records the original's measurements.
EXCERPT_MAX_CHARS: Final = 200
SYNTHETIC_MODEL: Final = "model-a"
SYNTHETIC_USAGE: Final[Mapping[str, int]] = MappingProxyType(
    {"input_tokens": 1200, "output_tokens": 300}
)
_NO_USAGE: Final[HookPayload] = MappingProxyType({})

HERMES_HOOKS: Final[tuple[str, ...]] = (
    "on_session_end",
    "on_session_finalize",
    "post_llm_call",
    "post_api_request",
)
"""The hooks ``plugin.yaml`` registers, in its order."""

HERMES_IDENTITY_KWARGS: Final[Mapping[str, tuple[str, frozenset[str]]]] = (
    MappingProxyType(
        {
            "session_id": (
                "session_id",
                frozenset(
                    {
                        "on_session_end",
                        "on_session_finalize",
                        "post_llm_call",
                        "post_api_request",
                    }
                ),
            ),
            "turn_id": ("turn_id", frozenset({"post_llm_call", "post_api_request"})),
            "task_id": ("task_id", frozenset({"post_llm_call", "post_api_request"})),
            "request_id": ("api_request_id", frozenset({"post_api_request"})),
        }
    )
)
"""``ActivityIdentity`` field to the hook keyword argument and hooks that feed it.

Exactly the ``[[field]]`` rows whose ``hermes`` column reads
``hook kwarg <name> (<hooks>)``. A test keeps the two in step.
"""


def _text(payload: HookPayload, key: str) -> str | None:
    value = payload.get(key)
    if value is None:
        return None
    if type(value) is not str:
        raise TypeError(f"{key} must be a str, got {type(value).__name__}")
    # ADR 0015 decision 1: an adapter records an empty native value as None.
    return value or None


def _flag(payload: HookPayload, key: str) -> bool | None:
    value = payload.get(key)
    if value is None:
        return None
    if type(value) is not bool:
        raise TypeError(f"{key} must be a bool, got {type(value).__name__}")
    return value


def _excerpt(payload: HookPayload, key: str) -> TextExcerpt | None:
    text = _text(payload, key)
    return None if text is None else text_excerpt(text, max_chars=EXCERPT_MAX_CHARS)


def _count(usage: HookPayload, key: str) -> int | None:
    # An exact int of at least 0, or nothing: Hermes coerces with int(), the
    # envelope never does.
    value = usage.get(key)
    return value if type(value) is int and value >= 0 else None


def _model(payload: HookPayload) -> str | None:
    value = payload.get("model")
    if type(value) is not str:
        return None
    try:
        UsageReport(model=value)
    except RecordValidationError:
        return None
    return value


def _usage_report(payload: HookPayload) -> UsageReport:
    raw = payload.get("usage")
    if raw is not None and not isinstance(raw, Mapping):
        raise TypeError(f"usage must be a mapping, got {type(raw).__name__}")
    usage: HookPayload = _NO_USAGE if raw is None else raw
    # Hermes reads completion_tokens when output_tokens is absent or None
    # (api_event_spool._extract_usage).
    output_key = "output_tokens"
    if usage.get(output_key) is None:
        output_key = "completion_tokens"
    return UsageReport(
        input_tokens=_count(usage, "input_tokens"),
        output_tokens=_count(usage, output_key),
        model=_model(payload),
    )


def _identity_text(hook: str, payload: HookPayload, field: str) -> str | None:
    kwarg, hooks = HERMES_IDENTITY_KWARGS[field]
    return _text(payload, kwarg) if hook in hooks else None


def _identity(hook: str, payload: HookPayload) -> ActivityIdentity:
    return ActivityIdentity(
        session_id=_identity_text(hook, payload, "session_id"),
        turn_id=_identity_text(hook, payload, "turn_id"),
        task_id=_identity_text(hook, payload, "task_id"),
        request_id=_identity_text(hook, payload, "request_id"),
    )


def _host_state_identity(payload: HookPayload) -> ActivityIdentity:
    # No origin, initiator, or mode: the row carries only the parent link.
    return ActivityIdentity(
        session_id=_text(payload, "session_id"),
        parent_session_id=_text(payload, "parent_session_id"),
    )


def _text_attributes(
    payload: HookPayload, keys: Sequence[str]
) -> tuple[tuple[str, AttributeValue], ...]:
    return tuple(
        (f"hermes.{key}", value)
        for key in sorted(keys)
        if (value := _text(payload, key)) is not None
    )


def _mapped(hook: str, payload: HookPayload) -> tuple[_Mapped, ...]:
    if hook == "post_llm_call":
        prompt = _excerpt(payload, "user_message")
        response = _excerpt(payload, "assistant_response")
        mapped: list[_Mapped] = []
        if prompt is not None:
            mapped.append((ActivityKind.PROMPT_SUBMITTED, prompt, ()))
        if response is not None:
            mapped.append((ActivityKind.TURN_STOPPED, response, ()))
        return tuple(mapped)
    if hook == "post_api_request":
        return ((ActivityKind.USAGE_REPORTED, _usage_report(payload), ()),)
    if hook == "on_session_end":
        attributes = tuple(
            (f"hermes.{key}", value)
            for key in ("completed", "interrupted")
            if (value := _flag(payload, key)) is not None
        )
        return ((ActivityKind.SESSION_ENDED, SessionEndInfo(), attributes),)
    if hook == "on_session_finalize":
        # A reset hands over old_session_id and new_session_id; the core
        # treats the new id as a new session, never a resume.
        return (
            (
                ActivityKind.SESSION_ENDED,
                SessionEndInfo(reason=_text(payload, "reason")),
                _text_attributes(payload, ("old_session_id", "new_session_id")),
            ),
        )
    return ((ActivityKind.HOST_OTHER, NoPayload(), ()),)


def _native_shape(
    index: int, payload: HookPayload
) -> tuple[EventSource, ActivityIdentity, tuple[_Mapped, ...]]:
    hook = _text(payload, HOOK_KEY)
    if hook is not None:
        return EventSource.HOOK, _identity(hook, payload), _mapped(hook, payload)
    if _text(payload, SOURCE_KEY) == HOST_STATE_SOURCE:
        return (
            EventSource.HOST_STATE,
            _host_state_identity(payload),
            ((ActivityKind.HOST_OTHER, NoPayload(), ()),),
        )
    raise TypeError(f"payload {index} has no {HOOK_KEY} and is not a host-state row")


def hermes_hook_events(
    payloads: Sequence[HookPayload], *, host: str = HERMES_HOST, start: datetime
) -> tuple[ActivityEvent, ...]:
    """Map Hermes hook payloads and host-state rows to envelope events.

    Hooks carry no timestamp, so ``occurred_at`` and ``observed_at`` are the
    adapter's receipt time: ``start`` plus the running event index in seconds
    (the ADR 0015 decision 4 adapter obligation). One ``post_llm_call`` can
    yield two events, so the index counts events, not payloads. The dedupe
    key comes from :func:`derive_dedupe_key`. The source is
    ``EventSource.HOOK`` for a hook payload and ``EventSource.HOST_STATE``
    for a host-state row.

    Raises:
        TypeError: If a payload is neither a hook payload nor a host-state
            row, or a known key has the wrong type.
    """
    events: list[ActivityEvent] = []
    for index, payload in enumerate(payloads):
        source, identity, mapped = _native_shape(index, payload)
        for kind, body, attributes in mapped:
            at = start + timedelta(seconds=len(events))
            events.append(
                ActivityEvent(
                    kind=kind,
                    host=host,
                    identity=identity,
                    payload=body,
                    observed_at=at,
                    occurred_at=at,
                    dedupe_key=derive_dedupe_key(
                        host=host, kind=kind, identity=identity, occurred_at=at
                    ),
                    source=source,
                    attributes=attributes,
                )
            )
    return tuple(events)


def hermes_turn_payloads(
    session_id: str, turns: Sequence[HermesTurn]
) -> tuple[HookPayload, ...]:
    """One ``post_api_request`` then one ``post_llm_call`` per completed turn.

    That is the host's firing order: ``post_api_request`` fires once per API
    call during the turn, and ``post_llm_call`` fires when the turn is
    finalized. Turn ``n`` (from 1) gets ``turn_id`` ``"turn-n"`` and the API
    request id ``"<session_id>-req-n"``, with :data:`SYNTHETIC_USAGE`.
    """
    payloads: list[HookPayload] = []
    for number, (user_message, assistant_response) in enumerate(turns, start=1):
        turn_id = f"turn-{number}"
        payloads.append(
            {
                "hook": "post_api_request",
                "session_id": session_id,
                "turn_id": turn_id,
                "api_request_id": f"{session_id}-req-{number}",
                "model": SYNTHETIC_MODEL,
                "usage": dict(SYNTHETIC_USAGE),
            }
        )
        payloads.append(
            {
                "hook": "post_llm_call",
                "session_id": session_id,
                "turn_id": turn_id,
                "user_message": user_message,
                "assistant_response": assistant_response,
            }
        )
    return tuple(payloads)


def hermes_child_session_payloads(
    parent: str, child: str, turns: Sequence[HermesTurn]
) -> tuple[HookPayload, ...]:
    """A parent turn, the host-state parent link, then the child's turns.

    A Hermes subagent is a separate session; only the host-state row links
    ``child`` to ``parent``. No payload names a delegation mode, so the child
    stays ``DelegationMode.UNKNOWN`` (D-26).
    """
    return (
        *hermes_turn_payloads(
            parent,
            (
                (
                    "Audit every caller of the redirect helper.",
                    "Started a subagent to audit the redirect helper.",
                ),
            ),
        ),
        {
            "source": HOST_STATE_SOURCE,
            "session_id": child,
            "parent_session_id": parent,
        },
        *hermes_turn_payloads(child, turns),
    )


def hermes_finalize_payloads(old: str, new: str) -> tuple[HookPayload, ...]:
    """A user-initiated reset: ``on_session_finalize`` for ``old``.

    Hermes fires it with ``reason="new_session"`` and hands over
    ``old_session_id`` and ``new_session_id``. The synthetic payload names
    ``old`` as the ``session_id`` the callback classifies.
    """
    return (
        {
            "hook": "on_session_finalize",
            "session_id": old,
            "reason": "new_session",
            "old_session_id": old,
            "new_session_id": new,
        },
    )


class HermesHookAdapter:
    """A ``HostAdapter`` over Hermes hook payloads (ENV-05, D-06).

    A synthetic reference adapter for conformance only, not a production
    integration.
    """

    def __init__(self, *, host: str = HERMES_HOST, start: datetime) -> None:
        """Bind the host name and the receipt time of the first event."""
        self.host = host
        self.start = start

    def normalize(self, native: object) -> Iterable[ActivityEvent]:
        """Map a list or tuple of hook payload dicts to envelope events.

        Raises:
            TypeError: If ``native`` is not a list or tuple of dicts.
        """
        if not isinstance(native, list | tuple):
            raise TypeError(
                f"native must be a list or tuple, got {type(native).__name__}"
            )
        payloads: list[HookPayload] = []
        for index, item in enumerate(native):
            if not isinstance(item, dict):
                raise TypeError(
                    f"native element {index} must be a dict, got {type(item).__name__}"
                )
            payloads.append(item)
        return hermes_hook_events(payloads, host=self.host, start=self.start)
