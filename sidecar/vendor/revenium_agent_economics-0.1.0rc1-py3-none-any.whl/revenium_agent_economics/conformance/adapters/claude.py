"""Synthetic Claude Code hook payloads and a host adapter over them.

This is a synthetic reference adapter for conformance only, not a production
integration (D-06). The conformance kit runs the same core over the
Claude-shaped stream it produces; a real Claude Code integration lives in the
host and owns its own adapter.

Every payload uses only hook input keys that Claude Code documents, each with
a non-excluded ``[[native]]`` row in ``compat/envelope_field_sources.toml``
(ADR 0015 decision 5, ENV-06).
No payload carries the transcript path, and nothing here reads a transcript:
Claude Code calls the transcript format internal and version-dependent.

All values are synthetic ("session-a", "prompt-1", ...).

:func:`claude_hook_events` implements every mapping rule; later plans add only
payloads. :data:`PAYLOAD_BUILDERS` lists the builders, such as
:func:`background_subagent_payloads` and :func:`stop_failure_payloads`.
:class:`ClaudeHookAdapter` wraps it as a ``HostAdapter``.

Mapping rules re-verified against raw Claude Code docs in Phase 6 (D-07):
``delegated_agent_type`` is recorded only with the payload's own
``agent_id`` (``agent_type`` also arrives on main-thread hooks under
``--agent``); Stop's ``background_tasks`` length rides as the
``claude.background_task_count`` attribute; StopFailure's API error text
never becomes a payload; a task's ``task_subject`` becomes
``TaskTransition.summary``.
"""

from collections.abc import Callable, Iterable, Mapping, Sequence
from datetime import UTC, datetime, timedelta
from types import MappingProxyType
from typing import Final, TypeAlias

from revenium_agent_economics import (
    ActivityEvent,
    ActivityIdentity,
    ActivityKind,
    ActivityPayload,
    AttributeValue,
    CompactionInfo,
    CompactionTrigger,
    DelegationMode,
    DelegationResult,
    EventSource,
    NoPayload,
    SessionEndInfo,
    SessionOrigin,
    TaskTransition,
    TextExcerpt,
    ToolOutcome,
    derive_dedupe_key,
    text_excerpt,
)

HookPayload: TypeAlias = Mapping[str, object]

HOST: Final = "claude_code"
START: Final = datetime(2026, 9, 28, 12, 0, tzinfo=UTC)
SESSION: Final = "session-a"
# The host chooses the cut; the excerpt records the original's measurements.
EXCERPT_MAX_CHARS: Final = 200
# Host paths are never an envelope source (the excluded rows).
TRANSCRIPT_PATH_KEY: Final = "transcript_path"
AGENT_TRANSCRIPT_PATH_KEY: Final = "agent_transcript_path"
SCRATCHPAD_DIR_KEY: Final = "scratchpad_dir"
# The tool whose PostToolUse response carries the delegated agent and mode.
AGENT_TOOL: Final = "Agent"
# Stop's in-flight task count: a non-empty list means paused, not done.
BACKGROUND_TASK_COUNT: Final = "claude.background_task_count"

HOOK_KINDS: Final[Mapping[str, ActivityKind]] = MappingProxyType(
    {
        "SessionStart": ActivityKind.SESSION_STARTED,
        "SessionEnd": ActivityKind.SESSION_ENDED,
        "UserPromptSubmit": ActivityKind.PROMPT_SUBMITTED,
        "Stop": ActivityKind.TURN_STOPPED,
        "StopFailure": ActivityKind.TURN_FAILED,
        "PreToolUse": ActivityKind.TOOL_CALL_STARTED,
        "PostToolUse": ActivityKind.TOOL_CALL_SUCCEEDED,
        "PostToolUseFailure": ActivityKind.TOOL_CALL_FAILED,
        "SubagentStart": ActivityKind.DELEGATION_STARTED,
        "SubagentStop": ActivityKind.DELEGATION_STOPPED,
        "TaskCreated": ActivityKind.TASK_CREATED,
        "TaskCompleted": ActivityKind.TASK_COMPLETION_ATTEMPTED,
        "PreCompact": ActivityKind.COMPACTION_STARTED,
        "PostCompact": ActivityKind.COMPACTION_COMPLETED,
    }
)
"""Hook event name to kind. Any other hook is ``HOST_OTHER``."""

SESSION_ORIGINS: Final[Mapping[str, SessionOrigin]] = MappingProxyType(
    {
        "startup": SessionOrigin.NEW,
        "resume": SessionOrigin.RESUMED,
        "fork": SessionOrigin.FORKED,
        "clear": SessionOrigin.CLEARED,
        "compact": SessionOrigin.COMPACTED,
    }
)
"""``SessionStart.source`` to origin. Any other value is ``UNKNOWN``.

Before v2.1.214 a fork arrives as ``"resume"`` and stays ``RESUMED``.
"""

AGENT_STATUS_MODES: Final[Mapping[str, DelegationMode]] = MappingProxyType(
    {
        "async_launched": DelegationMode.BACKGROUND,
        "completed": DelegationMode.FOREGROUND,
    }
)
"""``PostToolUse(Agent).tool_response.status`` to mode. Otherwise ``UNKNOWN``."""

COMPACTION_TRIGGERS: Final[Mapping[str, CompactionTrigger]] = MappingProxyType(
    {
        "manual": CompactionTrigger.MANUAL,
        "auto": CompactionTrigger.AUTO,
    }
)

TRACER_PAYLOADS: Final[tuple[HookPayload, ...]] = (
    {"hook_event_name": "SessionStart", "session_id": SESSION, "source": "startup"},
    {
        "hook_event_name": "UserPromptSubmit",
        "session_id": SESSION,
        "prompt_id": "prompt-1",
        "prompt": "Fix the failing login test.",
    },
    {
        "hook_event_name": "Stop",
        "session_id": SESSION,
        "prompt_id": "prompt-1",
        "last_assistant_message": "Fixed the redirect; the login test passes.",
    },
)
"""SessionStart, UserPromptSubmit, and Stop for one synthetic session."""

EXPANSION_PAYLOADS: Final[tuple[HookPayload, ...]] = (
    {"hook_event_name": "SessionStart", "session_id": "session-b", "source": "fork"},
    {
        "hook_event_name": "PreToolUse",
        "session_id": SESSION,
        "prompt_id": "prompt-1",
        "tool_name": "Bash",
        "tool_use_id": "toolu_01",
    },
    {
        "hook_event_name": "PostToolUse",
        "session_id": SESSION,
        "prompt_id": "prompt-1",
        "tool_name": "Bash",
        "tool_use_id": "toolu_01",
    },
    {
        "hook_event_name": "PostToolUse",
        "session_id": SESSION,
        "prompt_id": "prompt-1",
        "tool_name": AGENT_TOOL,
        "tool_use_id": "toolu_02",
        "tool_response": {"agentId": "agent-1", "status": "async_launched"},
    },
    {
        "hook_event_name": "SubagentStart",
        "session_id": SESSION,
        "agent_id": "agent-1",
        "agent_type": "Explore",
    },
    {
        "hook_event_name": "SubagentStop",
        "session_id": SESSION,
        "agent_id": "agent-1",
        "agent_type": "Explore",
        "last_assistant_message": "Found 3 call sites of the redirect helper.",
    },
    {
        "hook_event_name": "PostToolUse",
        "session_id": SESSION,
        "prompt_id": "prompt-1",
        "tool_name": AGENT_TOOL,
        "tool_use_id": "toolu_03",
        "tool_response": {"agentId": "agent-2", "status": "completed"},
    },
    {
        "hook_event_name": "SubagentStop",
        "session_id": SESSION,
        "agent_id": "agent-internal",
        "agent_type": "",
        "last_assistant_message": "Suggested next prompt.",
    },
    {"hook_event_name": "TaskCreated", "session_id": SESSION, "task_id": "task-1"},
    {"hook_event_name": "TaskCompleted", "session_id": SESSION, "task_id": "task-1"},
    {"hook_event_name": "PreCompact", "session_id": SESSION, "trigger": "auto"},
    {
        "hook_event_name": "PostCompact",
        "session_id": SESSION,
        "trigger": "auto",
        "compact_summary": "Fixed the login redirect; tests pass.",
    },
    {
        "hook_event_name": "SessionEnd",
        "session_id": SESSION,
        "reason": "prompt_input_exit",
    },
)
"""The remaining documented hooks, including both Agent tool modes."""

HOOK_FIXTURES: Final[tuple[HookPayload, ...]] = TRACER_PAYLOADS + EXPANSION_PAYLOADS
"""Every Claude-shaped hook payload; the provenance test checks each key."""


def _subagent_payloads(agent_id: str, status: str) -> tuple[HookPayload, ...]:
    return (
        {"hook_event_name": "SessionStart", "session_id": SESSION, "source": "startup"},
        {
            "hook_event_name": "UserPromptSubmit",
            "session_id": SESSION,
            "prompt_id": "prompt-1",
            "prompt": "Find every caller of the redirect helper.",
        },
        {
            "hook_event_name": "SubagentStart",
            "session_id": SESSION,
            "agent_id": agent_id,
            "agent_type": "Explore",
        },
        {
            "hook_event_name": "PostToolUse",
            "session_id": SESSION,
            "prompt_id": "prompt-1",
            "tool_name": AGENT_TOOL,
            "tool_use_id": "toolu_01",
            "tool_response": {"agentId": agent_id, "status": status},
        },
        {
            "hook_event_name": "SubagentStop",
            "session_id": SESSION,
            "agent_id": agent_id,
            "agent_type": "Explore",
            "last_assistant_message": "Found 3 call sites of the redirect helper.",
        },
        {
            "hook_event_name": "Stop",
            "session_id": SESSION,
            "prompt_id": "prompt-1",
            "last_assistant_message": "The redirect helper has 3 callers.",
        },
    )


def background_subagent_payloads() -> tuple[HookPayload, ...]:
    """One session delegating to ``agent-1``, launched in the background.

    ``PostToolUse(Agent)`` reports ``status: "async_launched"``, so the mode
    lands on ``(session-a, agent-1)`` as ``BACKGROUND``. No payload names an
    initiator, so it stays ``UNKNOWN``.
    """
    return _subagent_payloads("agent-1", "async_launched")


def foreground_subagent_payloads() -> tuple[HookPayload, ...]:
    """One session delegating to ``agent-2``, which ran in the foreground.

    ``PostToolUse(Agent)`` reports ``status: "completed"``, so the mode lands
    on ``(session-a, agent-2)`` as ``FOREGROUND``.
    """
    return _subagent_payloads("agent-2", "completed")


SUBAGENT_FIXTURES: Final[tuple[HookPayload, ...]] = (
    background_subagent_payloads() + foreground_subagent_payloads()
)
"""The subagent sequences, checked against the provenance table separately."""


def _opening(session_id: str, prompt_id: str, prompt: str) -> tuple[HookPayload, ...]:
    return (
        {
            "hook_event_name": "SessionStart",
            "session_id": session_id,
            "source": "startup",
        },
        {
            "hook_event_name": "UserPromptSubmit",
            "session_id": session_id,
            "prompt_id": prompt_id,
            "prompt": prompt,
        },
    )


def _stop(session_id: str, prompt_id: str, message: str) -> HookPayload:
    return {
        "hook_event_name": "Stop",
        "session_id": session_id,
        "prompt_id": prompt_id,
        "last_assistant_message": message,
    }


def stop_with_background_tasks_payloads() -> tuple[HookPayload, ...]:
    """A turn that stops while a background subagent is still running.

    The first ``Stop`` lists one in-flight ``subagent`` task, so it is paused,
    not done (``claude.background_task_count`` 1). The subagent's
    ``SubagentStop`` carries the parent-scoped arrays, which the adapter
    ignores. The final ``Stop`` lists none (count 0).
    """
    return (
        *_opening(SESSION, "prompt-1", "Find every caller of the redirect helper."),
        {
            "hook_event_name": "SubagentStart",
            "session_id": SESSION,
            "agent_id": "agent-1",
            "agent_type": "Explore",
        },
        {
            "hook_event_name": "PostToolUse",
            "session_id": SESSION,
            "prompt_id": "prompt-1",
            "tool_name": AGENT_TOOL,
            "tool_use_id": "toolu_01",
            "tool_response": {"agentId": "agent-1", "status": "async_launched"},
        },
        {
            **_stop(
                SESSION, "prompt-1", "An Explore agent is searching in the background."
            ),
            "stop_hook_active": False,
            "background_tasks": [
                {
                    "id": "task-bg-1",
                    "type": "subagent",
                    "status": "running",
                    "description": "Find callers of the redirect helper",
                    "agent_type": "Explore",
                }
            ],
            "session_crons": [],
        },
        {
            "hook_event_name": "SubagentStop",
            "session_id": SESSION,
            "agent_id": "agent-1",
            "agent_type": "Explore",
            "stop_hook_active": False,
            "last_assistant_message": "Found 3 call sites of the redirect helper.",
            "background_tasks": [],
            "session_crons": [],
        },
        {
            **_stop(SESSION, "prompt-1", "The redirect helper has 3 callers."),
            "stop_hook_active": False,
            "background_tasks": [],
            "session_crons": [],
        },
    )


def stop_failure_payloads() -> tuple[HookPayload, ...]:
    """A turn that ends on an API error.

    ``StopFailure`` becomes ``TURN_FAILED`` with ``NoPayload``: its ``error``,
    ``error_details``, and ``last_assistant_message`` (the API error string)
    are ignored.
    """
    return (
        *_opening(SESSION, "prompt-1", "Fix the failing login test."),
        {
            "hook_event_name": "StopFailure",
            "session_id": SESSION,
            "prompt_id": "prompt-1",
            "error": "rate_limit",
            "error_details": "429 Too Many Requests",
            "last_assistant_message": "API Error: Rate limit reached",
        },
    )


def task_event_payloads() -> tuple[HookPayload, ...]:
    """A turn that creates a task and marks it completed.

    ``task_subject`` becomes ``TaskTransition.summary``; ``task_description``
    and ``teammate_name`` are ignored. ``TaskCompleted`` is self-reported and
    never closes a job.
    """
    task: dict[str, object] = {
        "session_id": SESSION,
        "prompt_id": "prompt-1",
        "task_id": "task-1",
        "task_subject": "Fix the login redirect",
        "task_description": "Make the failing login test pass.",
    }
    return (
        *_opening(SESSION, "prompt-1", "Fix the failing login test."),
        {"hook_event_name": "TaskCreated", **task},
        {"hook_event_name": "TaskCompleted", **task, "teammate_name": "implementer"},
        _stop(SESSION, "prompt-1", "Fixed the redirect; the login test passes."),
    )


def compaction_payloads() -> tuple[HookPayload, ...]:
    """A manual compaction between two turns of one session.

    ``PreCompact`` carries a null ``custom_instructions``, ``PostCompact`` a
    ``compact_summary`` the adapter drops, and the session restarts with
    ``source: "compact"`` under the same ``session_id``.
    """
    return (
        *_opening(SESSION, "prompt-1", "Fix the failing login test."),
        _stop(SESSION, "prompt-1", "Fixed the redirect; the login test passes."),
        {
            "hook_event_name": "PreCompact",
            "session_id": SESSION,
            "trigger": "manual",
            "custom_instructions": None,
        },
        {
            "hook_event_name": "PostCompact",
            "session_id": SESSION,
            "trigger": "manual",
            "compact_summary": "Fixed the login redirect; tests pass.",
        },
        {"hook_event_name": "SessionStart", "session_id": SESSION, "source": "compact"},
        {
            "hook_event_name": "UserPromptSubmit",
            "session_id": SESSION,
            "prompt_id": "prompt-2",
            "prompt": "Add a regression test for the redirect.",
        },
        _stop(SESSION, "prompt-2", "Added a regression test for the redirect."),
    )


def resume_payloads() -> tuple[HookPayload, ...]:
    """A session that ends and is resumed under the same ``session_id``.

    The resumed ``SessionStart`` carries the four v2.1.251 resume fields,
    which the adapter ignores.
    """
    return (
        *_opening(SESSION, "prompt-1", "Fix the failing login test."),
        _stop(SESSION, "prompt-1", "Fixed the redirect; the login test passes."),
        {
            "hook_event_name": "SessionEnd",
            "session_id": SESSION,
            "reason": "prompt_input_exit",
        },
        {
            "hook_event_name": "SessionStart",
            "session_id": SESSION,
            "source": "resume",
            "seconds_since_last_response": 5400,
            "context_tokens": 18234,
            "prompt_cache_likely_expired": True,
            "estimated_cache_write_usd": 0.25,
        },
        {
            "hook_event_name": "UserPromptSubmit",
            "session_id": SESSION,
            "prompt_id": "prompt-2",
            "prompt": "Add a regression test for the redirect.",
        },
        _stop(SESSION, "prompt-2", "Added a regression test for the redirect."),
    )


def fork_payloads() -> tuple[HookPayload, ...]:
    """A session forked into a new ``session_id`` (``source: "fork"``).

    Hooks document no forked-from id, so the fork carries no edge back to
    ``session-a``.
    """
    return (
        *_opening(SESSION, "prompt-1", "Fix the failing login test."),
        _stop(SESSION, "prompt-1", "Fixed the redirect; the login test passes."),
        {
            "hook_event_name": "SessionStart",
            "session_id": "session-b",
            "source": "fork",
        },
        {
            "hook_event_name": "UserPromptSubmit",
            "session_id": "session-b",
            "prompt_id": "prompt-2",
            "prompt": "Try a different fix for the redirect.",
        },
        _stop("session-b", "prompt-2", "Tried a cookie-based redirect instead."),
    )


PAYLOAD_BUILDERS: Final[tuple[Callable[[], tuple[HookPayload, ...]], ...]] = (
    background_subagent_payloads,
    foreground_subagent_payloads,
    stop_with_background_tasks_payloads,
    stop_failure_payloads,
    task_event_payloads,
    compaction_payloads,
    resume_payloads,
    fork_payloads,
)
"""Every payload builder; the provenance test checks each key they emit."""


def native_keys(payload: HookPayload) -> tuple[str, ...]:
    """Return the payload's leaf keys, nested mappings flattened to dotted paths."""
    keys: list[str] = []
    for key, value in payload.items():
        if isinstance(value, Mapping):
            keys.extend(f"{key}.{inner}" for inner in native_keys(value))
        else:
            keys.append(key)
    return tuple(sorted(keys))


def _text(payload: HookPayload, key: str) -> str | None:
    value = payload.get(key)
    if value is None:
        return None
    if type(value) is not str:
        raise TypeError(f"{key} must be a str, got {type(value).__name__}")
    # ADR 0015 decision 1: an adapter records an empty native value as None.
    return value or None


def _mapping(payload: HookPayload, key: str) -> HookPayload | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise TypeError(f"{key} must be a mapping, got {type(value).__name__}")
    return value


def _excerpt(payload: HookPayload, key: str) -> TextExcerpt | None:
    text = _text(payload, key)
    return None if text is None else text_excerpt(text, max_chars=EXCERPT_MAX_CHARS)


def _agent_response(event_name: str, payload: HookPayload) -> HookPayload | None:
    if event_name != "PostToolUse" or _text(payload, "tool_name") != AGENT_TOOL:
        return None
    return _mapping(payload, "tool_response")


def _identity(event_name: str, payload: HookPayload) -> ActivityIdentity:
    agent_id = _text(payload, "agent_id")
    # agent_type also arrives on main-thread hooks under --agent, where no
    # agent_id names a delegated agent. Record it only alongside the payload's
    # own agent_id: the type describes the agent the hook fired inside.
    agent_type = _text(payload, "agent_type") if agent_id is not None else None
    mode = DelegationMode.UNKNOWN
    response = _agent_response(event_name, payload)
    if response is not None:
        # The response names the spawned agent, whose type this event does not
        # carry; any payload agent_type describes the calling agent.
        agent_type = None
        # Research assumption A1: agentId equals the subagent's hook agent_id.
        # The mode lands on the subagent's lineage node (A-06).
        agent_id = _text(response, "agentId")
        status = _text(response, "status")
        mode = AGENT_STATUS_MODES.get(status or "", DelegationMode.UNKNOWN)
    origin = SessionOrigin.UNKNOWN
    if event_name == "SessionStart":
        source = _text(payload, "source")
        origin = SESSION_ORIGINS.get(source or "", SessionOrigin.UNKNOWN)
    return ActivityIdentity(
        session_id=_text(payload, "session_id"),
        session_origin=origin,
        prompt_id=_text(payload, "prompt_id"),
        task_id=_text(payload, "task_id"),
        tool_call_id=_text(payload, "tool_use_id"),
        delegated_agent_id=agent_id,
        delegated_agent_type=agent_type,
        delegation_mode=mode,
    )


def _payload(event_name: str, payload: HookPayload) -> ActivityPayload:
    if event_name in {"UserPromptSubmit", "Stop"}:
        key = "prompt" if event_name == "UserPromptSubmit" else "last_assistant_message"
        excerpt = _excerpt(payload, key)
        return NoPayload() if excerpt is None else excerpt
    if event_name in {"PostToolUse", "PostToolUseFailure"}:
        interrupted = payload.get("is_interrupt")
        if interrupted is not None and type(interrupted) is not bool:
            raise TypeError("is_interrupt must be a bool")
        return ToolOutcome(
            tool_name=_text(payload, "tool_name"),
            succeeded=event_name == "PostToolUse",
            interrupted=interrupted,
        )
    if event_name == "SubagentStop":
        return DelegationResult(summary=_excerpt(payload, "last_assistant_message"))
    if event_name in {"TaskCreated", "TaskCompleted"}:
        return TaskTransition(summary=_excerpt(payload, "task_subject"))
    if event_name in {"PreCompact", "PostCompact"}:
        trigger = _text(payload, "trigger")
        return CompactionInfo(
            trigger=COMPACTION_TRIGGERS.get(trigger or "", CompactionTrigger.UNKNOWN)
        )
    if event_name == "SessionEnd":
        return SessionEndInfo(reason=_text(payload, "reason"))
    # StopFailure stays NoPayload: its error, error_details, and
    # last_assistant_message carry host error text, never a payload field.
    # PreCompact's custom_instructions (null for auto) is never read.
    return NoPayload()


def _background_task_count(payload: HookPayload) -> int | None:
    tasks = payload.get("background_tasks")
    if tasks is None:
        return None
    if type(tasks) is not list:
        raise TypeError(f"background_tasks must be a list, got {type(tasks).__name__}")
    return len(tasks)


def _attributes(
    event_name: str, payload: HookPayload
) -> tuple[tuple[str, AttributeValue], ...]:
    # PreToolUse has no outcome yet, so its tool name rides as an attribute.
    if event_name == "PreToolUse" and (name := _text(payload, "tool_name")):
        return (("claude.tool_name", name),)
    # Stop's in-flight count is evidence only. SubagentStop's arrays are
    # parent-scoped, so they never count against the subagent's node.
    if event_name == "Stop" and (count := _background_task_count(payload)) is not None:
        return ((BACKGROUND_TASK_COUNT, count),)
    return ()


def claude_hook_events(
    payloads: Sequence[HookPayload], *, host: str = HOST, start: datetime
) -> tuple[ActivityEvent, ...]:
    """Map documented Claude Code hook payloads to envelope events.

    Hooks carry no timestamp, so ``occurred_at`` and ``observed_at`` are the
    adapter's receipt time, ``start`` plus the payload's index in seconds
    (the ADR 0015 decision 4 adapter obligation). The dedupe key comes from
    :func:`derive_dedupe_key` and the source is ``EventSource.HOOK``.

    Raises:
        TypeError: If a payload lacks a ``hook_event_name`` or a known key has
            the wrong type.
    """
    events: list[ActivityEvent] = []
    for index, payload in enumerate(payloads):
        event_name = _text(payload, "hook_event_name")
        if event_name is None:
            raise TypeError(f"payload {index} has no hook_event_name")
        kind = HOOK_KINDS.get(event_name, ActivityKind.HOST_OTHER)
        identity = _identity(event_name, payload)
        at = start + timedelta(seconds=index)
        events.append(
            ActivityEvent(
                kind=kind,
                host=host,
                identity=identity,
                payload=_payload(event_name, payload),
                observed_at=at,
                occurred_at=at,
                dedupe_key=derive_dedupe_key(
                    host=host, kind=kind, identity=identity, occurred_at=at
                ),
                source=EventSource.HOOK,
                attributes=_attributes(event_name, payload),
            )
        )
    return tuple(events)


class ClaudeHookAdapter:
    """A ``HostAdapter`` over Claude Code hook payloads (ENV-05, D-25).

    A synthetic reference adapter for conformance only, not a production
    integration (D-06).
    """

    def __init__(self, *, host: str = HOST, start: datetime) -> None:
        """Bind the host name and the receipt time of the first payload."""
        self.host = host
        self.start = start

    def normalize(self, native: object) -> Iterable[ActivityEvent]:
        """Map a list or tuple of hook payload dicts to envelope events.

        Raises:
            TypeError: If ``native`` is not a list or tuple of dicts.
        """
        if not isinstance(native, list | tuple):
            raise TypeError(
                f"native must be a list or tuple, got {type(native).__name__}"
            )
        payloads: list[HookPayload] = []
        for index, item in enumerate(native):
            if not isinstance(item, dict):
                raise TypeError(
                    f"native element {index} must be a dict, got {type(item).__name__}"
                )
            payloads.append(item)
        return claude_hook_events(payloads, host=self.host, start=self.start)
