"""Synthetic reference host-shape adapters for the conformance kit (D-06).

Each adapter maps one host's native hook payloads onto the activity envelope
so the kit can run the same core over that host's stream shape. They are
synthetic reference adapters for conformance only, not production
integrations. They import only the package root.
"""

from revenium_agent_economics.conformance.adapters.claude import (
    ClaudeHookAdapter as ClaudeHookAdapter,
)
from revenium_agent_economics.conformance.adapters.claude import (
    claude_hook_events as claude_hook_events,
)
from revenium_agent_economics.conformance.adapters.hermes import (
    HERMES_HOOKS as HERMES_HOOKS,
)
from revenium_agent_economics.conformance.adapters.hermes import (
    HERMES_HOST as HERMES_HOST,
)
from revenium_agent_economics.conformance.adapters.hermes import (
    HermesHookAdapter as HermesHookAdapter,
)
from revenium_agent_economics.conformance.adapters.hermes import (
    hermes_hook_events as hermes_hook_events,
)

__all__ = [
    "HERMES_HOOKS",
    "HERMES_HOST",
    "ClaudeHookAdapter",
    "HermesHookAdapter",
    "claude_hook_events",
    "hermes_hook_events",
]
