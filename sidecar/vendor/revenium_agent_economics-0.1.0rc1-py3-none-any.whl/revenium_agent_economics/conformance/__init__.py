"""The conformance kit: scenarios, a runner, reference ports, and fakes.

A host project runs ``python -m revenium_agent_economics.conformance`` from a
bare install to check the core against every shipped scenario on Claude- and
Hermes-shaped streams, twice, with byte-identical results (CONF-01, CONF-05).
:func:`run_scenario` runs one scenario from a host's own test suite, and the
deterministic fakes and the keyword reference classifier and segmenter stand
in for host ports. The kit imports no pytest and reads no files.

Not imported by the package root. Import it explicitly:
``from revenium_agent_economics.conformance import ScriptedModel``.
"""

from revenium_agent_economics.conformance.fakes import (
    SCRIPTED_CLASSIFIER_DECLARATION as SCRIPTED_CLASSIFIER_DECLARATION,
)
from revenium_agent_economics.conformance.fakes import (
    SCRIPTED_DECIDER_DECLARATION as SCRIPTED_DECIDER_DECLARATION,
)
from revenium_agent_economics.conformance.fakes import (
    SCRIPTED_EVALUATOR_DECLARATION as SCRIPTED_EVALUATOR_DECLARATION,
)
from revenium_agent_economics.conformance.fakes import (
    SCRIPTED_SEGMENTER_DECLARATION as SCRIPTED_SEGMENTER_DECLARATION,
)
from revenium_agent_economics.conformance.fakes import (
    SCRIPTED_VALUATION_DECLARATION as SCRIPTED_VALUATION_DECLARATION,
)
from revenium_agent_economics.conformance.fakes import FixedClock as FixedClock
from revenium_agent_economics.conformance.fakes import (
    InMemoryTaxonomy as InMemoryTaxonomy,
)
from revenium_agent_economics.conformance.fakes import (
    RecordingDiagnostics as RecordingDiagnostics,
)
from revenium_agent_economics.conformance.fakes import (
    ScriptedEvidenceDecider as ScriptedEvidenceDecider,
)
from revenium_agent_economics.conformance.fakes import (
    ScriptedJobSegmenter as ScriptedJobSegmenter,
)
from revenium_agent_economics.conformance.fakes import ScriptedModel as ScriptedModel
from revenium_agent_economics.conformance.fakes import (
    ScriptedOutcomeEvaluator as ScriptedOutcomeEvaluator,
)
from revenium_agent_economics.conformance.fakes import (
    ScriptedTaskClassifier as ScriptedTaskClassifier,
)
from revenium_agent_economics.conformance.fakes import (
    ScriptedValuationPolicy as ScriptedValuationPolicy,
)
from revenium_agent_economics.conformance.fakes import SequentialIds as SequentialIds
from revenium_agent_economics.conformance.reference import (
    FALLBACK_JOB_TYPE as FALLBACK_JOB_TYPE,
)
from revenium_agent_economics.conformance.reference import (
    KEYWORD_CLASSIFIER_DECLARATION as KEYWORD_CLASSIFIER_DECLARATION,
)
from revenium_agent_economics.conformance.reference import (
    KEYWORD_SEGMENTER_DECLARATION as KEYWORD_SEGMENTER_DECLARATION,
)
from revenium_agent_economics.conformance.reference import (
    MAX_INFERRED_JOBS as MAX_INFERRED_JOBS,
)
from revenium_agent_economics.conformance.reference import (
    KeywordJobSegmenter as KeywordJobSegmenter,
)
from revenium_agent_economics.conformance.reference import (
    KeywordTaskClassifier as KeywordTaskClassifier,
)
from revenium_agent_economics.conformance.runner import run_scenario as run_scenario
from revenium_agent_economics.conformance.scenarios import SCENARIOS as SCENARIOS

__all__ = [
    "FALLBACK_JOB_TYPE",
    "KEYWORD_CLASSIFIER_DECLARATION",
    "KEYWORD_SEGMENTER_DECLARATION",
    "MAX_INFERRED_JOBS",
    "SCENARIOS",
    "SCRIPTED_CLASSIFIER_DECLARATION",
    "SCRIPTED_DECIDER_DECLARATION",
    "SCRIPTED_EVALUATOR_DECLARATION",
    "SCRIPTED_SEGMENTER_DECLARATION",
    "SCRIPTED_VALUATION_DECLARATION",
    "FixedClock",
    "InMemoryTaxonomy",
    "KeywordJobSegmenter",
    "KeywordTaskClassifier",
    "RecordingDiagnostics",
    "ScriptedEvidenceDecider",
    "ScriptedJobSegmenter",
    "ScriptedModel",
    "ScriptedOutcomeEvaluator",
    "ScriptedTaskClassifier",
    "ScriptedValuationPolicy",
    "SequentialIds",
    "run_scenario",
]
