"""``python -m revenium_agent_economics.conformance`` (ADR 0037 decision 5, D-03).

Runs every scenario in :data:`SCENARIOS` twice, each run through its own
``asyncio.run``, and compares the two runs' ``encode_record`` bytes (CONF-05).
It prints one line per scenario:

- ``PASS <name> <host_shape> <first 12 hex of the sha256>``, or
- ``FAIL <name> <host_shape> <reason>``, where the reason is
  ``nondeterministic`` when the two runs' bytes differ, or the failing
  expectation kinds otherwise,

then ``<N> scenarios, <F> failing``. With ``--digest`` it prints
``<name> <host_shape> <full sha256>`` lines instead, so CI can diff two
processes run under different ``PYTHONHASHSEED`` values. Either way it exits
1 when any scenario fails or differs between runs, and 0 otherwise.

This module is the only kit module that may use ``asyncio`` and ``sys``, and
it imports no pytest. ``asyncio.run`` is allowed here because the kit sits
outside the core (ADR 0012).
"""

import asyncio
import hashlib
import sys
from collections.abc import Sequence
from typing import Final

from revenium_agent_economics import Scenario, ScenarioResult, encode_record
from revenium_agent_economics.conformance.runner import run_scenario
from revenium_agent_economics.conformance.scenarios import SCENARIOS

DIGEST_FLAG: Final = "--digest"
SHORT_DIGEST_HEX: Final = 12
NONDETERMINISTIC: Final = "nondeterministic"
USAGE: Final = f"usage: python -m revenium_agent_economics.conformance [{DIGEST_FLAG}]"


def _run_once(scenario: Scenario) -> ScenarioResult:
    return asyncio.run(run_scenario(scenario))


def _failure_reason(result: ScenarioResult) -> str:
    failing = ",".join(
        verdict.kind.value for verdict in result.verdicts if not verdict.passed
    )
    return f"expectations {failing}"


def main(argv: Sequence[str] | None = None) -> int:
    """Run every scenario twice and report, as ADR 0037 decision 5 states.

    Args:
        argv: The command-line arguments after the program name. ``None``
            reads ``sys.argv[1:]``. Only ``--digest`` is accepted.

    Returns:
        0 when every scenario passes with identical bytes in both runs, 1
        when any fails or differs, and 2 on an unknown argument.
    """
    args = tuple(sys.argv[1:] if argv is None else argv)
    if any(arg != DIGEST_FLAG for arg in args):
        print(USAGE, file=sys.stderr)
        return 2
    digest_only = DIGEST_FLAG in args
    failing = 0
    for scenario in SCENARIOS:
        first = encode_record(_run_once(scenario))
        result = _run_once(scenario)
        second = encode_record(result)
        digest = hashlib.sha256(first).hexdigest()
        label = f"{scenario.name} {scenario.host_shape.value}"
        if first != second:
            reason: str | None = NONDETERMINISTIC
        elif not result.passed:
            reason = _failure_reason(result)
        else:
            reason = None
        if reason is not None:
            failing += 1
        if digest_only:
            print(f"{label} {digest}")
            if reason is not None:
                print(f"FAIL {label} {reason}", file=sys.stderr)
        elif reason is None:
            print(f"PASS {label} {digest[:SHORT_DIGEST_HEX]}")
        else:
            print(f"FAIL {label} {reason}")
    if not digest_only:
        print(f"{len(SCENARIOS)} scenarios, {failing} failing")
    return 1 if failing else 0


if __name__ == "__main__":
    sys.exit(main())
