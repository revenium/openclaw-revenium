"""The conformance scenarios the kit ships (ADR 0037 decision 1, D-01).

Each scenario is Python-constructed data: the kit reads no files. Every host
stream uses only synthetic values ("sess-hermes-1", "session-a", ...), and
every key in it traces to a documented row in
``compat/envelope_field_sources.toml``: a ``[[hermes_native]]`` row for a
``HERMES`` scenario and a non-excluded ``[[native]]`` row for a
``CLAUDE_CODE`` scenario. The provenance tests enforce that over
:data:`SCENARIOS`.

A scenario name is a contract with host CI: renaming or removing a shipped
scenario is a breaking change (ADR 0037 decision 10).
"""

from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Final, cast

from revenium_agent_economics import (
    DoubleCountingScope,
    ExpectationKind,
    HostShape,
    JobSource,
    JsonValue,
    PolicyPreset,
    Scenario,
    ScenarioExpectation,
    canonical_json,
)
from revenium_agent_economics.conformance.adapters.claude import (
    compaction_payloads,
    fork_payloads,
    resume_payloads,
    stop_failure_payloads,
    task_event_payloads,
)
from revenium_agent_economics.conformance.adapters.hermes import (
    HookPayload,
    hermes_child_session_payloads,
    hermes_finalize_payloads,
    hermes_turn_payloads,
)

TAXONOMY_VERSION: Final = "conformance-2026-10"
HERMES_SESSION: Final = "sess-hermes-1"
TASK_LABELS: Final = ("bug_fix", "question")
JOB_LABELS: Final = ("bug_fix", "documentation")
CLOCK_START: Final = datetime(2026, 10, 1, 9, 30, tzinfo=UTC)

# One synthetic turn, shared by both host shapes of simple_hermes_turn.
FIX_PROMPT: Final = "The export button crashes on empty reports. Please fix it."
FIX_RESPONSE: Final = "Fixed the null check in the export handler; exports work."

# The built-in evaluator's answer: 3 hours at 120.00 USD, confidence 0.8.
LABOR_SUBSTITUTION_EVALUATION: Final = (
    '{"economic_mechanism": "labor_substitution", "estimated_hours_saved": 3,'
    ' "assumed_loaded_rate": 120.0, "confidence": 0.8, "currency": "USD"}'
)


def _stream(*payloads: Mapping[str, object]) -> tuple[str, ...]:
    # canonical_json validates every value at runtime, so the cast only lets
    # the adapters' Mapping[str, object] builders through the type checker.
    return tuple(
        canonical_json(cast("JsonValue", dict(payload))).decode("ascii")
        for payload in payloads
    )


def _expect(kind: ExpectationKind, *values: str) -> ScenarioExpectation:
    return ScenarioExpectation(kind=kind, values=values)


SIMPLE_TURN_EXPECTATIONS: Final[tuple[ScenarioExpectation, ...]] = (
    _expect(ExpectationKind.JOB_COUNT, "1"),
    _expect(ExpectationKind.JOB_TYPES, "bug_fix"),
    _expect(ExpectationKind.TASK_DECISION, "bug_fix"),
    _expect(ExpectationKind.REPORTABILITY, "reportable"),
    _expect(ExpectationKind.METRIC_OUTCOMES, "intents"),
    _expect(ExpectationKind.MODEL_CALL_COUNT, "1"),
)

HERMES_SIMPLE_TURN_STREAM: Final[tuple[str, ...]] = _stream(
    {
        "hook": "post_llm_call",
        "session_id": "sess-hermes-1",
        "turn_id": "turn-1",
        "user_message": FIX_PROMPT,
        "assistant_response": FIX_RESPONSE,
    },
    {
        "hook": "on_session_end",
        "session_id": "sess-hermes-1",
        "completed": True,
        "interrupted": False,
    },
)
"""One Hermes ``post_llm_call`` turn, then ``on_session_end``."""

CLAUDE_SIMPLE_TURN_STREAM: Final[tuple[str, ...]] = _stream(
    {"hook_event_name": "SessionStart", "session_id": "session-a", "source": "startup"},
    {
        "hook_event_name": "UserPromptSubmit",
        "session_id": "session-a",
        "prompt_id": "prompt-1",
        "prompt": FIX_PROMPT,
    },
    {
        "hook_event_name": "Stop",
        "session_id": "session-a",
        "prompt_id": "prompt-1",
        "last_assistant_message": FIX_RESPONSE,
    },
    {"hook_event_name": "SessionEnd", "session_id": "session-a", "reason": "other"},
)
"""The same turn as Claude Code hooks, from ``SessionStart`` to ``SessionEnd``."""


def _scenario(
    name: str,
    host_shape: HostShape,
    summary: str,
    host_stream: tuple[str, ...],
    expectations: tuple[ScenarioExpectation, ...],
    *,
    inference_cuts: tuple[int, ...] | None = None,
    task_labels: tuple[str, ...] = TASK_LABELS,
    job_labels: tuple[str, ...] = JOB_LABELS,
    job_source: JobSource = JobSource.KEYWORD_SEGMENTER,
    model_responses: tuple[str, ...] = (LABOR_SUBSTITUTION_EVALUATION,),
    reportable_evidence: bool = True,
    double_counting_scope: DoubleCountingScope = DoubleCountingScope.INFERENCE,
) -> Scenario:
    return Scenario(
        name=name,
        host_shape=host_shape,
        summary=summary,
        host_stream=host_stream,
        inference_cuts=(
            (len(host_stream),) if inference_cuts is None else inference_cuts
        ),
        task_labels=task_labels,
        job_labels=job_labels,
        taxonomy_version=TAXONOMY_VERSION,
        job_source=job_source,
        model_responses=model_responses,
        policy=PolicyPreset.DEFAULT,
        reportable_evidence=reportable_evidence,
        clock_start=CLOCK_START,
        id_start=0,
        expectations=expectations,
        double_counting_scope=double_counting_scope,
    )


def _simple_turn(host_shape: HostShape, host_stream: tuple[str, ...]) -> Scenario:
    return _scenario(
        "simple_hermes_turn",
        host_shape,
        (
            "One user turn asks for a crash fix and the assistant fixes it. "
            "The keyword segmenter infers one bug_fix job, the evaluator "
            "values it at 3 hours at 120.00 USD, confirmed evidence makes it "
            "reportable, and the batch builds one metric intent set."
        ),
        host_stream,
        SIMPLE_TURN_EXPECTATIONS,
        task_labels=("bug_fix", "question"),
        job_labels=("bug_fix", "documentation"),
    )


# Scenario 6, turn_stop_not_job_completion (D-04 "paused, not done").
SEARCH_PROMPT: Final = "Search the code for every caller of the redirect helper."
SEARCH_PAUSED: Final = "An Explore agent is running the code search in the background."
SEARCH_FOUND: Final = "Found 3 call sites of the redirect helper."
SUMMARY_PROMPT: Final = "List the callers the code search found."
SUMMARY_RESPONSE: Final = "The code search found 3 callers of the redirect helper."

CLAUDE_TURN_STOP_STREAM: Final[tuple[str, ...]] = _stream(
    {"hook_event_name": "SessionStart", "session_id": "session-a", "source": "startup"},
    {
        "hook_event_name": "UserPromptSubmit",
        "session_id": "session-a",
        "prompt_id": "prompt-1",
        "prompt": SEARCH_PROMPT,
    },
    {
        "hook_event_name": "PostToolUse",
        "session_id": "session-a",
        "prompt_id": "prompt-1",
        "tool_name": "Agent",
        "tool_use_id": "toolu_01",
        "tool_response": {"agentId": "agent-1", "status": "async_launched"},
    },
    {
        "hook_event_name": "Stop",
        "session_id": "session-a",
        "prompt_id": "prompt-1",
        "last_assistant_message": SEARCH_PAUSED,
        "stop_hook_active": False,
        "background_tasks": [
            {
                "id": "task-bg-1",
                "type": "subagent",
                "status": "running",
                "description": "Search for callers of the redirect helper",
                "agent_type": "Explore",
            }
        ],
        "session_crons": [],
    },
    {
        "hook_event_name": "PreToolUse",
        "session_id": "session-a",
        "prompt_id": "prompt-1",
        "tool_name": "Bash",
        "tool_use_id": "toolu_02",
    },
    {
        "hook_event_name": "SubagentStop",
        "session_id": "session-a",
        "agent_id": "agent-1",
        "agent_type": "Explore",
        "stop_hook_active": False,
        "last_assistant_message": SEARCH_FOUND,
        "background_tasks": [],
        "session_crons": [],
    },
    {
        "hook_event_name": "UserPromptSubmit",
        "session_id": "session-a",
        "prompt_id": "prompt-2",
        "prompt": SUMMARY_PROMPT,
    },
    {
        "hook_event_name": "Stop",
        "session_id": "session-a",
        "prompt_id": "prompt-2",
        "last_assistant_message": SUMMARY_RESPONSE,
        "stop_hook_active": False,
        "background_tasks": [],
        "session_crons": [],
    },
    {"hook_event_name": "SessionEnd", "session_id": "session-a", "reason": "other"},
)
"""A Stop with one running background agent, then the agent's result and a
second turn. The first pass ends after the agent stops, so the paused Stop
(index 3) is interior to both passes."""

CLAUDE_PAUSED_STOP_INDEX: Final = 3
CLAUDE_TURN_STOP_CUTS: Final = (6, len(CLAUDE_TURN_STOP_STREAM))

HERMES_TURN_STOP_STREAM: Final[tuple[str, ...]] = _stream(
    *hermes_turn_payloads(
        HERMES_SESSION,
        ((SEARCH_PROMPT, SEARCH_PAUSED), (SUMMARY_PROMPT, SUMMARY_RESPONSE)),
    ),
    {
        "hook": "on_session_end",
        "session_id": HERMES_SESSION,
        "completed": True,
        "interrupted": False,
    },
)
"""Two Hermes turns, then ``on_session_end``. Hermes documents no
background-task field, so the paused turn is an ordinary ``post_llm_call``."""

# The first post_llm_call (index 1) ends the first pass, so the interior
# event is the second turn's post_api_request (index 2).
HERMES_INTERIOR_API_REQUEST_INDEX: Final = 2
HERMES_TURN_STOP_CUTS: Final = (2, len(HERMES_TURN_STOP_STREAM))


def _turn_stop_not_job_completion() -> tuple[Scenario, Scenario]:
    labels = ("code_search", "bug_fix")
    claude = _scenario(
        "turn_stop_not_job_completion",
        HostShape.CLAUDE_CODE,
        (
            "A Stop arrives while a background agent still runs. Dropping that "
            "Stop leaves every inference byte-identical, so a turn stop closes "
            "nothing; a second pass after the agent returns revises the first "
            "candidate, and the agent's work attaches to the root job."
        ),
        CLAUDE_TURN_STOP_STREAM,
        (
            _expect(
                ExpectationKind.INVARIANT_WITHOUT_EVENT, str(CLAUDE_PAUSED_STOP_INDEX)
            ),
            _expect(ExpectationKind.SUPERSEDED_COUNT, "1"),
            _expect(ExpectationKind.JOB_COUNT, "2"),
            _expect(ExpectationKind.JOB_TYPES, "code_search", "code_search"),
            _expect(ExpectationKind.JOB_OUTCOMES, "SUCCESS", "SUCCESS"),
            _expect(ExpectationKind.ATTRIBUTION_BASES, "inferred", "lineage_root"),
            _expect(ExpectationKind.DELEGATION_MODES, "background"),
            _expect(ExpectationKind.MODEL_CALL_COUNT, "1"),
        ),
        inference_cuts=CLAUDE_TURN_STOP_CUTS,
        task_labels=labels,
        job_labels=labels,
    )
    hermes = _scenario(
        "turn_stop_not_job_completion",
        HostShape.HERMES,
        (
            "Hermes documents no background-task field, so the paused turn is "
            "an ordinary turn. Dropping the second turn's API request leaves "
            "every inference byte-identical, and the pass after the second "
            "turn revises the first candidate."
        ),
        HERMES_TURN_STOP_STREAM,
        (
            _expect(
                ExpectationKind.INVARIANT_WITHOUT_EVENT,
                str(HERMES_INTERIOR_API_REQUEST_INDEX),
            ),
            _expect(ExpectationKind.SUPERSEDED_COUNT, "1"),
            _expect(ExpectationKind.JOB_COUNT, "1"),
            _expect(ExpectationKind.JOB_TYPES, "code_search"),
            _expect(ExpectationKind.JOB_OUTCOMES, "SUCCESS"),
            _expect(ExpectationKind.MODEL_CALL_COUNT, "1"),
        ),
        inference_cuts=HERMES_TURN_STOP_CUTS,
        task_labels=labels,
        job_labels=labels,
    )
    return claude, hermes


def _claude_session(
    *turns: tuple[str, str], session_id: str = "session-a"
) -> tuple[dict[str, JsonValue], ...]:
    # SessionStart, then UserPromptSubmit and Stop per turn, then SessionEnd.
    payloads: list[dict[str, JsonValue]] = [
        {
            "hook_event_name": "SessionStart",
            "session_id": session_id,
            "source": "startup",
        }
    ]
    for number, (prompt, response) in enumerate(turns, start=1):
        prompt_id = f"prompt-{number}"
        payloads.append(
            {
                "hook_event_name": "UserPromptSubmit",
                "session_id": session_id,
                "prompt_id": prompt_id,
                "prompt": prompt,
            }
        )
        payloads.append(
            {
                "hook_event_name": "Stop",
                "session_id": session_id,
                "prompt_id": prompt_id,
                "last_assistant_message": response,
            }
        )
    payloads.append(
        {"hook_event_name": "SessionEnd", "session_id": session_id, "reason": "other"}
    )
    return tuple(payloads)


def _hermes_session(
    *turns: tuple[str, str], session_id: str = HERMES_SESSION
) -> tuple[HookPayload, ...]:
    # post_api_request then post_llm_call per turn, then on_session_end.
    return (
        *hermes_turn_payloads(session_id, turns),
        {
            "hook": "on_session_end",
            "session_id": session_id,
            "completed": True,
            "interrupted": False,
        },
    )


# Scenario 2, multi_turn_multi_job_session (ADR 0033 REFUSE default).
DOCS_PROMPT: Final = "Now update the export documentation to describe empty reports."
DOCS_RESPONSE: Final = "Updated the export documentation for empty reports."
TWO_JOBS_RESPONSE: Final = (
    '[{"agentic_job_id": "fix_export_crash", "job_name": "Fix the export crash",'
    ' "job_type": "bug_fix", "status": "SUCCESS"},'
    ' {"agentic_job_id": "document_empty_reports",'
    ' "job_name": "Document empty reports", "job_type": "documentation",'
    ' "status": "SUCCESS"}]'
)
"""A scripted segmentation answer with two jobs in one session."""


def _multi_turn_multi_job_session() -> tuple[Scenario, Scenario]:
    turns = ((FIX_PROMPT, FIX_RESPONSE), (DOCS_PROMPT, DOCS_RESPONSE))
    expectations = (
        _expect(ExpectationKind.JOB_COUNT, "2"),
        _expect(ExpectationKind.JOB_TYPES, "bug_fix", "documentation"),
        _expect(ExpectationKind.DOUBLE_COUNTING_GROUP_COUNT, "1"),
        _expect(ExpectationKind.REPORTABILITY, "reportable", "reportable"),
        _expect(
            ExpectationKind.METRIC_OUTCOMES,
            "unallocated_shared_outcome",
            "unallocated_shared_outcome",
        ),
        _expect(ExpectationKind.MODEL_CALL_COUNT, "3"),
    )
    summary = (
        "Two turns produce two reportable jobs in one session. Both carry the "
        "session's lineage-root double-counting group, so the default REFUSE "
        "policy refuses both metric sets until the host allocates the shared "
        "outcome (ADR 0033)."
    )
    responses = (TWO_JOBS_RESPONSE,) + (LABOR_SUBSTITUTION_EVALUATION,) * 2
    return (
        _scenario(
            "multi_turn_multi_job_session",
            HostShape.CLAUDE_CODE,
            summary,
            _stream(*_claude_session(*turns)),
            expectations,
            job_source=JobSource.SCRIPTED_MODEL,
            model_responses=responses,
        ),
        _scenario(
            "multi_turn_multi_job_session",
            HostShape.HERMES,
            summary,
            _stream(*_hermes_session(*turns)),
            expectations,
            job_source=JobSource.SCRIPTED_MODEL,
            model_responses=responses,
        ),
    )


def _multi_job_session_job_scope() -> tuple[Scenario, Scenario]:
    # ADR 0044 decision 6: the stream of multi_turn_multi_job_session,
    # inferred with one double-counting group per job.
    turns = ((FIX_PROMPT, FIX_RESPONSE), (DOCS_PROMPT, DOCS_RESPONSE))
    expectations = (
        _expect(ExpectationKind.JOB_COUNT, "2"),
        _expect(ExpectationKind.JOB_TYPES, "bug_fix", "documentation"),
        _expect(ExpectationKind.DOUBLE_COUNTING_GROUP_COUNT, "2"),
        _expect(ExpectationKind.REPORTABILITY, "reportable", "reportable"),
        _expect(ExpectationKind.METRIC_OUTCOMES, "intents", "intents"),
        _expect(ExpectationKind.MODEL_CALL_COUNT, "3"),
    )
    summary = (
        "Two turns produce two independent reportable jobs in one long-lived "
        "session. Inferred under DoubleCountingScope.JOB, each job has its own "
        "double-counting group, so the default REFUSE policy delivers both "
        "metric sets with no allocation (ADR 0044)."
    )
    responses = (TWO_JOBS_RESPONSE,) + (LABOR_SUBSTITUTION_EVALUATION,) * 2
    return (
        _scenario(
            "multi_job_session_job_scope",
            HostShape.CLAUDE_CODE,
            summary,
            _stream(*_claude_session(*turns)),
            expectations,
            job_source=JobSource.SCRIPTED_MODEL,
            model_responses=responses,
            double_counting_scope=DoubleCountingScope.JOB,
        ),
        _scenario(
            "multi_job_session_job_scope",
            HostShape.HERMES,
            summary,
            _stream(*_hermes_session(*turns)),
            expectations,
            job_source=JobSource.SCRIPTED_MODEL,
            model_responses=responses,
            double_counting_scope=DoubleCountingScope.JOB,
        ),
    )


# Scenario 3, claude_user_prompt_event.
QUESTION_PROMPT: Final = "Question: which handler writes the export file?"
QUESTION_RESPONSE: Final = "The export handler in reports.py writes the file."


def _claude_user_prompt_event() -> tuple[Scenario, Scenario]:
    expectations = (
        _expect(ExpectationKind.TASK_DECISION, "question"),
        _expect(ExpectationKind.JOB_COUNT, "1"),
        _expect(ExpectationKind.JOB_TYPES, "question"),
    )
    labels = ("bug_fix", "question")
    turn = (QUESTION_PROMPT, QUESTION_RESPONSE)
    return (
        _scenario(
            "claude_user_prompt_event",
            HostShape.CLAUDE_CODE,
            (
                "A UserPromptSubmit carries the prompt text and a prompt_id. The "
                "keyword classifier labels the turn from the prompt and the "
                "reply alone; the prompt_id only correlates the Stop with it."
            ),
            _stream(*_claude_session(turn)),
            expectations,
            task_labels=labels,
            job_labels=labels,
        ),
        _scenario(
            "claude_user_prompt_event",
            HostShape.HERMES,
            (
                "Hermes carries the prompt as post_llm_call user_message, with no "
                "prompt id. The same classifier labels the turn from the same "
                "text, so both host shapes reach the same task decision."
            ),
            _stream(*_hermes_session(turn)),
            expectations,
            task_labels=labels,
            job_labels=labels,
        ),
    )


# Scenario 4, task_created_and_completed (ENV-04).
CLAUDE_TASK_STREAM: Final[tuple[str, ...]] = _stream(
    *task_event_payloads(),
    {"hook_event_name": "SessionEnd", "session_id": "session-a", "reason": "other"},
)
"""TaskCreated and a self-reported TaskCompleted inside one turn."""

CLAUDE_TASK_COMPLETED_INDEX: Final = 3
TASK_PROMPT: Final = "Fix the failing login test."
TASK_RESPONSE: Final = "Fixed the redirect; the login test passes."
TASK_FOLLOW_UP: Final = "Fix the flaky logout test too."
TASK_FOLLOW_UP_RESPONSE: Final = "Fixed the logout wait; the test passes."

HERMES_TASK_STREAM: Final[tuple[str, ...]] = _stream(
    *(
        {**payload, "task_id": "task-1"} if "turn_id" in payload else payload
        for payload in _hermes_session(
            (TASK_PROMPT, TASK_RESPONSE), (TASK_FOLLOW_UP, TASK_FOLLOW_UP_RESPONSE)
        )
    )
)
"""Two Hermes turns that carry ``task_id``; Hermes documents no task event."""


def _task_created_and_completed() -> tuple[Scenario, Scenario]:
    labels = ("bug_fix", "documentation")
    return (
        _scenario(
            "task_created_and_completed",
            HostShape.CLAUDE_CODE,
            (
                "A task is created and reported completed inside one turn. "
                "TaskCompleted is a self-report, so dropping it leaves every "
                "inference byte-identical: it closes no job and sets no outcome."
            ),
            CLAUDE_TASK_STREAM,
            (
                _expect(
                    ExpectationKind.INVARIANT_WITHOUT_EVENT,
                    str(CLAUDE_TASK_COMPLETED_INDEX),
                ),
                _expect(ExpectationKind.JOB_COUNT, "1"),
                _expect(ExpectationKind.JOB_OUTCOMES, "SUCCESS"),
            ),
            job_labels=labels,
        ),
        _scenario(
            "task_created_and_completed",
            HostShape.HERMES,
            (
                "Hermes carries task_id on its turn hooks but documents no task "
                "event. Dropping the second turn's API request leaves every "
                "inference byte-identical, and the task id sets no outcome."
            ),
            HERMES_TASK_STREAM,
            (
                _expect(
                    ExpectationKind.INVARIANT_WITHOUT_EVENT,
                    str(HERMES_INTERIOR_API_REQUEST_INDEX),
                ),
                _expect(ExpectationKind.JOB_COUNT, "1"),
                _expect(ExpectationKind.JOB_OUTCOMES, "SUCCESS"),
            ),
            job_labels=labels,
        ),
    )


# Scenario 5, foreground_and_background_delegation (ADR 0018 decision 11).
AUDIT_PROMPT: Final = "Audit every caller of the redirect helper."
AUDIT_RESPONSE: Final = "Two agents audited the redirect helper; it has 3 callers."
AUDIT_JOB_RESPONSE: Final = (
    '[{"agentic_job_id": "audit_redirect_callers",'
    ' "job_name": "Audit redirect callers", "job_type": "code_audit",'
    ' "status": "SUCCESS"}]'
)
"""A scripted segmentation answer with one job for the root session."""


def _agent_call(tool_use_id: str, agent_id: str, status: str) -> HookPayload:
    return {
        "hook_event_name": "PostToolUse",
        "session_id": "session-a",
        "prompt_id": "prompt-1",
        "tool_name": "Agent",
        "tool_use_id": tool_use_id,
        "tool_response": {"agentId": agent_id, "status": status},
    }


def _subagent(event: str, agent_id: str, message: str | None = None) -> HookPayload:
    payload: dict[str, object] = {
        "hook_event_name": event,
        "session_id": "session-a",
        "agent_id": agent_id,
        "agent_type": "Explore",
    }
    if message is not None:
        payload["last_assistant_message"] = message
    return payload


CLAUDE_DELEGATION_STREAM: Final[tuple[str, ...]] = _stream(
    {"hook_event_name": "SessionStart", "session_id": "session-a", "source": "startup"},
    {
        "hook_event_name": "UserPromptSubmit",
        "session_id": "session-a",
        "prompt_id": "prompt-1",
        "prompt": AUDIT_PROMPT,
    },
    _subagent("SubagentStart", "agent-1"),
    _agent_call("toolu_01", "agent-1", "async_launched"),
    _subagent("SubagentStart", "agent-2"),
    _subagent("SubagentStop", "agent-2", "The helper has 2 callers in auth."),
    _agent_call("toolu_02", "agent-2", "completed"),
    _subagent("SubagentStop", "agent-1", "The helper has 1 caller in billing."),
    {
        "hook_event_name": "Stop",
        "session_id": "session-a",
        "prompt_id": "prompt-1",
        "last_assistant_message": AUDIT_RESPONSE,
    },
    {"hook_event_name": "SessionEnd", "session_id": "session-a", "reason": "other"},
)
"""One turn that launches agent-1 in the background and runs agent-2 in the
foreground, the shapes of ``background_subagent_payloads`` and
``foreground_subagent_payloads`` in one session."""

HERMES_DELEGATION_STREAM: Final[tuple[str, ...]] = _stream(
    *hermes_child_session_payloads(
        HERMES_SESSION,
        "sess-hermes-child",
        (("Audit the billing caller.", "The helper has 1 caller in billing."),),
    ),
    {
        "hook": "on_session_end",
        "session_id": HERMES_SESSION,
        "completed": True,
        "interrupted": False,
    },
)
"""A parent turn, the host-state parent link, and the child session's turn."""


def _foreground_and_background_delegation() -> tuple[Scenario, Scenario]:
    labels = ("code_audit", "bug_fix")
    responses = (AUDIT_JOB_RESPONSE, LABOR_SUBSTITUTION_EVALUATION)
    return (
        _scenario(
            "foreground_and_background_delegation",
            HostShape.CLAUDE_CODE,
            (
                "One turn delegates to a background and a foreground agent. Each "
                "agent's lineage entry records its mode, and each attaches to "
                "the root job as a lineage_root attribution with no model call: "
                "two calls in all, one to segment the root and one to value it."
            ),
            CLAUDE_DELEGATION_STREAM,
            (
                _expect(ExpectationKind.DELEGATION_MODES, "background", "foreground"),
                _expect(
                    ExpectationKind.ATTRIBUTION_BASES,
                    "inferred",
                    "lineage_root",
                    "lineage_root",
                ),
                _expect(
                    ExpectationKind.JOB_TYPES, "code_audit", "code_audit", "code_audit"
                ),
                _expect(ExpectationKind.DOUBLE_COUNTING_GROUP_COUNT, "1"),
                _expect(ExpectationKind.METRIC_OUTCOMES, "intents"),
                _expect(ExpectationKind.MODEL_CALL_COUNT, "2"),
            ),
            task_labels=labels,
            job_labels=labels,
            job_source=JobSource.SCRIPTED_MODEL,
            model_responses=responses,
        ),
        _scenario(
            "foreground_and_background_delegation",
            HostShape.HERMES,
            (
                "A Hermes subagent is a child session linked only by the host "
                "state parent row. Hermes documents no delegation mode, so the "
                "child's mode stays unknown, and its work attaches to the root "
                "job with no model call."
            ),
            HERMES_DELEGATION_STREAM,
            (
                _expect(ExpectationKind.DELEGATION_MODES, "unknown"),
                _expect(ExpectationKind.ATTRIBUTION_BASES, "inferred", "lineage_root"),
                _expect(ExpectationKind.JOB_TYPES, "code_audit", "code_audit"),
                _expect(ExpectationKind.DOUBLE_COUNTING_GROUP_COUNT, "1"),
                _expect(ExpectationKind.METRIC_OUTCOMES, "intents"),
                _expect(ExpectationKind.MODEL_CALL_COUNT, "2"),
            ),
            task_labels=labels,
            job_labels=labels,
            job_source=JobSource.SCRIPTED_MODEL,
            model_responses=responses,
        ),
    )


# Scenario 7, failed_turn (VAL-06, ENV-04).
CLAUDE_FAILED_TURN_STREAM: Final[tuple[str, ...]] = _stream(
    *stop_failure_payloads(),
    {"hook_event_name": "SessionEnd", "session_id": "session-a", "reason": "other"},
)
"""A turn that ends on StopFailure, whose API error text is never read."""

CLAUDE_STOP_FAILURE_INDEX: Final = 2
FAILED_PROMPT: Final = "Fix the failing export test."
FAILED_RESPONSE: Final = "I could not fix the export test; it still fails."
FAILED_JOB_RESPONSE: Final = (
    '[{"agentic_job_id": "fix_export_test", "job_name": "Fix the export test",'
    ' "job_type": "bug_fix", "status": "FAILED",'
    ' "failure_reason": "The export test still fails."}]'
)
"""A scripted segmentation answer that reports the job as failed."""


def _failed_turn() -> tuple[Scenario, Scenario]:
    return (
        _scenario(
            "failed_turn",
            HostShape.CLAUDE_CODE,
            (
                "The turn ends on StopFailure. Dropping it leaves every "
                "inference byte-identical, so a turn failure sets no job "
                "outcome; the segmenter's own SUCCESS stands, and the API error "
                "text never enters an event."
            ),
            CLAUDE_FAILED_TURN_STREAM,
            (
                _expect(
                    ExpectationKind.INVARIANT_WITHOUT_EVENT,
                    str(CLAUDE_STOP_FAILURE_INDEX),
                ),
                _expect(ExpectationKind.JOB_COUNT, "1"),
                _expect(ExpectationKind.JOB_OUTCOMES, "SUCCESS"),
            ),
        ),
        _scenario(
            "failed_turn",
            HostShape.HERMES,
            (
                "The model reports the job FAILED. A failed job is never "
                "evaluated, so it costs no outcome call, carries zero value, "
                "and builds no metric intents."
            ),
            _stream(
                {
                    "hook": "post_llm_call",
                    "session_id": HERMES_SESSION,
                    "turn_id": "turn-1",
                    "user_message": FAILED_PROMPT,
                    "assistant_response": FAILED_RESPONSE,
                },
                {
                    "hook": "on_session_end",
                    "session_id": HERMES_SESSION,
                    "completed": False,
                    "interrupted": False,
                },
            ),
            (
                _expect(ExpectationKind.JOB_OUTCOMES, "FAILED"),
                _expect(ExpectationKind.VALUE_STATES, "zero_not_completed"),
                _expect(ExpectationKind.REPORTABILITY, "uncomputed"),
                _expect(ExpectationKind.METRIC_OUTCOMES, "not_reportable"),
                _expect(ExpectationKind.MODEL_CALL_COUNT, "1"),
            ),
            job_source=JobSource.SCRIPTED_MODEL,
            model_responses=(FAILED_JOB_RESPONSE,),
        ),
    )


# Scenario 8, compaction.
CLAUDE_COMPACTION_STREAM: Final[tuple[str, ...]] = _stream(*compaction_payloads())
"""Two turns of one session with a manual compaction between them."""

CLAUDE_POST_COMPACT_INDEX: Final = 4
SECOND_PROMPT: Final = "Add a regression test for the redirect."
SECOND_RESPONSE: Final = "Added a regression test for the redirect."


def _compaction() -> tuple[Scenario, Scenario]:
    return (
        _scenario(
            "compaction",
            HostShape.CLAUDE_CODE,
            (
                "A manual compaction and a compact restart sit between two "
                "turns. Dropping PostCompact leaves every inference "
                "byte-identical, and the session's origin stays new because "
                "the first reported origin wins."
            ),
            CLAUDE_COMPACTION_STREAM,
            (
                _expect(
                    ExpectationKind.INVARIANT_WITHOUT_EVENT,
                    str(CLAUDE_POST_COMPACT_INDEX),
                ),
                _expect(ExpectationKind.SESSION_ORIGINS, "new"),
                _expect(ExpectationKind.JOB_COUNT, "1"),
            ),
        ),
        _scenario(
            "compaction",
            HostShape.HERMES,
            (
                "Hermes documents no compaction event, so the stream carries "
                "none. The core invents no origin: the one session stays "
                "unknown, with one job (D-26)."
            ),
            _stream(
                *_hermes_session(
                    (TASK_PROMPT, TASK_RESPONSE), (SECOND_PROMPT, SECOND_RESPONSE)
                )
            ),
            (
                _expect(ExpectationKind.SESSION_ORIGINS, "unknown"),
                _expect(ExpectationKind.JOB_COUNT, "1"),
            ),
        ),
    )


# Scenario 9, resumed_session (ADR 0021).
CLAUDE_RESUME_STREAM: Final[tuple[str, ...]] = _stream(*resume_payloads())
"""A session that ends and resumes under the same session_id. The first pass
ends at SessionEnd, before the resume."""

CLAUDE_RESUME_CUTS: Final = (4, len(CLAUDE_RESUME_STREAM))
HERMES_NEXT_SESSION: Final = "sess-hermes-2"

HERMES_RESET_STREAM: Final[tuple[str, ...]] = _stream(
    *hermes_turn_payloads(HERMES_SESSION, ((TASK_PROMPT, TASK_RESPONSE),)),
    *hermes_finalize_payloads(HERMES_SESSION, HERMES_NEXT_SESSION),
    *_hermes_session((SECOND_PROMPT, SECOND_RESPONSE), session_id=HERMES_NEXT_SESSION),
)
"""A turn, a user reset that finalizes the session and hands over a new id,
and a turn in the new session. The first pass ends at the finalize."""

HERMES_RESET_CUTS: Final = (3, len(HERMES_RESET_STREAM))


def _resumed_session() -> tuple[Scenario, Scenario]:
    return (
        _scenario(
            "resumed_session",
            HostShape.CLAUDE_CODE,
            (
                "A session resumes under the same session_id, so it keeps one "
                "lineage root, and the pass after the resume revises the "
                "candidate the first pass inferred."
            ),
            CLAUDE_RESUME_STREAM,
            (
                _expect(ExpectationKind.LINEAGE_ROOT_COUNT, "1"),
                _expect(ExpectationKind.SUPERSEDED_COUNT, "1"),
                _expect(ExpectationKind.SESSION_ORIGINS, "new"),
                _expect(ExpectationKind.JOB_COUNT, "1"),
            ),
            inference_cuts=CLAUDE_RESUME_CUTS,
        ),
        _scenario(
            "resumed_session",
            HostShape.HERMES,
            (
                "Hermes documents a reset to a new session, not a resume. The "
                "new session is its own root with its own job, so only the old "
                "session's own revision is superseded, never across sessions "
                "(D-26)."
            ),
            HERMES_RESET_STREAM,
            (
                _expect(ExpectationKind.LINEAGE_ROOT_COUNT, "2"),
                _expect(ExpectationKind.SUPERSEDED_COUNT, "1"),
                _expect(ExpectationKind.SESSION_ORIGINS, "unknown", "unknown"),
                _expect(ExpectationKind.JOB_COUNT, "2"),
                _expect(ExpectationKind.DOUBLE_COUNTING_GROUP_COUNT, "2"),
            ),
            inference_cuts=HERMES_RESET_CUTS,
        ),
    )


# Scenario 10, forked_session (a session fork, not a forked subagent).
FORK_PROMPT: Final = "Try a different fix for the redirect."
FORK_RESPONSE: Final = "Tried a cookie-based redirect fix instead."


def _forked_session() -> tuple[Scenario, Scenario]:
    return (
        _scenario(
            "forked_session",
            HostShape.CLAUDE_CODE,
            (
                "A fork starts a new session_id with source fork. Hooks name no "
                "forked-from session, so the fork is its own lineage root with "
                "its own double-counting group, and both jobs build intents."
            ),
            _stream(*fork_payloads()),
            (
                _expect(ExpectationKind.SESSION_ORIGINS, "new", "forked"),
                _expect(ExpectationKind.LINEAGE_ROOT_COUNT, "2"),
                _expect(ExpectationKind.DOUBLE_COUNTING_GROUP_COUNT, "2"),
                _expect(ExpectationKind.METRIC_OUTCOMES, "intents", "intents"),
            ),
            model_responses=(LABOR_SUBSTITUTION_EVALUATION,) * 2,
        ),
        _scenario(
            "forked_session",
            HostShape.HERMES,
            (
                "Hermes documents no fork, so a second session with no parent "
                "row is simply another session: two roots, two groups, and "
                "both origins unknown (D-26)."
            ),
            _stream(
                *_hermes_session((TASK_PROMPT, TASK_RESPONSE)),
                *_hermes_session(
                    (FORK_PROMPT, FORK_RESPONSE), session_id=HERMES_NEXT_SESSION
                ),
            ),
            (
                _expect(ExpectationKind.SESSION_ORIGINS, "unknown", "unknown"),
                _expect(ExpectationKind.LINEAGE_ROOT_COUNT, "2"),
                _expect(ExpectationKind.DOUBLE_COUNTING_GROUP_COUNT, "2"),
                _expect(ExpectationKind.METRIC_OUTCOMES, "intents", "intents"),
            ),
            model_responses=(LABOR_SUBSTITUTION_EVALUATION,) * 2,
        ),
    )


# Scenario 11, duplicated_and_reordered_events (ENV-02).
def _duplicated_and_reordered_events() -> tuple[Scenario, Scenario]:
    labels = ("code_search", "bug_fix")
    expectations = (
        _expect(ExpectationKind.REPLAY_INVARIANT),
        _expect(ExpectationKind.DEDUPE_COLLISION_COUNT, "0"),
        _expect(ExpectationKind.SUPERSEDED_COUNT, "1"),
    )
    summary = (
        "Each pass's events are fed to normalize_stream twice and in reverse. "
        "The activity logs and every decision record stay byte-identical, and "
        "exact duplicates count no dedupe collision."
    )
    return (
        _scenario(
            "duplicated_and_reordered_events",
            HostShape.CLAUDE_CODE,
            summary,
            CLAUDE_TURN_STOP_STREAM,
            expectations,
            inference_cuts=CLAUDE_TURN_STOP_CUTS,
            task_labels=labels,
            job_labels=labels,
        ),
        _scenario(
            "duplicated_and_reordered_events",
            HostShape.HERMES,
            summary,
            HERMES_TURN_STOP_STREAM,
            expectations,
            inference_cuts=HERMES_TURN_STOP_CUTS,
            task_labels=labels,
            job_labels=labels,
        ),
    )


SCENARIOS: Final[tuple[Scenario, ...]] = (
    _simple_turn(HostShape.CLAUDE_CODE, CLAUDE_SIMPLE_TURN_STREAM),
    _simple_turn(HostShape.HERMES, HERMES_SIMPLE_TURN_STREAM),
    *_multi_turn_multi_job_session(),
    *_claude_user_prompt_event(),
    *_task_created_and_completed(),
    *_foreground_and_background_delegation(),
    *_turn_stop_not_job_completion(),
    *_failed_turn(),
    *_compaction(),
    *_resumed_session(),
    *_forked_session(),
    *_duplicated_and_reordered_events(),
    *_multi_job_session_job_scope(),
)
"""Every shipped scenario, in CONF-02 order, Claude Code then Hermes per name."""
