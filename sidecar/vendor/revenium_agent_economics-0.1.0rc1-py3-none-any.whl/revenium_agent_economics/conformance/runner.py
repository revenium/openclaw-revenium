"""Run one conformance scenario through the public API (ADR 0037 decision 4, D-02).

:func:`run_scenario` uses only the package root and the kit's own modules,
so it exercises exactly the contract a host sees. It builds every fake and
the :class:`~revenium_agent_economics.Engine` fresh from the scenario on each
call: ``ScriptedModel`` scripts drain and ``SequentialIds`` counts, so a
shared fake would make the second run differ from the first.

The result's ``encode_record`` bytes are the run's bytes (CONF-05).
"""

import json
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from types import MappingProxyType
from typing import Final, TypeAlias

from revenium_agent_economics import (
    ActivityEvent,
    ActivityKind,
    ActivityLog,
    AssessJobRequest,
    AssessmentAbstention,
    AssessmentPolicy,
    AttributionBasis,
    ClassificationAbstention,
    CompletionResult,
    ComponentDeclaration,
    Currency,
    DoubleCountingScope,
    EconomicsContract,
    EffectiveAssessment,
    Engine,
    EngineDependencies,
    ExpectationKind,
    ExpectationVerdict,
    HostAdapter,
    HostShape,
    JobAssessment,
    JobCandidate,
    JobInference,
    JobInferenceRequest,
    JobSource,
    JobSubject,
    JobTaxonomySnapshot,
    JsonValue,
    MetricDeclaration,
    MetricRefusal,
    MetricsPolicy,
    MetricType,
    OutcomeAbstention,
    OutcomeMetricIntents,
    OutcomeProposal,
    OutcomeRequest,
    PolicyPreset,
    ReportabilityQuery,
    ReportabilityStatus,
    ResolvedEvidence,
    Scenario,
    ScenarioExpectation,
    ScenarioResult,
    SessionLineage,
    TaskClassification,
    TaskClassificationRequest,
    TaskTaxonomySnapshot,
    TextExcerpt,
    __version__,
    build_outcome_metrics_batch,
    encode_record,
    fold_lineage,
    normalize_stream,
    resolve_current,
    resolve_effective,
    sample_transcript,
    subject_for,
)
from revenium_agent_economics.conformance.adapters import (
    ClaudeHookAdapter,
    HermesHookAdapter,
)
from revenium_agent_economics.conformance.fakes import (
    SCRIPTED_DECIDER_DECLARATION,
    FixedClock,
    InMemoryTaxonomy,
    ScriptedModel,
    SequentialIds,
)
from revenium_agent_economics.conformance.reference import (
    KeywordJobSegmenter,
    KeywordTaskClassifier,
)

_Assessment: TypeAlias = JobAssessment | AssessmentAbstention
_MetricResult: TypeAlias = OutcomeMetricIntents | MetricRefusal

# ADR 0037 decision 2: the PolicyPreset.DEFAULT contract version.
CONTRACT_VERSION: Final = "conformance-1"
INTENTS: Final = "intents"
ABSTAINED_PREFIX: Final = "abstained:"
# ADR 0037 decision 2: the actual values of the two invariance kinds.
UNCHANGED: Final = "unchanged"
CHANGED: Final = "changed"
IDENTICAL: Final = "identical"
DIFFERENT: Final = "different"


@dataclass(frozen=True, slots=True)
class _Pass:
    log: ActivityLog
    lineage: SessionLineage
    sample: TextExcerpt
    inferences: tuple[JobInference, ...]


@dataclass(frozen=True, slots=True)
class _Run:
    passes: tuple[_Pass, ...]
    task_decision: TaskClassification | ClassificationAbstention
    current: tuple[JobCandidate, ...]
    outcomes: tuple[OutcomeProposal | OutcomeAbstention, ...]
    assessments: tuple[_Assessment, ...]
    effectives: tuple[EffectiveAssessment, ...]
    metrics: tuple[_MetricResult, ...]
    model_calls: int


@dataclass(frozen=True, slots=True)
class _Ports:
    engine: Engine
    clock: FixedClock
    model: ScriptedModel


@dataclass(frozen=True, slots=True)
class _Context:
    scenario: Scenario
    adapter: HostAdapter
    run: _Run


_Extractor: TypeAlias = Callable[
    [_Context, ScenarioExpectation], Awaitable[tuple[str, ...]]
]


class _StandingEvidenceDecider:
    """An evidence decider that gives the same answer to every query.

    The scenario's ``reportable_evidence`` fixes the answer, so the decider
    needs no script sized to the number of jobs the run infers.
    """

    def __init__(self, status: ReportabilityStatus) -> None:
        self._status = status

    @property
    def declaration(self) -> ComponentDeclaration:
        """A customer confirmation workflow, as the scripted decider declares."""
        return SCRIPTED_DECIDER_DECLARATION

    def decide(self, query: ReportabilityQuery) -> JsonValue | None:
        """Return the standing status for ``query``."""
        del query
        return {"reportability_status": self._status.value}


def default_adapter(scenario: Scenario) -> HostAdapter:
    """Return the scenario's host-shape adapter, starting at its clock.

    Args:
        scenario: The scenario to adapt.

    Returns:
        ``ClaudeHookAdapter`` for ``CLAUDE_CODE``, ``HermesHookAdapter`` for
        ``HERMES``.
    """
    if scenario.host_shape is HostShape.HERMES:
        return HermesHookAdapter(start=scenario.clock_start)
    return ClaudeHookAdapter(start=scenario.clock_start)


def _preset(
    scenario: Scenario,
) -> tuple[AssessmentPolicy, tuple[EconomicsContract, ...], MetricsPolicy]:
    # ADR 0037 decision 2: PolicyPreset.DEFAULT is the only preset.
    if scenario.policy is not PolicyPreset.DEFAULT:
        raise LookupError(f"unknown policy preset {scenario.policy.value!r}")
    metrics = (
        MetricDeclaration(key="estimated_value", metric_type=MetricType.MONEY),
        MetricDeclaration(key="hours_saved", metric_type=MetricType.DURATION),
        MetricDeclaration(key="assessment_confidence", metric_type=MetricType.SCORE),
        MetricDeclaration(key="jobs_completed", metric_type=MetricType.COUNT),
    )
    contracts = tuple(
        EconomicsContract(
            job_type=label,
            version=CONTRACT_VERSION,
            currency=Currency.USD,
            metrics=metrics,
        )
        for label in scenario.job_labels
    )
    return AssessmentPolicy(), contracts, MetricsPolicy()


def _messages(log: ActivityLog) -> tuple[tuple[str, str], ...]:
    # ADR 0037 decision 4 step 4: prompts and turn stops, in log order.
    messages: list[tuple[str, str]] = []
    for event in log.events:
        if not isinstance(event.payload, TextExcerpt):
            continue
        if event.kind is ActivityKind.PROMPT_SUBMITTED:
            messages.append(("user", event.payload.text))
        elif event.kind is ActivityKind.TURN_STOPPED:
            messages.append(("assistant", event.payload.text))
    return tuple(messages)


def _last(messages: tuple[tuple[str, str], ...], role: str) -> str | None:
    texts = [text for who, text in messages if who == role]
    return texts[-1] if texts else None


def _subjects(lineage: SessionLineage) -> tuple[JobSubject, ...]:
    # Root subjects first, then every other entry, each in lineage entry order.
    roots = [entry.node for entry in lineage.entries if entry.parent is None]
    others = [entry.node for entry in lineage.entries if entry.parent is not None]
    return tuple(subject_for(lineage, node) for node in (*roots, *others))


def _current(final: _Pass) -> tuple[JobCandidate, ...]:
    # ADR 0037 decision 2: resolve_current over every candidate of the final
    # pass. It keeps input order, which is subject order, then result order.
    return resolve_current(
        candidate
        for inference in final.inferences
        for candidate in inference.candidates
    )


def _ports(scenario: Scenario) -> _Ports:
    # Research Pitfall 3: every fake is built fresh, because ScriptedModel
    # scripts drain and SequentialIds counts.
    clock = FixedClock(scenario.clock_start)
    model = ScriptedModel(
        *(CompletionResult(text=text) for text in scenario.model_responses)
    )
    status = (
        ReportabilityStatus.REPORTABLE
        if scenario.reportable_evidence
        else ReportabilityStatus.COMPUTED_NOT_REPORTABLE
    )
    engine = Engine(
        EngineDependencies(
            clock=clock,
            model=model,
            task_taxonomy=InMemoryTaxonomy(
                TaskTaxonomySnapshot(
                    version=scenario.taxonomy_version, labels=scenario.task_labels
                )
            ),
            task_classifier=KeywordTaskClassifier(),
            job_taxonomy=InMemoryTaxonomy(
                JobTaxonomySnapshot(
                    version=scenario.taxonomy_version, labels=scenario.job_labels
                )
            ),
            job_segmenter=(
                KeywordJobSegmenter()
                if scenario.job_source is JobSource.KEYWORD_SEGMENTER
                else None
            ),
            evidence_resolver=_StandingEvidenceDecider(status),
            ids=SequentialIds(start=scenario.id_start),
        )
    )
    return _Ports(engine=engine, clock=clock, model=model)


def _payloads(scenario: Scenario) -> list[JsonValue]:
    return [json.loads(text) for text in scenario.host_stream]


def _pass_events(
    scenario: Scenario, adapter: HostAdapter
) -> tuple[tuple[ActivityEvent, ...], ...]:
    # ADR 0037 decision 4 steps 2 and 3: each cut re-runs the adapter over
    # its payload prefix, so a later pass sees every earlier event.
    payloads = _payloads(scenario)
    return tuple(
        tuple(adapter.normalize(payloads[:cut])) for cut in scenario.inference_cuts
    )


async def _infer(
    ports: _Ports,
    inputs: tuple[tuple[ActivityLog, TextExcerpt], ...],
    scope: DoubleCountingScope,
) -> tuple[_Pass, ...]:
    # ADR 0037 decision 4 step 6. Each subject's prior candidates are every
    # earlier candidate under its lineage root, across passes and subjects, in
    # the order the inferences ran (ADR 0021: the scope's full history). A
    # delegated subject therefore sees its root's head and attaches to it
    # with no port call (ADR 0018 decision 11).
    passes: list[_Pass] = []
    history: list[JobCandidate] = []
    for log, sample in inputs:
        lineage = fold_lineage(log)
        inferences: list[JobInference] = []
        for subject in _subjects(lineage):
            inference = await ports.engine.infer_jobs(
                JobInferenceRequest(
                    transcript_sample=sample,
                    subject=subject,
                    prior_candidates=tuple(
                        candidate
                        for candidate in history
                        if candidate.boundary.root == subject.root
                    ),
                    double_counting_scope=scope,
                    activity_log=log,
                )
            )
            inferences.append(inference)
            history.extend(inference.candidates)
        passes.append(_Pass(log, lineage, sample, tuple(inferences)))
    return tuple(passes)


def _replayed(events: tuple[ActivityEvent, ...]) -> tuple[ActivityEvent, ...]:
    # ADR 0037 decision 2, REPLAY_INVARIANT: every event twice, in reverse.
    return tuple(reversed(events + events))


async def _run(
    scenario: Scenario, adapter: HostAdapter, *, replay: bool = False
) -> _Run:
    ports = _ports(scenario)
    engine = ports.engine
    assessment_policy, contracts, metrics_policy = _preset(scenario)
    logs = tuple(
        normalize_stream(_replayed(events) if replay else events)
        for events in _pass_events(scenario, adapter)
    )
    passes = await _infer(
        ports,
        tuple((log, sample_transcript(_messages(log))) for log in logs),
        scenario.double_counting_scope,
    )

    final = passes[-1]
    messages = _messages(final.log)
    task_decision = await engine.classify_task(
        TaskClassificationRequest(
            user_message=_last(messages, "user"),
            assistant_response=_last(messages, "assistant"),
        )
    )
    current = _current(final)
    # ADR 0037 addendum item 1: a LINEAGE_ROOT attribution reuses its head's
    # job_id, so it is the head's job, not a second one. Valuing it would
    # repeat the head's assessment id and count the job twice.
    valued = tuple(
        candidate
        for candidate in current
        if candidate.attribution_basis is AttributionBasis.INFERRED
    )
    outcomes = [
        await engine.propose_outcome(
            OutcomeRequest(candidate=candidate, transcript_sample=final.sample)
        )
        for candidate in valued
    ]
    assessments = tuple(
        engine.assess_job(
            AssessJobRequest(
                candidate=candidate,
                proposal=outcome,
                sequence=0,
                evidence=ResolvedEvidence(confirmed=scenario.reportable_evidence),
            ),
            policy=assessment_policy,
        )
        for candidate, outcome in zip(valued, outcomes, strict=True)
    )
    effectives = tuple(resolve_effective(record, ()) for record in assessments)
    metrics = build_outcome_metrics_batch(
        effectives, contracts, clock=ports.clock, policy=metrics_policy
    )
    return _Run(
        passes=passes,
        task_decision=task_decision,
        current=current,
        outcomes=tuple(outcomes),
        assessments=assessments,
        effectives=effectives,
        metrics=metrics,
        model_calls=len(ports.model.requests),
    )


def _inference_bytes(passes: tuple[_Pass, ...]) -> tuple[bytes, ...]:
    return tuple(
        encode_record(inference) for one in passes for inference in one.inferences
    )


def _single_index(scenario: Scenario, expectation: ScenarioExpectation) -> int:
    # ADR 0037 decision 2: the expectation names one host_stream index, which
    # is neither the first nor the last payload of any pass that holds it.
    if len(expectation.values) != 1 or not expectation.values[0].isdecimal():
        raise ValueError(
            f"{expectation.kind.value} needs one decimal host_stream index, "
            f"got {expectation.values!r}"
        )
    index = int(expectation.values[0])
    if index >= len(scenario.host_stream):
        raise ValueError(
            f"{expectation.kind.value} index {index} is outside the host stream "
            f"of {len(scenario.host_stream)} payloads"
        )
    for cut in scenario.inference_cuts:
        if index < cut and index in {0, cut - 1}:
            raise ValueError(
                f"{expectation.kind.value} index {index} is the first or last "
                f"payload of the pass ending at {cut}"
            )
    return index


def _event_offsets(scenario: Scenario, adapter: HostAdapter) -> tuple[int, ...]:
    # offsets[k] is how many events payloads[:k] produce, so payload k made
    # the events at positions offsets[k] to offsets[k + 1] of any prefix.
    payloads = _payloads(scenario)
    return tuple(
        len(tuple(adapter.normalize(payloads[:end])))
        for end in range(len(payloads) + 1)
    )


def _job_count(run: _Run) -> tuple[str, ...]:
    return (str(len(run.current)),)


def _job_types(run: _Run) -> tuple[str, ...]:
    return tuple(candidate.type_assignment.job_type for candidate in run.current)


def _job_outcomes(run: _Run) -> tuple[str, ...]:
    return tuple(candidate.outcome.value for candidate in run.current)


def _attribution_bases(run: _Run) -> tuple[str, ...]:
    return tuple(candidate.attribution_basis.value for candidate in run.current)


def _delegation_modes(run: _Run) -> tuple[str, ...]:
    # ADR 0037 decision 2: each final-pass lineage entry with a parent.
    return tuple(
        entry.delegation_mode.value
        for entry in run.passes[-1].lineage.entries
        if entry.parent is not None
    )


def _session_origins(run: _Run) -> tuple[str, ...]:
    return tuple(entry.origin.value for entry in run.passes[-1].lineage.entries)


def _lineage_root_count(run: _Run) -> tuple[str, ...]:
    roots = {entry.root for entry in run.passes[-1].lineage.entries}
    return (str(len(roots)),)


def _dedupe_collision_count(run: _Run) -> tuple[str, ...]:
    return (str(run.passes[-1].log.collision_count),)


def _double_counting_group_count(run: _Run) -> tuple[str, ...]:
    groups = {
        candidate.double_counting_group
        for candidate in run.current
        if candidate.double_counting_group is not None
    }
    return (str(len(groups)),)


def _superseded_count(run: _Run) -> tuple[str, ...]:
    # ADR 0037 decision 2: every candidate over every pass and subject that
    # resolve_current over all of them drops.
    candidates = tuple(
        candidate
        for one in run.passes
        for inference in one.inferences
        for candidate in inference.candidates
    )
    return (str(len(candidates) - len(resolve_current(candidates))),)


def _task_decision(run: _Run) -> tuple[str, ...]:
    decision = run.task_decision
    if isinstance(decision, TaskClassification):
        return (decision.label,)
    return (f"{ABSTAINED_PREFIX}{decision.reason.value}",)


def _reportability(run: _Run) -> tuple[str, ...]:
    return tuple(record.reportability.value for record in run.assessments)


def _value_states(run: _Run) -> tuple[str, ...]:
    return tuple(record.roi.value_state.value for record in run.assessments)


def _metric_outcomes(run: _Run) -> tuple[str, ...]:
    return tuple(
        INTENTS if isinstance(result, OutcomeMetricIntents) else result.reason.value
        for result in run.metrics
    )


def _model_call_count(run: _Run) -> tuple[str, ...]:
    return (str(run.model_calls),)


def _from_run(extract: Callable[[_Run], tuple[str, ...]]) -> _Extractor:
    async def extractor(
        context: _Context, expectation: ScenarioExpectation
    ) -> tuple[str, ...]:
        del expectation
        return extract(context.run)

    return extractor


async def _invariant_without_event(
    context: _Context, expectation: ScenarioExpectation
) -> tuple[str, ...]:
    # ADR 0037 decision 2 (ENV-04, ADR 0018 decision 9): drop the events one
    # payload produced from each pass's log, keep each pass's transcript
    # sample, re-run inference with fresh fakes, and compare every
    # JobInference's bytes.
    scenario = context.scenario
    index = _single_index(scenario, expectation)
    offsets = _event_offsets(scenario, context.adapter)
    dropped = range(offsets[index], offsets[index + 1])
    inputs = tuple(
        (
            normalize_stream(
                event
                for position, event in enumerate(events)
                if position not in dropped
            ),
            one.sample,
        )
        for events, one in zip(
            _pass_events(scenario, context.adapter), context.run.passes, strict=True
        )
    )
    without = await _infer(_ports(scenario), inputs, scenario.double_counting_scope)
    same = _inference_bytes(without) == _inference_bytes(context.run.passes)
    return (UNCHANGED if same else CHANGED,)


async def _replay_invariant(
    context: _Context, expectation: ScenarioExpectation
) -> tuple[str, ...]:
    # ADR 0037 decision 2 (ENV-02): each pass's events duplicated and
    # reversed before normalize_stream must give the same ActivityLog bytes
    # for every pass and the same decision bytes.
    del expectation
    replayed = await _run(context.scenario, context.adapter, replay=True)
    same = _logs(replayed) == _logs(context.run) and _records(replayed) == _records(
        context.run
    )
    return (IDENTICAL if same else DIFFERENT,)


def _logs(run: _Run) -> tuple[bytes, ...]:
    return tuple(encode_record(one.log) for one in run.passes)


# ADR 0037 decision 2: one extractor per ExpectationKind member.
_EXTRACTORS: Final[Mapping[ExpectationKind, _Extractor]] = MappingProxyType(
    {
        ExpectationKind.JOB_COUNT: _from_run(_job_count),
        ExpectationKind.JOB_TYPES: _from_run(_job_types),
        ExpectationKind.JOB_OUTCOMES: _from_run(_job_outcomes),
        ExpectationKind.ATTRIBUTION_BASES: _from_run(_attribution_bases),
        ExpectationKind.SUPERSEDED_COUNT: _from_run(_superseded_count),
        ExpectationKind.TASK_DECISION: _from_run(_task_decision),
        ExpectationKind.SESSION_ORIGINS: _from_run(_session_origins),
        ExpectationKind.DELEGATION_MODES: _from_run(_delegation_modes),
        ExpectationKind.LINEAGE_ROOT_COUNT: _from_run(_lineage_root_count),
        ExpectationKind.DOUBLE_COUNTING_GROUP_COUNT: _from_run(
            _double_counting_group_count
        ),
        ExpectationKind.REPORTABILITY: _from_run(_reportability),
        ExpectationKind.VALUE_STATES: _from_run(_value_states),
        ExpectationKind.METRIC_OUTCOMES: _from_run(_metric_outcomes),
        ExpectationKind.MODEL_CALL_COUNT: _from_run(_model_call_count),
        ExpectationKind.INVARIANT_WITHOUT_EVENT: _invariant_without_event,
        ExpectationKind.REPLAY_INVARIANT: _replay_invariant,
        ExpectationKind.DEDUPE_COLLISION_COUNT: _from_run(_dedupe_collision_count),
    }
)

# ADR 0037 decision 2: the verdict's expected values for the kinds whose
# expectation carries an argument or nothing instead of the expected values.
_FIXED_EXPECTED: Final[Mapping[ExpectationKind, tuple[str, ...]]] = MappingProxyType(
    {
        ExpectationKind.INVARIANT_WITHOUT_EVENT: (UNCHANGED,),
        ExpectationKind.REPLAY_INVARIANT: (IDENTICAL,),
    }
)


async def _verdict(
    expectation: ScenarioExpectation, context: _Context
) -> ExpectationVerdict:
    actual = await _EXTRACTORS[expectation.kind](context, expectation)
    expected = _FIXED_EXPECTED.get(expectation.kind, expectation.values)
    return ExpectationVerdict(
        kind=expectation.kind,
        expected=expected,
        actual=actual,
        passed=expected == actual,
    )


def _records(run: _Run) -> tuple[str, ...]:
    # ADR 0037 decision 3: chain order.
    final = run.passes[-1]
    chain = (
        final.log,
        final.lineage,
        run.task_decision,
        *(inference for one in run.passes for inference in one.inferences),
        *run.outcomes,
        *run.assessments,
        *run.effectives,
        *run.metrics,
    )
    return tuple(encode_record(record).decode("ascii") for record in chain)


async def run_scenario(
    scenario: Scenario, *, adapter: HostAdapter | None = None
) -> ScenarioResult:
    """Run one scenario and return its verdicts (ADR 0037 decision 4).

    Every fake and the engine are built inside the call, so two calls with
    the same scenario return results with identical ``encode_record`` bytes.
    Expectations that re-run the pipeline, ``INVARIANT_WITHOUT_EVENT`` and
    ``REPLAY_INVARIANT``, build their own fresh fakes too.

    Args:
        scenario: The scenario to run.
        adapter: The host adapter for the scenario's stream. ``None`` picks
            the kit's synthetic adapter for ``scenario.host_shape``. It must
            map each payload prefix to a prefix of the full stream's events,
            as receipt-time adapters do.

    Returns:
        The canonical text of every decision record the run produced and one
        verdict per expectation.

    Raises:
        LookupError: If the scenario names a policy preset the runner does
            not know.
        ValueError: If an ``INVARIANT_WITHOUT_EVENT`` expectation does not
            name one interior ``host_stream`` index.
    """
    chosen = default_adapter(scenario) if adapter is None else adapter
    run = await _run(scenario, chosen)
    context = _Context(scenario=scenario, adapter=chosen, run=run)
    verdicts = tuple(
        [await _verdict(expectation, context) for expectation in scenario.expectations]
    )
    return ScenarioResult(
        scenario=scenario.name,
        host_shape=scenario.host_shape,
        records=_records(run),
        verdicts=verdicts,
        passed=all(verdict.passed for verdict in verdicts),
        library_version=__version__,
    )
