"""The operand gates, HoursTimesRate, the derived band, and the ceiling.

This is the trusted half of the trust boundary. An untrusted
:class:`~revenium_agent_economics.outcomes.OutcomeProposal` crosses into
money only through :func:`validate_proposal`, which applies Hermes'
``_validate_assessment`` gates in order (classifier.py:L2042-L2133,
ADR 0028 decision 1) and returns operands, never a total (VAL-03).

Gate comparisons use the finite ``float`` Hermes compares. Operands become
``Decimal`` through ``decimal_from_float`` only after every gate has passed,
and money is computed only with ``money_multiply`` and ``quantize_money``
under ``_MONEY_CONTEXT`` (ADR 0002). No builtin ``round``, ``min``, or
``max`` is used.
"""

import decimal
import enum
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from decimal import Decimal
from typing import ClassVar, Final, TypeAlias

from revenium_agent_economics._bounded import (
    IDENTIFIER_MAX_BYTES,
    IFS_CHARACTERS,
    NARRATIVE_CLAMP_BYTES,
    clamp_bytes,
    finite_number,
    is_bounded_printable,
    normalize_text,
    serialized_byte_length,
)
from revenium_agent_economics._canonical import JsonValue
from revenium_agent_economics.errors import ConfigurationError, RecordValidationError
from revenium_agent_economics.outcomes import (
    BandShape,
    OperandBounds,
    OperandKind,
    OutcomeProposal,
    ProposedOperand,
)
from revenium_agent_economics.primitives import (
    _MONEY_CONTEXT,
    Confidence,
    Money,
    _require_exact_type,
    decimal_from_float,
    money_multiply,
    quantize_money,
)
from revenium_agent_economics.protocols import (
    INFERRED_ROLE_MAX_BYTES,
    ComponentDeclaration,
    ResolvedAssumptions,
)
from revenium_agent_economics.vocab import (
    CLAIM_BASIS_STRENGTH,
    EVALUATOR_MECHANISMS,
    AssessmentRefusal,
    ClaimBasis,
    Currency,
    EconomicMechanism,
    EvidenceClass,
)

_ONE: Final = Decimal(1)
_ZERO: Final = Decimal(0)
_EVALUATOR_MECHANISM_VALUES: Final[frozenset[str]] = frozenset(
    mechanism.value for mechanism in EVALUATOR_MECHANISMS
)
# Hermes _clamp_assessment_text(registrant basis, 200) (classifier.py:L2447).
POLICY_BASIS_MAX_BYTES: Final[int] = 200


class ValuationMethod(enum.Enum):
    """The method that priced an assessment (ADR 0028 decisions 3 and 4).

    Library code sets it on every :class:`ValuationResult` and every
    ``JobAssessment`` as ``produced_by``; a policy never sets it.
    """

    HOURS_TIMES_RATE = "hours_times_rate"
    RATE_CARD = "rate_card"
    REVENUE_CARD = "revenue_card"
    BASELINES = "baselines"
    INJECTED = "injected"


class PolicyErrorMode(enum.Enum):
    """What a raising injected valuation policy produces (ADR 0028 decision 6).

    STRICT, the default, gives an ``AssessmentAbstention`` with refusal
    VALUATION_POLICY_FAILED. FALLBACK_HOURS_TIMES_RATE reproduces Hermes'
    fallback (classifier.py:L2184-L2196) and prices HoursTimesRate instead.
    """

    STRICT = "strict"
    FALLBACK_HOURS_TIMES_RATE = "fallback_hours_times_rate"


class ValuationOperand(enum.Enum):
    """One operand that produced an amount, keyed to its claim basis (ADR 0024).

    The declaration order is the order operand bases are recorded in.
    """

    HOURS = "hours"
    RATE = "rate"
    ROLE_SELECTION = "role_selection"
    CARD_AMOUNT = "card_amount"
    GROSS = "gross"
    ATTRIBUTION_SHARE = "attribution_share"
    CARD_KEY = "card_key"
    BASELINE_RATE = "baseline_rate"
    BASELINE_MINUTES = "baseline_minutes"
    QUANTITY = "quantity"
    UNIT_VALUE = "unit_value"


_OPERAND_ORDER: Final[tuple[ValuationOperand, ...]] = tuple(ValuationOperand)
OperandBases: TypeAlias = tuple[tuple[ValuationOperand, ClaimBasis], ...]


@dataclass(frozen=True, slots=True, kw_only=True)
class ValuationResult:
    """What a valuation produced, before the lower bound and the ceiling.

    An internal result with no schema id. ``produced_by`` is set by library
    code, never by a policy (ADR 0028 decision 4).

    Attributes:
        amount: The quantized amount in the policy currency, or ``None`` when
            the product cannot be quantized as money (VALUATION_AMOUNT_INVALID).
        produced_by: The method that produced ``amount``.
        operand_bases: The claim basis of each operand behind ``amount``, in
            :class:`ValuationOperand` declaration order.
        declared_mechanism: The operator-only mechanism the policy asserted
            and its construction-checked declaration allows, if any.
        basis: The policy's basis sentence, kept only with a declared
            mechanism, normalized to 200 serialized bytes.
        attribution: The accepted ``(fraction, basis)`` pair, if any.
    """

    amount: Money | None
    produced_by: ValuationMethod
    operand_bases: OperandBases
    declared_mechanism: EconomicMechanism | None = None
    basis: str | None = None
    attribution: tuple[Decimal, str] | None = None


@dataclass(frozen=True, slots=True, kw_only=True)
class DerivedBand:
    """A named, versioned spread for the derived value band (ADR 0027).

    Attributes:
        spread: An exact, finite ``Decimal`` with ``0 <= spread < 1``.
        version: The band version, an exact ``int`` of at least 1.
    """

    SCHEMA_ID: ClassVar[str] = "rae.derived_band"
    SCHEMA_VERSION: ClassVar[int] = 1

    spread: Decimal
    version: int

    def __post_init__(self) -> None:
        """Validate the spread and the version.

        Raises:
            RecordValidationError: If ``spread`` is not an exact finite
                ``Decimal`` in ``[0, 1)`` or ``version`` is not an exact
                ``int`` of at least 1.
        """
        schema_id = DerivedBand.SCHEMA_ID
        _require_exact_type(self.spread, Decimal, schema_id, "spread")
        if not self.spread.is_finite() or not _ZERO <= self.spread < _ONE:
            raise RecordValidationError(
                schema_id,
                "spread",
                f"must be finite and satisfy 0 <= spread < 1, got {self.spread!r}",
            )
        _require_exact_type(self.version, int, schema_id, "version")
        if self.version < 1:
            raise RecordValidationError(
                schema_id, "version", f"must be at least 1, got {self.version!r}"
            )


# Hermes DERIVED_BOUND_SPREAD = 0.15 (classifier.py:L1936).
DEFAULT_DERIVED_BAND: Final[DerivedBand] = DerivedBand(
    spread=Decimal("0.15"), version=1
)


def weakest_claim_basis(bases: Iterable[ClaimBasis]) -> ClaimBasis:
    """Return the weakest basis in ``CLAIM_BASIS_STRENGTH`` order (ADR 0024).

    Args:
        bases: The bases that produced an amount.

    Returns:
        The member with the lowest strength index.

    Raises:
        RecordValidationError: If ``bases`` is empty or holds anything that is
            not exactly a ``ClaimBasis``, an ``EvidenceClass`` member included.
    """
    weakest: int | None = None
    for index, basis in enumerate(bases):
        if type(basis) is not ClaimBasis:
            raise RecordValidationError(
                "rae.claim_basis",
                "bases",
                f"element {index} must be ClaimBasis, got {type(basis).__name__}",
            )
        strength = CLAIM_BASIS_STRENGTH.index(basis)
        if weakest is None or strength < weakest:
            weakest = strength
    if weakest is None:
        raise RecordValidationError("rae.claim_basis", "bases", "must not be empty")
    return CLAIM_BASIS_STRENGTH[weakest]


@dataclass(frozen=True, slots=True)
class MechanismAbstains:
    """The proposal named ``newly_enabled_work``, which is never priced.

    Hermes handles it before the gates (``_attach_assessment``,
    classifier.py:L4831-L4844), so the assessment abstains with
    MECHANISM_ABSTAINS_FROM_VALUE and keeps the mechanism and narratives.
    """


def _text(operand: ProposedOperand) -> str | None:
    # Hermes strips both text gates itself (L1781 and L2107). The parser
    # already stores TEXT stripped, but a hand-built or decoded operand need
    # not be, so the gate strips again; stripping twice changes nothing.
    value = operand.value
    if operand.kind is OperandKind.TEXT and type(value) is str:
        return value.strip()
    return None


def _number(operand: ProposedOperand) -> float | None:
    if operand.kind is not OperandKind.NUMBER:
        return None
    return finite_number(operand.value)


def validate_proposal(
    proposal: OutcomeProposal, *, bounds: OperandBounds, currency: Currency
) -> ResolvedAssumptions | MechanismAbstains | AssessmentRefusal:
    """Gate an untrusted proposal in Hermes order (ADR 0028 decision 1).

    ``newly_enabled_work`` is recognized first. Gates 2 to 8 then run in
    ``_validate_assessment`` order (classifier.py:L2042-L2115), and the first
    failing gate is returned. Gate 1, NOT_AN_OBJECT, is already decided at
    parse time and never reaches here.

    Args:
        proposal: The evaluator's untrusted answer.
        bounds: The caller's operand ceilings.
        currency: The policy currency.

    Returns:
        The gated operands, the newly-enabled-work marker, or the refusal of
        the first failing gate.

    Raises:
        RecordValidationError: If ``proposal`` or ``bounds`` is not exactly
            the expected record type, or ``currency`` is not a ``Currency``.
    """
    _require_exact_type(proposal, OutcomeProposal, "rae.outcome_proposal", "$")
    _require_exact_type(bounds, OperandBounds, OperandBounds.SCHEMA_ID, "$")
    _require_exact_type(currency, Currency, "rae.currency", "$")
    # Hermes _resolve_economic_mechanism (L1748-L1784): a str, stripped, with
    # no case-folding.
    mechanism = _text(proposal.economic_mechanism)
    if mechanism == EconomicMechanism.NEWLY_ENABLED_WORK.value:
        return MechanismAbstains()
    if mechanism not in _EVALUATOR_MECHANISM_VALUES:
        return AssessmentRefusal.MECHANISM_NOT_ALLOWED
    hours = _number(proposal.estimated_hours_saved)
    rate = _number(proposal.assumed_loaded_rate)
    if hours is None or rate is None:
        return AssessmentRefusal.OPERAND_NOT_NUMERIC
    max_hours = finite_number(bounds.max_hours_saved)
    max_rate = finite_number(bounds.max_loaded_rate)
    if (
        max_hours is None
        or max_rate is None
        or not 0 < hours <= max_hours
        or not 0 < rate <= max_rate
    ):
        return AssessmentRefusal.OPERAND_OUT_OF_BOUNDS
    confidence = _number(proposal.confidence)
    if confidence is None or not 0.0 <= confidence <= 1.0:
        return AssessmentRefusal.CONFIDENCE_INVALID
    if proposal.band_shape is BandShape.REFUSED:
        return AssessmentRefusal.VALUE_BAND_INVALID
    currency_text = _text(proposal.currency)
    if currency_text is None:
        return AssessmentRefusal.CURRENCY_NOT_TEXT
    if currency_text.upper() != currency.value:
        return AssessmentRefusal.CURRENCY_MISMATCH
    return ResolvedAssumptions(
        job_type=proposal.job_type,
        economic_mechanism=EconomicMechanism(mechanism),
        estimated_hours_saved=decimal_from_float(hours),
        assumed_loaded_rate=decimal_from_float(rate),
        currency=currency,
        inferred_role=clamp_bytes(
            proposal.inferred_role, max_bytes=INFERRED_ROLE_MAX_BYTES
        ),
        hours_basis=ClaimBasis.ESTIMATED,
        rate_basis=ClaimBasis.ESTIMATED,
    )


def _accepted_confidence(proposal: OutcomeProposal) -> Confidence:
    # Gate 5 already passed, so the operand is a NUMBER in [0, 1].
    value = _number(proposal.confidence)
    if value is None:
        raise RecordValidationError(
            Confidence.SCHEMA_ID, "value", "the confidence gate did not pass"
        )
    return Confidence(value=value)


def hours_times_rate(assumptions: ResolvedAssumptions) -> Money | None:
    """Price the gated hours and rate (HoursTimesRate, D-05).

    Hermes ``round(hours * rate, 2)`` (classifier.py:L2184-L2196), computed as
    ``quantize_money(money_multiply(hours, rate))``.

    Args:
        assumptions: The gated operands.

    Returns:
        The quantized amount, or ``None`` when the product cannot be
        quantized as money within ``_MONEY_CONTEXT``.
    """
    try:
        amount = quantize_money(
            money_multiply(
                assumptions.estimated_hours_saved, assumptions.assumed_loaded_rate
            ),
            assumptions.currency,
        )
    except (decimal.InvalidOperation, decimal.Overflow):
        return None
    return Money(amount=amount, currency=assumptions.currency)


def hours_times_rate_result(assumptions: ResolvedAssumptions) -> ValuationResult:
    """Return the HoursTimesRate result for the gated operands (D-05).

    Args:
        assumptions: The gated operands.

    Returns:
        A result produced by HOURS_TIMES_RATE whose operand bases are the
        hours and rate bases of ``assumptions``.
    """
    return ValuationResult(
        amount=hours_times_rate(assumptions),
        produced_by=ValuationMethod.HOURS_TIMES_RATE,
        operand_bases=(
            (ValuationOperand.HOURS, assumptions.hours_basis),
            (ValuationOperand.RATE, assumptions.rate_basis),
        ),
    )


def _policy_operand(output: dict[str, JsonValue], key: str) -> Decimal | None:
    # ADR 0028 decision 5: gated like an operand. finite_number refuses bool,
    # NaN, infinity, and an int too large for float; the exact-type check
    # refuses number subclasses, whose conversions a policy could override.
    raw = output.get(key)
    if type(raw) is not int and type(raw) is not float:
        return None
    number = finite_number(raw)
    if number is None or number <= 0:
        return None
    return decimal_from_float(number)


def _declared_mechanism(
    output: dict[str, JsonValue], declaration: ComponentDeclaration
) -> EconomicMechanism | None:
    # Hermes L2210-L2226: only a str in the policy's own declared set counts;
    # anything else is discarded silently, never refused.
    raw = output.get("economic_mechanism")
    if type(raw) is not str:
        return None
    for mechanism in declaration.declared_mechanisms:
        if mechanism.value == raw:
            return mechanism
    return None


def _policy_attribution(output: dict[str, JsonValue]) -> tuple[Decimal, str] | None:
    # Hermes L2485-L2526: kept only as a valid pair, otherwise dropped
    # silently. The fraction is finite and in [0, 1]; the basis is non-blank
    # after stripping and is normalized to 500 serialized bytes.
    raw_fraction = output.get("attribution_fraction")
    raw_basis = output.get("attribution_basis")
    if type(raw_fraction) is not int and type(raw_fraction) is not float:
        return None
    fraction = finite_number(raw_fraction)
    if fraction is None or not 0.0 <= fraction <= 1.0:
        return None
    if type(raw_basis) is not str or raw_basis.strip() == "":
        return None
    return (
        decimal_from_float(fraction),
        normalize_text(raw_basis, max_bytes=NARRATIVE_CLAMP_BYTES),
    )


def parse_policy_output(
    value: JsonValue | None,
    *,
    declaration: ComponentDeclaration,
    currency: Currency,
    attribution_certain: bool,
) -> ValuationResult | AssessmentRefusal:
    """Read an injected policy's untrusted output as operands (ADR 0028).

    The checks run in Hermes' re-check order (classifier.py:L2210-L2381):
    shape, declared mechanism, the attribution fence, the operands, the
    amount, then the currency. The lower bound and the ceiling are the
    caller's, through :func:`check_valuation_amount`. Keys named
    ``estimated_value`` or ``total`` are never read, so a policy can never
    hand the library a total (VAL-03).

    Args:
        value: What the policy returned.
        declaration: The engine's stored, construction-checked declaration.
        currency: The policy currency.
        attribution_certain: The request's assertion that a declared
            operator mechanism belongs to this job (ADR 0028 decision 3).

    Returns:
        The result, produced by INJECTED with UNVERIFIED operand bases, or the
        refusal: VALUATION_DECLINED for ``None``, VALUATION_POLICY_FAILED for
        a value that is not a ``dict`` or a missing or malformed ``quantity``
        or ``unit_value``, REVENUE_ATTRIBUTION_UNCERTAIN for an accepted
        declared mechanism without attribution certainty, and
        VALUATION_CURRENCY_MISMATCH for an absent ``currency`` or one that is
        not exactly the policy currency code. ``currency`` is required.

    Raises:
        RecordValidationError: If ``declaration`` is not a
            ``ComponentDeclaration``, ``currency`` is not a ``Currency``, or
            ``attribution_certain`` is not exactly a ``bool``.
    """
    _require_exact_type(declaration, ComponentDeclaration, "rae.valuation", "$")
    _require_exact_type(currency, Currency, "rae.currency", "$")
    _require_exact_type(
        attribution_certain, bool, "rae.valuation", "attribution_certain"
    )
    if value is None:
        return AssessmentRefusal.VALUATION_DECLINED
    if type(value) is not dict:
        return AssessmentRefusal.VALUATION_POLICY_FAILED
    mechanism = _declared_mechanism(value, declaration)
    if mechanism is not None and not attribution_certain:
        return AssessmentRefusal.REVENUE_ATTRIBUTION_UNCERTAIN
    quantity = _policy_operand(value, "quantity")
    unit_value = _policy_operand(value, "unit_value")
    if quantity is None or unit_value is None:
        return AssessmentRefusal.VALUATION_POLICY_FAILED
    amount: Money | None
    try:
        amount = Money(
            amount=quantize_money(money_multiply(quantity, unit_value), currency),
            currency=currency,
        )
    except (decimal.InvalidOperation, decimal.Overflow):
        amount = None
    # Hermes compares `returned_currency != currency` with no strip or
    # case-folding (L2372), after the amount check.
    returned_currency = value.get("currency")
    if amount is not None and (
        type(returned_currency) is not str or returned_currency != currency.value
    ):
        return AssessmentRefusal.VALUATION_CURRENCY_MISMATCH
    basis: str | None = None
    attribution: tuple[Decimal, str] | None = None
    if mechanism is not None:
        # Hermes L2441-L2447 and L2485-L2526: both are operator caveats, kept
        # only beside an accepted declared mechanism.
        raw_basis = value.get("basis")
        if type(raw_basis) is str and raw_basis.strip():
            basis = normalize_text(raw_basis, max_bytes=POLICY_BASIS_MAX_BYTES)
        attribution = _policy_attribution(value)
    return ValuationResult(
        amount=amount,
        produced_by=ValuationMethod.INJECTED,
        operand_bases=(
            (ValuationOperand.QUANTITY, ClaimBasis.UNVERIFIED),
            (ValuationOperand.UNIT_VALUE, ClaimBasis.UNVERIFIED),
        ),
        declared_mechanism=mechanism,
        basis=basis,
        attribution=attribution,
    )


def require_operand_bases(bases: object, schema_id: str, field_name: str) -> None:
    """Check a recorded operand-bases tuple (ADR 0024 decision 4).

    Args:
        bases: The value to check.
        schema_id: The schema id to name in an error.
        field_name: The field name to name in an error.

    Raises:
        RecordValidationError: If ``bases`` is not a non-empty tuple of
            ``(ValuationOperand, ClaimBasis)`` pairs in strictly increasing
            :class:`ValuationOperand` declaration order.
    """
    if type(bases) is not tuple or not bases:
        raise RecordValidationError(
            schema_id, field_name, "must be a non-empty tuple of operand bases"
        )
    previous = -1
    for index, pair in enumerate(bases):
        if (
            type(pair) is not tuple
            or len(pair) != 2
            or type(pair[0]) is not ValuationOperand
            or type(pair[1]) is not ClaimBasis
        ):
            raise RecordValidationError(
                schema_id,
                field_name,
                f"element {index} must be a (ValuationOperand, ClaimBasis) pair",
            )
        position = _OPERAND_ORDER.index(pair[0])
        if position <= previous:
            raise RecordValidationError(
                schema_id,
                field_name,
                "operands must be unique and in ValuationOperand order",
            )
        previous = position


def active_ceiling(bounds: OperandBounds, currency: Currency) -> Money:
    """Return the HoursTimesRate ceiling (ADR 0027 decision 4).

    Hermes ``round(max_hours * max_rate, 2)`` (classifier.py:L2328-L2337).

    Args:
        bounds: The caller's operand ceilings.
        currency: The policy currency.

    Returns:
        ``quantize_money`` of the product of the two maxima.

    Raises:
        decimal.InvalidOperation: If the product cannot be quantized as
            money. ``AssessmentPolicy`` refuses such bounds at construction.
    """
    amount = quantize_money(
        money_multiply(
            decimal_from_float(bounds.max_hours_saved),
            decimal_from_float(bounds.max_loaded_rate),
        ),
        currency,
    )
    return Money(amount=amount, currency=currency)


def check_valuation_amount(
    amount: Money | None,
    *,
    currency: Currency,
    ceiling: Money,
    inclusive_zero: bool,
) -> AssessmentRefusal | None:
    """Check an amount in Hermes' gate-10 order (classifier.py:L2364-L2381).

    Args:
        amount: The amount a valuation produced, or ``None`` when it could not
            be quantized.
        currency: The policy currency.
        ceiling: The active ceiling.
        inclusive_zero: Whether 0 is accepted (HoursTimesRate's ``>= 0``) or
            refused (every other producer's ``> 0``).

    Returns:
        The first failing check, or ``None`` when the amount is accepted.
    """
    if amount is None:
        return AssessmentRefusal.VALUATION_AMOUNT_INVALID
    if amount.currency is not currency:
        return AssessmentRefusal.VALUATION_CURRENCY_MISMATCH
    value = amount.amount
    if value < 0 or (value == 0 and not inclusive_zero):
        return AssessmentRefusal.VALUATION_BELOW_LOWER_BOUND
    if value > ceiling.amount:
        return AssessmentRefusal.VALUATION_ABOVE_CEILING
    return None


def derive_band(
    base: Decimal, band: DerivedBand, currency: Currency
) -> tuple[Decimal, Decimal]:
    """Return the derived ``(low, high)`` band around ``base`` (ADR 0027).

    Hermes L2008-L2012 without the ``max(0.0, ...)``: with
    ``0 <= spread < 1`` and ``base >= 0`` the low end is already at least 0.

    Args:
        base: The accepted, quantized amount.
        band: The spread and version.
        currency: The currency whose minor unit sets the exponent.

    Returns:
        The quantized low and high ends.
    """
    low = quantize_money(
        money_multiply(base, _MONEY_CONTEXT.subtract(_ONE, band.spread)), currency
    )
    high = quantize_money(
        money_multiply(base, _MONEY_CONTEXT.add(_ONE, band.spread)), currency
    )
    return low, high


# --- The built-in valuations (ADR 0028 decisions 3 and 4) -------------------

# Hermes _REVENUE_CARD_BASIS_PREFIX (valuation.py:L553).
REVENUE_CARD_BASIS_PREFIX: Final[str] = (
    "revenue card: an approved value per completed booking, not this "
    "booking's actual revenue"
)
# Hermes registers both fixtures as CUSTOMER_CONFIGURED at version "1"
# (valuation.py:L445-L450 and L944-L950). They vote only when they produced
# the value (ADR 0025 decision 1).
BUILTIN_RATE_CARD: Final[ComponentDeclaration] = ComponentDeclaration(
    name="rate_card_valuation_fixture",
    version="1",
    evidence_class=EvidenceClass.CUSTOMER_CONFIGURED,
)
BUILTIN_REVENUE_CARD: Final[ComponentDeclaration] = ComponentDeclaration(
    name="revenue_card_valuation_fixture",
    version="1",
    evidence_class=EvidenceClass.CUSTOMER_CONFIGURED,
    declared_mechanisms=(EconomicMechanism.INCREMENTAL_REVENUE,),
)
_SIXTY: Final = Decimal(60)


def _require_positive_decimal(value: object, schema_id: str, field_name: str) -> None:
    _require_exact_type(value, Decimal, schema_id, field_name)
    if not isinstance(value, Decimal) or not value.is_finite() or value <= 0:
        raise RecordValidationError(
            schema_id, field_name, f"must be a finite Decimal above 0, got {value!r}"
        )


def _is_role_text(value: object) -> bool:
    # The shape of ResolvedAssumptions.inferred_role: a longer or
    # unnormalized key could never equal the clamped role, so it is refused.
    return (
        type(value) is str
        and not any(character in value for character in IFS_CHARACTERS)
        and value == value.lstrip()
        and serialized_byte_length(value) <= INFERRED_ROLE_MAX_BYTES
    )


def _is_card_key(value: object) -> bool:
    return type(value) is str and is_bounded_printable(value, IDENTIFIER_MAX_BYTES)


def _require_sorted_unique(keys: list[str], schema_id: str, field_name: str) -> None:
    for index in range(1, len(keys)):
        if not keys[index - 1] < keys[index]:
            raise RecordValidationError(
                schema_id, field_name, "keys must be unique and sorted"
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class RateCardFigures:
    """An operator's flat amount per inferred role (ADR 0028 decision 3).

    Hermes ``llmOutcomeEvaluation.rateCard`` (valuation.py:L365-L437).

    Attributes:
        amounts: ``(role, amount)`` pairs sorted by role, roles unique. A role
            has the shape of ``ResolvedAssumptions.inferred_role``: no IFS
            characters, no leading whitespace, at most 60 serialized bytes.
            An amount is a finite ``Decimal`` above 0.
    """

    SCHEMA_ID: ClassVar[str] = "rae.rate_card_figures"
    SCHEMA_VERSION: ClassVar[int] = 1

    amounts: tuple[tuple[str, Decimal], ...]

    def __post_init__(self) -> None:
        """Validate every role and amount and the role order.

        Raises:
            RecordValidationError: If ``amounts`` is not a tuple of
                ``(role, amount)`` pairs, a role is malformed, an amount is
                not a finite ``Decimal`` above 0, or the roles are not unique
                and sorted.
        """
        schema_id = RateCardFigures.SCHEMA_ID
        _require_exact_type(self.amounts, tuple, schema_id, "amounts")
        roles: list[str] = []
        items: tuple[object, ...] = self.amounts
        for index, pair in enumerate(items):
            if type(pair) is not tuple or len(pair) != 2 or not _is_role_text(pair[0]):
                raise RecordValidationError(
                    schema_id,
                    "amounts",
                    f"element {index} must be a (role, amount) pair whose role is "
                    "normalized text of at most "
                    f"{INFERRED_ROLE_MAX_BYTES} serialized bytes",
                )
            _require_positive_decimal(pair[1], schema_id, "amounts")
            roles.append(pair[0])
        _require_sorted_unique(roles, schema_id, "amounts")

    @classmethod
    def from_numbers(cls, amounts: Mapping[str, int | float]) -> "RateCardFigures":
        """Build a card from host numbers, each converted through its ``repr``.

        Args:
            amounts: Role to amount.

        Returns:
            The card, sorted by role.

        Raises:
            RecordValidationError: For a ``bool``, a non-finite amount, an
                amount of 0 or less, or a malformed role.
        """
        return cls(
            amounts=tuple(
                (role, decimal_from_float(amounts[role])) for role in sorted(amounts)
            )
        )

    def amount_for(self, role: str) -> Decimal | None:
        """Return the amount configured for ``role``, or ``None``."""
        for configured, amount in self.amounts:
            if configured == role:
                return amount
        return None


def _is_normalized_basis(value: object) -> bool:
    # The shape normalize_text produces, and non-blank.
    return (
        type(value) is str
        and value.strip() != ""
        and not any(character in value for character in IFS_CHARACTERS)
        and value == value.lstrip()
        and serialized_byte_length(value) <= NARRATIVE_CLAMP_BYTES
    )


@dataclass(frozen=True, slots=True, kw_only=True)
class RevenueCardEntry:
    """One revenue card row (Hermes ``revenueCard[key]``, valuation.py:L687).

    Attributes:
        gross_per_job: The approved value per completed job, a finite
            ``Decimal`` above 0.
        attribution_fraction: The share attributed to the agent, a finite
            ``Decimal`` in [0, 1], or ``None``.
        attribution_basis: Why that share, non-blank normalized text of at
            most 500 serialized bytes. Set exactly when
            ``attribution_fraction`` is.
    """

    SCHEMA_ID: ClassVar[str] = "rae.revenue_card_entry"
    SCHEMA_VERSION: ClassVar[int] = 1

    gross_per_job: Decimal
    attribution_fraction: Decimal | None = None
    attribution_basis: str | None = None

    def __post_init__(self) -> None:
        """Validate the gross and the attribution pair.

        Raises:
            RecordValidationError: If the gross is not a finite ``Decimal``
                above 0, the fraction is outside [0, 1], the basis is blank or
                not normalized, or only one of the pair is set.
        """
        schema_id = RevenueCardEntry.SCHEMA_ID
        _require_positive_decimal(self.gross_per_job, schema_id, "gross_per_job")
        fraction = self.attribution_fraction
        basis = self.attribution_basis
        if (fraction is None) != (basis is None):
            raise RecordValidationError(
                schema_id,
                "attribution_fraction",
                "the attribution fraction and basis are both set or both None",
            )
        if fraction is None:
            return
        _require_exact_type(fraction, Decimal, schema_id, "attribution_fraction")
        if not fraction.is_finite() or not _ZERO <= fraction <= _ONE:
            raise RecordValidationError(
                schema_id,
                "attribution_fraction",
                f"must be finite and in [0, 1], got {fraction!r}",
            )
        if not _is_normalized_basis(basis):
            raise RecordValidationError(
                schema_id,
                "attribution_basis",
                "must be non-blank normalized text of at most "
                f"{NARRATIVE_CLAMP_BYTES} serialized bytes",
            )

    @classmethod
    def from_numbers(
        cls,
        gross_per_job: int | float,
        *,
        attribution_fraction: int | float | None = None,
        attribution_basis: str | None = None,
    ) -> "RevenueCardEntry":
        """Build a row from host numbers, each converted through its ``repr``.

        Args:
            gross_per_job: The approved value per completed job.
            attribution_fraction: The attributed share, if any.
            attribution_basis: Why that share; required with a fraction.

        Returns:
            The row. The basis is kept as given, so it must already be
            normalized.

        Raises:
            RecordValidationError: For a ``bool`` or non-finite number, or
                any value the constructor refuses.
        """
        return cls(
            gross_per_job=decimal_from_float(gross_per_job),
            attribution_fraction=(
                None
                if attribution_fraction is None
                else decimal_from_float(attribution_fraction)
            ),
            attribution_basis=attribution_basis,
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class RevenueCardFigures:
    """An operator's revenue card and the key that selects a row.

    Hermes ``revenueCard`` and ``revenueCardKey`` (valuation.py:L687-L933).
    The key is operator-bound and never the model's role.

    Attributes:
        key: The configured card key, or ``None``. Non-empty printable text
            of at most 128 serialized bytes.
        entries: ``(key, row)`` pairs sorted by key, keys unique and shaped
            like ``key``. A row of ``None`` records a configured row that
            cannot be read (Hermes' ``malformed_entry``, ``malformed_gross``,
            and ``malformed_attribution``); selecting it is
            VALUATION_DECLINED, never a delegation.
    """

    SCHEMA_ID: ClassVar[str] = "rae.revenue_card_figures"
    SCHEMA_VERSION: ClassVar[int] = 1

    key: str | None = None
    entries: tuple[tuple[str, RevenueCardEntry | None], ...] = ()

    def __post_init__(self) -> None:
        """Validate the key, the rows, and the key order.

        Raises:
            RecordValidationError: If the key or a row key is not printable
                text of 1 to 128 serialized bytes, a row is not a
                ``RevenueCardEntry`` or ``None``, or the row keys are not
                unique and sorted.
        """
        schema_id = RevenueCardFigures.SCHEMA_ID
        if self.key is not None and not _is_card_key(self.key):
            raise RecordValidationError(
                schema_id,
                "key",
                "must be printable text of 1 to "
                f"{IDENTIFIER_MAX_BYTES} serialized bytes",
            )
        _require_exact_type(self.entries, tuple, schema_id, "entries")
        keys: list[str] = []
        items: tuple[object, ...] = self.entries
        for index, pair in enumerate(items):
            if (
                type(pair) is not tuple
                or len(pair) != 2
                or not _is_card_key(pair[0])
                or (pair[1] is not None and type(pair[1]) is not RevenueCardEntry)
            ):
                raise RecordValidationError(
                    schema_id,
                    "entries",
                    f"element {index} must be a (key, RevenueCardEntry | None) "
                    "pair with a printable key of 1 to "
                    f"{IDENTIFIER_MAX_BYTES} serialized bytes",
                )
            keys.append(pair[0])
        _require_sorted_unique(keys, schema_id, "entries")

    @classmethod
    def from_mapping(
        cls, key: str | None, entries: Mapping[str, RevenueCardEntry | None]
    ) -> "RevenueCardFigures":
        """Build a card from a mapping of rows.

        Args:
            key: The configured card key, or ``None``.
            entries: Card key to row, or to ``None`` for an unreadable row.

        Returns:
            The card, sorted by key.

        Raises:
            RecordValidationError: For any value the constructor refuses.
        """
        return cls(
            key=key, entries=tuple((name, entries[name]) for name in sorted(entries))
        )

    def selected(self) -> tuple[bool, RevenueCardEntry | None]:
        """Return whether ``key`` names a row, and that row.

        Returns:
            ``(False, None)`` when the key is ``None`` or names no row,
            otherwise ``(True, row)``, where ``row`` may be ``None``.
        """
        for name, entry in self.entries:
            if name == self.key:
                return True, entry
        return False, None


@dataclass(frozen=True, slots=True, kw_only=True)
class BaselineFigures:
    """A host-fetched baseline (Hermes ``source_figures``, valuation.py:L999).

    Attributes:
        hourly_rate: Hermes ``hourlyRate``, a finite ``Decimal`` above 0.
        minutes_per_unit: Hermes ``minutesPerUnit``, a finite ``Decimal``
            above 0.
    """

    SCHEMA_ID: ClassVar[str] = "rae.baseline_figures"
    SCHEMA_VERSION: ClassVar[int] = 1

    hourly_rate: Decimal
    minutes_per_unit: Decimal

    def __post_init__(self) -> None:
        """Validate both figures.

        Raises:
            RecordValidationError: If a figure is not a finite ``Decimal``
                above 0.
        """
        schema_id = BaselineFigures.SCHEMA_ID
        _require_positive_decimal(self.hourly_rate, schema_id, "hourly_rate")
        _require_positive_decimal(self.minutes_per_unit, schema_id, "minutes_per_unit")

    @classmethod
    def from_numbers(
        cls, *, hourly_rate: int | float, minutes_per_unit: int | float
    ) -> "BaselineFigures":
        """Build a baseline from host numbers, converted through their ``repr``.

        Args:
            hourly_rate: The hourly rate.
            minutes_per_unit: The minutes one unit of work takes.

        Returns:
            The baseline.

        Raises:
            RecordValidationError: For a ``bool``, a non-finite value, or a
                value of 0 or less.
        """
        return cls(
            hourly_rate=decimal_from_float(hourly_rate),
            minutes_per_unit=decimal_from_float(minutes_per_unit),
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class ValuationFigures:
    """The caller-resolved figures the built-ins price from (D-01).

    Attributes:
        rate_card: The rate card, if configured.
        revenue_card: The revenue card, if configured.
        baselines: The fetched baseline, if any.
    """

    SCHEMA_ID: ClassVar[str] = "rae.valuation_figures"
    SCHEMA_VERSION: ClassVar[int] = 1

    rate_card: RateCardFigures | None = None
    revenue_card: RevenueCardFigures | None = None
    baselines: BaselineFigures | None = None

    def __post_init__(self) -> None:
        """Validate that each figure is exactly its record type or ``None``.

        Raises:
            RecordValidationError: If a field has another type.
        """
        schema_id = ValuationFigures.SCHEMA_ID
        for name, expected in (
            ("rate_card", RateCardFigures),
            ("revenue_card", RevenueCardFigures),
            ("baselines", BaselineFigures),
        ):
            value = getattr(self, name)
            if value is not None:
                _require_exact_type(value, expected, schema_id, name)


@dataclass(frozen=True, slots=True, kw_only=True)
class FallbackPolicy:
    """A built-in method and the method that runs when it delegates.

    ADR 0028 decision 4. RevenueCard delegates when it has nothing to price
    and Baselines when it has no figures; RateCard and HoursTimesRate never
    delegate. Library code sets ``produced_by`` to the method that actually
    produced the value. Configuration, not a schema record.

    Attributes:
        primary: The built-in to try; ``INJECTED`` is refused, because an
            injected policy's failure is ``PolicyErrorMode``'s concern.
        fallback: The method a delegation runs. Only HOURS_TIMES_RATE, the
            one target Hermes delegates to (valuation.py:L629-L640).
    """

    primary: ValuationMethod
    fallback: ValuationMethod = ValuationMethod.HOURS_TIMES_RATE

    def __post_init__(self) -> None:
        """Validate both methods.

        Raises:
            ConfigurationError: If ``primary`` is not a built-in method or
                ``fallback`` is not HOURS_TIMES_RATE.
        """
        if type(self.primary) is not ValuationMethod or (
            self.primary is ValuationMethod.INJECTED
        ):
            raise ConfigurationError(
                f"primary must be a built-in ValuationMethod, got {self.primary!r}"
            )
        if self.fallback is not ValuationMethod.HOURS_TIMES_RATE:
            raise ConfigurationError(
                "fallback must be ValuationMethod.HOURS_TIMES_RATE, got "
                f"{self.fallback!r}"
            )


@dataclass(frozen=True, slots=True)
class ValuationDelegated:
    """A built-in found nothing to price and delegates to its fallback.

    Hermes' ``no_configured_card`` and ``unmatched_key`` for the revenue
    card, and absent ``source_figures`` for baselines (valuation.py:L629).
    """


def _quantized(amount: Decimal, currency: Currency) -> Money | None:
    try:
        return Money(amount=quantize_money(amount, currency), currency=currency)
    except (decimal.InvalidOperation, decimal.Overflow):
        return None


def rate_card(
    assumptions: ResolvedAssumptions, figures: RateCardFigures | None
) -> ValuationResult | AssessmentRefusal:
    """Price the flat amount the card sets for the inferred role (RateCard).

    Hermes ``round(rateCard[role], 2)`` (valuation.py:L365-L437). The gated
    hours and rate are not used in the amount. RateCard never delegates.

    Args:
        assumptions: The gated operands; ``inferred_role`` selects the row.
        figures: The rate card, or ``None`` when none is configured.

    Returns:
        A result produced by RATE_CARD, with the role selection ESTIMATED and
        the card amount CONFIGURED (ADR 0024 decision 3), or
        VALUATION_DECLINED when the card is absent or has no row for the role.
    """
    amount = None if figures is None else figures.amount_for(assumptions.inferred_role)
    if amount is None:
        return AssessmentRefusal.VALUATION_DECLINED
    return ValuationResult(
        amount=_quantized(amount, assumptions.currency),
        produced_by=ValuationMethod.RATE_CARD,
        operand_bases=(
            (ValuationOperand.ROLE_SELECTION, ClaimBasis.ESTIMATED),
            (ValuationOperand.CARD_AMOUNT, ClaimBasis.CONFIGURED),
        ),
    )


def revenue_card(
    assumptions: ResolvedAssumptions, figures: RevenueCardFigures | None
) -> ValuationResult | AssessmentRefusal | ValuationDelegated:
    """Price the selected revenue card row (RevenueCard).

    Hermes ``round(gross * fraction, 2)``, or the gross alone without a
    fraction (valuation.py:L687-L933), computed as one ``ROUND_HALF_UP``
    quantization of the exact ``Decimal`` product (ID-10). The hours and
    rate are never read.

    Args:
        assumptions: The gated operands; only the currency is read.
        figures: The revenue card, or ``None`` when none is configured.

    Returns:
        A result produced by REVENUE_CARD that declares ``incremental_revenue``
        and carries the producer basis and the attribution pair;
        :class:`ValuationDelegated` for an absent or empty card, no key, or a
        key with no row; or VALUATION_DECLINED for an unreadable row.
    """
    if figures is None or not figures.entries:
        return ValuationDelegated()
    found, entry = figures.selected()
    if not found:
        return ValuationDelegated()
    if entry is None:
        return AssessmentRefusal.VALUATION_DECLINED
    fraction = entry.attribution_fraction
    basis = entry.attribution_basis
    if fraction is None or basis is None:
        product = entry.gross_per_job
        producer_basis = REVENUE_CARD_BASIS_PREFIX
        attribution: tuple[Decimal, str] | None = None
        operand_bases: OperandBases = (
            (ValuationOperand.GROSS, ClaimBasis.CONFIGURED),
            (ValuationOperand.CARD_KEY, ClaimBasis.CONFIGURED),
        )
    else:
        product = money_multiply(entry.gross_per_job, fraction)
        # Hermes formats the float it read (L909-L912); decimal_from_float
        # round-trips exactly, so repr(float(fraction)) is the same text.
        producer_basis = (
            f"{REVENUE_CARD_BASIS_PREFIX} (attribution {float(fraction)!r} "
            "applied; see attribution_basis)"
        )
        attribution = (fraction, basis)
        operand_bases = (
            (ValuationOperand.GROSS, ClaimBasis.CONFIGURED),
            (ValuationOperand.ATTRIBUTION_SHARE, ClaimBasis.CONFIGURED),
            (ValuationOperand.CARD_KEY, ClaimBasis.CONFIGURED),
        )
    return ValuationResult(
        amount=_quantized(product, assumptions.currency),
        produced_by=ValuationMethod.REVENUE_CARD,
        operand_bases=operand_bases,
        declared_mechanism=EconomicMechanism.INCREMENTAL_REVENUE,
        basis=normalize_text(producer_basis, max_bytes=POLICY_BASIS_MAX_BYTES),
        attribution=attribution,
    )


def baselines(
    assumptions: ResolvedAssumptions, figures: BaselineFigures | None
) -> ValuationResult | ValuationDelegated:
    """Price minutes per unit times the hourly rate over 60 (Baselines).

    Hermes ``round(minutes / 60.0 * rate, 2)`` (valuation.py:L999-L1027),
    computed as ``minutes x rate`` then ``/ 60`` under ``_MONEY_CONTEXT``
    and one ``ROUND_HALF_UP`` quantization. The two differ only at
    half-cent ties (ID-10).

    Args:
        assumptions: The gated operands; only the currency is read.
        figures: The host-fetched baseline, or ``None``.

    Returns:
        A result produced by BASELINES with both figures CONFIGURED, or
        :class:`ValuationDelegated` when no baseline was resolved.
    """
    if figures is None:
        return ValuationDelegated()
    amount: Money | None
    try:
        amount = _quantized(
            _MONEY_CONTEXT.divide(
                money_multiply(figures.minutes_per_unit, figures.hourly_rate), _SIXTY
            ),
            assumptions.currency,
        )
    except (decimal.InvalidOperation, decimal.Overflow):
        amount = None
    return ValuationResult(
        amount=amount,
        produced_by=ValuationMethod.BASELINES,
        operand_bases=(
            (ValuationOperand.BASELINE_RATE, ClaimBasis.CONFIGURED),
            (ValuationOperand.BASELINE_MINUTES, ClaimBasis.CONFIGURED),
        ),
    )


def builtin_plan(method: "ValuationMethod | FallbackPolicy") -> FallbackPolicy | None:
    """Return the fallback plan a configured method runs, if it is a built-in.

    Args:
        method: ``AssessmentPolicy.method``.

    Returns:
        ``method`` itself when it is a :class:`FallbackPolicy`,
        ``FallbackPolicy(primary=method)`` for a bare built-in, and ``None``
        for INJECTED.
    """
    if isinstance(method, FallbackPolicy):
        return method
    if method is ValuationMethod.INJECTED:
        return None
    return FallbackPolicy(primary=method)


def builtin_declaration(method: ValuationMethod) -> ComponentDeclaration | None:
    """Return the declaration a built-in votes with in the evidence walk.

    Args:
        method: The method that produced, or was configured to produce, the
            value.

    Returns:
        ``BUILTIN_RATE_CARD`` or ``BUILTIN_REVENUE_CARD``, or ``None`` for the
        non-voting HoursTimesRate and Baselines and for INJECTED, whose
        declaration the engine stores.
    """
    if method is ValuationMethod.RATE_CARD:
        return BUILTIN_RATE_CARD
    if method is ValuationMethod.REVENUE_CARD:
        return BUILTIN_REVENUE_CARD
    return None


def _price_one(
    method: ValuationMethod,
    assumptions: ResolvedAssumptions,
    figures: ValuationFigures,
) -> ValuationResult | AssessmentRefusal | ValuationDelegated:
    if method is ValuationMethod.RATE_CARD:
        return rate_card(assumptions, figures.rate_card)
    if method is ValuationMethod.REVENUE_CARD:
        return revenue_card(assumptions, figures.revenue_card)
    if method is ValuationMethod.BASELINES:
        return baselines(assumptions, figures.baselines)
    return hours_times_rate_result(assumptions)


def price_builtin(
    plan: FallbackPolicy,
    assumptions: ResolvedAssumptions,
    figures: ValuationFigures,
    *,
    attribution_certain: bool,
) -> ValuationResult | AssessmentRefusal:
    """Price a built-in plan, resolving one delegation (ADR 0028 decision 4).

    The attribution fence runs on the producing result, before any amount
    check, as Hermes orders it (classifier.py:L2240-L2262). The lower bound
    and the ceiling are the caller's, through :func:`check_valuation_amount`.

    Args:
        plan: The primary built-in and its fallback.
        assumptions: The gated operands.
        figures: The caller-resolved figures.
        attribution_certain: The request's assertion that a declared
            operator mechanism belongs to this job.

    Returns:
        The producing result, whose ``produced_by`` names the method that
        priced it, or the refusal: VALUATION_DECLINED, or
        REVENUE_ATTRIBUTION_UNCERTAIN for a declared mechanism without
        attribution certainty.

    Raises:
        RecordValidationError: If ``plan``, ``figures``, or
            ``attribution_certain`` has the wrong type.
    """
    if type(plan) is not FallbackPolicy:
        raise RecordValidationError(
            "rae.valuation",
            "plan",
            f"FallbackPolicy required, got {type(plan).__name__}",
        )
    _require_exact_type(figures, ValuationFigures, ValuationFigures.SCHEMA_ID, "$")
    _require_exact_type(
        attribution_certain, bool, "rae.valuation", "attribution_certain"
    )
    result = _price_one(plan.primary, assumptions, figures)
    if type(result) is ValuationDelegated:
        result = _price_one(plan.fallback, assumptions, figures)
    if type(result) is not ValuationResult:
        # The fallback is HoursTimesRate, which never delegates.
        return (
            result
            if type(result) is AssessmentRefusal
            else AssessmentRefusal.VALUATION_DECLINED
        )
    if result.declared_mechanism is not None and not attribution_certain:
        return AssessmentRefusal.REVENUE_ATTRIBUTION_UNCERTAIN
    return result
