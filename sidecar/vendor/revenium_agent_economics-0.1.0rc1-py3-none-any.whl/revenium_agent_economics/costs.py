"""Supplied human-side costs, cost coverage, net value, and ROI operands.

Costs are read from the caller, never from evaluator output, and arrive
already resolved for one job (ADR 0029, D-01). Metered AI cost travels with
the job but never enters net value, because Revenium already nets it (D-02,
OD-18). The library derives no ratio: a consumer computes ROI from
:class:`RoiOperands`.

Every sum and difference goes through ``_MONEY_CONTEXT`` in
``COST_CATEGORIES`` order. The builtin ``sum``, ``min``, and ``max`` are never
used on money (ADR 0002, ADR 0027 decision 2).
"""

import decimal
import enum
from dataclasses import dataclass
from decimal import Decimal
from typing import ClassVar, Final

from revenium_agent_economics.errors import RecordValidationError
from revenium_agent_economics.primitives import (
    _MONEY_CONTEXT,
    Money,
    _require_exact_type,
    _require_minor_unit_scale,
    _require_tuple_of,
    decimal_from_float,
    quantize_money,
)
from revenium_agent_economics.vocab import (
    COST_CATEGORIES,
    COST_COVERAGE_EXCLUDED_AI,
    ClaimBasis,
    CostCategory,
    Currency,
)

_EXCLUDED: Final[tuple[str, ...]] = (COST_COVERAGE_EXCLUDED_AI,)

# ADR 0030 addendum item 4 (ADR 0029 decision 1): every supplied cost is below
# this bound. AssessmentPolicy accepts only ceilings whose derived band
# quantizes, so every amount it accepts is below 1E+26. Four costs below the
# bound total below 4E+20, so the amount minus the costs always quantizes as
# money and net_value never raises from assess_job.
SUPPLIED_COST_LIMIT: Final = Decimal("1E+20")
# ADR 0030 Phase 6 addendum (WR-09): the smallest exponent a cost or a metered
# AI cost may carry. It sits below repr(5e-324), the smallest float, so every
# decimal_from_float output passes. Without it, Decimal("0E-999999999") is a
# valid cost that format(value, "f") cannot write.
_MIN_COST_EXPONENT: Final = -340


def _significant_digits(value: Decimal) -> int:
    # IN-07: the coefficient's digits without trailing zeros, counted exactly,
    # so 25 written with 27 fractional zeros is 2 digits. A zero is 1 digit.
    # Decimal.normalize would round to the context precision first, so it
    # could not see a 29th digit.
    digits = value.as_tuple().digits
    count = len(digits)
    while count > 1 and digits[count - 1] == 0:
        count -= 1
    return count


def _require_amount_bounds(value: Decimal, schema_id: str, field: str) -> None:
    """Refuse an amount that cannot be netted or written (ADR 0030 items 4, 6).

    The amount is a finite ``Decimal`` the caller has already checked. It must
    be below :data:`SUPPLIED_COST_LIMIT`, have at most 28 significant digits
    once trailing zeros are dropped, and have an exponent of at least -340.
    An out-of-bound amount is refused, never clamped or rounded. The message
    names the rule, never the value (T-04-58).

    Raises:
        RecordValidationError: If any bound fails.
    """
    exponent = value.as_tuple().exponent
    if (
        value >= SUPPLIED_COST_LIMIT
        or _significant_digits(value) > _MONEY_CONTEXT.prec
        or (isinstance(exponent, int) and exponent < _MIN_COST_EXPONENT)
    ):
        raise RecordValidationError(
            schema_id,
            field,
            f"must be below {SUPPLIED_COST_LIMIT} with at most "
            f"{_MONEY_CONTEXT.prec} significant digits and an exponent of at "
            f"least {_MIN_COST_EXPONENT}, so it can be netted and encoded",
        )


def _require_cost(value: object, schema_id: str, field: str) -> None:
    if value is None:
        return
    _require_exact_type(value, Decimal, schema_id, field)
    if not isinstance(value, Decimal) or not value.is_finite() or value < 0:
        raise RecordValidationError(
            schema_id, field, f"must be a finite Decimal of at least 0, got {value!r}"
        )
    _require_amount_bounds(value, schema_id, field)


@dataclass(frozen=True, slots=True, kw_only=True)
class SuppliedCosts:
    """The caller's human-side costs for one job (ADR 0029 decision 1).

    ``None`` means unknown. A value is a finite ``Decimal`` of at least 0,
    below :data:`SUPPLIED_COST_LIMIT`, with at most 28 significant digits once
    trailing zeros are dropped and an exponent of at least -340, so every
    accepted cost can be netted against any amount a policy accepts and
    encoded (ADR 0030 addendum item 4 and its Phase 6 note). A value stays
    unquantized, so ``float(value)`` equals the Hermes float exactly when it
    came through ``decimal_from_float``.

    Attributes:
        currency: The currency of every cost.
        human_review: Review time spent by people.
        rework_or_error: Rework or error correction.
        handoff: Handoff overhead.
        training_or_change: Training or change management.
    """

    SCHEMA_ID: ClassVar[str] = "rae.supplied_costs"
    SCHEMA_VERSION: ClassVar[int] = 1

    currency: Currency
    human_review: Decimal | None = None
    rework_or_error: Decimal | None = None
    handoff: Decimal | None = None
    training_or_change: Decimal | None = None

    def __post_init__(self) -> None:
        """Validate the currency and every category value.

        Raises:
            RecordValidationError: For a negative, non-finite, or ``bool``
                value, any value that is not exactly a ``Decimal``, a value of
                at least ``SUPPLIED_COST_LIMIT``, a value with more than 28
                significant digits once trailing zeros are dropped, or a value
                with an exponent below -340. The field names the category.
        """
        schema_id = SuppliedCosts.SCHEMA_ID
        _require_exact_type(self.currency, Currency, schema_id, "currency")
        for category in COST_CATEGORIES:
            _require_cost(getattr(self, category.value), schema_id, category.value)

    @classmethod
    def from_numbers(
        cls, currency: Currency, **values: int | float | None
    ) -> "SuppliedCosts":
        """Build costs from host numbers, converting each through its ``repr``.

        Args:
            currency: The currency of every cost.
            **values: Category name to an ``int``, a ``float``, or ``None``.

        Returns:
            The costs, each converted with ``decimal_from_float``.

        Raises:
            RecordValidationError: For an unknown category, a ``bool``, a
                non-finite value, a negative value, or a value of at least
                ``SUPPLIED_COST_LIMIT``.
        """
        known = {category.value for category in COST_CATEGORIES}
        converted: dict[str, Decimal | None] = {}
        for name in sorted(values):
            if name not in known:
                raise RecordValidationError(
                    SuppliedCosts.SCHEMA_ID, name, "unknown cost category"
                )
            value = values[name]
            converted[name] = None if value is None else decimal_from_float(value)
        return cls(currency=currency, **converted)

    def amount(self, category: CostCategory) -> Decimal | None:
        """Return the value of one category, or ``None`` when unknown."""
        value: Decimal | None = getattr(self, category.value)
        return value


def empty_supplied_costs(currency: Currency) -> SuppliedCosts:
    """Return costs with every category unknown.

    Args:
        currency: The currency of the costs.

    Returns:
        A ``SuppliedCosts`` whose four categories are ``None``.
    """
    return SuppliedCosts(currency=currency)


def _require_categories(value: object, schema_id: str, field: str) -> None:
    _require_tuple_of(value, str, schema_id, field)
    names = [category.value for category in COST_CATEGORIES]
    items = value if isinstance(value, tuple) else ()
    positions = []
    for item in items:
        if item not in names:
            raise RecordValidationError(
                schema_id, field, f"not a cost category: {item!r}"
            )
        positions.append(names.index(item))
    if positions != sorted(set(positions)):
        raise RecordValidationError(
            schema_id, field, "must be unique and in COST_CATEGORIES order"
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class CostCoverage:
    """Which cost categories a job's net value accounts for (ADR 0029 decision 2).

    Attributes:
        included: Categories with a supplied value, in category order.
        known_zero: Included categories whose value is 0.
        unknown: Categories with no supplied value.
        excluded: Always ``("metered_ai_cost",)``: Revenium nets metered AI
            cost itself, so it never enters net value.
    """

    SCHEMA_ID: ClassVar[str] = "rae.cost_coverage"
    SCHEMA_VERSION: ClassVar[int] = 1

    included: tuple[str, ...]
    known_zero: tuple[str, ...]
    unknown: tuple[str, ...]
    excluded: tuple[str, ...] = _EXCLUDED

    def __post_init__(self) -> None:
        """Validate that the lists partition the cost categories.

        Raises:
            RecordValidationError: If a list is not a tuple of category names
                in category order, a category is in both or neither of
                ``included`` and ``unknown``, ``known_zero`` is not a subset of
                ``included``, or ``excluded`` is not the metered AI cost.
        """
        schema_id = CostCoverage.SCHEMA_ID
        for field in ("included", "known_zero", "unknown"):
            _require_categories(getattr(self, field), schema_id, field)
        _require_tuple_of(self.excluded, str, schema_id, "excluded")
        if self.excluded != _EXCLUDED:
            raise RecordValidationError(schema_id, "excluded", f"must be {_EXCLUDED!r}")
        included = set(self.included)
        unknown = set(self.unknown)
        every = {category.value for category in COST_CATEGORIES}
        if included & unknown or included | unknown != every:
            raise RecordValidationError(
                schema_id,
                "included",
                "every category must be in exactly one of included and unknown",
            )
        if not set(self.known_zero) <= included:
            raise RecordValidationError(
                schema_id, "known_zero", "must be a subset of included"
            )


def cost_coverage(costs: SuppliedCosts) -> CostCoverage:
    """Apply Hermes' coverage rule per category (classifier.py:L3231-L3239).

    Args:
        costs: The supplied costs.

    Returns:
        The coverage: unknown for ``None``, otherwise included, and also
        known-zero when the value equals 0. Every list follows
        ``COST_CATEGORIES`` order.
    """
    included: list[str] = []
    known_zero: list[str] = []
    unknown: list[str] = []
    for category in COST_CATEGORIES:
        value = costs.amount(category)
        if value is None:
            unknown.append(category.value)
            continue
        included.append(category.value)
        if value.is_zero():
            known_zero.append(category.value)
    return CostCoverage(
        included=tuple(included), known_zero=tuple(known_zero), unknown=tuple(unknown)
    )


def net_value(value: Decimal, costs: SuppliedCosts, currency: Currency) -> Decimal:
    """Return the value minus the included costs, quantized once (VAL-07).

    Hermes ``round(estimated_value - sum(supplied_costs.values()), 2)``
    (classifier.py:L3660). The sum and difference run through
    ``_MONEY_CONTEXT`` in category order; the result is not clamped and may
    be negative. A negative zero is normalized to zero (ADR 0002).

    Args:
        value: The accepted, already quantized estimated value.
        costs: The supplied costs, unquantized.
        currency: The currency whose minor unit sets the exponent.

    Returns:
        The net value.

    Raises:
        RecordValidationError: If the result cannot be quantized as money
            within ``_MONEY_CONTEXT``. Unreachable from ``assess_job``, whose
            amounts are below 1E+26 and whose costs are below
            ``SUPPLIED_COST_LIMIT`` (ADR 0030 addendum item 4); it stays for
            a direct caller whose ``value`` is out of range.
    """
    total = Decimal(0)
    for category in COST_CATEGORIES:
        amount = costs.amount(category)
        if amount is not None:
            total = _MONEY_CONTEXT.add(total, amount)
    try:
        result = quantize_money(_MONEY_CONTEXT.subtract(value, total), currency)
    except (decimal.InvalidOperation, decimal.Overflow) as error:
        raise RecordValidationError(
            RoiOperands.SCHEMA_ID, "net_value", "is not representable as money"
        ) from error
    return result.copy_abs() if result.is_zero() else result


class ValueSideState(enum.Enum):
    """What the value side of an assessment measured (ADR 0029 decision 5)."""

    VALUED = "valued"
    ZERO_NOT_COMPLETED = "zero_not_completed"
    UNCOMPUTED = "uncomputed"


def _require_money_in(
    value: object, currency: Currency, schema_id: str, field: str
) -> None:
    _require_exact_type(value, Money, schema_id, field)
    if isinstance(value, Money) and value.currency is not currency:
        raise RecordValidationError(
            schema_id, field, "currency must equal the costs currency"
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class RoiOperands:
    """The operands a consumer computes ROI from (ADR 0029 decision 5).

    Attributes:
        value_state: What the value side measured.
        value: The accepted estimated value. Present only when VALUED.
        value_basis: The weakest claim basis behind ``value``. Present only
            when VALUED.
        costs: The supplied costs. Always present.
        coverage: The coverage of ``costs``. Always present.
        metered_ai_cost: The host's metered AI cost, carried but never netted.
            Its amount is at least 0 and within the cost bounds of
            :class:`SuppliedCosts`, also at decode, and it stays unquantized
            (ADR 0029 decision 4, ADR 0030 addendum item 6 and its Phase 6
            note).
        net_value: ``value`` minus the included costs. Present only when
            VALUED.
    """

    SCHEMA_ID: ClassVar[str] = "rae.roi_operands"
    SCHEMA_VERSION: ClassVar[int] = 1

    value_state: ValueSideState
    value: Money | None = None
    value_basis: ClaimBasis | None = None
    costs: SuppliedCosts
    coverage: CostCoverage
    metered_ai_cost: Money | None = None
    net_value: Money | None = None

    def __post_init__(self) -> None:
        """Validate the state, the value-side presence rule, and currencies.

        Raises:
            RecordValidationError: If any field is invalid or inconsistent,
                including a ``value`` or ``net_value`` amount whose exponent
                is not exactly the currency's minor unit, such as ``300`` or
                ``12.3`` for USD (ADR 0030 Phase 6 owner-decision addendum).
        """
        schema_id = RoiOperands.SCHEMA_ID
        _require_exact_type(self.value_state, ValueSideState, schema_id, "value_state")
        _require_exact_type(self.costs, SuppliedCosts, schema_id, "costs")
        _require_exact_type(self.coverage, CostCoverage, schema_id, "coverage")
        if self.coverage != cost_coverage(self.costs):
            raise RecordValidationError(
                schema_id, "coverage", "must equal cost_coverage(costs)"
            )
        currency = self.costs.currency
        if self.metered_ai_cost is not None:
            _require_money_in(
                self.metered_ai_cost, currency, schema_id, "metered_ai_cost"
            )
            # ADR 0030 addendum item 6: a negative zero is not below 0.
            if self.metered_ai_cost.amount < 0:
                raise RecordValidationError(
                    schema_id, "metered_ai_cost", "must be at least 0"
                )
            # The Phase 6 note on item 6: the cost bounds, at decode too.
            _require_amount_bounds(
                self.metered_ai_cost.amount, schema_id, "metered_ai_cost"
            )
        valued = self.value_state is ValueSideState.VALUED
        for field in ("value", "value_basis", "net_value"):
            if (getattr(self, field) is not None) != valued:
                raise RecordValidationError(
                    schema_id, field, "is present exactly when value_state is valued"
                )
        if not valued or self.value is None or self.net_value is None:
            return
        _require_money_in(self.value, currency, schema_id, "value")
        _require_minor_unit_scale(self.value.amount, currency, schema_id, "value")
        _require_exact_type(self.value_basis, ClaimBasis, schema_id, "value_basis")
        _require_money_in(self.net_value, currency, schema_id, "net_value")
        _require_minor_unit_scale(
            self.net_value.amount, currency, schema_id, "net_value"
        )
        expected = net_value(self.value.amount, self.costs, currency)
        if self.net_value.amount != expected:
            raise RecordValidationError(
                schema_id,
                "net_value",
                f"must equal net_value(value, costs), {format(expected, 'f')}",
            )
