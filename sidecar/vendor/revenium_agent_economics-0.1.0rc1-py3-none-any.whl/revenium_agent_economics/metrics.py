"""Outcome-metric intents built from the corrected effective state.

:func:`build_outcome_metrics` turns one :class:`EffectiveAssessment` and the
caller's :class:`EconomicsContract` into the complete four-intent set or one
typed :class:`MetricRefusal`, never a partial set (METR-01, METR-02, ADR
0034, ADR 0036). It accepts only an effective view, so no metric set can skip
a correction (D-16). It is sync and pure: ``recorded_at`` is the effective job
end, ``built_at`` comes from the ``clock`` argument, and the set key is a
sha256 over canonical JSON (D-12, D-13).

:func:`build_outcome_metrics_batch` is the set-level builder of ADR 0033. It
sees every effective view a host is about to deliver, so it alone enforces
double counting: the members of a shared outcome are refused, allocated with
a :class:`GroupAllocation`, or flagged, never counted twice silently (METR-04,
D-01 to D-04).

The core never delivers, ledgers, or appends a metric, and never reads or
writes a remote contract (METR-06, ADR 0032).
"""

import decimal
import enum
import hashlib
import math
import re
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from typing import ClassVar, Final

from revenium_agent_economics._bounded import (
    DOUBLE_COUNTING_GROUP_MAX_BYTES,
    IDENTIFIER_MAX_BYTES,
    NARRATIVE_CLAMP_BYTES,
    is_bounded_printable,
    normalize_text,
)
from revenium_agent_economics._canonical import (
    JsonValue,
    canonical_json,
    format_decimal,
)
from revenium_agent_economics._version import __version__
from revenium_agent_economics.assessment import _require_normalized
from revenium_agent_economics.corrections import (
    CorrectionRejectionReason,
    EffectiveAssessment,
    _checked_now,
    _require_assessment_id_text,
    _require_bounded_identifier,
)
from revenium_agent_economics.errors import ConfigurationError, RecordValidationError
from revenium_agent_economics.evidence import ReportabilityPolicy
from revenium_agent_economics.jobs import _require_clamped_text, _require_job_id
from revenium_agent_economics.primitives import (
    _MONEY_CONTEXT,
    MINOR_UNITS,
    _require_exact_type,
    _require_text,
    _require_tuple_of,
    decimal_from_float,
    money_multiply,
)
from revenium_agent_economics.protocols import Clock
from revenium_agent_economics.tasks import _require_utc
from revenium_agent_economics.taxonomy import is_valid_label, validate_label
from revenium_agent_economics.vocab import (
    REQUIRED_METRIC_TYPES,
    UNIT_INTERVAL_METRIC_TYPES,
    UNIT_METRIC_TYPE,
    Currency,
    EvidenceClass,
    MetricType,
    ReportabilityStatus,
)

# Hermes outcome-metrics-report.sh OM_UNIT_METRIC_KEY (L33).
OM_UNIT_METRIC_KEY_DEFAULT: Final = "jobs_completed"
# Hermes omr.sh L484: every entry is DERIVED.
METRIC_PROVENANCE: Final = "DERIVED"
# Hermes omr.sh L440-L441, the recordedAt text format.
RECORDED_AT_FORMAT: Final = "%Y-%m-%dT%H:%M:%SZ"
_SET_KEY_VERSION: Final = 1
_SET_KEY_TEXT: Final = re.compile(r"[0-9a-f]{64}", re.ASCII)
_INTENT_COUNT: Final = 4
_MIN_SHARED_MEMBERS: Final = 2
_NONE_TEXT: Final = "None"
# Python's ASCII whitespace (string.whitespace), the C-locale strip set.
_ASCII_WHITESPACE: Final = " \t\n\r\x0b\x0c"
# ADR 0033 decision 6, Phase 6 addendum (owner, Phase 5 WR-01): the money
# context with ROUND_DOWN. Neither the 28-digit product nor its quantization
# can round a member's part of a shared value up.
_ALLOCATION_CONTEXT: Final = decimal.Context(
    prec=_MONEY_CONTEXT.prec,
    rounding=decimal.ROUND_DOWN,
    Emin=_MONEY_CONTEXT.Emin,
    Emax=_MONEY_CONTEXT.Emax,
    capitals=_MONEY_CONTEXT.capitals,
    clamp=_MONEY_CONTEXT.clamp,
    flags=[],
    traps=[trap for trap, on in _MONEY_CONTEXT.traps.items() if on],
)


class MetricRefusalReason(enum.Enum):
    """Why a metric set was refused (ADR 0036 decision 3).

    A plain ``Enum`` with no ordering. The single builder checks the
    first thirteen in member order; the first failure is the refusal. The
    last four are batch-only and library-only (ADR 0033). MODEL_ESTIMATE_NOT_OPTED_IN
    is the metric-time re-gate of the model-estimate opt-in (ADR 0039
    decision 5). CONTRACT_MONETIZATION_OVERRIDES_VALUE refuses a contract
    that declares a per-unit rate, which Revenium would use in place of the
    reported value (ADR 0041 decision 4).
    """

    NOT_REPORTABLE = "not_reportable"
    MODEL_ESTIMATE_NOT_OPTED_IN = "model_estimate_not_opted_in"
    STALE_CORRECTION_PENDING = "stale_correction_pending"
    CONTRACT_JOB_TYPE_MISMATCH = "contract_job_type_mismatch"
    CONTRACT_METRIC_MISSING = "contract_metric_missing"
    CONTRACT_METRIC_MISTYPED = "contract_metric_mistyped"
    UNIT_METRIC_UNDECLARED = "unit_metric_undeclared"
    UNIT_METRIC_NOT_COUNT = "unit_metric_not_count"
    CONTRACT_CURRENCY_UNDECLARED = "contract_currency_undeclared"
    CONTRACT_CURRENCY_MISMATCH = "contract_currency_mismatch"
    CONTRACT_MONETIZATION_OVERRIDES_VALUE = "contract_monetization_overrides_value"
    INTENT_VALUE_INVALID = "intent_value_invalid"
    INTENT_VALUE_OUT_OF_RANGE = "intent_value_out_of_range"
    CONTRACT_NOT_SUPPLIED = "contract_not_supplied"
    SUPERSEDED_BY_LATER_ASSESSMENT = "superseded_by_later_assessment"
    UNALLOCATED_SHARED_OUTCOME = "unallocated_shared_outcome"
    ALLOCATION_INVALID = "allocation_invalid"


# The reasons that name the metric they are about (ADR 0036 decision 2).
_METRIC_KEY_REASONS: Final[frozenset[MetricRefusalReason]] = frozenset(
    {
        MetricRefusalReason.UNIT_METRIC_UNDECLARED,
        MetricRefusalReason.UNIT_METRIC_NOT_COUNT,
        MetricRefusalReason.INTENT_VALUE_INVALID,
        MetricRefusalReason.INTENT_VALUE_OUT_OF_RANGE,
    }
)
# The reasons that name a group and its members (ADR 0033 decision 5).
_GROUP_REASONS: Final[frozenset[MetricRefusalReason]] = frozenset(
    {
        MetricRefusalReason.UNALLOCATED_SHARED_OUTCOME,
        MetricRefusalReason.ALLOCATION_INVALID,
    }
)


def _require_job_type(value: object, schema_id: str, field: str) -> None:
    # ADR 0013: the label grammar, as taxonomy.validate_label returns it.
    _require_exact_type(value, str, schema_id, field)
    if validate_label(value) != value:
        raise RecordValidationError(schema_id, field, "fails the label grammar")


def _require_share(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, Decimal, schema_id, field)
    if (
        not isinstance(value, Decimal)
        or not value.is_finite()
        or not Decimal(0) < value <= Decimal(1)
    ):
        raise RecordValidationError(
            schema_id, field, "must be a finite Decimal in (0, 1]"
        )


def _normal_share(share: Decimal) -> Decimal:
    # ADR 0034 Phase 6 addendum (owner, Phase 5 IN-03): strip the
    # coefficient's trailing zeros directly. Decimal.normalize would first
    # round to the context precision, changing a share of more than 28
    # digits. A share is in (0, 1], so stripping stops at exponent 0 and
    # format_decimal always renders the result as a plain decimal.
    sign, digits, exponent = share.as_tuple()
    if not isinstance(exponent, int):  # pragma: no cover - shares are finite
        return share
    count = len(digits)
    while exponent < 0 and count > 1 and digits[count - 1] == 0:
        count -= 1
        exponent += 1
    return Decimal((sign, digits[:count], exponent))


def _require_members(
    value: object, schema_id: str, field: str, *, minimum: int
) -> None:
    # Sorted, unique assessment ids, at least ``minimum`` of them.
    _require_tuple_of(value, str, schema_id, field)
    members = value if isinstance(value, tuple) else ()
    if len(members) < minimum or list(members) != sorted(set(members)):
        raise RecordValidationError(
            schema_id,
            field,
            f"must be at least {minimum} sorted, unique assessment ids",
        )
    for member in members:
        _require_assessment_id_text(member, schema_id, field)


def _require_assessment_of_job(
    assessment_id: object, job_id: object, schema_id: str
) -> None:
    _require_job_id(job_id, schema_id, "job_id")
    _require_assessment_id_text(assessment_id, schema_id, "assessment_id")
    if str(assessment_id).rpartition(":")[0] != job_id:
        raise RecordValidationError(
            schema_id, "assessment_id", "must be an assessment of job_id"
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class MetricDeclaration:
    """One metric an economics contract declares (ADR 0035 decision 1).

    Attributes:
        key: The metric key, non-empty printable text of at most 128
            serialized bytes.
        metric_type: The declared type, or ``None`` when the contract names
            the key without a usable type.
    """

    SCHEMA_ID: ClassVar[str] = "rae.metric_declaration"
    SCHEMA_VERSION: ClassVar[int] = 1

    key: str
    metric_type: MetricType | None = None

    def __post_init__(self) -> None:
        """Validate the key and the type.

        Raises:
            RecordValidationError: If either field is invalid.
        """
        schema_id = MetricDeclaration.SCHEMA_ID
        _require_bounded_identifier(self.key, schema_id, "key")
        if self.metric_type is not None:
            _require_exact_type(self.metric_type, MetricType, schema_id, "metric_type")


@dataclass(frozen=True, slots=True, kw_only=True)
class EconomicsContract:
    """The caller's economics contract for one job type (ADR 0035, D-15).

    The record holds what the contract says. Whether that fits the four
    intents is checked by :func:`build_outcome_metrics`, so each problem is a
    typed refusal rather than a construction error.

    Attributes:
        job_type: The job type the contract is keyed by.
        version: The contract version, non-empty printable text of at most
            128 serialized bytes. It enters the set idempotency key.
        currency: The declared currency, or ``None`` when the contract
            declares none.
        metrics: The declared metrics, with unique keys.
        unit_metric_key: The key of the job's COUNT unit metric.
        value_per_unit: The declared per-unit rate (``monetization.valuePerUnit``
            in a Revenium document), an exact, finite ``Decimal``, or ``None``
            when the contract declares none. Revenium computes Value as rate x
            units and ignores the reported value when a rate is declared, so
            the builders refuse any rate, 0 included (ADR 0041 decision 2).
    """

    SCHEMA_ID: ClassVar[str] = "rae.economics_contract"
    SCHEMA_VERSION: ClassVar[int] = 1

    job_type: str
    version: str
    currency: Currency | None = None
    metrics: tuple[MetricDeclaration, ...]
    unit_metric_key: str = OM_UNIT_METRIC_KEY_DEFAULT
    value_per_unit: Decimal | None = None

    def __post_init__(self) -> None:
        """Validate every field and refuse duplicate metric keys.

        Raises:
            RecordValidationError: If any field is invalid, or two
                declarations share a key.
        """
        schema_id = EconomicsContract.SCHEMA_ID
        _require_job_type(self.job_type, schema_id, "job_type")
        _require_bounded_identifier(self.version, schema_id, "version")
        if self.currency is not None:
            _require_exact_type(self.currency, Currency, schema_id, "currency")
        _require_tuple_of(self.metrics, MetricDeclaration, schema_id, "metrics")
        keys = [declaration.key for declaration in self.metrics]
        if len(set(keys)) != len(keys):
            raise RecordValidationError(
                schema_id, "metrics", "two declarations share a key"
            )
        _require_bounded_identifier(self.unit_metric_key, schema_id, "unit_metric_key")
        if self.value_per_unit is not None:
            _require_exact_type(
                self.value_per_unit, Decimal, schema_id, "value_per_unit"
            )
            if not self.value_per_unit.is_finite():
                raise RecordValidationError(
                    schema_id, "value_per_unit", "must be finite"
                )


@dataclass(frozen=True, slots=True, kw_only=True)
class MetricRefusal:
    """Why no metric set was built for one effective view (ADR 0036).

    A refusal is a result, not an error, and carries no partial intents.

    Attributes:
        assessment_id: The effective assessment id.
        job_id: The effective job id.
        job_type: The effective, possibly corrected, job type.
        reason: Why the set was refused.
        metric_key: The metric the refusal is about. Set exactly for the two
            unit reasons and the two value reasons.
        details: Bounded texts in ``normalize_text`` form, whose content
            each reason defines (ADR 0035 decision 2).
        group: The shared group. Set exactly for UNALLOCATED_SHARED_OUTCOME
            and ALLOCATION_INVALID.
        members: The group's sorted member assessment ids, under the same
            rule; otherwise empty.
        built_at: When the refusal was built, from the injected clock.
        library_version: The library version that built it.
    """

    SCHEMA_ID: ClassVar[str] = "rae.metric_refusal"
    SCHEMA_VERSION: ClassVar[int] = 1

    assessment_id: str
    job_id: str
    job_type: str
    reason: MetricRefusalReason
    metric_key: str | None = None
    details: tuple[str, ...] = ()
    group: str | None = None
    members: tuple[str, ...] = ()
    built_at: datetime
    library_version: str

    def __post_init__(self) -> None:
        """Validate every field and the per-reason presence rules.

        Raises:
            RecordValidationError: If any field is invalid or inconsistent.
        """
        schema_id = MetricRefusal.SCHEMA_ID
        _require_assessment_of_job(self.assessment_id, self.job_id, schema_id)
        _require_exact_type(self.job_type, str, schema_id, "job_type")
        if not is_valid_label(self.job_type):
            raise RecordValidationError(
                schema_id, "job_type", "fails the label grammar"
            )
        _require_exact_type(self.reason, MetricRefusalReason, schema_id, "reason")
        if (self.metric_key is not None) != (self.reason in _METRIC_KEY_REASONS):
            raise RecordValidationError(
                schema_id,
                "metric_key",
                "is set exactly for the unit and value reasons",
            )
        if self.metric_key is not None:
            _require_bounded_identifier(self.metric_key, schema_id, "metric_key")
        _require_tuple_of(self.details, str, schema_id, "details")
        for detail in self.details:
            _require_normalized(detail, schema_id, "details", NARRATIVE_CLAMP_BYTES)
        _require_tuple_of(self.members, str, schema_id, "members")
        grouped = self.reason in _GROUP_REASONS
        if (self.group is not None) != grouped or (bool(self.members) != grouped):
            raise RecordValidationError(
                schema_id,
                "group",
                "group and members are set exactly for the group reasons",
            )
        if self.group is not None:
            _require_clamped_text(
                self.group, schema_id, "group", DOUBLE_COUNTING_GROUP_MAX_BYTES
            )
            _require_members(self.members, schema_id, "members", minimum=1)
        _require_utc(self.built_at, schema_id, "built_at")
        _require_text(self.library_version, schema_id, "library_version")


@dataclass(frozen=True, slots=True, kw_only=True)
class OutcomeMetricIntent:
    """One metric value of one job, ready for a host to deliver (ADR 0034).

    Attributes:
        key: The metric key.
        metric_type: The metric's type.
        value: A finite ``Decimal``.
        line_key: The per-metric key
            ``f"OM:{job_id}:{key}:{recorded_at_text}"`` (D-12). Hermes'
            parity label, never a delivery dedupe key on its own.
    """

    SCHEMA_ID: ClassVar[str] = "rae.outcome_metric_intent"
    SCHEMA_VERSION: ClassVar[int] = 1

    key: str
    metric_type: MetricType
    value: Decimal
    line_key: str

    def __post_init__(self) -> None:
        """Validate every field.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = OutcomeMetricIntent.SCHEMA_ID
        _require_bounded_identifier(self.key, schema_id, "key")
        _require_exact_type(self.metric_type, MetricType, schema_id, "metric_type")
        _require_exact_type(self.value, Decimal, schema_id, "value")
        if not self.value.is_finite():
            raise RecordValidationError(schema_id, "value", "must be finite")
        _require_text(self.line_key, schema_id, "line_key")
        if not self.line_key.startswith("OM:") or f":{self.key}:" not in self.line_key:
            raise RecordValidationError(
                schema_id, "line_key", "must be f'OM:{job_id}:{key}:{recorded_at}'"
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class SharedOutcomeFlag:
    """A FLAG-mode marker that siblings share an outcome (ADR 0034, ADR 0033).

    Attributes:
        reason: Always ``MetricRefusalReason.UNALLOCATED_SHARED_OUTCOME``.
        group: The shared double-counting group.
        members: The sorted member assessment ids, at least two.
    """

    SCHEMA_ID: ClassVar[str] = "rae.shared_outcome_flag"
    SCHEMA_VERSION: ClassVar[int] = 1

    reason: MetricRefusalReason = MetricRefusalReason.UNALLOCATED_SHARED_OUTCOME
    group: str
    members: tuple[str, ...]

    def __post_init__(self) -> None:
        """Validate the reason, the group, and the members.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = SharedOutcomeFlag.SCHEMA_ID
        _require_exact_type(self.reason, MetricRefusalReason, schema_id, "reason")
        if self.reason is not MetricRefusalReason.UNALLOCATED_SHARED_OUTCOME:
            raise RecordValidationError(
                schema_id, "reason", "must be unallocated_shared_outcome"
            )
        _require_clamped_text(
            self.group, schema_id, "group", DOUBLE_COUNTING_GROUP_MAX_BYTES
        )
        _require_members(
            self.members, schema_id, "members", minimum=_MIN_SHARED_MEMBERS
        )


def _set_key(
    *,
    assessment_id: str,
    applied: tuple[str, ...],
    contract_job_type: str,
    contract_version: str,
    share: Decimal | None,
) -> str:
    # D-12, exactly the bytes the owner approved at the 05-01 Task 3
    # checkpoint (ADR 0034 decision 5). canonical_json sorts the keys.
    payload: dict[str, JsonValue] = {
        "v": _SET_KEY_VERSION,
        "assessment_id": assessment_id,
        "applied": list(applied),
        "contract_job_type": contract_job_type,
        "contract_version": contract_version,
        "share": None if share is None else format_decimal(share),
    }
    return hashlib.sha256(canonical_json(payload)).hexdigest()


def _line_key(job_id: str, metric_key: str, recorded_at_text: str) -> str:
    # D-12 and D-13: byte-identical to Hermes omr.sh L480.
    return f"OM:{job_id}:{metric_key}:{recorded_at_text}"


def _check_intent_value(
    metric_type: MetricType, value: object
) -> MetricRefusalReason | None:
    # The BADFIELD and BADRANGE analogs of omr.sh L460-L489 (ADR 0034
    # decision 6). NaN and infinity are out of range. An int is compared
    # directly, as Hermes' in_range does, and never converted to float, so
    # an int too wide for a float gets a typed verdict (Phase 5 WR-04).
    if (
        value is None
        or isinstance(value, bool)
        or not isinstance(value, int | float | Decimal)
    ):
        return MetricRefusalReason.INTENT_VALUE_INVALID
    if isinstance(value, Decimal):
        if not value.is_finite():
            return MetricRefusalReason.INTENT_VALUE_OUT_OF_RANGE
    elif isinstance(value, float) and not math.isfinite(value):
        return MetricRefusalReason.INTENT_VALUE_OUT_OF_RANGE
    if metric_type in UNIT_INTERVAL_METRIC_TYPES:
        in_range = 0 <= value <= 1
    else:
        in_range = value >= 0
    return None if in_range else MetricRefusalReason.INTENT_VALUE_OUT_OF_RANGE


def _require_intents(record: "OutcomeMetricIntents") -> str:
    # Exactly four intents in Hermes candidate order (H-M4), each with its
    # value in range and its line key. Returns the recorded_at text.
    schema_id = OutcomeMetricIntents.SCHEMA_ID
    _require_tuple_of(record.intents, OutcomeMetricIntent, schema_id, "intents")
    intents = record.intents
    expected = list(REQUIRED_METRIC_TYPES.items())
    if (
        len(intents) != _INTENT_COUNT
        or [(intent.key, intent.metric_type) for intent in intents[:3]] != expected
    ):
        raise RecordValidationError(
            schema_id,
            "intents",
            "must be estimated_value, hours_saved, assessment_confidence, then "
            "the unit metric",
        )
    unit = intents[3]
    if unit.metric_type is not UNIT_METRIC_TYPE or unit.key in REQUIRED_METRIC_TYPES:
        raise RecordValidationError(
            schema_id, "intents", "the fourth intent is a COUNT unit metric"
        )
    if unit.value != 1:
        raise RecordValidationError(schema_id, "intents", "the unit metric is 1")
    for intent in intents:
        if _check_intent_value(intent.metric_type, intent.value) is not None:
            raise RecordValidationError(
                schema_id, "intents", f"{intent.key} is out of range"
            )
    _require_utc(record.recorded_at, schema_id, "recorded_at")
    if record.recorded_at.microsecond != 0:
        raise RecordValidationError(
            schema_id, "recorded_at", "must be floored to the second"
        )
    text = record.recorded_at.strftime(RECORDED_AT_FORMAT)
    for intent in intents:
        if intent.line_key != _line_key(record.job_id, intent.key, text):
            raise RecordValidationError(
                schema_id,
                "intents",
                "every line_key is f'OM:{job_id}:{key}:{recorded_at}'",
            )
    return text


@dataclass(frozen=True, slots=True, kw_only=True)
class OutcomeMetricIntents:
    """The complete metric set of one job (ADR 0034 decision 2).

    Attributes:
        assessment_id: The effective assessment id.
        job_id: The effective job id.
        job_type: The effective, possibly corrected, job type.
        contract_job_type: The job type of the contract the set was built
            against.
        contract_version: That contract's version.
        currency: The currency of the effective value.
        intents: Exactly four, in Hermes candidate order: estimated_value
            MONEY, hours_saved DURATION, assessment_confidence SCORE, then
            the contract's unit metric as COUNT with value 1.
        value_low: The effective band's low end, an audit field.
        value_high: The effective band's high end, an audit field.
        recorded_at: The effective job end, floored to the second (D-13).
        built_at: When the set was built, from the injected clock.
        idempotency_key: The D-12 set key, 64 lowercase hex characters.
            The key a host dedupes deliveries on.
        applied_corrections: The effective view's applied ids, in fold order.
        provenance: Always ``"DERIVED"``.
        double_counting_group: The effective group.
        allocation_share: The member's share without trailing zeros after
            the decimal point, or ``None`` when unallocated.
        shared_outcome: A FLAG-mode marker, or ``None``. Never set together
            with ``allocation_share``.
        library_version: The library version that built the set.
    """

    SCHEMA_ID: ClassVar[str] = "rae.outcome_metric_intents"
    SCHEMA_VERSION: ClassVar[int] = 1

    assessment_id: str
    job_id: str
    job_type: str
    contract_job_type: str
    contract_version: str
    currency: Currency
    intents: tuple[OutcomeMetricIntent, ...]
    value_low: Decimal
    value_high: Decimal
    recorded_at: datetime
    built_at: datetime
    idempotency_key: str
    applied_corrections: tuple[str, ...]
    provenance: str = METRIC_PROVENANCE
    double_counting_group: str | None = None
    allocation_share: Decimal | None = None
    shared_outcome: SharedOutcomeFlag | None = None
    library_version: str

    def __post_init__(self) -> None:
        """Validate the set, its keys, and its audit fields.

        Raises:
            RecordValidationError: If any field is invalid or inconsistent.
        """
        schema_id = OutcomeMetricIntents.SCHEMA_ID
        _require_assessment_of_job(self.assessment_id, self.job_id, schema_id)
        _require_exact_type(self.job_type, str, schema_id, "job_type")
        if not is_valid_label(self.job_type):
            raise RecordValidationError(
                schema_id, "job_type", "fails the label grammar"
            )
        _require_job_type(self.contract_job_type, schema_id, "contract_job_type")
        _require_bounded_identifier(
            self.contract_version, schema_id, "contract_version"
        )
        _require_exact_type(self.currency, Currency, schema_id, "currency")
        _require_intents(self)
        _require_utc(self.built_at, schema_id, "built_at")
        _require_tuple_of(
            self.applied_corrections, str, schema_id, "applied_corrections"
        )
        if self.provenance != METRIC_PROVENANCE:
            raise RecordValidationError(
                schema_id, "provenance", f"must be {METRIC_PROVENANCE!r}"
            )
        if self.double_counting_group is not None:
            _require_clamped_text(
                self.double_counting_group,
                schema_id,
                "double_counting_group",
                DOUBLE_COUNTING_GROUP_MAX_BYTES,
            )
        self._require_sharing()
        self._require_band()
        _require_exact_type(self.idempotency_key, str, schema_id, "idempotency_key")
        if _SET_KEY_TEXT.fullmatch(self.idempotency_key) is None or (
            self.idempotency_key
            != _set_key(
                assessment_id=self.assessment_id,
                applied=self.applied_corrections,
                contract_job_type=self.contract_job_type,
                contract_version=self.contract_version,
                share=self.allocation_share,
            )
        ):
            raise RecordValidationError(
                schema_id, "idempotency_key", "must equal the D-12 set key"
            )
        _require_text(self.library_version, schema_id, "library_version")

    def _require_sharing(self) -> None:
        schema_id = OutcomeMetricIntents.SCHEMA_ID
        if self.allocation_share is not None:
            _require_share(self.allocation_share, schema_id, "allocation_share")
            share = self.allocation_share
            if share.as_tuple() != _normal_share(share).as_tuple():
                raise RecordValidationError(
                    schema_id,
                    "allocation_share",
                    "must have no trailing zeros after the decimal point",
                )
        flag = self.shared_outcome
        if flag is None:
            return
        _require_exact_type(flag, SharedOutcomeFlag, schema_id, "shared_outcome")
        if self.allocation_share is not None:
            raise RecordValidationError(
                schema_id,
                "shared_outcome",
                "is never set together with allocation_share",
            )
        if (
            flag.group != self.double_counting_group
            or self.assessment_id not in flag.members
        ):
            raise RecordValidationError(
                schema_id,
                "shared_outcome",
                "must name this set's group and include its assessment",
            )

    def _require_band(self) -> None:
        schema_id = OutcomeMetricIntents.SCHEMA_ID
        for name in ("value_low", "value_high"):
            value = getattr(self, name)
            _require_exact_type(value, Decimal, schema_id, name)
            if not value.is_finite() or value < 0:
                raise RecordValidationError(
                    schema_id, name, "must be a finite Decimal of at least 0"
                )
        # Allocated sets too (Phase 5 IN-04): the builder scales MONEY and
        # the band with one monotone rounding, so a built set always holds.
        money = self.intents[0].value
        if not self.value_low <= money <= self.value_high:
            raise RecordValidationError(
                schema_id,
                "value_low",
                "must satisfy value_low <= value <= value_high",
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class AllocationShare:
    """One member's share of a shared outcome (ADR 0033 decision 6).

    Attributes:
        assessment_id: The member's assessment id.
        share: An exact, finite ``Decimal`` in (0, 1].
    """

    SCHEMA_ID: ClassVar[str] = "rae.allocation_share"
    SCHEMA_VERSION: ClassVar[int] = 1

    assessment_id: str
    share: Decimal

    def __post_init__(self) -> None:
        """Validate the assessment id and the share.

        Raises:
            RecordValidationError: If either field is invalid.
        """
        schema_id = AllocationShare.SCHEMA_ID
        _require_assessment_id_text(self.assessment_id, schema_id, "assessment_id")
        _require_share(self.share, schema_id, "share")


@dataclass(frozen=True, slots=True, kw_only=True)
class GroupAllocation:
    """A host's split of one group's shared outcome (ADR 0033 decision 6).

    The batch builder applies it; the single builder never group-checks.

    Attributes:
        group: The double-counting group, non-empty and in the form every
            record's group has.
        shares: One share per member, with distinct assessment ids, summing
            exactly to 1 under the money context. No tolerance is allowed.
    """

    SCHEMA_ID: ClassVar[str] = "rae.group_allocation"
    SCHEMA_VERSION: ClassVar[int] = 1

    group: str
    shares: tuple[AllocationShare, ...]

    def __post_init__(self) -> None:
        """Validate the group, the distinct members, and the exact sum.

        Raises:
            RecordValidationError: If any field is invalid, an assessment id
                repeats, or the shares do not sum exactly to 1.
        """
        schema_id = GroupAllocation.SCHEMA_ID
        _require_clamped_text(
            self.group, schema_id, "group", DOUBLE_COUNTING_GROUP_MAX_BYTES
        )
        _require_tuple_of(self.shares, AllocationShare, schema_id, "shares")
        if not self.shares:
            raise RecordValidationError(schema_id, "shares", "must not be empty")
        members = [share.assessment_id for share in self.shares]
        if len(set(members)) != len(members):
            raise RecordValidationError(
                schema_id, "shares", "assessment ids must be distinct"
            )
        total = Decimal(0)
        for share in self.shares:
            total = _MONEY_CONTEXT.add(total, share.share)
        if total != Decimal(1):
            raise RecordValidationError(schema_id, "shares", "must sum exactly to 1")


def _contract_refusal(
    contract: EconomicsContract, value_currency: Currency
) -> tuple[MetricRefusalReason, str | None, tuple[str, ...]] | None:
    # Hermes' verdict order (omr.sh L146-L172), then currency (ID-20), then
    # the per-unit rate (ID-36, ADR 0041 decision 4). ADR 0035 decision 2.
    declared: dict[str, MetricType | None] = {
        declaration.key: declaration.metric_type for declaration in contract.metrics
    }
    missing = tuple(key for key in REQUIRED_METRIC_TYPES if key not in declared)
    if missing:
        return MetricRefusalReason.CONTRACT_METRIC_MISSING, None, missing
    mistyped = tuple(
        f"{key} is {_type_text(declared[key])}, expected {expected.value}"
        for key, expected in sorted(REQUIRED_METRIC_TYPES.items())
        if declared[key] is not expected
    )
    if mistyped:
        return MetricRefusalReason.CONTRACT_METRIC_MISTYPED, None, mistyped
    unit = contract.unit_metric_key
    if unit not in declared:
        return MetricRefusalReason.UNIT_METRIC_UNDECLARED, unit, ()
    if declared[unit] is not UNIT_METRIC_TYPE:
        return (
            MetricRefusalReason.UNIT_METRIC_NOT_COUNT,
            unit,
            (_type_text(declared[unit]),),
        )
    if contract.currency is None:
        return (
            MetricRefusalReason.CONTRACT_CURRENCY_UNDECLARED,
            None,
            (_NONE_TEXT, value_currency.value),
        )
    if contract.currency is not value_currency:
        return (
            MetricRefusalReason.CONTRACT_CURRENCY_MISMATCH,
            None,
            (contract.currency.value, value_currency.value),
        )
    if contract.value_per_unit is not None:
        return (
            MetricRefusalReason.CONTRACT_MONETIZATION_OVERRIDES_VALUE,
            None,
            (format_decimal(contract.value_per_unit),),
        )
    return None


def _type_text(metric_type: MetricType | None) -> str:
    return _NONE_TEXT if metric_type is None else metric_type.value


# The metric-time reportability policy when the caller passes none: it admits
# no model estimate, so a host that forgets its current policy gets a visible
# MODEL_ESTIMATE_NOT_OPTED_IN refusal, never a shipped estimate (ADR 0039).
_DEFAULT_REPORTABILITY: Final = ReportabilityPolicy()


def build_outcome_metrics(
    effective: EffectiveAssessment,
    contract: EconomicsContract,
    *,
    clock: Clock,
    reportability: ReportabilityPolicy = _DEFAULT_REPORTABILITY,
) -> OutcomeMetricIntents | MetricRefusal:
    """Build one job's four metric intents, or refuse the whole set.

    The single builder never group-checks (D-05): a grouped effective view
    still gets its four intents. Double counting is enforced only by the
    batch builder (ADR 0033); a host that builds sets one at a time owns
    double counting itself.

    Checks run in ADR 0036 decision 3 order, and the first failure refuses
    the whole set:

    1. NOT_REPORTABLE: the effective view is not REPORTABLE.
    2. MODEL_ESTIMATE_NOT_OPTED_IN: the view's evidence class is
       MODEL_ESTIMATED and ``reportability`` does not admit model
       estimates (ADR 0039). The switch is read again here, as Hermes
       omr.sh does at report time, so a stored reportable estimate is
       withheld once the caller turns it off. It never promotes a view:
       NOT_REPORTABLE is checked first.
    3. STALE_CORRECTION_PENDING: the view holds a STALE_EXPECTED_PRIOR
       rejection (A2). ``details`` names the stale correction ids.
    4. CONTRACT_JOB_TYPE_MISMATCH: the contract is for another job type.
    5. to 8. Hermes' verdict (omr.sh L146-L172): CONTRACT_METRIC_MISSING
       (required keys in ``REQUIRED_METRIC_TYPES`` order),
       CONTRACT_METRIC_MISTYPED (sorted by key), UNIT_METRIC_UNDECLARED,
       and UNIT_METRIC_NOT_COUNT. A unit key equal to a required key is
       always refused here.
    9. and 10. CONTRACT_CURRENCY_UNDECLARED, then CONTRACT_CURRENCY_MISMATCH
       (ID-20).
    11. CONTRACT_MONETIZATION_OVERRIDES_VALUE: the contract declares a
        per-unit rate, 0 included, which Revenium would use in place of the
        reported value (ADR 0041 decision 4). ``details`` is the rate as
        exponent-free text.
    12. and 13. INTENT_VALUE_INVALID and INTENT_VALUE_OUT_OF_RANGE for each
        candidate value, in candidate order.

    The intents are
    estimated_value (the effective ``roi.value``), hours_saved,
    assessment_confidence, and the contract's unit metric with value 1.
    ``recorded_at`` is the effective job end floored to the second, never a
    clock reading, and ``built_at`` is ``clock.now()`` (D-13).

    Args:
        effective: The corrected effective state. A bare ``JobAssessment``
            must pass through ``resolve_effective(record, ())`` first (D-16).
        contract: The caller's contract for the effective job type.
        clock: The source of ``built_at``.
        reportability: The caller's current reportability policy. Only its
            :attr:`ReportabilityPolicy.admits_model_estimates` is read. The
            default admits no model estimate.

    Returns:
        The complete set, or one typed refusal with no intents.

    Raises:
        RecordValidationError: If ``effective`` is not exactly an
            ``EffectiveAssessment`` or ``contract`` is not exactly an
            ``EconomicsContract``.
        ConfigurationError: If ``reportability`` is not exactly a
            ``ReportabilityPolicy``, or the clock returns a naive or non-UTC
            value.
    """
    schema_id = OutcomeMetricIntents.SCHEMA_ID
    if type(effective) is not EffectiveAssessment:
        raise RecordValidationError(
            schema_id,
            "effective",
            f"EffectiveAssessment required, got {type(effective).__name__}",
        )
    if type(contract) is not EconomicsContract:
        raise RecordValidationError(
            schema_id,
            "contract",
            f"EconomicsContract required, got {type(contract).__name__}",
        )
    if type(reportability) is not ReportabilityPolicy:
        raise ConfigurationError("reportability must be a ReportabilityPolicy")
    built_at = _checked_now(clock, "built_at")
    return _build_set(effective, contract, built_at, reportability=reportability)


def _refusal(
    effective: EffectiveAssessment,
    reason: MetricRefusalReason,
    built_at: datetime,
    *,
    metric_key: str | None = None,
    details: tuple[str, ...] = (),
    group: str | None = None,
    members: tuple[str, ...] = (),
) -> MetricRefusal:
    return MetricRefusal(
        assessment_id=effective.assessment_id,
        job_id=effective.job_id,
        job_type=effective.job_type,
        reason=reason,
        metric_key=metric_key,
        details=tuple(
            normalize_text(detail, max_bytes=NARRATIVE_CLAMP_BYTES)
            for detail in details
        ),
        group=group,
        members=members,
        built_at=built_at,
        library_version=__version__,
    )


def _scaled_money(
    amount: Decimal, share: Decimal | None, currency: Currency
) -> Decimal:
    # ADR 0033 decision 6 and its Phase 6 addendum (owner, Phase 5 WR-01):
    # MONEY and both audit band ends are scaled and quantized ROUND_DOWN, so
    # a group's members never sum above the shared value, and one monotone
    # rounding keeps value_low <= MONEY <= value_high. Never clamped.
    if share is None:
        return amount
    quantum = Decimal((0, (1,), -MINOR_UNITS[currency]))
    return _ALLOCATION_CONTEXT.multiply(amount, share).quantize(
        quantum, rounding=decimal.ROUND_DOWN, context=_ALLOCATION_CONTEXT
    )


def _build_set(
    effective: EffectiveAssessment,
    contract: EconomicsContract | None,
    built_at: datetime,
    *,
    reportability: ReportabilityPolicy,
    share: Decimal | None = None,
    flag: SharedOutcomeFlag | None = None,
) -> OutcomeMetricIntents | MetricRefusal:
    # The single builder's checks and intent construction, shared by both
    # builders. ``contract`` is None only in the batch, where the lookup by
    # job type found none (CONTRACT_NOT_SUPPLIED takes the place of
    # CONTRACT_JOB_TYPE_MISMATCH, ADR 0033 decision 4). ``share`` scales
    # MONEY, the audit band, and DURATION before the per-intent value check
    # runs; SCORE and COUNT are never scaled.
    value = effective.roi.value
    if effective.reportability is not ReportabilityStatus.REPORTABLE or value is None:
        return _refusal(effective, MetricRefusalReason.NOT_REPORTABLE, built_at)
    # ADR 0039 decision 5: the model-estimate switch, read again at metric
    # time (Hermes omr.sh L458-L466 at 532eeb3f). After NOT_REPORTABLE, so
    # the switch never promotes a view.
    if (
        effective.evidence_class is EvidenceClass.MODEL_ESTIMATED
        and not reportability.admits_model_estimates
    ):
        return _refusal(
            effective, MetricRefusalReason.MODEL_ESTIMATE_NOT_OPTED_IN, built_at
        )
    # A2: an operator meant to change a value the fold did not apply.
    stale = tuple(
        dict.fromkeys(
            rejection.correction_id
            for rejection in effective.rejected
            if rejection.reason is CorrectionRejectionReason.STALE_EXPECTED_PRIOR
        )
    )
    if stale:
        return _refusal(
            effective,
            MetricRefusalReason.STALE_CORRECTION_PENDING,
            built_at,
            details=stale,
        )
    if contract is None:
        return _refusal(effective, MetricRefusalReason.CONTRACT_NOT_SUPPLIED, built_at)
    if contract.job_type != effective.job_type:
        return _refusal(
            effective, MetricRefusalReason.CONTRACT_JOB_TYPE_MISMATCH, built_at
        )
    verdict = _contract_refusal(contract, value.currency)
    if verdict is not None:
        reason, metric_key, details = verdict
        return _refusal(
            effective, reason, built_at, metric_key=metric_key, details=details
        )
    currency = value.currency
    unit = contract.unit_metric_key
    hours = effective.hours_saved
    if share is not None and hours is not None:
        hours = money_multiply(hours, share)
    confidence = effective.confidence
    money = _scaled_money(value.amount, share, currency)
    candidates: tuple[tuple[str, MetricType, object], ...] = (
        ("estimated_value", MetricType.MONEY, money),
        ("hours_saved", MetricType.DURATION, hours),
        (
            "assessment_confidence",
            MetricType.SCORE,
            None if confidence is None else confidence.value,
        ),
        (unit, UNIT_METRIC_TYPE, 1),
    )
    for key, metric_type, raw in candidates:
        failed = _check_intent_value(metric_type, raw)
        if failed is not None:
            return _refusal(effective, failed, built_at, metric_key=key)
    low = effective.value_low
    high = effective.value_high
    if (
        hours is None or confidence is None or low is None or high is None
    ):  # pragma: no cover
        # A REPORTABLE view always carries a valued JobAssessment's family.
        raise RecordValidationError(
            OutcomeMetricIntents.SCHEMA_ID, "effective", "has no value family"
        )
    recorded_at = effective.job_ended_at.replace(microsecond=0, tzinfo=UTC)
    text = recorded_at.strftime(RECORDED_AT_FORMAT)
    values = (money, hours, decimal_from_float(confidence.value), Decimal(1))
    return OutcomeMetricIntents(
        assessment_id=effective.assessment_id,
        job_id=effective.job_id,
        job_type=effective.job_type,
        contract_job_type=contract.job_type,
        contract_version=contract.version,
        currency=currency,
        intents=tuple(
            OutcomeMetricIntent(
                key=key,
                metric_type=metric_type,
                value=amount,
                line_key=_line_key(effective.job_id, key, text),
            )
            for (key, metric_type, _), amount in zip(candidates, values, strict=True)
        ),
        value_low=_scaled_money(low, share, currency),
        value_high=_scaled_money(high, share, currency),
        recorded_at=recorded_at,
        built_at=built_at,
        idempotency_key=_set_key(
            assessment_id=effective.assessment_id,
            applied=effective.applied,
            contract_job_type=contract.job_type,
            contract_version=contract.version,
            share=share,
        ),
        applied_corrections=effective.applied,
        double_counting_group=effective.double_counting_group,
        allocation_share=share,
        shared_outcome=flag,
        library_version=__version__,
    )


# --- The batch builder (ADR 0033) ------------------------------------------------


class DoubleCountingMode(enum.Enum):
    """What the batch builder does with an unallocated shared group (D-01).

    A plain ``Enum`` with no ordering (ADR 0033 decision 7). It is an
    explicit policy field, never a global compat switch.

    Attributes:
        REFUSE: Refuse every member as UNALLOCATED_SHARED_OUTCOME. The
            default.
        FLAG: Give every member its full, unscaled set with a
            :class:`SharedOutcomeFlag`, so the host decides, visibly.
    """

    REFUSE = "refuse"
    FLAG = "flag"


@dataclass(frozen=True, slots=True, kw_only=True)
class MetricsPolicy:
    """The caller's double-counting policy for one batch (ADR 0033 decision 7).

    Configuration, not a schema record, like ``AssessmentPolicy``. Validated
    at construction, so a misconfiguration fails once.

    Attributes:
        double_counting: What happens to a shared group with no allocation.
    """

    double_counting: DoubleCountingMode = DoubleCountingMode.REFUSE

    def __post_init__(self) -> None:
        """Validate the exact type of the mode.

        Raises:
            ConfigurationError: If ``double_counting`` is not exactly a
                ``DoubleCountingMode``.
        """
        if type(self.double_counting) is not DoubleCountingMode:
            raise ConfigurationError(
                "MetricsPolicy.double_counting must be a DoubleCountingMode"
            )


_DEFAULT_POLICY: Final = MetricsPolicy()


def _contracts_by_job_type(
    contracts: tuple[EconomicsContract, ...],
) -> dict[str, EconomicsContract]:
    by_type: dict[str, EconomicsContract] = {}
    for contract in contracts:
        if contract.job_type in by_type:
            raise RecordValidationError(
                OutcomeMetricIntents.SCHEMA_ID,
                "contracts",
                "two contracts share a job_type",
            )
        by_type[contract.job_type] = contract
    return by_type


def _allocations_by_group(
    allocations: tuple[GroupAllocation, ...],
) -> dict[str, GroupAllocation]:
    by_group: dict[str, GroupAllocation] = {}
    for allocation in allocations:
        if allocation.group in by_group:
            raise RecordValidationError(
                OutcomeMetricIntents.SCHEMA_ID,
                "allocations",
                "two allocations share a group",
            )
        by_group[allocation.group] = allocation
    return by_group


def _latest_by_job(
    effectives: tuple[EffectiveAssessment, ...],
) -> dict[str, EffectiveAssessment]:
    # A3: the highest original sequence per job_id. A repeated assessment id
    # raises, which also rules out a tie on the highest sequence.
    seen: set[str] = set()
    latest: dict[str, EffectiveAssessment] = {}
    for effective in effectives:
        if effective.assessment_id in seen:
            raise RecordValidationError(
                OutcomeMetricIntents.SCHEMA_ID,
                "effectives",
                "two effective views share an assessment_id",
            )
        seen.add(effective.assessment_id)
        held = latest.get(effective.job_id)
        if held is None or effective.original.sequence > held.original.sequence:
            latest[effective.job_id] = effective
    return latest


def _shared_groups(
    selected: tuple[EffectiveAssessment, ...],
) -> dict[str, tuple[EffectiveAssessment, ...]]:
    # ADR 0033 decision 5: the selected REPORTABLE effectives, grouped by
    # double_counting_group, None skipped, members sorted by assessment id.
    grouped: dict[str, list[EffectiveAssessment]] = {}
    for effective in selected:
        group = effective.double_counting_group
        if (
            group is not None
            and effective.reportability is ReportabilityStatus.REPORTABLE
        ):
            grouped.setdefault(group, []).append(effective)
    return {
        group: tuple(sorted(members, key=lambda member: member.assessment_id))
        for group, members in sorted(grouped.items())
    }


def build_outcome_metrics_batch(
    effectives: tuple[EffectiveAssessment, ...],
    contracts: tuple[EconomicsContract, ...],
    *,
    clock: Clock,
    allocations: tuple[GroupAllocation, ...] = (),
    policy: MetricsPolicy = _DEFAULT_POLICY,
    reportability: ReportabilityPolicy = _DEFAULT_REPORTABILITY,
) -> tuple[OutcomeMetricIntents | MetricRefusal, ...]:
    """Build every metric set a host is about to deliver, never double counting.

    This is the only builder that enforces double counting (ADR 0033, D-02).
    It keeps no state between calls, so the host must pass, in one batch,
    every effective view it will deliver for the groups concerned. A host
    that delivers members of one group across separate batches, or through
    :func:`build_outcome_metrics`, owns double counting itself.

    The rules, in order:

    1. Selection (A3): per ``job_id``, the view whose original has the
       highest ``sequence`` is selected. Each older one is refused as
       SUPERSEDED_BY_LATER_ASSESSMENT, with the selected assessment id as
       its detail, and takes no further part.
    2. Each selected view runs the single builder's checks against the
       contract whose ``job_type`` equals its effective job type (A4), and
       against ``reportability`` for the model-estimate re-gate (ADR 0039).
       A job type with no contract is refused as CONTRACT_NOT_SUPPLIED, in
       the place of CONTRACT_JOB_TYPE_MISMATCH. A contract that declares a
       per-unit rate is refused as CONTRACT_MONETIZATION_OVERRIDES_VALUE,
       after both currency checks, as in the single builder (ADR 0041
       decision 4). Selection runs first, so an
       older assessment of a job whose latest view is a withheld model
       estimate stays SUPERSEDED_BY_LATER_ASSESSMENT and never stands in
       for it (Hermes omr.sh L458-L466).
    3. Groups (D-01, D-04): the selected REPORTABLE views are grouped by
       ``double_counting_group``; a ``None`` group is never grouped. A
       member's own refusal from rule 2 always wins, but the member still
       counts, so one stale correction or one withheld model estimate
       cannot make a shared outcome unshared.
    4. An allocation for a present group must cover exactly its members,
       or every member is refused as ALLOCATION_INVALID, in either mode.
       With a valid allocation each member's MONEY and both audit band
       ends become ``x * share`` rounded down to the currency's minor unit,
       and its DURATION ``money_multiply(hours, share)``, unquantized; SCORE
       and COUNT are unchanged (D-03). The scaled MONEY of a group never
       sums above the shared value and falls short of it by less than one
       minor unit per member; no member absorbs the difference. The share is
       taken without trailing zeros, so ``Decimal("0.5")`` and
       ``Decimal("0.50")`` give one ``allocation_share`` and one set key.
    5. A group of two or more members with no allocation is refused as
       UNALLOCATED_SHARED_OUTCOME for every member under REFUSE, or gets its
       full sets with a :class:`SharedOutcomeFlag` under FLAG. The library
       never sums, nets, or picks across a group.

    Each refusal of rules 3 to 5 names the group and its sorted member
    assessment ids. No rule depends on the order of any input tuple.

    Args:
        effectives: The effective views to build sets for.
        contracts: The caller's contracts, one per job type.
        clock: The source of ``built_at``, read once for the whole batch.
        allocations: The host's splits of shared groups, one per group. An
            allocation naming no present group is ignored.
        policy: What to do with an unallocated shared group.
        reportability: The caller's current reportability policy, read for
            the model-estimate re-gate only. The default admits no model
            estimate.

    Returns:
        One result per input, in input order: a complete set or one typed
        refusal.

    Raises:
        RecordValidationError: If an input is not a tuple, an element is not
            exactly the documented record type, two views share an
            assessment id, two contracts share a job type, or two
            allocations share a group.
        ConfigurationError: If ``policy`` is not exactly a ``MetricsPolicy``,
            ``reportability`` is not exactly a ``ReportabilityPolicy``, or the
            clock returns a naive or non-UTC value.
    """
    schema_id = OutcomeMetricIntents.SCHEMA_ID
    _require_tuple_of(effectives, EffectiveAssessment, schema_id, "effectives")
    _require_tuple_of(contracts, EconomicsContract, schema_id, "contracts")
    _require_tuple_of(allocations, GroupAllocation, schema_id, "allocations")
    if type(policy) is not MetricsPolicy:
        raise ConfigurationError("policy must be a MetricsPolicy")
    if type(reportability) is not ReportabilityPolicy:
        raise ConfigurationError("reportability must be a ReportabilityPolicy")
    by_type = _contracts_by_job_type(contracts)
    by_group = _allocations_by_group(allocations)
    latest = _latest_by_job(effectives)
    built_at = _checked_now(clock, "built_at")

    results: dict[str, OutcomeMetricIntents | MetricRefusal] = {}
    for effective in effectives:
        selected = latest[effective.job_id]
        if selected is effective:
            contract = by_type.get(effective.job_type)
            results[effective.assessment_id] = _build_set(
                effective, contract, built_at, reportability=reportability
            )
        else:
            results[effective.assessment_id] = _refusal(
                effective,
                MetricRefusalReason.SUPERSEDED_BY_LATER_ASSESSMENT,
                built_at,
                details=(selected.assessment_id,),
            )

    for group, members in _shared_groups(tuple(latest.values())).items():
        ids = tuple(member.assessment_id for member in members)
        allocation = by_group.get(group)
        if allocation is None and len(members) < _MIN_SHARED_MEMBERS:
            continue
        # One normalized share per member feeds the scaling, the set key,
        # and allocation_share (ADR 0034 Phase 6 addendum).
        shares = (
            {}
            if allocation is None
            else {
                share.assessment_id: _normal_share(share.share)
                for share in allocation.shares
            }
        )
        covered = allocation is not None and set(shares) == set(ids)
        for member in members:
            if type(results[member.assessment_id]) is MetricRefusal:
                continue  # A member's own refusal wins (ADR 0033 decision 5).
            contract = by_type.get(member.job_type)
            if covered:
                built = _build_set(
                    member,
                    contract,
                    built_at,
                    reportability=reportability,
                    share=shares[member.assessment_id],
                )
            elif allocation is not None:
                built = _refusal(
                    member,
                    MetricRefusalReason.ALLOCATION_INVALID,
                    built_at,
                    group=group,
                    members=ids,
                )
            elif policy.double_counting is DoubleCountingMode.FLAG:
                built = _build_set(
                    member,
                    contract,
                    built_at,
                    reportability=reportability,
                    flag=SharedOutcomeFlag(group=group, members=ids),
                )
            else:
                built = _refusal(
                    member,
                    MetricRefusalReason.UNALLOCATED_SHARED_OUTCOME,
                    built_at,
                    group=group,
                    members=ids,
                )
            results[member.assessment_id] = built

    return tuple(results[effective.assessment_id] for effective in effectives)


# --- The Hermes contract adapter (D-15, ADR 0035 decision 3) ---------------------
#
# The only home of Hermes' lenient contract reading. EconomicsContract stays
# strict, and the compat projection never calls the adapter.

# The JSON-native copy behind a digest version drops a container nested deeper
# than this, so no document can exhaust the stack.
_NATIVE_MAX_DEPTH: Final = 64
# An int wider than this is dropped from the copy and is never a version:
# str() of a wide enough int raises under the interpreter's
# int_max_str_digits limit, whose floor is 640 digits.
_NATIVE_INT_MAX_BITS: Final = 2048
# The rate bound of ADR 0041's Phase 7 gap-closure note, item 3. The largest
# adjusted exponent a kept rate may have: that of the widest
# _NATIVE_INT_MAX_BITS int, since 2**2048 - 1 has 617 digits.
_RATE_MAX_ADJUSTED: Final = 616
# The smallest exponent a kept rate may have (note item 3): the costs
# _MIN_COST_EXPONENT floor of ADR 0030's Phase 6 addendum, below every
# Decimal(repr(x)) of a finite float, whose exponent is at least -324.
_RATE_MIN_EXPONENT: Final = -340


def _native_copy(value: object, depth: int, seen: set[int]) -> tuple[bool, JsonValue]:
    # A copy of ``value`` that canonical_json accepts, and whether to keep
    # it. Each container is copied once, so a cycle or a shared subtree is
    # dropped after its first appearance.
    if value is None or type(value) is bool or type(value) is str:
        return True, value
    if type(value) is int:
        return value.bit_length() <= _NATIVE_INT_MAX_BITS, value
    if type(value) is float:
        return math.isfinite(value), value
    if (
        not isinstance(value, Mapping | list | tuple)
        or depth >= _NATIVE_MAX_DEPTH
        or id(value) in seen
    ):
        return False, None
    seen.add(id(value))
    if isinstance(value, Mapping):
        copied: dict[str, JsonValue] = {}
        for key, item in value.items():
            if type(key) is str:
                keep, native = _native_copy(item, depth + 1, seen)
                if keep:
                    copied[key] = native
        return True, copied
    items: list[JsonValue] = []
    for item in value:
        keep, native = _native_copy(item, depth + 1, seen)
        if keep:
            items.append(native)
    return True, items


def _is_identifier(value: object) -> bool:
    # The bound of ADR 0035 decision 1, for exactly a str.
    return type(value) is str and is_bounded_printable(value, IDENTIFIER_MAX_BYTES)


def _hermes_metric_type(raw: object) -> MetricType | None:
    # Hermes compares the raw type text (omr.sh L162-L166).
    if isinstance(raw, str):
        for metric_type in MetricType:
            if metric_type.value == raw:
                return metric_type
    return None


def _hermes_currency_text(raw: object) -> Currency | None:
    # ASCII text only, stripped of ASCII whitespace and upper-cased in ASCII,
    # as Hermes' C-locale handling reads a currency (ca.sh L581). Unicode
    # case mapping would read "u" U+017F "d" as USD (ADR 0035 Phase 6 addendum).
    if isinstance(raw, str) and raw.isascii():
        text = raw.strip(_ASCII_WHITESPACE).upper()
        for currency in Currency:
            if currency.value == text:
                return currency
    return None


def _hermes_contract_currency(*raws: object) -> Currency | None:
    # Two different readable currencies are never resolved by picking one.
    readable = {
        currency
        for currency in (_hermes_currency_text(raw) for raw in raws)
        if currency is not None
    }
    return readable.pop() if len(readable) == 1 else None


def _rate_stand_in(negative: bool) -> Decimal:
    # 1E+616 with the rate's sign: the stand-in for a non-zero rate too large
    # to keep (ADR 0041 Phase 7 note item 3). It is still a declared rate, so
    # the builders refuse the set.
    return Decimal((1 if negative else 0, (1,), _RATE_MAX_ADJUSTED))


def _bounded_decimal_rate(raw: Decimal) -> Decimal:
    # ADR 0041 Phase 7 note item 3, for a finite, exact Decimal. Built from
    # the digit tuple with int arithmetic only, so no decimal context is read
    # (ADR 0002), and every result renders in at most 959 characters.
    sign, digits, exponent = raw.as_tuple()
    if type(exponent) is not int:  # pragma: no cover - the caller checks is_finite
        return raw
    if digits == (0,):
        # A zero declares magnitude 0, always in bound, so it never takes the
        # stand-in: Decimal("0E+5000").adjusted() is 5000. Outside the window
        # its exponent is clamped to the nearer end, which keeps its value
        # and its sign. (The money modules call no min or max.)
        if _RATE_MIN_EXPONENT <= exponent <= _RATE_MAX_ADJUSTED:
            return raw
        nearer = (
            _RATE_MIN_EXPONENT if exponent < _RATE_MIN_EXPONENT else _RATE_MAX_ADJUSTED
        )
        return Decimal((sign, (0,), nearer))
    if raw.adjusted() > _RATE_MAX_ADJUSTED:
        return _rate_stand_in(raw.is_signed())
    if exponent >= _RATE_MIN_EXPONENT:
        return raw
    # Truncate toward zero at the floor, keeping the leading
    # max(n - (-340 - e), 0) digits. The count is clamped at 0: a negative
    # slice end would keep digits and read 1.23E-343 as 1E-340.
    count = len(digits) - (_RATE_MIN_EXPONENT - exponent)
    kept = digits[:count] if count > 0 else (0,)
    return Decimal((sign, kept, _RATE_MIN_EXPONENT))


def _hermes_contract_value_per_unit(raw: object) -> Decimal | None:
    # ADR 0041 decision 3 and its Phase 7 gap-closure note: a finite JSON
    # number is a rate however the host's stdlib parser represents it. A
    # non-bool int, a finite float, or a finite, exact Decimal (as
    # json.loads(..., parse_float=Decimal) produces) is a rate. Anything
    # else, a non-finite float or Decimal, a subclass, a bool, text, or a
    # container, reads as no rate (assumption A2: Revenium rejects it at
    # ``economics set``). A Decimal rate is bounded by _bounded_decimal_rate.
    # An int wider than _NATIVE_INT_MAX_BITS is never converted, because
    # Decimal(int) takes quadratic time; it reads as the signed 1E+616
    # stand-in, still a declared rate (note item 3, code review WR-03).
    if type(raw) is int:
        if raw.bit_length() <= _NATIVE_INT_MAX_BITS:
            return Decimal(raw)
        return _rate_stand_in(raw < 0)
    if type(raw) is float and math.isfinite(raw):
        return Decimal(repr(raw))
    if type(raw) is Decimal and raw.is_finite():
        return _bounded_decimal_rate(raw)
    return None


def _hermes_contract_version(raw: object, document: object) -> str:
    if type(raw) is int and raw.bit_length() <= _NATIVE_INT_MAX_BITS:
        text = str(raw)
        if _is_identifier(text):
            return text
    if type(raw) is str and _is_identifier(raw):
        return raw
    _, native = _native_copy(document, 0, set())
    return hashlib.sha256(canonical_json(native)).hexdigest()


def from_hermes_contract(
    document: object,
    *,
    job_type: str,
    default_unit_key: str = OM_UNIT_METRIC_KEY_DEFAULT,
    default_currency: Currency | None = None,
) -> EconomicsContract:
    """Read a Revenium economics contract document as an ``EconomicsContract``.

    The only home of Hermes' lenient contract reading (D-15, ADR 0035
    decision 3). The rules follow Hermes' verdict body
    (outcome-metrics-report.sh, omr.sh, L146-L172 at d8714d83):

    - A document that is not a mapping reads as an empty mapping. Hermes'
      body crashes on it and skips the type.
    - ``metrics`` is read only when it is a list. Entries that are not dicts
      are ignored, an entry is keyed by its ``"key"`` when that is a str of
      at most 128 serialized printable bytes, and other entries are ignored.
      The last declaration of a key wins (omr.sh L151).
    - A ``type`` whose text is a ``MetricType`` value reads as that member.
      Any other type, including an absent one, reads as ``None``, so the
      contract is refused as mistyped (omr.sh L162-L166).
    - A ``unitMetricKey`` that is falsy, not a str, or outside the same bound
      reads as ``default_unit_key`` (omr.sh L167).
    - The currency is read from ``monetization.currency``, where the
      contract omr.sh creates declares it (L215-L216), and from a top-level
      ``currency``. Each is read only when it is ASCII text, stripped of
      ASCII whitespace and upper-cased, that names a member. A currency
      spelled with a long s (U+017F) or padded with a no-break space is
      unreadable. When the readable values name exactly one
      currency, that is the contract currency. Otherwise it is ``None``, and
      the builder refuses as CONTRACT_CURRENCY_UNDECLARED (ID-20). Hermes
      never reads a currency.
    - ``default_currency`` is the contract currency only when neither
      ``monetization.currency`` nor a top-level ``currency`` key is present,
      as in the contract omr.sh creates since 44bad57 (L201-L229). Presence
      is the test, not readability: a present but unreadable or conflicting
      currency still reads as ``None`` (ADR 0041 decision 1).
    - ``monetization.valuePerUnit`` is the contract's per-unit rate when it
      is an int that is not a bool (``Decimal(x)``), a finite float
      (``Decimal(repr(x))``), or an exact, finite ``Decimal`` (kept), so a
      document parsed with ``json.loads(..., parse_float=Decimal)`` reads
      the same rate. A non-zero rate outside the bound of ADR 0041's Phase 7
      note is kept as a bounded stand-in of the same sign, so the builders
      still refuse it, and a zero keeps its value and sign with its
      exponent clamped into the bound. Anything else, an absent key, a
      subclass of these types, or a non-finite value included, reads as no
      rate (ADR 0041 decision 3 and its Phase 7 note). Contracts omr.sh
      created before 44bad57 declare
      ``valuePerUnit`` 1.0 (omr.sh L201-L229 at 44bad57 explains its
      removal), and the builders refuse any rate as
      CONTRACT_MONETIZATION_OVERRIDES_VALUE (ADR 0041 decisions 3 and 4).
    - The version is the document's ``"version"`` when that is an int that
      is not a bool (rendered with ``str()``) or a str within the same
      bound. Otherwise it is the sha256 hex of ``canonical_json`` of the
      document's JSON-native content (A9). That copy keeps exact str, bool,
      None, finite float, and int of at most 2048 bits, mappings (str keys
      only), lists, and tuples, at most 64 containers deep and each
      container once; it drops anything else. A digest version changes on
      any change to the document, including server-side metadata such as an
      ``updatedAt`` field, which re-keys unchanged metrics, so supply a
      stable ``"version"`` (ADR 0034 WR-02 addendum).

    Args:
        document: The contract document, as the host parsed it.
        job_type: The job type the contract is keyed by (ADR 0013 grammar).
        default_unit_key: The unit metric key when the document names none
            usable, Hermes' ``OM_UNIT_METRIC_KEY`` (omr.sh L33).
        default_currency: The host's configured currency, used only when the
            document has no currency key at all (ADR 0041 decision 1).

    Returns:
        The strict contract. Whether it fits the four intents is decided by
        :func:`build_outcome_metrics`.

    Raises:
        ConfigurationError: If ``job_type`` fails the job-type grammar, or
            ``default_unit_key`` is not non-empty printable text of at most
            128 serialized bytes, or ``default_currency`` is not exactly a
            ``Currency`` or ``None``. The message names the argument, never
            its value. No document raises.
    """
    if type(job_type) is not str or validate_label(job_type) != job_type:
        raise ConfigurationError("job_type must be a label in the job-type grammar")
    if not _is_identifier(default_unit_key):
        raise ConfigurationError(
            "default_unit_key must be non-empty printable text of at most "
            f"{IDENTIFIER_MAX_BYTES} serialized bytes"
        )
    if default_currency is not None and type(default_currency) is not Currency:
        raise ConfigurationError("default_currency must be a Currency or None")
    config: Mapping[str, object] = document if isinstance(document, Mapping) else {}
    declared: dict[str, MetricType | None] = {}
    entries = config.get("metrics")
    for entry in entries if isinstance(entries, list) else ():
        if isinstance(entry, dict):
            key = entry.get("key")
            if _is_identifier(key):
                declared[str(key)] = _hermes_metric_type(entry.get("type"))
    unit = config.get("unitMetricKey")
    # Hermes wrote the currency under monetization (omr.sh L215-L216); a
    # top-level currency is read too. Since 44bad57 the created contract has
    # neither, and the caller's default applies (ADR 0041 decision 1).
    monetization = config.get("monetization")
    monetization_fields: Mapping[object, object] = (
        monetization if isinstance(monetization, Mapping) else {}
    )
    declares_currency = "currency" in config or "currency" in monetization_fields
    return EconomicsContract(
        job_type=job_type,
        version=_hermes_contract_version(config.get("version"), document),
        currency=(
            _hermes_contract_currency(
                monetization_fields.get("currency"), config.get("currency")
            )
            if declares_currency
            else default_currency
        ),
        metrics=tuple(
            MetricDeclaration(key=key, metric_type=metric_type)
            for key, metric_type in declared.items()
        ),
        unit_metric_key=str(unit) if _is_identifier(unit) else default_unit_key,
        value_per_unit=_hermes_contract_value_per_unit(
            monetization_fields.get("valuePerUnit")
        ),
    )
