"""Exceptions raised by the library."""


class RaeError(Exception):
    """Base class for every error the library raises."""


class CanonicalizationError(RaeError):
    """A value cannot be encoded as canonical JSON."""


class ConfigurationError(RaeError):
    """A composition or input violates a documented contract.

    Raised for an invalid ``EngineConfig`` value, a taxonomy snapshot of the
    wrong namespace type, or a port that returns a value of the wrong type.
    Messages format any caller-supplied name with ``!r``.
    """


class CompletionUnavailable(RaeError):
    """A ``ModelCompletion`` port could not obtain a completion.

    Ports raise it to signal a provider failure. The engine maps it to the
    provider-side ``UNAVAILABLE`` abstention and records only the type name.
    """


class RecordValidationError(RaeError):
    """A record field holds a value its schema does not allow.

    Attributes:
        schema_id: The schema id of the record being validated.
        field: The name of the offending field.
        reason: Why the value was rejected.
    """

    schema_id: str
    field: str
    reason: str

    def __init__(self, schema_id: str, field: str, reason: str) -> None:
        """Record which field of which schema failed and why.

        Args:
            schema_id: The schema id of the record being validated.
            field: The name of the offending field.
            reason: Why the value was rejected.
        """
        super().__init__(schema_id, field, reason)
        self.schema_id = schema_id
        self.field = field
        self.reason = reason

    def __str__(self) -> str:
        """Format the location with repr so untrusted names cannot forge output."""
        return f"schema {self.schema_id!r} field {self.field!r}: {self.reason}"


class UnsupportedSchemaError(RaeError):
    """Serialized input names a schema id or version with no decoder or migration.

    Attributes:
        schema_id: The schema id found in the input.
        schema_version: The schema version found in the input.
    """

    schema_id: str
    schema_version: int

    def __init__(self, schema_id: str, schema_version: int) -> None:
        """Record the unsupported schema identity.

        Args:
            schema_id: The schema id found in the input.
            schema_version: The schema version found in the input.
        """
        super().__init__(schema_id, schema_version)
        self.schema_id = schema_id
        self.schema_version = schema_version

    def __str__(self) -> str:
        """Format the identity with repr so untrusted input cannot forge output."""
        return f"unsupported schema {self.schema_id!r} version {self.schema_version!r}"
