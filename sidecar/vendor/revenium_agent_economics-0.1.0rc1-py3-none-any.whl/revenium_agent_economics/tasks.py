"""The task prompt as data, the pure prompt builder and parser, and task decisions.

The engine and a sync host call the same :func:`build_task_prompt` and
:func:`parse_task_response`, so both render and decide identical bytes (D-22,
ADR 0012). The default template renders byte-identically to the Hermes
reference prompt at ``5c2bfea8`` (D-11, ADR 0010).
"""

import hashlib
import re
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime, timedelta
from types import MappingProxyType
from typing import ClassVar, Final

from revenium_agent_economics._bounded import (
    IFS_CHARACTERS,
    INFERENCE_PROVIDER_MAX_BYTES,
    PROVENANCE_MODEL_MAX_BYTES,
    SUBJECT_REF_MAX_BYTES,
    is_bounded_printable,
    normalize_text,
    serialized_byte_length,
)
from revenium_agent_economics._canonical import canonical_json
from revenium_agent_economics._version import __version__
from revenium_agent_economics.config import EngineConfig
from revenium_agent_economics.errors import ConfigurationError, RecordValidationError
from revenium_agent_economics.primitives import (
    Money,
    _require_exact_type,
    _require_text,
    _require_version_number,
)
from revenium_agent_economics.protocols import (
    AddressClass,
    CompletionMessage,
    CompletionPurpose,
    CompletionRequest,
    CompletionResult,
    ComponentDeclaration,
    FinishReason,
    MessageRole,
    TokenUsage,
)
from revenium_agent_economics.taxonomy import (
    MODEL_SIDE_REASONS,
    PROVIDER_SIDE_REASONS,
    ClassificationAbstentionReason,
    LabelProposal,
    TaskTaxonomySnapshot,
    TaxonomyNamespace,
    TaxonomyRef,
    is_valid_label,
    validate_label,
)
from revenium_agent_economics.vocab import (
    TRIVIAL_LABELS,
    UNCLASSIFIED_LABEL,
    EvidenceClass,
)

_SLOT: Final = re.compile(r"\{\{([a-z_]+)\}\}")
_SYSTEM_SLOTS: Final = ("host_display_name",)
_USER_SLOTS: Final = (
    "assistant_preview",
    "host_display_name",
    "labels",
    "user_preview",
)
_SHA256_HEX: Final = re.compile(r"[0-9a-f]{64}")
_HOST_DISPLAY_NAME_MAX_BYTES: Final = 64
_NO_LABELS: Final = "(no existing labels yet)"
_TRUNCATED: Final = " ... [truncated]"
_NO_TAXONOMY_REASONS: Final[frozenset[ClassificationAbstentionReason]] = frozenset(
    {
        ClassificationAbstentionReason.NOT_CONFIGURED,
        ClassificationAbstentionReason.TAXONOMY_UNAVAILABLE,
    }
)


def _render(template: str, values: Mapping[str, str]) -> str:
    # Split once: even indices are literal text, odd indices are slot names.
    # Substituted values are never rescanned, so a preview that contains a
    # slot marker cannot inject text into a later slot.
    parts = _SLOT.split(template)
    return "".join(
        values[part] if index % 2 else part for index, part in enumerate(parts)
    )


@dataclass(frozen=True, slots=True, kw_only=True)
class PromptTemplate:
    """A versioned prompt held as data (D-11).

    Slots are written ``{{name}}``. The system text has exactly the
    ``host_display_name`` slot, and the user text has exactly the
    ``host_display_name``, ``labels``, ``user_preview``, and
    ``assistant_preview`` slots, each once. This is configuration, not a
    schema record.

    Attributes:
        name: The template family name.
        version: The prompt version, at least 1.
        system: The system message template.
        user: The user message template.
    """

    name: str
    version: int
    system: str
    user: str

    def __post_init__(self) -> None:
        """Validate the name, version, and slot sets.

        Raises:
            ConfigurationError: If any field is invalid.
        """
        if type(self.name) is not str or self.name == "":
            raise ConfigurationError(f"name must be non-empty text, got {self.name!r}")
        if type(self.version) is not int or self.version < 1:
            raise ConfigurationError(
                f"version must be an int of at least 1, got {self.version!r}"
            )
        for field, text, expected in (
            ("system", self.system, _SYSTEM_SLOTS),
            ("user", self.user, _USER_SLOTS),
        ):
            if type(text) is not str:
                raise ConfigurationError(f"{field} must be text, got {text!r}")
            found = tuple(sorted(_SLOT.findall(text)))
            if found != expected:
                raise ConfigurationError(
                    f"{field} must use each of the slots {expected!r} exactly once, "
                    f"found {found!r}"
                )

    @property
    def template_hash(self) -> str:
        """The lowercase hexadecimal SHA-256 of the unfilled template (D-12)."""
        return hashlib.sha256(
            canonical_json(
                {"name": self.name, "system": self.system, "user": self.user}
            )
        ).hexdigest()

    def render_system(self, host_display_name: str) -> str:
        """Render the system message.

        Args:
            host_display_name: The host name for the ``host_display_name`` slot.

        Returns:
            The system message text.
        """
        return _render(self.system, {"host_display_name": host_display_name})

    def render_user(
        self,
        *,
        host_display_name: str,
        labels: str,
        user_preview: str,
        assistant_preview: str,
    ) -> str:
        """Render the user message.

        Args:
            host_display_name: The host name.
            labels: The rendered label list.
            user_preview: The truncated user message.
            assistant_preview: The truncated assistant response.

        Returns:
            The user message text.
        """
        return _render(
            self.user,
            {
                "host_display_name": host_display_name,
                "labels": labels,
                "user_preview": user_preview,
                "assistant_preview": assistant_preview,
            },
        )


TASK_PROMPT_NAME: Final = "task_classification"

# Hermes classifier.py:L4453 (system) and L4391-L4420 (user) at
# 5c2bfea8f9013e7b4521eb2153e62bd435d2bc17, with "Hermes" replaced by the
# host_display_name slot and the three interpolations replaced by slots.
DEFAULT_TASK_PROMPT: Final[PromptTemplate] = PromptTemplate(
    name=TASK_PROMPT_NAME,
    version=1,
    system=(
        "You classify {{host_display_name}} turns into task_type labels. "
        "Output only the label."
    ),
    user=(
        "You are classifying a {{host_display_name}} session turn for spend "
        "attribution. "
        "Output ONLY a single snake_case label, no explanation, no quotes, "
        "no punctuation.\n\n"
        "Mint a SPECIFIC, DESCRIPTIVE label that captures what the agent "
        "actually did. "
        "Use 2-4 words joined by underscores.\n\n"
        "AVOID bland catch-all labels like generation, analysis, review, task "
        "when a more specific label fits.\n\n"
        "Existing labels (for reference): {{labels}}\n\n"
        "You MAY reuse one of the existing labels, but only if it describes "
        "the SAME specific work \u2014 "
        "not 'close enough'. If no existing label is an exact match for this "
        "work, mint a new one.\n\n"
        "Label format: ^[a-z][a-z0-9_]{1,47}$\n"
        "Forbidden labels (do NOT emit): ack, acknowledgment, greeting, "
        "confirmation, hello, thanks.\n\n"
        "User message preview:\n{{user_preview}}\n\n"
        "Assistant response preview:\n{{assistant_preview}}\n\n"
        "Label:"
    ),
)
TASK_PROMPT_HASHES: Final[Mapping[tuple[str, int], str]] = MappingProxyType(
    {(TASK_PROMPT_NAME, 1): DEFAULT_TASK_PROMPT.template_hash}
)

BUILTIN_TASK_CLASSIFIER: Final[ComponentDeclaration] = ComponentDeclaration(
    name="llm", version="1", evidence_class=EvidenceClass.MODEL_ESTIMATED
)


def _require_host_display_name(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, str, schema_id, field)
    if not is_bounded_printable(str(value), _HOST_DISPLAY_NAME_MAX_BYTES):
        raise RecordValidationError(
            schema_id,
            field,
            "must be non-empty printable text within "
            f"{_HOST_DISPLAY_NAME_MAX_BYTES} serialized bytes",
        )


def _require_subject_ref(value: object, schema_id: str) -> None:
    if value is None:
        return
    _require_exact_type(value, str, schema_id, "subject_ref")
    if not is_bounded_printable(str(value), SUBJECT_REF_MAX_BYTES):
        raise RecordValidationError(
            schema_id,
            "subject_ref",
            "must be non-empty printable text within "
            f"{SUBJECT_REF_MAX_BYTES} serialized bytes",
        )


def _require_utc(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, datetime, schema_id, field)
    if not isinstance(value, datetime) or value.utcoffset() != timedelta(0):
        raise RecordValidationError(
            schema_id, field, "must be an aware datetime with a zero UTC offset"
        )


def _require_task_taxonomy(value: object, schema_id: str) -> None:
    _require_exact_type(value, TaxonomyRef, schema_id, "taxonomy")
    if (
        not isinstance(value, TaxonomyRef)
        or value.namespace is not TaxonomyNamespace.TASK
    ):
        raise RecordValidationError(
            schema_id, "taxonomy", "must reference a task taxonomy"
        )


def _require_provenance_text(
    value: object, schema_id: str, field: str, max_bytes: int
) -> None:
    if value is None:
        return
    _require_exact_type(value, str, schema_id, field)
    text = str(value)
    if text == "" or any(character in text for character in IFS_CHARACTERS):
        raise RecordValidationError(
            schema_id, field, "must be non-empty normalized text"
        )
    if serialized_byte_length(text) > max_bytes:
        raise RecordValidationError(
            schema_id, field, f"must be within {max_bytes} serialized bytes"
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class PromptRef:
    """Which prompt, under which host framing, produced a decision (D-12).

    Attributes:
        name: The template family name.
        version: The prompt version.
        template_hash: The SHA-256 of the unfilled template.
        host_display_name: The host name rendered into the prompt.
    """

    SCHEMA_ID: ClassVar[str] = "rae.prompt_ref"
    SCHEMA_VERSION: ClassVar[int] = 1

    name: str
    version: int
    template_hash: str
    host_display_name: str

    def __post_init__(self) -> None:
        """Validate every field.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = PromptRef.SCHEMA_ID
        _require_text(self.name, schema_id, "name")
        _require_version_number(self.version, schema_id, "version")
        _require_exact_type(self.template_hash, str, schema_id, "template_hash")
        if _SHA256_HEX.fullmatch(self.template_hash) is None:
            raise RecordValidationError(
                schema_id,
                "template_hash",
                "must be 64 lowercase hexadecimal characters",
            )
        _require_host_display_name(
            self.host_display_name, schema_id, "host_display_name"
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class InferenceProvenance:
    """What the host reported about the completion behind a decision (D-01, D-03).

    Attributes:
        finish_reason: Why the model stopped. It never changes the decision.
        served_model: The serving model, clamped to 64 serialized bytes.
        provider: The provider name, clamped to 32 serialized bytes.
        address_class: The endpoint's network class.
        usage: Token counts, if reported.
        cost: The metered cost, if reported.
    """

    SCHEMA_ID: ClassVar[str] = "rae.inference_provenance"
    SCHEMA_VERSION: ClassVar[int] = 1

    finish_reason: FinishReason
    served_model: str | None
    provider: str | None
    address_class: AddressClass
    usage: TokenUsage | None
    cost: Money | None

    def __post_init__(self) -> None:
        """Validate exact types and the byte bounds.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = InferenceProvenance.SCHEMA_ID
        _require_exact_type(
            self.finish_reason, FinishReason, schema_id, "finish_reason"
        )
        _require_provenance_text(
            self.served_model, schema_id, "served_model", PROVENANCE_MODEL_MAX_BYTES
        )
        _require_provenance_text(
            self.provider, schema_id, "provider", INFERENCE_PROVIDER_MAX_BYTES
        )
        _require_exact_type(
            self.address_class, AddressClass, schema_id, "address_class"
        )
        if self.usage is not None:
            _require_exact_type(self.usage, TokenUsage, schema_id, "usage")
        if self.cost is not None:
            _require_exact_type(self.cost, Money, schema_id, "cost")


def inference_provenance(result: CompletionResult) -> InferenceProvenance:
    """Record a completion's metadata with the Hermes provenance clamps.

    ``served_model`` and ``provider`` pass through the shared normalizer at 64
    and 32 serialized bytes. A value that normalizes to empty becomes ``None``.

    Args:
        result: The port's completion result.

    Returns:
        The bounded provenance.

    Raises:
        ConfigurationError: If ``result`` is not a ``CompletionResult``.
    """
    if type(result) is not CompletionResult:
        raise ConfigurationError(
            f"CompletionResult required, got {type(result).__name__!r}"
        )
    served_model = None
    if result.served_model is not None:
        served_model = (
            normalize_text(result.served_model, max_bytes=PROVENANCE_MODEL_MAX_BYTES)
            or None
        )
    provider = None
    if result.provider is not None:
        provider = (
            normalize_text(result.provider, max_bytes=INFERENCE_PROVIDER_MAX_BYTES)
            or None
        )
    return InferenceProvenance(
        finish_reason=result.finish_reason,
        served_model=served_model,
        provider=provider,
        address_class=result.address_class,
        usage=result.usage,
        cost=result.cost,
    )


@dataclass(frozen=True, slots=True, kw_only=True)
class TaskClassificationRequest:
    """One turn a host asks the engine to classify.

    Attributes:
        user_message: The user's message, if any.
        assistant_response: The assistant's response, if any.
        subject_ref: An opaque host key echoed on the decision: non-empty
            printable text within 128 serialized bytes. Out-of-bounds values
            are rejected, never clamped (D-23).
    """

    SCHEMA_ID: ClassVar[str] = "rae.task_classification_request"
    SCHEMA_VERSION: ClassVar[int] = 1

    user_message: str | None = None
    assistant_response: str | None = None
    subject_ref: str | None = None

    def __post_init__(self) -> None:
        """Validate exact types and the subject reference bound.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = TaskClassificationRequest.SCHEMA_ID
        if self.user_message is not None:
            _require_exact_type(self.user_message, str, schema_id, "user_message")
        if self.assistant_response is not None:
            _require_exact_type(
                self.assistant_response, str, schema_id, "assistant_response"
            )
        _require_subject_ref(self.subject_ref, schema_id)


@dataclass(frozen=True, slots=True, kw_only=True)
class TaskClassification:
    """A task label and everything needed to audit it later.

    Attributes:
        label: The validated label. Never trivial and never the reserved
            ``"unclassified"``.
        taxonomy: The task taxonomy the label was chosen against.
        prompt: The prompt that produced it, on the model path.
        inference: The completion metadata, on the model path.
        classifier: The component that produced the label.
        proposal: Set when the label is not in the taxonomy.
        classified_at: When the decision was made, from the injected clock.
        subject_ref: The request's subject reference, echoed.
        library_version: The library version that made the decision.
    """

    SCHEMA_ID: ClassVar[str] = "rae.task_classification"
    SCHEMA_VERSION: ClassVar[int] = 1

    label: str
    taxonomy: TaxonomyRef
    prompt: PromptRef | None
    inference: InferenceProvenance | None
    classifier: ComponentDeclaration
    proposal: LabelProposal | None = None
    classified_at: datetime
    subject_ref: str | None = None
    library_version: str

    def __post_init__(self) -> None:
        """Validate the label, references, and their consistency.

        Raises:
            RecordValidationError: If any field is invalid or inconsistent.
        """
        schema_id = TaskClassification.SCHEMA_ID
        _require_exact_type(self.label, str, schema_id, "label")
        if not is_valid_label(self.label):
            raise RecordValidationError(schema_id, "label", "fails the label grammar")
        if self.label in TRIVIAL_LABELS or self.label == UNCLASSIFIED_LABEL:
            raise RecordValidationError(
                schema_id, "label", "must not be trivial or the reserved label"
            )
        _require_task_taxonomy(self.taxonomy, schema_id)
        if self.prompt is not None:
            _require_exact_type(self.prompt, PromptRef, schema_id, "prompt")
        if self.inference is not None:
            _require_exact_type(
                self.inference, InferenceProvenance, schema_id, "inference"
            )
        if (self.prompt is None) != (self.inference is None):
            raise RecordValidationError(
                schema_id, "inference", "prompt and inference must both be set or unset"
            )
        _require_exact_type(
            self.classifier, ComponentDeclaration, schema_id, "classifier"
        )
        if self.proposal is not None:
            _require_exact_type(self.proposal, LabelProposal, schema_id, "proposal")
            if (
                self.proposal.label != self.label
                or self.proposal.taxonomy != self.taxonomy
            ):
                raise RecordValidationError(
                    schema_id,
                    "proposal",
                    "must carry the decision's label and taxonomy",
                )
        _require_utc(self.classified_at, schema_id, "classified_at")
        _require_subject_ref(self.subject_ref, schema_id)
        _require_text(self.library_version, schema_id, "library_version")


@dataclass(frozen=True, slots=True, kw_only=True)
class ClassificationAbstention:
    """A task classification with no usable label, and why (D-04, D-06).

    Everything except the label is kept: the taxonomy, prompt, and inference
    that were reached before the classification stopped.

    Attributes:
        reason: Why there is no label.
        taxonomy: The task taxonomy read. ``None`` exactly for
            ``NOT_CONFIGURED`` and ``TAXONOMY_UNAVAILABLE``.
        prompt: The prompt, once one was built.
        inference: The completion metadata, once a result was received.
        classifier: The component invoked. ``None`` exactly when
            ``taxonomy`` is ``None``.
        classified_at: When the decision was made, from the injected clock.
        subject_ref: The request's subject reference, echoed.
        library_version: The library version that made the decision.
    """

    SCHEMA_ID: ClassVar[str] = "rae.classification_abstention"
    SCHEMA_VERSION: ClassVar[int] = 1

    reason: ClassificationAbstentionReason
    taxonomy: TaxonomyRef | None
    prompt: PromptRef | None = None
    inference: InferenceProvenance | None = None
    classifier: ComponentDeclaration | None
    classified_at: datetime
    subject_ref: str | None = None
    library_version: str

    def __post_init__(self) -> None:
        """Validate the reason, references, and their consistency.

        Raises:
            RecordValidationError: If any field is invalid or inconsistent.
        """
        schema_id = ClassificationAbstention.SCHEMA_ID
        _require_exact_type(
            self.reason, ClassificationAbstentionReason, schema_id, "reason"
        )
        if self.taxonomy is not None:
            _require_task_taxonomy(self.taxonomy, schema_id)
        if (self.taxonomy is None) != (self.reason in _NO_TAXONOMY_REASONS):
            raise RecordValidationError(
                schema_id,
                "taxonomy",
                "must be unset exactly for not_configured and taxonomy_unavailable",
            )
        if self.classifier is not None:
            _require_exact_type(
                self.classifier, ComponentDeclaration, schema_id, "classifier"
            )
        if (self.classifier is None) != (self.taxonomy is None):
            raise RecordValidationError(
                schema_id, "classifier", "must be unset exactly when taxonomy is unset"
            )
        if self.prompt is not None:
            _require_exact_type(self.prompt, PromptRef, schema_id, "prompt")
            if self.taxonomy is None:
                raise RecordValidationError(schema_id, "prompt", "requires a taxonomy")
        if self.inference is not None:
            _require_exact_type(
                self.inference, InferenceProvenance, schema_id, "inference"
            )
            if self.prompt is None:
                raise RecordValidationError(schema_id, "inference", "requires a prompt")
        _require_utc(self.classified_at, schema_id, "classified_at")
        _require_subject_ref(self.subject_ref, schema_id)
        _require_text(self.library_version, schema_id, "library_version")

    @property
    def is_model_side(self) -> bool:
        """Whether a classifier answered but the answer was not a usable label."""
        return self.reason in MODEL_SIDE_REASONS

    @property
    def is_provider_side(self) -> bool:
        """Whether no answer was obtained."""
        return self.reason in PROVIDER_SIDE_REASONS


def _resolve_host_display_name(
    config: EngineConfig, host_display_name: str | None
) -> str:
    if type(config) is not EngineConfig:
        raise ConfigurationError(
            f"EngineConfig required, got {type(config).__name__!r}"
        )
    if host_display_name is None:
        return config.host_display_name
    if type(host_display_name) is not str or not is_bounded_printable(
        host_display_name, _HOST_DISPLAY_NAME_MAX_BYTES
    ):
        raise ConfigurationError(
            "host_display_name must be non-empty printable text within "
            f"{_HOST_DISPLAY_NAME_MAX_BYTES} serialized bytes, "
            f"got {host_display_name!r}"
        )
    return host_display_name


def _require_task_snapshot(snapshot: object) -> TaskTaxonomySnapshot:
    if type(snapshot) is TaskTaxonomySnapshot:
        return snapshot
    raise ConfigurationError(
        f"TaskTaxonomySnapshot required, got {type(snapshot).__name__!r}"
    )


def task_prompt_ref(
    *, config: EngineConfig, host_display_name: str | None = None
) -> PromptRef:
    """Return the reference for the default task prompt under a host framing.

    Args:
        config: The engine configuration.
        host_display_name: The host name, or ``None`` for
            ``config.host_display_name``.

    Returns:
        The prompt reference a decision records.

    Raises:
        ConfigurationError: If ``config`` or ``host_display_name`` is invalid.
    """
    host = _resolve_host_display_name(config, host_display_name)
    return PromptRef(
        name=DEFAULT_TASK_PROMPT.name,
        version=DEFAULT_TASK_PROMPT.version,
        template_hash=DEFAULT_TASK_PROMPT.template_hash,
        host_display_name=host,
    )


def build_task_prompt(
    user_message: str | None,
    assistant_response: str | None,
    snapshot: TaskTaxonomySnapshot,
    *,
    config: EngineConfig,
    host_display_name: str | None = None,
) -> CompletionRequest:
    """Render the task classification request for one turn (D-11, D-22).

    Truncation is character-based, as in Hermes: each preview keeps its first
    ``config.preview_max_chars`` characters, and a label list longer than
    ``config.labels_block_max_chars`` is cut to that length plus
    ``" ... [truncated]"``.

    Args:
        user_message: The user's message, or ``None``.
        assistant_response: The assistant's response, or ``None``.
        snapshot: The task taxonomy, rendered in its own order.
        config: The engine configuration.
        host_display_name: The host name, or ``None`` for
            ``config.host_display_name``.

    Returns:
        The system and user messages with the configured call parameters.

    Raises:
        ConfigurationError: If ``snapshot`` is not exactly a
            ``TaskTaxonomySnapshot``, or another argument is invalid.
    """
    task_snapshot = _require_task_snapshot(snapshot)
    host = _resolve_host_display_name(config, host_display_name)
    for name, text in (
        ("user_message", user_message),
        ("assistant_response", assistant_response),
    ):
        if text is not None and type(text) is not str:
            raise ConfigurationError(
                f"{name} must be text or None, got {type(text).__name__!r}"
            )
    labels = ", ".join(task_snapshot.labels) if task_snapshot.labels else _NO_LABELS
    if len(labels) > config.labels_block_max_chars:
        labels = labels[: config.labels_block_max_chars] + _TRUNCATED
    limit = config.preview_max_chars
    template = DEFAULT_TASK_PROMPT
    return CompletionRequest(
        messages=(
            CompletionMessage(
                role=MessageRole.SYSTEM, content=template.render_system(host)
            ),
            CompletionMessage(
                role=MessageRole.USER,
                content=template.render_user(
                    host_display_name=host,
                    labels=labels,
                    user_preview=(user_message or "")[:limit],
                    assistant_preview=(assistant_response or "")[:limit],
                ),
            ),
        ),
        max_tokens=config.max_tokens,
        temperature=float(config.temperature),
        purpose=CompletionPurpose.TASK_CLASSIFICATION,
    )


def parse_task_response(
    raw: object,
    snapshot: TaskTaxonomySnapshot,
    *,
    prompt_ref: PromptRef | None,
    classified_at: datetime,
    provenance: InferenceProvenance | None,
    classifier: ComponentDeclaration = BUILTIN_TASK_CLASSIFIER,
    subject_ref: str | None = None,
) -> TaskClassification | ClassificationAbstention:
    """Turn raw classifier or model output into a decision (D-22, ADR 0012).

    ``None`` is ``ABSTAINED``. On the model path (``provenance`` set), text is
    stripped first, as Hermes does. The result then passes
    :func:`~revenium_agent_economics.taxonomy.validate_label`. The reserved
    label becomes ``ABSTAINED``, and a label missing from the snapshot carries
    a :class:`~revenium_agent_economics.taxonomy.LabelProposal`.

    Args:
        raw: The classifier or model output.
        snapshot: The task taxonomy the output was produced against.
        prompt_ref: The prompt reference, on the model path.
        classified_at: The decision time, from the injected clock.
        provenance: The completion metadata, on the model path.
        classifier: The component that produced ``raw``.
        subject_ref: The request's subject reference.

    Returns:
        A classification, or an abstention with a model-side reason.

    Raises:
        ConfigurationError: If ``snapshot`` is not exactly a
            ``TaskTaxonomySnapshot``.
    """
    task_snapshot = _require_task_snapshot(snapshot)
    ref = task_snapshot.ref
    if raw is not None and provenance is not None and type(raw) is str:
        raw = raw.strip()
    result = (
        ClassificationAbstentionReason.ABSTAINED if raw is None else validate_label(raw)
    )
    if result == UNCLASSIFIED_LABEL:
        result = ClassificationAbstentionReason.ABSTAINED
    if type(result) is ClassificationAbstentionReason:
        return ClassificationAbstention(
            reason=result,
            taxonomy=ref,
            prompt=prompt_ref,
            inference=provenance,
            classifier=classifier,
            classified_at=classified_at,
            subject_ref=subject_ref,
            library_version=__version__,
        )
    label = str(result)
    proposal = (
        None
        if label in task_snapshot.labels
        else LabelProposal(namespace=ref.namespace, label=label, taxonomy=ref)
    )
    return TaskClassification(
        label=label,
        taxonomy=ref,
        prompt=prompt_ref,
        inference=provenance,
        classifier=classifier,
        proposal=proposal,
        classified_at=classified_at,
        subject_ref=subject_ref,
        library_version=__version__,
    )
