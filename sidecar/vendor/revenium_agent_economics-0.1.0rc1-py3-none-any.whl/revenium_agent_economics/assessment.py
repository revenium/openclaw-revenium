"""The assessment request, policy, records, and assessment id (ADR 0030).

``Engine.assess_job`` turns one host-resolved :class:`AssessJobRequest` into a
:class:`JobAssessment` or an :class:`AssessmentAbstention` under an explicit
:class:`AssessmentPolicy`. Both records keep identity, provenance, costs, and
coverage on every branch (VAL-09). Only a ``JobAssessment`` carries a value,
and its value is derived from gated operands by trusted code.
"""

import decimal
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from typing import ClassVar, Final

from revenium_agent_economics._bounded import (
    ASSESSMENT_ID_MAX_BYTES as ASSESSMENT_ID_MAX_BYTES,
)
from revenium_agent_economics._bounded import (
    DOUBLE_COUNTING_GROUP_MAX_BYTES,
    EVALUATOR_MAX_BYTES,
    EVALUATOR_VERSION_MAX_BYTES,
    IFS_CHARACTERS,
    INFERENCE_PROVIDER_MAX_BYTES,
    NARRATIVE_CLAMP_BYTES,
    PROVENANCE_MODEL_MAX_BYTES,
    clamp_bytes,
    finite_number,
    normalize_text,
    serialized_byte_length,
)
from revenium_agent_economics._version import __version__
from revenium_agent_economics.costs import (
    SUPPLIED_COST_LIMIT,
    RoiOperands,
    SuppliedCosts,
    ValueSideState,
    _require_amount_bounds,
    cost_coverage,
    net_value,
)
from revenium_agent_economics.errors import ConfigurationError, RecordValidationError
from revenium_agent_economics.evidence import ReportabilityPolicy, ResolvedEvidence
from revenium_agent_economics.jobs import (
    JobCandidate,
    JobOutcome,
    _require_clamped_text,
    _require_job_id,
)
from revenium_agent_economics.outcomes import (
    OperandBounds,
    OutcomeAbstention,
    OutcomeAssertion,
    OutcomeProposal,
    _require_narrative,
)
from revenium_agent_economics.primitives import (
    Confidence,
    Money,
    StudyReference,
    _require_exact_type,
    _require_minor_unit_scale,
    _require_text,
    _require_version_number,
    decimal_from_float,
    quantize_money,
)
from revenium_agent_economics.protocols import (
    INFERRED_ROLE_MAX_BYTES,
    AddressClass,
    ComponentDeclaration,
    ResolvedAssumptions,
)
from revenium_agent_economics.tasks import _require_subject_ref, _require_utc
from revenium_agent_economics.taxonomy import _require_version_text, is_valid_label
from revenium_agent_economics.valuation import (
    DEFAULT_DERIVED_BAND,
    DerivedBand,
    FallbackPolicy,
    OperandBases,
    PolicyErrorMode,
    RateCardFigures,
    RevenueCardEntry,
    RevenueCardFigures,
    ValuationFigures,
    ValuationMethod,
    ValuationOperand,
    ValuationResult,
    active_ceiling,
    derive_band,
    hours_times_rate,
    require_operand_bases,
    weakest_claim_basis,
)
from revenium_agent_economics.valuation import _is_card_key as _is_card_key
from revenium_agent_economics.valuation import _is_role_text as _is_role_text
from revenium_agent_economics.vocab import (
    BOUNDS_SOURCE_DERIVED,
    COST_CATEGORIES,
    ECONOMIC_MECHANISM_UNKNOWN,
    OPERATOR_ONLY_MECHANISMS,
    REPORTABLE_EVIDENCE_CLASSES,
    STUDY_EVIDENCE_CLASSES,
    AbstentionReason,
    AssessmentRefusal,
    ClaimBasis,
    Currency,
    EconomicMechanism,
    EvidenceAuthority,
    EvidenceClass,
    ReportabilityReason,
    ReportabilityStatus,
)

SEQUENCE_MAX: Final = 2**63 - 1
MODEL_UNKNOWN: Final = "unknown"
_ASSESSMENT_SCHEMA_ID: Final = "rae.job_assessment"
_MECHANISM_VALUES: Final[frozenset[str]] = frozenset(
    mechanism.value for mechanism in EconomicMechanism
)
_OPERATOR_ONLY_VALUES: Final[frozenset[str]] = frozenset(
    mechanism.value for mechanism in OPERATOR_ONLY_MECHANISMS
)
# The operands each method records (ADR 0024 decision 3). RevenueCard
# records ATTRIBUTION_SHARE only when an attribution fraction was applied.
_METHOD_OPERANDS: Final[
    tuple[tuple[ValuationMethod, tuple[ValuationOperand, ...]], ...]
] = (
    (ValuationMethod.HOURS_TIMES_RATE, (ValuationOperand.HOURS, ValuationOperand.RATE)),
    (
        ValuationMethod.INJECTED,
        (ValuationOperand.QUANTITY, ValuationOperand.UNIT_VALUE),
    ),
    (
        ValuationMethod.RATE_CARD,
        (ValuationOperand.ROLE_SELECTION, ValuationOperand.CARD_AMOUNT),
    ),
    (ValuationMethod.REVENUE_CARD, (ValuationOperand.GROSS, ValuationOperand.CARD_KEY)),
    (
        ValuationMethod.BASELINES,
        (ValuationOperand.BASELINE_RATE, ValuationOperand.BASELINE_MINUTES),
    ),
)
# The fixed claim basis of each built-in operand (ADR 0024 decision 3). The
# HoursTimesRate bases come from the assumptions, and an injected policy's
# operands are UNVERIFIED.
_FIXED_OPERAND_BASES: Final[tuple[tuple[ValuationOperand, ClaimBasis], ...]] = (
    (ValuationOperand.ROLE_SELECTION, ClaimBasis.ESTIMATED),
    (ValuationOperand.CARD_AMOUNT, ClaimBasis.CONFIGURED),
    (ValuationOperand.GROSS, ClaimBasis.CONFIGURED),
    (ValuationOperand.ATTRIBUTION_SHARE, ClaimBasis.CONFIGURED),
    (ValuationOperand.CARD_KEY, ClaimBasis.CONFIGURED),
    (ValuationOperand.BASELINE_RATE, ClaimBasis.CONFIGURED),
    (ValuationOperand.BASELINE_MINUTES, ClaimBasis.CONFIGURED),
    (ValuationOperand.QUANTITY, ClaimBasis.UNVERIFIED),
    (ValuationOperand.UNIT_VALUE, ClaimBasis.UNVERIFIED),
)
# The producers that may declare an operator-only mechanism, and which.
_DECLARING_PRODUCERS: Final[
    tuple[tuple[ValuationMethod, frozenset[str] | None], ...]
] = (
    (
        ValuationMethod.REVENUE_CARD,
        frozenset({EconomicMechanism.INCREMENTAL_REVENUE.value}),
    ),
    # An injected policy's declared set is the engine's, checked there.
    (ValuationMethod.INJECTED, None),
)
_REPORTABLE_REASONS: Final[frozenset[ReportabilityReason]] = frozenset(
    {
        ReportabilityReason.DECIDER_REPORTABLE,
        ReportabilityReason.DECIDER_FALLBACK_OPT_IN,
        ReportabilityReason.CONFIG_OPT_IN,
    }
)
_COMPUTED_NOT_REPORTABLE_REASONS: Final[frozenset[ReportabilityReason]] = frozenset(
    {
        ReportabilityReason.EVIDENCE_CLASS_NOT_REPORTABLE,
        ReportabilityReason.DECIDER_CANDIDATE,
        ReportabilityReason.DECIDER_FAILED,
        ReportabilityReason.DECIDER_FALLBACK_NOT_OPTED_IN,
        ReportabilityReason.NOT_OPTED_IN,
    }
)
# ADR 0039 decision 3: the reasons a MODEL_ESTIMATED record can carry
# once the model-estimate opt-in admitted it past rule 2. The opt-in needs
# experimental_report_estimates True, so NOT_OPTED_IN and
# DECIDER_FALLBACK_NOT_OPTED_IN can never follow it.
_MODEL_ESTIMATE_ADMITTED_REASONS: Final[frozenset[ReportabilityReason]] = frozenset(
    {
        ReportabilityReason.CONFIG_OPT_IN,
        ReportabilityReason.DECIDER_REPORTABLE,
        ReportabilityReason.DECIDER_FALLBACK_OPT_IN,
        ReportabilityReason.DECIDER_CANDIDATE,
        ReportabilityReason.DECIDER_FAILED,
    }
)


def _require_sequence(value: object, schema_id: str, field_name: str) -> None:
    _require_exact_type(value, int, schema_id, field_name)
    if not isinstance(value, int) or not 0 <= value <= SEQUENCE_MAX:
        raise RecordValidationError(
            schema_id, field_name, f"must be from 0 to 2**63 - 1, got {value!r}"
        )


def assessment_id(job_id: str, n: int) -> str:
    """Return the assessment id ``f"{job_id}:{n}"`` (D-03, ADR 0030 decision 3).

    The format is one-way: hosts persist it and Phase 5 corrections target
    it. With ``n = 0`` it equals Hermes' id byte for byte.

    Args:
        job_id: An ADR 0017 job id.
        n: The caller's sequence for this job, an exact ``int`` from 0 to
            ``2**63 - 1``.

    Returns:
        The assessment id, at most ``ASSESSMENT_ID_MAX_BYTES`` bytes.

    Raises:
        RecordValidationError: If ``job_id`` is not an ADR 0017 job id, or
            ``n`` is a ``bool``, not an ``int``, or out of range.
    """
    _require_job_id(job_id, _ASSESSMENT_SCHEMA_ID, "job_id")
    _require_sequence(n, _ASSESSMENT_SCHEMA_ID, "sequence")
    result = f"{job_id}:{n}"
    if serialized_byte_length(result) > ASSESSMENT_ID_MAX_BYTES:
        raise RecordValidationError(
            _ASSESSMENT_SCHEMA_ID,
            "assessment_id",
            f"must be at most {ASSESSMENT_ID_MAX_BYTES} serialized bytes",
        )
    return result


def _require_normalized(
    value: object, schema_id: str, field_name: str, max_bytes: int
) -> None:
    # The shape _bounded.normalize_text produces: no IFS characters, no
    # leading whitespace, within the byte bound. Empty is allowed.
    _require_exact_type(value, str, schema_id, field_name)
    text = str(value)
    if (
        any(character in text for character in IFS_CHARACTERS)
        or text != text.lstrip()
        or serialized_byte_length(text) > max_bytes
    ):
        raise RecordValidationError(
            schema_id,
            field_name,
            "must be normalized text with no IFS characters and no leading "
            f"whitespace, at most {max_bytes} serialized bytes",
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class InferenceLocality:
    """The configured inference endpoint a host records (ADR 0030 decision 2).

    Hermes records it on every branch, including those that call no model.

    Attributes:
        provider: The provider name, normalized, at most 32 serialized bytes.
        address_class: The endpoint's network class.
    """

    SCHEMA_ID: ClassVar[str] = "rae.inference_locality"
    SCHEMA_VERSION: ClassVar[int] = 1

    provider: str = ""
    address_class: AddressClass = AddressClass.UNSET

    def __post_init__(self) -> None:
        """Validate both fields.

        Raises:
            RecordValidationError: If any field is invalid.
        """
        schema_id = InferenceLocality.SCHEMA_ID
        _require_normalized(
            self.provider, schema_id, "provider", INFERENCE_PROVIDER_MAX_BYTES
        )
        _require_exact_type(
            self.address_class, AddressClass, schema_id, "address_class"
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class AssessmentPolicy:
    """The caller's money policy for one assessment (ADR 0028 decision 7).

    Configuration, not a schema record; ``version`` is recorded on every
    assessment as ``policy_version``. Validated at construction, so a
    misconfiguration fails once instead of refusing every assessment.

    Attributes:
        method: The valuation method, or a ``FallbackPolicy`` naming a
            built-in and the method its delegation runs. A bare built-in
            means ``FallbackPolicy(primary=method)``. ``INJECTED`` prices
            with the engine's injected ``ValuationPolicy``; ``assess_job``
            raises ``ConfigurationError`` when the engine has none.
        bounds: The operand ceilings.
        currency: The policy currency.
        band: The derived value band.
        revenue_ceiling: The ceiling for an amount whose producer asserted
            an accepted operator-only mechanism (Hermes ``maxRevenueValue``,
            classifier.py:L2328-L2337). ``None`` keeps the HoursTimesRate
            ceiling. Finite and above 0 once quantized.
        on_policy_error: What a raising injected policy produces (D-11).
        reportability: The reportability policy.
        version: The policy version, an exact ``int`` of at least 1.
    """

    method: ValuationMethod | FallbackPolicy = ValuationMethod.HOURS_TIMES_RATE
    bounds: OperandBounds = field(default_factory=OperandBounds)
    currency: Currency = Currency.USD
    band: DerivedBand = DEFAULT_DERIVED_BAND
    revenue_ceiling: Decimal | None = None
    on_policy_error: PolicyErrorMode = PolicyErrorMode.STRICT
    reportability: ReportabilityPolicy = field(default_factory=ReportabilityPolicy)
    version: int = 1

    def __post_init__(self) -> None:
        """Validate exact types and that the ceiling is representable.

        Raises:
            ConfigurationError: If a field has the wrong type, ``version`` is
                below 1, a ceiling or its band cannot be quantized as money,
                or ``revenue_ceiling`` is not finite and above 0 once
                quantized.
        """
        if type(self.method) is not ValuationMethod and (
            type(self.method) is not FallbackPolicy
        ):
            raise ConfigurationError(
                "method must be ValuationMethod or FallbackPolicy, got "
                f"{type(self.method).__name__}"
            )
        for name, expected in (
            ("bounds", OperandBounds),
            ("currency", Currency),
            ("band", DerivedBand),
            ("on_policy_error", PolicyErrorMode),
            ("reportability", ReportabilityPolicy),
            ("version", int),
        ):
            value = getattr(self, name)
            if type(value) is not expected:
                raise ConfigurationError(
                    f"{name} must be {expected.__name__}, got {type(value).__name__}"
                )
        if self.version < 1:
            raise ConfigurationError(
                f"version must be at least 1, got {self.version!r}"
            )
        try:
            ceiling = active_ceiling(self.bounds, self.currency)
            derive_band(ceiling.amount, self.band, self.currency)
        except (decimal.InvalidOperation, decimal.Overflow) as error:
            raise ConfigurationError(
                "bounds give a ceiling that cannot be quantized as money"
            ) from error
        if self.revenue_ceiling is not None:
            self._check_revenue_ceiling(self.revenue_ceiling)

    def _check_revenue_ceiling(self, value: object) -> None:
        if type(value) is not Decimal:
            raise ConfigurationError(
                f"revenue_ceiling must be Decimal, got {type(value).__name__}"
            )
        if not value.is_finite() or value <= 0:
            raise ConfigurationError(
                f"revenue_ceiling must be finite and above 0, got {value!r}"
            )
        try:
            quantized = quantize_money(value, self.currency)
            derive_band(quantized, self.band, self.currency)
        except (decimal.InvalidOperation, decimal.Overflow) as error:
            raise ConfigurationError(
                "revenue_ceiling cannot be quantized as money"
            ) from error
        if quantized <= 0:
            raise ConfigurationError(
                f"revenue_ceiling must be above 0 once quantized, got {value!r}"
            )

    def valuation_ceiling(self, *, declared_mechanism: bool) -> Money:
        """Return the active ceiling for one amount (ADR 0027 decision 4).

        Args:
            declared_mechanism: Whether the producer asserted an accepted
                operator-only mechanism.

        Returns:
            The quantized ``revenue_ceiling`` when it is set and a declared
            mechanism was accepted, otherwise the HoursTimesRate ceiling.
        """
        if declared_mechanism and self.revenue_ceiling is not None:
            return Money(
                amount=quantize_money(self.revenue_ceiling, self.currency),
                currency=self.currency,
            )
        return active_ceiling(self.bounds, self.currency)


@dataclass(frozen=True, slots=True, kw_only=True)
class AssessJobRequest:
    """One job a host asks the engine to assess (ADR 0030 decision 2).

    Attributes:
        candidate: The job to assess.
        proposal: The result of ``propose_outcome`` for the job, if any. It
            must name the candidate's job id and job type (ADR 0030 addendum
            items 1 and 3).
        sequence: The caller's assessment sequence for the job, an exact
            ``int`` from 0 to ``2**63 - 1`` (D-03).
        costs: The job's supplied costs. ``None`` means every category is
            unknown, in the policy currency.
        locality: The configured inference endpoint. ``None`` records
            ``""`` and UNSET.
        job_started_at: When the job started. When only ``job_ended_at`` is
            set, the start is that end if it is before the assessment time,
            otherwise the assessment time. When neither is set, it is the
            assessment time (ADR 0030 addendum item 2).
        job_ended_at: When the job ended. When only ``job_started_at`` is
            set, the end is that start if it is after the assessment time,
            otherwise the assessment time. When neither is set, it is the
            assessment time. A supplied end is never moved, so the recorded
            window is always ordered.
        subject_ref: An opaque host key echoed on the record.
        attribution_certain: The caller's assertion, an exact ``bool``, that
            an operator-only mechanism a valuation declares belongs to this
            job. Hermes reads the host's profile directories for this
            (``_revenue_profile_attribution_certain``); the library cannot,
            so it fails closed with the default False (ADR 0028 decision 3).
        figures: The caller-resolved rate card, revenue card, and baseline
            the built-in valuations price from (D-01, ADR 0028 decision 3).
        evidence: The evidence the host resolved for the job, handed to an
            injected reportability decider as plain data (D-01, ADR 0025
            decision 3). The default resolves nothing.
        outcome_assertion: A host-observed non-SUCCESS outcome (D-04, ADR
            0024 decision 5). When set, its outcome replaces the candidate's
            as the effective outcome, so it can demote a job but never
            promote one.
        metered_ai_cost: The host's metered AI cost for the job, carried on
            the record's ROI operands and never netted (D-02, OD-18, ADR 0029
            decision 4). Its amount is at least 0, and ``Decimal("-0")`` is
            accepted (ADR 0030 addendum item 6). Its currency must be the
            policy currency.
    """

    SCHEMA_ID: ClassVar[str] = "rae.assess_job_request"
    SCHEMA_VERSION: ClassVar[int] = 1

    candidate: JobCandidate
    proposal: OutcomeProposal | OutcomeAbstention | None = None
    sequence: int
    costs: SuppliedCosts | None = None
    locality: InferenceLocality | None = None
    job_started_at: datetime | None = None
    job_ended_at: datetime | None = None
    subject_ref: str | None = None
    attribution_certain: bool = False
    figures: ValuationFigures = field(default_factory=ValuationFigures)
    evidence: ResolvedEvidence = field(default_factory=ResolvedEvidence)
    outcome_assertion: OutcomeAssertion | None = None
    metered_ai_cost: Money | None = None

    def __post_init__(self) -> None:
        """Validate every field and that the proposal names this job.

        Raises:
            RecordValidationError: If any field is invalid or inconsistent.
        """
        schema_id = AssessJobRequest.SCHEMA_ID
        _require_exact_type(self.candidate, JobCandidate, schema_id, "candidate")
        proposal = self.proposal
        if proposal is not None:
            if type(proposal) is not OutcomeProposal and (
                type(proposal) is not OutcomeAbstention
            ):
                raise RecordValidationError(
                    schema_id,
                    "proposal",
                    "OutcomeProposal or OutcomeAbstention required, got "
                    f"{type(proposal).__name__}",
                )
            if proposal.job_id != self.candidate.boundary.job_id:
                raise RecordValidationError(
                    schema_id, "proposal", "must name the candidate's job"
                )
            # ADR 0030 addendum item 3: another type's proposal never values
            # this job, on any branch.
            if proposal.job_type != self.candidate.type_assignment.job_type:
                raise RecordValidationError(
                    schema_id, "proposal", "must name the candidate's job type"
                )
        _require_sequence(self.sequence, schema_id, "sequence")
        if self.costs is not None:
            _require_exact_type(self.costs, SuppliedCosts, schema_id, "costs")
        if self.locality is not None:
            _require_exact_type(self.locality, InferenceLocality, schema_id, "locality")
        if self.job_started_at is not None:
            _require_utc(self.job_started_at, schema_id, "job_started_at")
        if self.job_ended_at is not None:
            _require_utc(self.job_ended_at, schema_id, "job_ended_at")
        if (
            self.job_started_at is not None
            and self.job_ended_at is not None
            and self.job_started_at > self.job_ended_at
        ):
            raise RecordValidationError(
                schema_id, "job_ended_at", "must not be before job_started_at"
            )
        _require_subject_ref(self.subject_ref, schema_id)
        _require_exact_type(
            self.attribution_certain, bool, schema_id, "attribution_certain"
        )
        _require_exact_type(self.figures, ValuationFigures, schema_id, "figures")
        _require_exact_type(self.evidence, ResolvedEvidence, schema_id, "evidence")
        if self.outcome_assertion is not None:
            _require_exact_type(
                self.outcome_assertion,
                OutcomeAssertion,
                schema_id,
                "outcome_assertion",
            )
        if self.metered_ai_cost is not None:
            _require_exact_type(
                self.metered_ai_cost, Money, schema_id, "metered_ai_cost"
            )
            # ADR 0030 addendum item 6: a negative zero is not below 0.
            if self.metered_ai_cost.amount < 0:
                raise RecordValidationError(
                    schema_id, "metered_ai_cost", "must be at least 0"
                )
            # The Phase 6 note on item 6: the same bounds as a supplied cost.
            _require_amount_bounds(
                self.metered_ai_cost.amount, schema_id, "metered_ai_cost"
            )


def _assessed_outcome(request: AssessJobRequest) -> JobOutcome:
    """Return the outcome ``assess_job`` acts on (ADR 0030 decision 4).

    Args:
        request: The assessment request.

    Returns:
        The assertion's outcome when the host asserted one, otherwise the
        candidate's. An assertion is never SUCCESS, so it only demotes.
    """
    assertion = request.outcome_assertion
    return request.candidate.outcome if assertion is None else assertion.outcome


def _job_window(
    request: AssessJobRequest, assessed_at: datetime
) -> tuple[datetime, datetime]:
    """Return the job window a record states (ADR 0030 addendum item 2).

    Hermes always records ``now`` for both ends (classifier.py L3352-L3359),
    which is the both-absent case here. A single supplied end is kept, and the
    missing end is that end or ``assessed_at``, whichever keeps the window
    ordered. ``assessment`` is under the builtin min/max ban (ADR 0027
    decision 2), so this compares explicitly.

    Args:
        request: The assessment request.
        assessed_at: The engine clock's time for this assessment.

    Returns:
        The ``(job_started_at, job_ended_at)`` pair, never disordered when the
        request is valid.
    """
    started = request.job_started_at
    ended = request.job_ended_at
    if started is None:
        if ended is None:
            return assessed_at, assessed_at
        if ended < assessed_at:
            return ended, ended
        return assessed_at, ended
    if ended is None:
        if started > assessed_at:
            return started, started
        return started, assessed_at
    return started, ended


def _validate_common(record: "JobAssessment | AssessmentAbstention") -> None:
    schema_id = type(record).SCHEMA_ID
    _require_job_id(record.job_id, schema_id, "job_id")
    _require_sequence(record.sequence, schema_id, "sequence")
    _require_exact_type(record.assessment_id, str, schema_id, "assessment_id")
    if record.assessment_id != assessment_id(record.job_id, record.sequence):
        raise RecordValidationError(
            schema_id, "assessment_id", "must equal f'{job_id}:{sequence}'"
        )
    _require_exact_type(record.job_type, str, schema_id, "job_type")
    if not is_valid_label(record.job_type):
        raise RecordValidationError(schema_id, "job_type", "fails the label grammar")
    _require_version_text(record.taxonomy_version, schema_id, "taxonomy_version")
    _require_exact_type(
        record.execution_status, JobOutcome, schema_id, "execution_status"
    )
    assertion = record.outcome_assertion
    if assertion is not None:
        _require_exact_type(assertion, OutcomeAssertion, schema_id, "outcome_assertion")
        if record.execution_status is not assertion.outcome:
            raise RecordValidationError(
                schema_id,
                "execution_status",
                "must equal the asserted outcome, the effective outcome",
            )
    for name in (
        "assessed_at",
        "job_started_at",
        "job_ended_at",
        "observation_window_start",
        "observation_window_end",
    ):
        _require_utc(getattr(record, name), schema_id, name)
    if record.job_started_at > record.job_ended_at:
        raise RecordValidationError(
            schema_id, "job_ended_at", "must not be before job_started_at"
        )
    if record.observation_window_start > record.observation_window_end:
        raise RecordValidationError(
            schema_id,
            "observation_window_end",
            "must not be before observation_window_start",
        )
    for name in ("candidate_downstream_outcome", "counterfactual_assumption", "basis"):
        _require_narrative(getattr(record, name), schema_id, name)
    _require_exact_type(record.economic_mechanism, str, schema_id, "economic_mechanism")
    if record.double_counting_group is not None:
        _require_clamped_text(
            record.double_counting_group,
            schema_id,
            "double_counting_group",
            DOUBLE_COUNTING_GROUP_MAX_BYTES,
        )
    _require_exact_type(
        record.evidence_class, EvidenceClass, schema_id, "evidence_class"
    )
    if record.study is not None:
        _require_exact_type(record.study, StudyReference, schema_id, "study")
    if record.evidence_class in STUDY_EVIDENCE_CLASSES and record.study is None:
        # ADR 0026 decision 2: a study class requires a study reference. The
        # reference never sets the class; this only refuses a class claimed
        # without one, at construction and at decode.
        raise RecordValidationError(
            schema_id, "evidence_class", "a study evidence class requires a study"
        )
    _require_exact_type(
        record.evidence_class_authority,
        EvidenceAuthority,
        schema_id,
        "evidence_class_authority",
    )
    _require_normalized(record.evaluator, schema_id, "evaluator", EVALUATOR_MAX_BYTES)
    _require_normalized(
        record.evaluator_version,
        schema_id,
        "evaluator_version",
        EVALUATOR_VERSION_MAX_BYTES,
    )
    _require_text(record.model, schema_id, "model")
    _require_normalized(record.model, schema_id, "model", PROVENANCE_MODEL_MAX_BYTES)
    _require_normalized(
        record.inference_provider,
        schema_id,
        "inference_provider",
        INFERENCE_PROVIDER_MAX_BYTES,
    )
    _require_exact_type(
        record.inference_address_class,
        AddressClass,
        schema_id,
        "inference_address_class",
    )
    _require_version_number(record.prompt_version, schema_id, "prompt_version")
    _require_version_number(record.policy_version, schema_id, "policy_version")
    _require_exact_type(
        record.reportability, ReportabilityStatus, schema_id, "reportability"
    )
    _require_exact_type(
        record.reportability_reason,
        ReportabilityReason,
        schema_id,
        "reportability_reason",
    )
    _require_exact_type(record.roi, RoiOperands, schema_id, "roi")
    _require_subject_ref(record.subject_ref, schema_id)
    _require_text(record.library_version, schema_id, "library_version")


@dataclass(frozen=True, slots=True, kw_only=True)
class JobAssessment:
    """A valued assessment of one SUCCESS job (ADR 0030 decision 5).

    ``value_base`` and ``estimated_value`` are ``roi.value``; the band ends
    are derived from it with ``band``. The value is at least 0 and quantized
    to the currency's minor unit, and a HOURS_TIMES_RATE value equals
    ``hours_times_rate(assumptions)`` (ADR 0030 addendum item 8). Decode
    builds the record through the same checks. The record carries no policy,
    so the active ceiling is not re-checked here; a consumer that holds the
    policy re-checks with ``AssessmentPolicy.valuation_ceiling``.

    ``job_started_at`` and ``job_ended_at`` may be derived (ADR 0030 addendum
    item 2): a missing end is the supplied end or ``assessed_at``, and when
    the host supplied neither, both are ``assessed_at``. The record does not
    say which end the host supplied, so a window whose ends are equal may be
    a derived one rather than a job that took no time.

    Attributes:
        assessment_id: ``f"{job_id}:{sequence}"``.
        sequence: The caller's assessment sequence for the job.
        job_id: The assessed job's id.
        job_type: The assessed job's type label.
        taxonomy_version: The job taxonomy version the type came from.
        execution_status: The effective outcome, always SUCCESS here.
        outcome_assertion: Always ``None``: an assertion only demotes, so an
            asserted job is never valued (ADR 0024 decision 5).
        assessed_at: When the assessment was made, from the injected clock.
        job_started_at: When the job started, supplied or derived.
        job_ended_at: When the job ended, supplied or derived.
        observation_window_start: The start of the observation window.
        observation_window_end: The end of the observation window.
        candidate_downstream_outcome: The evaluator's narrative.
        counterfactual_assumption: The evaluator's narrative.
        basis: The basis narrative.
        economic_mechanism: The accepted mechanism's value.
        double_counting_group: The candidate's group, if any.
        evidence_class: The class from the precedence walk.
        evidence_class_authority: The walk leg that set the class.
        study: The request's study reference, echoed, or ``None``. It never
            changes ``evidence_class``; a study class requires it.
        evaluator: The evaluator name, at most 32 serialized bytes.
        evaluator_version: The evaluator version, at most 16 serialized bytes.
        model: The served model, or ``"unknown"``.
        inference_provider: The configured provider, or ``""``.
        inference_address_class: The configured address class.
        prompt_version: The engine's outcome prompt version.
        policy_version: ``AssessmentPolicy.version``.
        confidence: The accepted confidence.
        value_low: The low end of the derived band.
        value_high: The high end of the derived band.
        band: The spread and version that produced the band.
        bounds_source: Always ``"derived"``.
        assumptions: The gated operands and their claim bases.
        produced_by: The method that produced the value, set by library code
            (ADR 0028 decision 4).
        operand_bases: The claim basis of each operand behind the value, in
            ``ValuationOperand`` order; ``roi.value_basis`` is their weakest
            (ADR 0024 decision 4).
        attribution_fraction: The accepted attribution fraction, in [0, 1].
        attribution_basis: The accepted attribution basis, normalized to 500
            serialized bytes. Set exactly when ``attribution_fraction`` is.
        reportability: Whether the value may be reported.
        reportability_reason: The rule that decided ``reportability``.
        roi: The value, costs, coverage, and net value.
        subject_ref: The request's subject reference, echoed.
        library_version: The library version that made the assessment.
    """

    SCHEMA_ID: ClassVar[str] = "rae.job_assessment"
    SCHEMA_VERSION: ClassVar[int] = 1

    assessment_id: str
    sequence: int
    job_id: str
    job_type: str
    taxonomy_version: str
    execution_status: JobOutcome
    outcome_assertion: OutcomeAssertion | None = None
    assessed_at: datetime
    job_started_at: datetime
    job_ended_at: datetime
    observation_window_start: datetime
    observation_window_end: datetime
    candidate_downstream_outcome: str = ""
    counterfactual_assumption: str = ""
    basis: str = ""
    economic_mechanism: str
    double_counting_group: str | None = None
    evidence_class: EvidenceClass
    evidence_class_authority: EvidenceAuthority
    study: StudyReference | None = None
    evaluator: str
    evaluator_version: str
    model: str = MODEL_UNKNOWN
    inference_provider: str = ""
    inference_address_class: AddressClass = AddressClass.UNSET
    prompt_version: int
    policy_version: int
    confidence: Confidence
    value_low: Decimal
    value_high: Decimal
    band: DerivedBand
    bounds_source: str = BOUNDS_SOURCE_DERIVED
    assumptions: ResolvedAssumptions
    produced_by: ValuationMethod
    operand_bases: OperandBases
    attribution_fraction: Decimal | None = None
    attribution_basis: str | None = None
    reportability: ReportabilityStatus
    reportability_reason: ReportabilityReason
    roi: RoiOperands
    subject_ref: str | None = None
    library_version: str

    def __post_init__(self) -> None:
        """Validate every field and the valued-record invariants.

        Raises:
            RecordValidationError: If any field is invalid or inconsistent.
                On field ``roi``: the estimated value is below 0, is not
                quantized to the currency minor unit (or cannot be), or, for
                a HOURS_TIMES_RATE record, differs from
                ``hours_times_rate(assumptions)`` (ADR 0030 addendum item 8).
                On ``value_low`` or ``value_high``: the end's exponent is not
                exactly the currency's minor unit, so ``425`` is refused
                where ``425.00`` is required. ``roi`` refuses its own
                ``value`` and ``net_value`` by the same rule (ADR 0030 Phase
                6 owner-decision addendum).
        """
        schema_id = JobAssessment.SCHEMA_ID
        _validate_common(self)
        if self.execution_status is not JobOutcome.SUCCESS:
            raise RecordValidationError(
                schema_id, "execution_status", "a valued assessment is SUCCESS only"
            )
        if self.outcome_assertion is not None:
            raise RecordValidationError(
                schema_id,
                "outcome_assertion",
                "an assertion only demotes, so a valued assessment has none",
            )
        if self.economic_mechanism not in _MECHANISM_VALUES or (
            self.economic_mechanism == EconomicMechanism.NEWLY_ENABLED_WORK.value
        ):
            raise RecordValidationError(
                schema_id, "economic_mechanism", "must be a priced mechanism"
            )
        _require_valuation_provenance(self)
        _require_text(self.evaluator, schema_id, "evaluator")
        _require_exact_type(self.confidence, Confidence, schema_id, "confidence")
        _require_exact_type(self.band, DerivedBand, schema_id, "band")
        if self.bounds_source != BOUNDS_SOURCE_DERIVED:
            raise RecordValidationError(
                schema_id, "bounds_source", f"must be {BOUNDS_SOURCE_DERIVED!r}"
            )
        _require_exact_type(
            self.assumptions, ResolvedAssumptions, schema_id, "assumptions"
        )
        roi = self.roi
        if roi.value_state is not ValueSideState.VALUED or roi.value is None:
            raise RecordValidationError(
                schema_id, "roi", "a JobAssessment's value state is valued"
            )
        if self.assumptions.job_type != self.job_type:
            raise RecordValidationError(
                schema_id, "assumptions", "job_type must equal the record's"
            )
        if self.assumptions.currency is not roi.costs.currency:
            raise RecordValidationError(
                schema_id, "assumptions", "currency must equal the costs currency"
            )
        if roi.value_basis is not weakest_claim_basis(
            basis for _, basis in self.operand_bases
        ):
            raise RecordValidationError(
                schema_id,
                "roi",
                "value_basis must be the weakest of the operand bases",
            )
        # ADR 0030 addendum item 8 (review WR-03): a decoded record meets the
        # money rules the engine applies. With the band equality below,
        # value_low <= value <= value_high follows. An amount that cannot be
        # quantized is refused like an unquantized one (IN-08: inlined, so
        # this invariant reads no other module's private helper).
        value = roi.value
        if value.amount < 0:
            raise RecordValidationError(
                schema_id, "roi", "estimated value must be at least 0"
            )
        try:
            quantized: Decimal | None = quantize_money(value.amount, value.currency)
        except (decimal.InvalidOperation, decimal.Overflow):
            quantized = None
        if quantized is None or quantized != value.amount:
            raise RecordValidationError(
                schema_id,
                "roi",
                "estimated value must be quantized to the currency minor unit",
            )
        if self.produced_by is ValuationMethod.HOURS_TIMES_RATE and (
            hours_times_rate(self.assumptions) != value
        ):
            raise RecordValidationError(
                schema_id,
                "roi",
                "an hours-times-rate value must equal the product of its "
                "recorded operands",
            )
        _require_exact_type(self.value_low, Decimal, schema_id, "value_low")
        _require_exact_type(self.value_high, Decimal, schema_id, "value_high")
        # ADR 0030 Phase 6 owner-decision addendum (Phase 4 WR-08): the band
        # ends carry the minor-unit exponent, as roi.value and roi.net_value
        # already do (RoiOperands), so equal records encode to equal bytes.
        _require_minor_unit_scale(
            self.value_low, value.currency, schema_id, "value_low"
        )
        _require_minor_unit_scale(
            self.value_high, value.currency, schema_id, "value_high"
        )
        low, high = derive_band(roi.value.amount, self.band, roi.value.currency)
        if self.value_low != low or self.value_high != high:
            raise RecordValidationError(
                schema_id,
                "value_low",
                "the band must equal derive_band(estimated_value, band)",
            )
        _require_valued_reportability(self)

    @property
    def estimated_value(self) -> Money:
        """The accepted estimated value, ``roi.value``."""
        value = self.roi.value
        if value is None:  # pragma: no cover - excluded by __post_init__
            raise RecordValidationError(JobAssessment.SCHEMA_ID, "roi", "no value")
        return value

    @property
    def value_base(self) -> Decimal:
        """The band base, equal to ``estimated_value.amount``."""
        return self.estimated_value.amount


def _expected_operands(record: JobAssessment) -> tuple[ValuationOperand, ...]:
    for method, operands in _METHOD_OPERANDS:
        if method is record.produced_by:
            if (
                method is ValuationMethod.REVENUE_CARD
                and record.attribution_fraction is not None
            ):
                return (
                    ValuationOperand.GROSS,
                    ValuationOperand.ATTRIBUTION_SHARE,
                    ValuationOperand.CARD_KEY,
                )
            return operands
    raise RecordValidationError(  # pragma: no cover - every method has a row
        JobAssessment.SCHEMA_ID, "produced_by", "unknown producer"
    )


def _require_valuation_provenance(record: JobAssessment) -> None:
    # ADR 0028 decisions 4 and 5, ADR 0024 decisions 3 and 4: who produced
    # the value, from which operands, with which bases, and which mechanism
    # and attribution it may carry.
    schema_id = JobAssessment.SCHEMA_ID
    _require_exact_type(record.produced_by, ValuationMethod, schema_id, "produced_by")
    require_operand_bases(record.operand_bases, schema_id, "operand_bases")
    _require_exact_type(
        record.assumptions, ResolvedAssumptions, schema_id, "assumptions"
    )
    expected = _expected_operands(record)
    operands = tuple(operand for operand, _ in record.operand_bases)
    if operands != expected:
        raise RecordValidationError(
            schema_id,
            "operand_bases",
            f"{record.produced_by.value} records the operands "
            f"{[operand.value for operand in expected]}",
        )
    bases = tuple(basis for _, basis in record.operand_bases)
    if record.produced_by is ValuationMethod.HOURS_TIMES_RATE:
        fixed: tuple[ClaimBasis, ...] = (
            record.assumptions.hours_basis,
            record.assumptions.rate_basis,
        )
    else:
        fixed = tuple(
            next(basis for known, basis in _FIXED_OPERAND_BASES if known is operand)
            for operand in operands
        )
    if bases != fixed:
        raise RecordValidationError(
            schema_id,
            "operand_bases",
            f"{record.produced_by.value} records the bases "
            f"{[basis.value for basis in fixed]}",
        )
    declaring = next(
        (
            (True, allowed)
            for method, allowed in _DECLARING_PRODUCERS
            if method is record.produced_by
        ),
        (False, None),
    )
    operator_mechanism = record.economic_mechanism in _OPERATOR_ONLY_VALUES
    if record.economic_mechanism != record.assumptions.economic_mechanism.value and (
        not operator_mechanism
        or not declaring[0]
        or (declaring[1] is not None and record.economic_mechanism not in declaring[1])
    ):
        raise RecordValidationError(
            schema_id,
            "economic_mechanism",
            "must be the evaluator's mechanism or a producer's declared "
            "operator-only mechanism",
        )
    fraction = record.attribution_fraction
    basis = record.attribution_basis
    if (fraction is None) != (basis is None):
        raise RecordValidationError(
            schema_id,
            "attribution_fraction",
            "the attribution fraction and basis are both set or both None",
        )
    if fraction is None:
        return
    if not operator_mechanism:
        raise RecordValidationError(
            schema_id,
            "attribution_fraction",
            "an attribution needs a declared operator-only mechanism",
        )
    _require_exact_type(fraction, Decimal, schema_id, "attribution_fraction")
    if not fraction.is_finite() or not Decimal(0) <= fraction <= Decimal(1):
        raise RecordValidationError(
            schema_id,
            "attribution_fraction",
            f"must be finite and in [0, 1], got {fraction!r}",
        )
    _require_normalized(basis, schema_id, "attribution_basis", NARRATIVE_CLAMP_BYTES)


def _require_valued_reportability(record: JobAssessment) -> None:
    schema_id = JobAssessment.SCHEMA_ID
    status = record.reportability
    reason = record.reportability_reason
    admitted_model_estimate = (
        record.evidence_class is EvidenceClass.MODEL_ESTIMATED
        and reason in _MODEL_ESTIMATE_ADMITTED_REASONS
    )
    if (
        record.evidence_class not in REPORTABLE_EVIDENCE_CLASSES
        and not admitted_model_estimate
    ):
        # Rule 2 runs before any opt-in or decider (VAL-08). Its one
        # exception, a model estimate the caller's opt-in admitted, carries
        # a rule 3 or rule 4 reason checked below (ADR 0039 decision 3).
        if (
            status is not ReportabilityStatus.COMPUTED_NOT_REPORTABLE
            or reason is not ReportabilityReason.EVIDENCE_CLASS_NOT_REPORTABLE
        ):
            raise RecordValidationError(
                schema_id,
                "reportability",
                "a class outside REPORTABLE_EVIDENCE_CLASSES is "
                "computed_not_reportable for evidence_class_not_reportable, "
                "unless the model-estimate opt-in admitted a "
                "model_estimated record (ADR 0039)",
            )
        return
    if reason is ReportabilityReason.EVIDENCE_CLASS_NOT_REPORTABLE:
        raise RecordValidationError(
            schema_id, "reportability_reason", "the class is reportable"
        )
    allowed = (
        _REPORTABLE_REASONS
        if status is ReportabilityStatus.REPORTABLE
        else _COMPUTED_NOT_REPORTABLE_REASONS
        if status is ReportabilityStatus.COMPUTED_NOT_REPORTABLE
        else frozenset()
    )
    if reason not in allowed:
        raise RecordValidationError(
            schema_id,
            "reportability_reason",
            f"{reason.value} does not decide {status.value}",
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class AssessmentAbstention:
    """Why one job has no value, keeping its costs (ADR 0030 decision 5).

    It has no confidence and no value family (ledger ID-07): an abstention
    made no claim. Its costs and coverage are kept, so negative ROI stays
    visible downstream without a number nobody measured.

    ``job_started_at`` and ``job_ended_at`` may be derived (ADR 0030 addendum
    item 2): a missing end is the supplied end or ``assessed_at``, and when
    the host supplied neither, both are ``assessed_at``. The record does not
    say which end the host supplied, so a window whose ends are equal may be
    a derived one rather than a job that took no time.

    Attributes:
        assessment_id: ``f"{job_id}:{sequence}"``.
        sequence: The caller's assessment sequence for the job.
        job_id: The job's id.
        job_type: The job's type label.
        taxonomy_version: The job taxonomy version the type came from.
        execution_status: The effective outcome: the asserted outcome when
            ``outcome_assertion`` is set, otherwise the candidate's.
        outcome_assertion: The host's assertion that demoted the job,
            recorded with ``ClaimBasis.OBSERVED`` (ADR 0024 decision 5), or
            ``None``.
        assessed_at: When the assessment was made, from the injected clock.
        job_started_at: When the job started, supplied or derived.
        job_ended_at: When the job ended, supplied or derived.
        observation_window_start: The start of the observation window.
        observation_window_end: The end of the observation window.
        candidate_downstream_outcome: The proposal's narrative, or ``""``.
        counterfactual_assumption: The proposal's narrative, or ``""``.
        basis: The proposal's basis, or ``""``.
        economic_mechanism: The resolved mechanism's value, or ``"unknown"``.
        double_counting_group: The candidate's group, if any.
        evidence_class: The class from the abstention-record walk.
        evidence_class_authority: The walk leg that set the class.
        study: The request's study reference, echoed, or ``None``. It never
            changes ``evidence_class``; a study class requires it.
        evaluator: The evaluator name, or ``""`` when none is configured.
        evaluator_version: The evaluator version, or ``""``.
        model: The served model, or ``"unknown"``.
        inference_provider: The configured provider, or ``""``.
        inference_address_class: The configured address class.
        prompt_version: The engine's outcome prompt version.
        policy_version: ``AssessmentPolicy.version``.
        abstention_reason: Why no value was recorded.
        refusal: The first failing check. Set exactly for REJECTED.
        reportability: Always UNCOMPUTED (rule 1).
        reportability_reason: Always ABSTAINED.
        roi: The costs and coverage, with no value.
        subject_ref: The request's subject reference, echoed.
        library_version: The library version that made the assessment.
    """

    SCHEMA_ID: ClassVar[str] = "rae.assessment_abstention"
    SCHEMA_VERSION: ClassVar[int] = 1

    assessment_id: str
    sequence: int
    job_id: str
    job_type: str
    taxonomy_version: str
    execution_status: JobOutcome
    outcome_assertion: OutcomeAssertion | None = None
    assessed_at: datetime
    job_started_at: datetime
    job_ended_at: datetime
    observation_window_start: datetime
    observation_window_end: datetime
    candidate_downstream_outcome: str = ""
    counterfactual_assumption: str = ""
    basis: str = ""
    economic_mechanism: str = ECONOMIC_MECHANISM_UNKNOWN
    double_counting_group: str | None = None
    evidence_class: EvidenceClass
    evidence_class_authority: EvidenceAuthority
    study: StudyReference | None = None
    evaluator: str = ""
    evaluator_version: str = ""
    model: str = MODEL_UNKNOWN
    inference_provider: str = ""
    inference_address_class: AddressClass = AddressClass.UNSET
    prompt_version: int
    policy_version: int
    abstention_reason: AbstentionReason
    refusal: AssessmentRefusal | None = None
    reportability: ReportabilityStatus = ReportabilityStatus.UNCOMPUTED
    reportability_reason: ReportabilityReason = ReportabilityReason.ABSTAINED
    roi: RoiOperands
    subject_ref: str | None = None
    library_version: str

    def __post_init__(self) -> None:
        """Validate every field and the abstention invariants.

        Raises:
            RecordValidationError: If any field is invalid or inconsistent.
        """
        schema_id = AssessmentAbstention.SCHEMA_ID
        _validate_common(self)
        if (
            self.economic_mechanism not in _MECHANISM_VALUES
            and self.economic_mechanism != ECONOMIC_MECHANISM_UNKNOWN
        ):
            raise RecordValidationError(
                schema_id,
                "economic_mechanism",
                "must be a mechanism value or 'unknown'",
            )
        _require_exact_type(
            self.abstention_reason, AbstentionReason, schema_id, "abstention_reason"
        )
        rejected = self.abstention_reason is AbstentionReason.REJECTED
        if (self.refusal is not None) != rejected:
            raise RecordValidationError(
                schema_id, "refusal", "is set exactly for a rejected abstention"
            )
        if self.refusal is not None:
            _require_exact_type(self.refusal, AssessmentRefusal, schema_id, "refusal")
        not_success = (
            self.abstention_reason is AbstentionReason.NOT_EVALUATED_NON_SUCCESS
        )
        if (self.execution_status is not JobOutcome.SUCCESS) != not_success:
            raise RecordValidationError(
                schema_id,
                "execution_status",
                "is non-SUCCESS exactly for not_evaluated_non_success",
            )
        expected_state = (
            ValueSideState.ZERO_NOT_COMPLETED
            if not_success
            else ValueSideState.UNCOMPUTED
        )
        if self.roi.value_state is not expected_state:
            raise RecordValidationError(
                schema_id, "roi", f"value_state must be {expected_state.value}"
            )
        if (
            self.reportability is not ReportabilityStatus.UNCOMPUTED
            or self.reportability_reason is not ReportabilityReason.ABSTAINED
        ):
            raise RecordValidationError(
                schema_id,
                "reportability",
                "an abstention is uncomputed for abstained (rule 1)",
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class _Frame:
    # The identity, times, provenance, and costs every branch records
    # (ADR 0030 decision 4). Built once per assess_job call.
    sequence: int
    job_id: str
    job_type: str
    taxonomy_version: str
    execution_status: JobOutcome
    outcome_assertion: OutcomeAssertion | None = None
    assessed_at: datetime
    job_started_at: datetime
    job_ended_at: datetime
    double_counting_group: str | None
    evaluator: str
    evaluator_version: str
    inference_provider: str
    inference_address_class: AddressClass
    prompt_version: int
    policy_version: int
    costs: SuppliedCosts
    metered_ai_cost: Money | None
    subject_ref: str | None
    study: StudyReference | None


def _frame(
    request: AssessJobRequest,
    *,
    policy: AssessmentPolicy,
    costs: SuppliedCosts,
    assessed_at: datetime,
    evaluator: ComponentDeclaration | None,
    prompt_version: int,
) -> _Frame:
    candidate = request.candidate
    locality = request.locality or InferenceLocality()
    job_started_at, job_ended_at = _job_window(request, assessed_at)
    return _Frame(
        sequence=request.sequence,
        job_id=candidate.boundary.job_id,
        job_type=candidate.type_assignment.job_type,
        taxonomy_version=candidate.type_assignment.taxonomy.version,
        # ADR 0030 decision 4: the effective outcome, with the assertion
        # that set it kept beside it.
        execution_status=_assessed_outcome(request),
        outcome_assertion=request.outcome_assertion,
        assessed_at=assessed_at,
        job_started_at=job_started_at,
        job_ended_at=job_ended_at,
        double_counting_group=candidate.double_counting_group,
        # Hermes _clamp_assessment_text(evaluator, 32) and (version, 16).
        evaluator=(
            ""
            if evaluator is None
            else normalize_text(evaluator.name, max_bytes=EVALUATOR_MAX_BYTES)
        ),
        evaluator_version=(
            ""
            if evaluator is None
            else normalize_text(
                evaluator.version, max_bytes=EVALUATOR_VERSION_MAX_BYTES
            )
        ),
        inference_provider=locality.provider,
        inference_address_class=locality.address_class,
        prompt_version=prompt_version,
        policy_version=policy.version,
        costs=costs,
        metered_ai_cost=request.metered_ai_cost,
        subject_ref=request.subject_ref,
        # Hermes records the configured study on every branch (L3105-L3168).
        study=request.evidence.study,
    )


def _served_model(decision: OutcomeProposal | OutcomeAbstention | None) -> str:
    inference = None if decision is None else decision.inference
    if inference is None or inference.served_model is None:
        return MODEL_UNKNOWN
    # ADR 0030 addendum item 7 and decision 5: Hermes
    # _clamp_assessment_text(model, 64). inference_provenance already
    # normalizes, so only a hand-built InferenceProvenance changes here.
    model = normalize_text(inference.served_model, max_bytes=PROVENANCE_MODEL_MAX_BYTES)
    return model or MODEL_UNKNOWN


def _abstention(
    frame: _Frame,
    *,
    reason: AbstentionReason,
    refusal: AssessmentRefusal | None = None,
    proposal: OutcomeProposal | None = None,
    economic_mechanism: str = ECONOMIC_MECHANISM_UNKNOWN,
    model: str = MODEL_UNKNOWN,
    evidence: tuple[EvidenceClass, EvidenceAuthority],
) -> AssessmentAbstention:
    value_state = (
        ValueSideState.ZERO_NOT_COMPLETED
        if reason is AbstentionReason.NOT_EVALUATED_NON_SUCCESS
        else ValueSideState.UNCOMPUTED
    )
    return AssessmentAbstention(
        assessment_id=assessment_id(frame.job_id, frame.sequence),
        sequence=frame.sequence,
        job_id=frame.job_id,
        job_type=frame.job_type,
        taxonomy_version=frame.taxonomy_version,
        execution_status=frame.execution_status,
        outcome_assertion=frame.outcome_assertion,
        assessed_at=frame.assessed_at,
        job_started_at=frame.job_started_at,
        job_ended_at=frame.job_ended_at,
        observation_window_start=frame.job_started_at,
        observation_window_end=frame.job_ended_at,
        candidate_downstream_outcome=(
            "" if proposal is None else proposal.candidate_downstream_outcome
        ),
        counterfactual_assumption=(
            "" if proposal is None else proposal.counterfactual_assumption
        ),
        basis="" if proposal is None else proposal.basis,
        economic_mechanism=economic_mechanism,
        double_counting_group=frame.double_counting_group,
        evidence_class=evidence[0],
        evidence_class_authority=evidence[1],
        study=frame.study,
        evaluator=frame.evaluator,
        evaluator_version=frame.evaluator_version,
        model=model,
        inference_provider=frame.inference_provider,
        inference_address_class=frame.inference_address_class,
        prompt_version=frame.prompt_version,
        policy_version=frame.policy_version,
        abstention_reason=reason,
        refusal=refusal,
        roi=RoiOperands(
            value_state=value_state,
            costs=frame.costs,
            coverage=cost_coverage(frame.costs),
            metered_ai_cost=frame.metered_ai_cost,
        ),
        subject_ref=frame.subject_ref,
        library_version=__version__,
    )


def _valued(
    frame: _Frame,
    *,
    proposal: OutcomeProposal,
    assumptions: ResolvedAssumptions,
    valuation: ValuationResult,
    amount: Money,
    confidence: Confidence,
    band: DerivedBand,
    evidence: tuple[EvidenceClass, EvidenceAuthority],
    reportability: tuple[ReportabilityStatus, ReportabilityReason],
) -> JobAssessment:
    currency = amount.currency
    low, high = derive_band(amount.amount, band, currency)
    net = net_value(amount.amount, frame.costs, currency)
    return JobAssessment(
        assessment_id=assessment_id(frame.job_id, frame.sequence),
        sequence=frame.sequence,
        job_id=frame.job_id,
        job_type=frame.job_type,
        taxonomy_version=frame.taxonomy_version,
        execution_status=frame.execution_status,
        outcome_assertion=frame.outcome_assertion,
        assessed_at=frame.assessed_at,
        job_started_at=frame.job_started_at,
        job_ended_at=frame.job_ended_at,
        observation_window_start=frame.job_started_at,
        observation_window_end=frame.job_ended_at,
        candidate_downstream_outcome=proposal.candidate_downstream_outcome,
        counterfactual_assumption=proposal.counterfactual_assumption,
        # Hermes L2441-L2449: the producer's basis replaces the model's only
        # beside an accepted declared mechanism.
        basis=proposal.basis if valuation.basis is None else valuation.basis,
        economic_mechanism=(
            assumptions.economic_mechanism.value
            if valuation.declared_mechanism is None
            else valuation.declared_mechanism.value
        ),
        double_counting_group=frame.double_counting_group,
        evidence_class=evidence[0],
        evidence_class_authority=evidence[1],
        study=frame.study,
        evaluator=frame.evaluator,
        evaluator_version=frame.evaluator_version,
        model=_served_model(proposal),
        inference_provider=frame.inference_provider,
        inference_address_class=frame.inference_address_class,
        prompt_version=frame.prompt_version,
        policy_version=frame.policy_version,
        confidence=confidence,
        value_low=low,
        value_high=high,
        band=band,
        assumptions=assumptions,
        produced_by=valuation.produced_by,
        operand_bases=valuation.operand_bases,
        attribution_fraction=(
            None if valuation.attribution is None else valuation.attribution[0]
        ),
        attribution_basis=(
            None if valuation.attribution is None else valuation.attribution[1]
        ),
        reportability=reportability[0],
        reportability_reason=reportability[1],
        roi=RoiOperands(
            value_state=ValueSideState.VALUED,
            value=amount,
            value_basis=weakest_claim_basis(
                basis for _, basis in valuation.operand_bases
            ),
            costs=frame.costs,
            coverage=cost_coverage(frame.costs),
            # D-02, OD-18: carried beside net_value, never netted into it.
            metered_ai_cost=frame.metered_ai_cost,
            net_value=Money(amount=net, currency=currency),
        ),
        subject_ref=frame.subject_ref,
        library_version=__version__,
    )


# --- The Hermes config adapters (D-09, ADR 0028 decision 7, ledger ID-15) ---
#
# The only home of Hermes' lenient configuration reading. Every library
# constructor stays strict. The compat projection never calls these
# functions: calling them there would hide ID-15.

# Hermes DEFAULT_MAX_HOURS_SAVED and DEFAULT_MAX_LOADED_RATE
# (classifier.py:L1788-L1789).
_HERMES_DEFAULT_MAX_HOURS_SAVED: Final[float] = 40.0
_HERMES_DEFAULT_MAX_LOADED_RATE: Final[float] = 500.0
# Hermes valuation boundary names (valuation.py and classifier.py
# _boundary_impl_name("valuation", "hours_times_rate")).
_HERMES_VALUATION_BOUNDARIES: Final[tuple[tuple[str, ValuationMethod], ...]] = (
    ("hours_times_rate", ValuationMethod.HOURS_TIMES_RATE),
    ("rate_card_valuation_fixture", ValuationMethod.RATE_CARD),
    ("revenue_card_valuation_fixture", ValuationMethod.REVENUE_CARD),
    ("baselines_valuation_fixture", ValuationMethod.BASELINES),
)


def _hermes_maximum(cfg: Mapping[str, object], key: str, default: float) -> int | float:
    # Hermes `_finite_number(cfg.get(key)) or DEFAULT` (classifier.py:L2070):
    # 0, -0.0, missing, and non-finite mean the default. A usable number keeps
    # its int or float type, because the prompt renders the configured value
    # (classifier.py:L737).
    raw = cfg.get(key)
    number = finite_number(raw)
    if number is None or number == 0:
        return default
    if number < 0:
        raise ConfigurationError(
            f"{key} must be above 0, got {raw!r}; Hermes would refuse every "
            "assessment with it (ledger ID-15)"
        )
    if type(raw) is int or type(raw) is float:
        return raw
    return number


def _hermes_currency(cfg: Mapping[str, object]) -> Currency:
    # Hermes `cfg.get("currency", "USD")`, stripped and upper-cased when it
    # is a str, otherwise USD (classifier.py:L2108-L2109).
    raw = cfg.get("currency", "USD")
    text = raw.strip().upper() if isinstance(raw, str) else "USD"
    for currency in Currency:
        if currency.value == text:
            return currency
    raise ConfigurationError(
        f"currency {text!r} is not supported; Hermes would refuse every "
        "assessment with it (ledger ID-15)"
    )


def _hermes_valuation_method(cfg: Mapping[str, object]) -> ValuationMethod:
    # Hermes _boundary_impl_name (classifier.py:L4042-L4068): a missing or
    # non-object `boundaries`, or a missing, empty, or non-str name, means
    # the built-in hours_times_rate.
    boundaries = cfg.get("boundaries")
    name = boundaries.get("valuation") if isinstance(boundaries, Mapping) else None
    if not isinstance(name, str) or name == "":
        return ValuationMethod.HOURS_TIMES_RATE
    for boundary, method in _HERMES_VALUATION_BOUNDARIES:
        if boundary == name:
            return method
    raise ConfigurationError(
        f"valuation boundary {name!r} is not a Hermes built-in; inject a "
        "ValuationPolicy and use ValuationMethod.INJECTED instead"
    )


def _hermes_revenue_ceiling(
    cfg: Mapping[str, object], currency: Currency
) -> Decimal | None:
    # Hermes uses maxRevenueValue only when it is finite and above 0
    # (classifier.py:L2302-L2310), rounded to cents.
    number = finite_number(cfg.get("maxRevenueValue"))
    if number is None or number <= 0:
        return None
    try:
        ceiling = quantize_money(decimal_from_float(number), currency)
    except (decimal.InvalidOperation, decimal.Overflow) as error:
        raise ConfigurationError(
            "maxRevenueValue cannot be quantized as money"
        ) from error
    if ceiling <= 0:
        raise ConfigurationError(
            f"maxRevenueValue {number!r} rounds to 0; Hermes would refuse every "
            "revenue assessment with it (ledger ID-15)"
        )
    return ceiling


def from_hermes_config(cfg: object) -> AssessmentPolicy:
    """Read a Hermes ``llmOutcomeEvaluation`` object as an assessment policy.

    The only home of Hermes' lenient policy reading (D-09, ADR 0028
    decision 7). The compat projection never calls this function, because
    calling it there would hide ledger ID-15.

    - ``maxHoursSaved`` and ``maxLoadedRate``: 0, missing, or a non-finite
      or non-numeric value means 40.0 and 500.0. A negative value raises.
    - ``currency``: stripped and upper-cased; a missing or non-string value
      means USD. An unsupported currency raises.
    - ``experimentalReportEstimates``: read with ``is True``.
    - ``reportModelEstimates``: read with ``is True``, as Hermes
      ``_model_estimates_opted_in`` reads it (ADR 0039 decision 4). Model
      estimates are admitted only when both keys are the literal ``True``.
    - ``maxRevenueValue``: the revenue ceiling when finite and above 0,
      quantized; otherwise none. A value that rounds to 0 raises.
    - ``boundaries``: the top-level ``boundaries`` object from Hermes'
      config.json, which the host places under this key because it sits
      outside ``llmOutcomeEvaluation``. Its ``valuation`` name maps
      ``hours_times_rate``, ``rate_card_valuation_fixture``,
      ``revenue_card_valuation_fixture``, and
      ``baselines_valuation_fixture`` to ``ValuationMethod``. A missing,
      empty, or non-string name means HOURS_TIMES_RATE. Any other name
      raises, because a third-party implementation cannot be built from
      data; inject a ``ValuationPolicy`` instead.

    Args:
        cfg: The Hermes ``llmOutcomeEvaluation`` mapping, not the whole
            plugin ``config.json``, plus the ``boundaries`` key above. A
            non-mapping reads as empty, as Hermes reads it.

    Returns:
        The validated policy.

    Raises:
        ConfigurationError: For a negative maximum, an unsupported currency,
            a ``maxRevenueValue`` that rounds to 0 or cannot be quantized, an
            unknown valuation boundary name, or bounds whose ceiling cannot
            be quantized. Each names the configuration key.
    """
    config: Mapping[str, object] = cfg if isinstance(cfg, Mapping) else {}
    currency = _hermes_currency(config)
    return AssessmentPolicy(
        method=_hermes_valuation_method(config),
        bounds=OperandBounds(
            max_hours_saved=_hermes_maximum(
                config, "maxHoursSaved", _HERMES_DEFAULT_MAX_HOURS_SAVED
            ),
            max_loaded_rate=_hermes_maximum(
                config, "maxLoadedRate", _HERMES_DEFAULT_MAX_LOADED_RATE
            ),
        ),
        currency=currency,
        revenue_ceiling=_hermes_revenue_ceiling(config, currency),
        reportability=ReportabilityPolicy(
            experimental_report_estimates=config.get("experimentalReportEstimates")
            is True,
            report_model_estimates=config.get("reportModelEstimates") is True,
        ),
    )


def _hermes_rate_card(
    cfg: Mapping[str, object], inferred_role: str | None
) -> RateCardFigures | None:
    # Hermes valuation.py:L401-L425: a non-dict card is absent; a row whose
    # amount is not finite and above 0 declines, so it is dropped here.
    card = cfg.get("rateCard")
    if not isinstance(card, Mapping):
        return None
    wanted = (
        None
        if inferred_role is None
        else clamp_bytes(inferred_role, max_bytes=INFERRED_ROLE_MAX_BYTES)
    )
    amounts: list[tuple[str, Decimal]] = []
    for role, raw in card.items():
        if not _is_role_text(role) or (wanted is not None and role != wanted):
            continue
        number = finite_number(raw)
        if number is not None and number > 0:
            amounts.append((role, decimal_from_float(number)))
    return RateCardFigures(amounts=tuple(sorted(amounts)))


def _hermes_revenue_entry(raw: object) -> RevenueCardEntry | None:
    # Hermes valuation.py:L846-L895, the "asked to price and cannot" rows.
    if not isinstance(raw, Mapping):
        return None
    gross = finite_number(raw.get("grossPerJob"))
    if gross is None or gross <= 0:
        return None
    raw_fraction = raw.get("attributionFraction")
    raw_basis = raw.get("attributionBasis")
    has_fraction = raw_fraction is not None
    has_basis_text = isinstance(raw_basis, str) and raw_basis.strip() != ""
    if has_fraction != has_basis_text or (not has_fraction and raw_basis is not None):
        return None
    fraction = finite_number(raw_fraction)
    if has_fraction and (fraction is None or not 0.0 <= fraction <= 1.0):
        return None
    try:
        return RevenueCardEntry(
            gross_per_job=decimal_from_float(gross),
            attribution_fraction=(
                None if fraction is None else decimal_from_float(fraction)
            ),
            attribution_basis=(
                normalize_text(raw_basis, max_bytes=NARRATIVE_CLAMP_BYTES)
                if has_fraction
                else None
            ),
        )
    except RecordValidationError:
        # A basis of only separators and whitespace normalizes to blank.
        return None


def _hermes_revenue_card(cfg: Mapping[str, object]) -> RevenueCardFigures | None:
    # Hermes valuation.py:L813-L843: a non-dict or empty card is absent, and
    # a missing, empty, or non-str key selects nothing; both delegate.
    card = cfg.get("revenueCard")
    if not isinstance(card, Mapping) or not card:
        return None
    raw_key = cfg.get("revenueCardKey")
    key = raw_key if isinstance(raw_key, str) and raw_key != "" else None
    if key is not None and not _is_card_key(key):
        raise ConfigurationError(
            "revenueCardKey must be printable text of at most 128 serialized bytes"
        )
    entries = tuple(
        (name, _hermes_revenue_entry(card[name]))
        for name in sorted(name for name in card if _is_card_key(name))
    )
    return RevenueCardFigures(key=key, entries=entries)


def figures_from_hermes_config(
    cfg: object, *, inferred_role: str | None = None
) -> ValuationFigures:
    """Read Hermes' rate card and revenue card leniently (ADR 0028 decision 7).

    The compat projection never calls this function (ledger ID-15). A row
    that Hermes would decline per assessment is kept out of the strict
    records: a rate-card row is dropped, so its role is declined, and a
    revenue-card row becomes ``None``, so selecting it is declined rather
    than delegated, as Hermes' ``malformed_entry``, ``malformed_gross``, and
    ``malformed_attribution`` decline it. Baselines are host-fetched in
    Hermes (``_resolve_valuation_source_figures``), never read from this
    object, so ``baselines`` is always ``None``.

    Args:
        cfg: The Hermes ``llmOutcomeEvaluation`` mapping (``rateCard``,
            ``revenueCard``, ``revenueCardKey``). A non-mapping reads as
            empty.
        inferred_role: When given, only the row for this role, clamped to 60
            serialized bytes as the gate clamps it, is read from the rate
            card, as Hermes reads only the looked-up row.

    Returns:
        The figures.

    Raises:
        ConfigurationError: If ``revenueCardKey`` is a non-empty string that
            is not printable or exceeds 128 serialized bytes.
    """
    config: Mapping[str, object] = cfg if isinstance(cfg, Mapping) else {}
    return ValuationFigures(
        rate_card=_hermes_rate_card(config, inferred_role),
        revenue_card=_hermes_revenue_card(config),
    )


def supplied_costs_from_hermes_config(
    cfg: object, job_type: str, currency: Currency
) -> SuppliedCosts:
    """Read one job type's costs as Hermes' ``_resolve_supplied_costs`` does.

    Hermes classifier.py:L3171-L3247. A negative, non-finite, ``bool``,
    non-numeric, or missing cost is unknown, never zero; a supplied 0 is
    known. The compat projection never calls this function (ledger ID-15).

    A cost of at least ``costs.SUPPLIED_COST_LIMIT`` raises instead of being
    dropped. Hermes keeps it and nets it as a float; this is ADR 0028's
    seventh adapter-only difference (ADR 0030 addendum item 4). A positive
    ``int`` too large for a float raises the same way, where Hermes reads it
    as unknown (ADR 0028's eighth adapter-only difference). A NaN or infinite
    float still reads as unknown, as in Hermes.

    Args:
        cfg: The Hermes ``llmOutcomeEvaluation`` mapping. A non-mapping
            reads as empty.
        job_type: The job type whose ``costs`` object is read.
        currency: The currency of every cost.

    Returns:
        The costs, each converted with ``decimal_from_float``.

    Raises:
        RecordValidationError: If ``currency`` is not a ``Currency``.
        ConfigurationError: If a configured cost is at least
            ``SUPPLIED_COST_LIMIT``, or is a positive ``int`` too large for a
            float. The message names the category and the limit, never the
            value.
    """
    config: Mapping[str, object] = cfg if isinstance(cfg, Mapping) else {}
    costs = config.get("costs")
    job_costs = costs.get(job_type) if isinstance(costs, Mapping) else None
    values: Mapping[str, object] = job_costs if isinstance(job_costs, Mapping) else {}
    known: dict[str, Decimal | None] = {}
    for category in COST_CATEGORIES:
        raw = values.get(category.value)
        number = finite_number(raw)
        if (
            number is None
            and isinstance(raw, int)
            and not isinstance(raw, bool)
            and raw > 0
        ):
            # ADR 0028 adapter-only item 8 (IN-10): a positive int too large
            # for a float is past the limit too, so it raises like 10**25.
            raise ConfigurationError(
                f"costs.{category.value} must be below {SUPPLIED_COST_LIMIT} "
                "so it can be netted"
            )
        if number is None or number < 0:
            known[category.value] = None
            continue
        cost = decimal_from_float(number)
        if cost >= SUPPLIED_COST_LIMIT:
            raise ConfigurationError(
                f"costs.{category.value} must be below {SUPPLIED_COST_LIMIT} "
                "so it can be netted"
            )
        known[category.value] = cost
    return SuppliedCosts(currency=currency, **known)
