"""Byte-bounded text normalization shared by every clamped field.

Bounds are serialized bytes, not characters: the length of the JSON string body
under ``ensure_ascii=True`` escaping, which is how the Hermes reference defines
every clamp.
"""

import json
import math
from typing import Final

IFS_CHARACTERS: Final[tuple[str, ...]] = ("|", "\n", "\r")
NARRATIVE_CLAMP_BYTES: Final[int] = 500
PROVENANCE_MODEL_MAX_BYTES: Final[int] = 64
INFERENCE_PROVIDER_MAX_BYTES: Final[int] = 32
SUBJECT_REF_MAX_BYTES: Final[int] = 128
# Hermes classifier.py:L2599; ADR 0014.
FAILURE_REASON_CLAMP_BYTES: Final[int] = 500
# Hermes classifier.py:L3102; ADR 0020.
DOUBLE_COUNTING_GROUP_MAX_BYTES: Final[int] = 64
# Hermes classifier.py:L3096; ADR 0026 decision 1. Study ids are clamped,
# not rejected, to this bound.
STUDY_ID_MAX_BYTES: Final[int] = 100
# ADR 0017: the job name clamp and the job id bound.
JOB_NAME_MAX_BYTES: Final[int] = 200
JOB_ID_MAX_BYTES: Final[int] = 64
# ADR 0030 decision 3: 64 job-id bytes, ":", and 19 digits for 2**63 - 1.
ASSESSMENT_ID_MAX_BYTES: Final[int] = 84
# ADR 0031 decision 2 (D-10): an assessment id, ":c", and 19 digits.
CORRECTION_ID_MAX_BYTES: Final[int] = 105
# ADR 0030 decision 5: the evaluator name and version bounds on the record.
EVALUATOR_MAX_BYTES: Final[int] = 32
EVALUATOR_VERSION_MAX_BYTES: Final[int] = 16
# ADR 0015: caller identifiers are rejected, never clamped, beyond these.
IDENTIFIER_MAX_BYTES: Final[int] = 128
HOST_NAME_MAX_BYTES: Final[int] = 64


def serialized_byte_length(text: str) -> int:
    """Return the byte length of ``text`` as an ASCII-escaped JSON string body.

    Args:
        text: The string to measure.

    Returns:
        The encoded length without the two surrounding quote characters.
    """
    return len(json.dumps(text, ensure_ascii=True).encode("ascii")) - 2


def is_bounded_printable(text: str, max_bytes: int) -> bool:
    """Return whether ``text`` is non-empty, printable, and within ``max_bytes``.

    Used for identifiers a caller supplies, such as versions, display names,
    and subject references, which are rejected rather than clamped.

    Args:
        text: The text to check.
        max_bytes: The serialized-byte budget, measured by
            :func:`serialized_byte_length`.

    Returns:
        ``True`` when every condition holds.
    """
    return (
        text != "" and text.isprintable() and serialized_byte_length(text) <= max_bytes
    )


def normalize_text(value: object, *, max_bytes: int) -> str:
    """Coerce ``value`` to text, neutralize field separators, and clamp it.

    ``None`` becomes the empty string and any other non-string becomes
    ``str(value)``. Each IFS character becomes a space, the text is stripped,
    and the longest code-point prefix whose serialized length fits
    ``max_bytes`` is returned. The prefix is not stripped again, so a cut that
    lands after whitespace leaves trailing whitespace and the function is not
    idempotent. That matches the Hermes clamp.

    Args:
        value: The value to normalize.
        max_bytes: The serialized-byte budget, measured by
            :func:`serialized_byte_length`.

    Returns:
        The normalized, clamped text.
    """
    text = "" if value is None else value if isinstance(value, str) else str(value)
    for character in IFS_CHARACTERS:
        text = text.replace(character, " ")
    text = text.strip()
    if serialized_byte_length(text) <= max_bytes:
        return text
    return text[: _longest_fitting_prefix(text, max_bytes)]


def clamp_bytes(text: str, *, max_bytes: int) -> str:
    """Return the longest code-point prefix of ``text`` that fits ``max_bytes``.

    Unlike :func:`normalize_text`, nothing is replaced or stripped. It is used
    for ``repr()`` output, which is already escaped.

    Args:
        text: The text to clamp.
        max_bytes: The serialized-byte budget, measured by
            :func:`serialized_byte_length`.

    Returns:
        ``text`` itself when it fits, otherwise its longest fitting prefix.
    """
    if serialized_byte_length(text) <= max_bytes:
        return text
    return text[: _longest_fitting_prefix(text, max_bytes)]


def finite_number(value: object) -> float | None:
    """Return ``value`` as a float when it is a real, finite, non-bool number.

    ``bool`` is rejected even though it subclasses ``int``. NaN, infinity, and
    an ``int`` too large to convert to ``float`` all return ``None``, so an
    unrepresentable number reads as unknown, never as zero. ``-0.0`` keeps its
    sign.

    Args:
        value: The value to check.

    Returns:
        The float, or ``None``.
    """
    if isinstance(value, bool) or not isinstance(value, int | float):
        return None
    try:
        number = float(value)
    except OverflowError:
        return None
    if math.isnan(number) or math.isinf(number):
        return None
    return number


def _longest_fitting_prefix(text: str, max_bytes: int) -> int:
    low, high = 0, len(text)
    while low < high:
        middle = (low + high + 1) // 2
        if serialized_byte_length(text[:middle]) <= max_bytes:
            low = middle
        else:
            high = middle - 1
    return low
