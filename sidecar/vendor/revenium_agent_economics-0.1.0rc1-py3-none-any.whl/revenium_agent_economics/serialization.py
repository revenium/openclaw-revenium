"""Canonical JSON encoding, strict decoding, and record codecs.

Every encoded byte comes from :func:`canonical_json`. Decoding accepts only
bytes that :func:`canonical_json` would have produced, for a schema id and
version listed in the static ``SCHEMA_IDS`` tuple or reachable from one through
the static ``MIGRATIONS`` tuple.
"""

import enum
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from types import MappingProxyType
from typing import Any, Final, TypeAlias, TypeVar

from revenium_agent_economics._canonical import JsonValue as JsonValue
from revenium_agent_economics._canonical import canonical_json as canonical_json
from revenium_agent_economics._canonical import format_decimal as format_decimal
from revenium_agent_economics._canonical import (
    format_utc_timestamp as format_utc_timestamp,
)
from revenium_agent_economics._canonical import parse_decimal as parse_decimal
from revenium_agent_economics._canonical import (
    parse_json_strict as parse_json_strict,
)
from revenium_agent_economics._canonical import (
    parse_utc_timestamp as parse_utc_timestamp,
)
from revenium_agent_economics.assessment import (
    AssessJobRequest,
    AssessmentAbstention,
    InferenceLocality,
    JobAssessment,
)
from revenium_agent_economics.corrections import (
    CorrectableField,
    Correction,
    CorrectionFields,
    CorrectionRejection,
    CorrectionRejectionReason,
    EffectiveAssessment,
    RecordRef,
)
from revenium_agent_economics.costs import (
    CostCoverage,
    RoiOperands,
    SuppliedCosts,
    ValueSideState,
)
from revenium_agent_economics.diagnostics import (
    Diagnostic,
    DiagnosticCode,
    DiagnosticLevel,
)
from revenium_agent_economics.envelope import (
    _PAYLOAD_TYPES,
    ActivityEvent,
    ActivityIdentity,
    ActivityKind,
    ActivityLog,
    ActivityPayload,
    AttributeValue,
    CompactionInfo,
    CompactionTrigger,
    DelegationInitiator,
    DelegationMode,
    DelegationResult,
    EventSource,
    NoPayload,
    SessionEndInfo,
    SessionOrigin,
    TaskTransition,
    TextExcerpt,
    ToolOutcome,
    UsageReport,
)
from revenium_agent_economics.errors import (
    CanonicalizationError,
    RecordValidationError,
    UnsupportedSchemaError,
)
from revenium_agent_economics.evidence import ResolvedEvidence
from revenium_agent_economics.jobs import (
    AttributionBasis,
    DoubleCountingScope,
    JobBoundary,
    JobCandidate,
    JobInference,
    JobInferenceAbstention,
    JobInferenceAbstentionReason,
    JobInferenceRequest,
    JobOutcome,
    JobRejectionReason,
    JobTypeAssignment,
    RejectedJobProposal,
)
from revenium_agent_economics.lineage import (
    JobSubject,
    LineageEdgeKind,
    LineageEntry,
    LineageNode,
    SessionLineage,
)
from revenium_agent_economics.metrics import (
    AllocationShare,
    EconomicsContract,
    GroupAllocation,
    MetricDeclaration,
    MetricRefusal,
    MetricRefusalReason,
    OutcomeMetricIntent,
    OutcomeMetricIntents,
    SharedOutcomeFlag,
)
from revenium_agent_economics.outcomes import (
    BandShape,
    DiscardedField,
    OperandBounds,
    OperandKind,
    OutcomeAbstention,
    OutcomeAbstentionReason,
    OutcomeAssertion,
    OutcomeProposal,
    OutcomeRequest,
    ProposedOperand,
    RoleVocabulary,
    RoleVocabularyEntry,
)
from revenium_agent_economics.primitives import (
    Abstention,
    ComponentVersion,
    Confidence,
    Money,
    StudyReference,
    VersionStamp,
)
from revenium_agent_economics.protocols import (
    AddressClass,
    CompletionMessage,
    CompletionPurpose,
    CompletionRequest,
    CompletionResult,
    ComponentDeclaration,
    EvidenceQuery,
    FinishReason,
    JobSegmentationInput,
    MessageRole,
    OutcomeEvaluationInput,
    ReportabilityQuery,
    ResolvedAssumptions,
    TaskClassificationInput,
    TokenUsage,
)
from revenium_agent_economics.scenarios import (
    ExpectationKind,
    ExpectationVerdict,
    HostShape,
    JobSource,
    PolicyPreset,
    Scenario,
    ScenarioExpectation,
    ScenarioResult,
)
from revenium_agent_economics.tasks import (
    ClassificationAbstention,
    InferenceProvenance,
    PromptRef,
    TaskClassification,
    TaskClassificationRequest,
)
from revenium_agent_economics.taxonomy import (
    ClassificationAbstentionReason,
    JobTaxonomySnapshot,
    LabelProposal,
    TaskTaxonomySnapshot,
    TaxonomyNamespace,
    TaxonomyRef,
)
from revenium_agent_economics.valuation import (
    BaselineFigures,
    DerivedBand,
    OperandBases,
    RateCardFigures,
    RevenueCardEntry,
    RevenueCardFigures,
    ValuationFigures,
    ValuationMethod,
    ValuationOperand,
)
from revenium_agent_economics.vocab import (
    COST_CATEGORIES,
    AbstentionReason,
    AssessmentRefusal,
    ClaimBasis,
    Currency,
    EconomicMechanism,
    EvidenceAuthority,
    EvidenceClass,
    MetricType,
    ReportabilityReason,
    ReportabilityStatus,
)

Record: TypeAlias = (
    Money
    | Confidence
    | ComponentVersion
    | VersionStamp
    | Abstention
    | StudyReference
    | Diagnostic
    | TaxonomyRef
    | PromptRef
    | TokenUsage
    | InferenceProvenance
    | ComponentDeclaration
    | ClassificationAbstention
    | TaskTaxonomySnapshot
    | JobTaxonomySnapshot
    | LabelProposal
    | CompletionMessage
    | CompletionRequest
    | CompletionResult
    | TaskClassificationRequest
    | TaskClassification
    | TaskClassificationInput
    | JobSegmentationInput
    | OutcomeEvaluationInput
    | EvidenceQuery
    | ReportabilityQuery
    | TextExcerpt
    | LineageNode
    | JobSubject
    | LineageEntry
    | SessionLineage
    | JobBoundary
    | JobTypeAssignment
    | JobCandidate
    | RejectedJobProposal
    | JobInferenceAbstention
    | JobInference
    | JobInferenceRequest
    | ActivityIdentity
    | ToolOutcome
    | TaskTransition
    | UsageReport
    | CompactionInfo
    | SessionEndInfo
    | DelegationResult
    | NoPayload
    | ActivityEvent
    | ActivityLog
    | OperandBounds
    | OutcomeAssertion
    | ProposedOperand
    | DiscardedField
    | RoleVocabularyEntry
    | RoleVocabulary
    | OutcomeRequest
    | OutcomeProposal
    | OutcomeAbstention
    | ResolvedAssumptions
    | DerivedBand
    | RateCardFigures
    | RevenueCardEntry
    | RevenueCardFigures
    | BaselineFigures
    | ValuationFigures
    | ResolvedEvidence
    | SuppliedCosts
    | CostCoverage
    | RoiOperands
    | InferenceLocality
    | AssessJobRequest
    | JobAssessment
    | AssessmentAbstention
    | RecordRef
    | CorrectionFields
    | Correction
    | CorrectionRejection
    | EffectiveAssessment
    | MetricDeclaration
    | EconomicsContract
    | OutcomeMetricIntent
    | OutcomeMetricIntents
    | SharedOutcomeFlag
    | MetricRefusal
    | AllocationShare
    | GroupAllocation
    | ScenarioExpectation
    | Scenario
    | ExpectationVerdict
    | ScenarioResult
)
NestedDecoder: TypeAlias = Callable[[JsonValue], Record]
RecordEncoder: TypeAlias = Callable[[Any], dict[str, JsonValue]]
RecordDecoder: TypeAlias = Callable[[Mapping[str, JsonValue], NestedDecoder], Record]
Upgrade: TypeAlias = Callable[[Mapping[str, JsonValue]], dict[str, JsonValue]]

_E = TypeVar("_E", bound=enum.Enum)
_R = TypeVar(
    "_R",
    Money,
    Confidence,
    ComponentVersion,
    VersionStamp,
    Abstention,
    StudyReference,
    Diagnostic,
    TaxonomyRef,
    PromptRef,
    TokenUsage,
    InferenceProvenance,
    ComponentDeclaration,
    ClassificationAbstention,
    TaskTaxonomySnapshot,
    JobTaxonomySnapshot,
    LabelProposal,
    CompletionMessage,
    CompletionRequest,
    CompletionResult,
    TaskClassificationRequest,
    TaskClassification,
    TaskClassificationInput,
    JobSegmentationInput,
    OutcomeEvaluationInput,
    EvidenceQuery,
    ReportabilityQuery,
    TextExcerpt,
    LineageNode,
    JobSubject,
    LineageEntry,
    SessionLineage,
    JobBoundary,
    JobTypeAssignment,
    JobCandidate,
    RejectedJobProposal,
    JobInferenceAbstention,
    JobInference,
    JobInferenceRequest,
    ActivityIdentity,
    ToolOutcome,
    TaskTransition,
    UsageReport,
    CompactionInfo,
    SessionEndInfo,
    DelegationResult,
    NoPayload,
    ActivityEvent,
    ActivityLog,
    OperandBounds,
    OutcomeAssertion,
    ProposedOperand,
    DiscardedField,
    RoleVocabularyEntry,
    RoleVocabulary,
    OutcomeRequest,
    OutcomeProposal,
    OutcomeAbstention,
    ResolvedAssumptions,
    DerivedBand,
    RateCardFigures,
    RevenueCardEntry,
    RevenueCardFigures,
    BaselineFigures,
    ValuationFigures,
    ResolvedEvidence,
    SuppliedCosts,
    CostCoverage,
    RoiOperands,
    InferenceLocality,
    AssessJobRequest,
    JobAssessment,
    AssessmentAbstention,
    RecordRef,
    CorrectionFields,
    Correction,
    CorrectionRejection,
    EffectiveAssessment,
    MetricDeclaration,
    EconomicsContract,
    OutcomeMetricIntent,
    OutcomeMetricIntents,
    SharedOutcomeFlag,
    MetricRefusal,
    AllocationShare,
    GroupAllocation,
    ScenarioExpectation,
    Scenario,
    ExpectationVerdict,
    ScenarioResult,
)

_SCHEMA_KEYS: Final = frozenset({"schema_id", "schema_version"})
_UNKNOWN_SCHEMA: Final = "<unknown>"
_JSON_TYPE_NAMES: Final[Mapping[type, str]] = MappingProxyType(
    {
        dict: "object",
        list: "array",
        str: "string",
        int: "integer",
        float: "number",
        bool: "boolean",
        type(None): "null",
    }
)


@dataclass(frozen=True, slots=True, kw_only=True)
class SchemaEntry:
    """One decodable schema id and version and the codec for its record type.

    Attributes:
        schema_id: The schema id written into every encoded record.
        schema_version: The schema version this codec reads and writes.
        record_type: The record class this entry encodes and decodes.
        encode: Returns the record's fields, without the schema keys, as
            JSON-native values.
        decode: Builds the record from its fields, without the schema keys,
            decoding nested records through the supplied decoder.
    """

    schema_id: str
    schema_version: int
    record_type: type[Record]
    encode: RecordEncoder
    decode: RecordDecoder


@dataclass(frozen=True, slots=True, kw_only=True)
class Migration:
    """An explicit upgrade of one schema version's fields to a later version.

    Attributes:
        schema_id: The schema id the migration applies to.
        from_version: The stored version the migration reads.
        to_version: The version the upgraded fields conform to.
        upgrade: Maps the stored fields, without the schema keys, to the
            fields of ``to_version``.
    """

    schema_id: str
    from_version: int
    to_version: int
    upgrade: Upgrade


def _json_type(value: object) -> str:
    return _JSON_TYPE_NAMES.get(type(value), type(value).__name__)


def _require_keys(
    schema_id: str,
    fields: Mapping[str, JsonValue],
    required: tuple[str, ...],
    optional: tuple[str, ...] = (),
) -> None:
    for key in sorted(fields):
        if key not in required and key not in optional:
            raise RecordValidationError(schema_id, key, "unknown key")
    for key in required:
        if key not in fields:
            raise RecordValidationError(schema_id, key, "missing key")
    for key in optional:
        if key in fields and fields[key] is None:
            raise RecordValidationError(
                schema_id, key, "explicit null; omit the key instead"
            )


def _read_str(schema_id: str, fields: Mapping[str, JsonValue], key: str) -> str:
    value = fields[key]
    if type(value) is not str:
        raise RecordValidationError(
            schema_id, key, f"JSON string required, got {_json_type(value)}"
        )
    return value


def _read_int(schema_id: str, fields: Mapping[str, JsonValue], key: str) -> int:
    value = fields[key]
    if type(value) is not int:
        raise RecordValidationError(
            schema_id, key, f"JSON integer required, got {_json_type(value)}"
        )
    return value


def _read_float(schema_id: str, fields: Mapping[str, JsonValue], key: str) -> float:
    value = fields[key]
    if type(value) is not float:
        raise RecordValidationError(
            schema_id,
            key,
            f"JSON number with a fraction required, got {_json_type(value)}",
        )
    return value


def _read_bool(schema_id: str, fields: Mapping[str, JsonValue], key: str) -> bool:
    value = fields[key]
    if type(value) is not bool:
        raise RecordValidationError(
            schema_id, key, f"JSON boolean required, got {_json_type(value)}"
        )
    return value


def _read_optional_str(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> str | None:
    return _read_str(schema_id, fields, key) if key in fields else None


def _read_optional_int(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> int | None:
    return _read_int(schema_id, fields, key) if key in fields else None


def _read_decimal(schema_id: str, fields: Mapping[str, JsonValue], key: str) -> Decimal:
    text = _read_str(schema_id, fields, key)
    try:
        return parse_decimal(text)
    except CanonicalizationError as error:
        raise RecordValidationError(schema_id, key, str(error)) from error


def _read_enum(
    schema_id: str, fields: Mapping[str, JsonValue], key: str, enum_type: type[_E]
) -> _E:
    text = _read_str(schema_id, fields, key)
    try:
        return enum_type(text)
    except ValueError as error:
        raise RecordValidationError(
            schema_id, key, f"not a {enum_type.__name__} value: {text!r}"
        ) from error


def _read_records(
    schema_id: str,
    fields: Mapping[str, JsonValue],
    key: str,
    nested: NestedDecoder,
    record_type: type[_R],
) -> tuple[_R, ...]:
    value = fields[key]
    if type(value) is not list:
        raise RecordValidationError(
            schema_id, key, f"JSON array required, got {_json_type(value)}"
        )
    records: list[_R] = []
    for index, item in enumerate(value):
        record = nested(item)
        if not isinstance(record, record_type) or type(record) is not record_type:
            raise RecordValidationError(
                schema_id,
                key,
                f"element {index} must be {record_type.__name__}, "
                f"got {type(record).__name__}",
            )
        records.append(record)
    return tuple(records)


def _read_strs(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> tuple[str, ...]:
    value = fields[key]
    if type(value) is not list:
        raise RecordValidationError(
            schema_id, key, f"JSON array required, got {_json_type(value)}"
        )
    items: list[str] = []
    for index, item in enumerate(value):
        if type(item) is not str:
            raise RecordValidationError(
                schema_id,
                key,
                f"element {index} must be a JSON string, got {_json_type(item)}",
            )
        items.append(item)
    return tuple(items)


def _read_ints(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> tuple[int, ...]:
    value = fields[key]
    if type(value) is not list:
        raise RecordValidationError(
            schema_id, key, f"JSON array required, got {_json_type(value)}"
        )
    items: list[int] = []
    for index, item in enumerate(value):
        if type(item) is not int:
            raise RecordValidationError(
                schema_id,
                key,
                f"element {index} must be a JSON integer, got {_json_type(item)}",
            )
        items.append(item)
    return tuple(items)


def _read_enums(
    schema_id: str, fields: Mapping[str, JsonValue], key: str, enum_type: type[_E]
) -> tuple[_E, ...]:
    value = fields[key]
    if type(value) is not list:
        raise RecordValidationError(
            schema_id, key, f"JSON array required, got {_json_type(value)}"
        )
    members: list[_E] = []
    for index, item in enumerate(value):
        if type(item) is not str:
            raise RecordValidationError(
                schema_id,
                key,
                f"element {index} must be a JSON string, got {_json_type(item)}",
            )
        try:
            members.append(enum_type(item))
        except ValueError as error:
            raise RecordValidationError(
                schema_id,
                key,
                f"element {index} is not a {enum_type.__name__} value: {item!r}",
            ) from error
    return tuple(members)


def _read_timestamp(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> datetime:
    text = _read_str(schema_id, fields, key)
    try:
        return parse_utc_timestamp(text)
    except CanonicalizationError as error:
        raise RecordValidationError(schema_id, key, str(error)) from error


def _read_record(
    schema_id: str,
    fields: Mapping[str, JsonValue],
    key: str,
    nested: NestedDecoder,
    record_type: type[_R],
) -> _R:
    record = nested(fields[key])
    if not isinstance(record, record_type) or type(record) is not record_type:
        raise RecordValidationError(
            schema_id,
            key,
            f"{record_type.__name__} required, got {type(record).__name__}",
        )
    return record


def _read_optional_record(
    schema_id: str,
    fields: Mapping[str, JsonValue],
    key: str,
    nested: NestedDecoder,
    record_type: type[_R],
) -> _R | None:
    if key not in fields:
        return None
    return _read_record(schema_id, fields, key, nested, record_type)


def _encode_money(record: Money) -> dict[str, JsonValue]:
    return {"amount": format_decimal(record.amount), "currency": record.currency.value}


def _decode_money(fields: Mapping[str, JsonValue], nested: NestedDecoder) -> Money:
    schema_id = Money.SCHEMA_ID
    _require_keys(schema_id, fields, ("amount", "currency"))
    return Money(
        amount=_read_decimal(schema_id, fields, "amount"),
        currency=_read_enum(schema_id, fields, "currency", Currency),
    )


def _encode_confidence(record: Confidence) -> dict[str, JsonValue]:
    # Adding 0.0 turns -0.0 into 0.0: the two compare equal, so they must
    # encode to the same bytes.
    return {"value": record.value + 0.0}


def _decode_confidence(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> Confidence:
    _require_keys(Confidence.SCHEMA_ID, fields, ("value",))
    return Confidence(value=_read_float(Confidence.SCHEMA_ID, fields, "value"))


def _encode_component_version(record: ComponentVersion) -> dict[str, JsonValue]:
    return {"name": record.name, "version": record.version}


def _decode_component_version(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ComponentVersion:
    schema_id = ComponentVersion.SCHEMA_ID
    _require_keys(schema_id, fields, ("name", "version"))
    return ComponentVersion(
        name=_read_str(schema_id, fields, "name"),
        version=_read_str(schema_id, fields, "version"),
    )


# The stamped record's schema id and version use "stamped_" wire keys because
# "schema_id" and "schema_version" identify the VersionStamp record itself.
def _encode_version_stamp(record: VersionStamp) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "stamped_schema_id": record.schema_id,
        "stamped_schema_version": record.schema_version,
        "library_version": record.library_version,
        "component_versions": [
            to_json_value(component) for component in record.component_versions
        ],
    }
    if record.taxonomy_version is not None:
        encoded["taxonomy_version"] = record.taxonomy_version
    if record.prompt_version is not None:
        encoded["prompt_version"] = record.prompt_version
    if record.policy_version is not None:
        encoded["policy_version"] = record.policy_version
    return encoded


def _decode_version_stamp(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> VersionStamp:
    schema_id = VersionStamp.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            "stamped_schema_id",
            "stamped_schema_version",
            "library_version",
            "component_versions",
        ),
        ("taxonomy_version", "prompt_version", "policy_version"),
    )
    return VersionStamp(
        schema_id=_read_str(schema_id, fields, "stamped_schema_id"),
        schema_version=_read_int(schema_id, fields, "stamped_schema_version"),
        library_version=_read_str(schema_id, fields, "library_version"),
        taxonomy_version=_read_optional_str(schema_id, fields, "taxonomy_version"),
        prompt_version=_read_optional_int(schema_id, fields, "prompt_version"),
        policy_version=_read_optional_str(schema_id, fields, "policy_version"),
        component_versions=_read_records(
            schema_id, fields, "component_versions", nested, ComponentVersion
        ),
    )


def _encode_abstention(record: Abstention) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {"reason": record.reason.value}
    if record.detail is not None:
        encoded["detail"] = record.detail
    return encoded


def _decode_abstention(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> Abstention:
    schema_id = Abstention.SCHEMA_ID
    _require_keys(schema_id, fields, ("reason",), ("detail",))
    return Abstention(
        reason=_read_enum(schema_id, fields, "reason", AbstentionReason),
        detail=_read_optional_str(schema_id, fields, "detail"),
    )


def _encode_study_reference(record: StudyReference) -> dict[str, JsonValue]:
    return {"study_id": record.study_id, "study_version": record.study_version}


def _decode_study_reference(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> StudyReference:
    schema_id = StudyReference.SCHEMA_ID
    _require_keys(schema_id, fields, ("study_id", "study_version"))
    return StudyReference(
        study_id=_read_str(schema_id, fields, "study_id"),
        study_version=_read_int(schema_id, fields, "study_version"),
    )


def _encode_diagnostic(record: Diagnostic) -> dict[str, JsonValue]:
    fields: dict[str, JsonValue] = dict(record.fields)
    return {"code": record.code.value, "level": record.level.value, "fields": fields}


def _decode_diagnostic(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> Diagnostic:
    schema_id = Diagnostic.SCHEMA_ID
    _require_keys(schema_id, fields, ("code", "level", "fields"))
    pairs = fields["fields"]
    if type(pairs) is not dict:
        raise RecordValidationError(
            schema_id, "fields", f"JSON object required, got {_json_type(pairs)}"
        )
    items: list[tuple[str, str]] = []
    for key in sorted(pairs):
        value = pairs[key]
        if type(value) is not str:
            raise RecordValidationError(
                schema_id,
                "fields",
                f"value for {key!r} must be a JSON string, got {_json_type(value)}",
            )
        items.append((key, value))
    return Diagnostic(
        code=_read_enum(schema_id, fields, "code", DiagnosticCode),
        level=_read_enum(schema_id, fields, "level", DiagnosticLevel),
        fields=tuple(items),
    )


def _encode_taxonomy_ref(record: TaxonomyRef) -> dict[str, JsonValue]:
    return {
        "namespace": record.namespace.value,
        "version": record.version,
        "content_hash": record.content_hash,
    }


def _decode_taxonomy_ref(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> TaxonomyRef:
    schema_id = TaxonomyRef.SCHEMA_ID
    _require_keys(schema_id, fields, ("namespace", "version", "content_hash"))
    return TaxonomyRef(
        namespace=_read_enum(schema_id, fields, "namespace", TaxonomyNamespace),
        version=_read_str(schema_id, fields, "version"),
        content_hash=_read_str(schema_id, fields, "content_hash"),
    )


def _encode_prompt_ref(record: PromptRef) -> dict[str, JsonValue]:
    return {
        "name": record.name,
        "version": record.version,
        "template_hash": record.template_hash,
        "host_display_name": record.host_display_name,
    }


def _decode_prompt_ref(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> PromptRef:
    schema_id = PromptRef.SCHEMA_ID
    _require_keys(
        schema_id, fields, ("name", "version", "template_hash", "host_display_name")
    )
    return PromptRef(
        name=_read_str(schema_id, fields, "name"),
        version=_read_int(schema_id, fields, "version"),
        template_hash=_read_str(schema_id, fields, "template_hash"),
        host_display_name=_read_str(schema_id, fields, "host_display_name"),
    )


def _encode_token_usage(record: TokenUsage) -> dict[str, JsonValue]:
    return {
        "input_tokens": record.input_tokens,
        "output_tokens": record.output_tokens,
    }


def _decode_token_usage(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> TokenUsage:
    schema_id = TokenUsage.SCHEMA_ID
    _require_keys(schema_id, fields, ("input_tokens", "output_tokens"))
    return TokenUsage(
        input_tokens=_read_int(schema_id, fields, "input_tokens"),
        output_tokens=_read_int(schema_id, fields, "output_tokens"),
    )


def _encode_inference_provenance(
    record: InferenceProvenance,
) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "finish_reason": record.finish_reason.value,
        "address_class": record.address_class.value,
    }
    if record.served_model is not None:
        encoded["served_model"] = record.served_model
    if record.provider is not None:
        encoded["provider"] = record.provider
    if record.usage is not None:
        encoded["usage"] = to_json_value(record.usage)
    if record.cost is not None:
        encoded["cost"] = to_json_value(record.cost)
    return encoded


def _decode_inference_provenance(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> InferenceProvenance:
    schema_id = InferenceProvenance.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("finish_reason", "address_class"),
        ("served_model", "provider", "usage", "cost"),
    )
    return InferenceProvenance(
        finish_reason=_read_enum(schema_id, fields, "finish_reason", FinishReason),
        served_model=_read_optional_str(schema_id, fields, "served_model"),
        provider=_read_optional_str(schema_id, fields, "provider"),
        address_class=_read_enum(schema_id, fields, "address_class", AddressClass),
        usage=_read_optional_record(schema_id, fields, "usage", nested, TokenUsage),
        cost=_read_optional_record(schema_id, fields, "cost", nested, Money),
    )


def _encode_component_declaration(
    record: ComponentDeclaration,
) -> dict[str, JsonValue]:
    return {
        "name": record.name,
        "version": record.version,
        "evidence_class": record.evidence_class.value,
        "declared_mechanisms": [
            mechanism.value for mechanism in record.declared_mechanisms
        ],
    }


def _decode_component_declaration(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ComponentDeclaration:
    schema_id = ComponentDeclaration.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("name", "version", "evidence_class", "declared_mechanisms"),
    )
    return ComponentDeclaration(
        name=_read_str(schema_id, fields, "name"),
        version=_read_str(schema_id, fields, "version"),
        evidence_class=_read_enum(schema_id, fields, "evidence_class", EvidenceClass),
        declared_mechanisms=_read_enums(
            schema_id, fields, "declared_mechanisms", EconomicMechanism
        ),
    )


def _encode_classification_abstention(
    record: ClassificationAbstention,
) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "reason": record.reason.value,
        "classified_at": format_utc_timestamp(record.classified_at),
        "library_version": record.library_version,
    }
    if record.taxonomy is not None:
        encoded["taxonomy"] = to_json_value(record.taxonomy)
    if record.prompt is not None:
        encoded["prompt"] = to_json_value(record.prompt)
    if record.inference is not None:
        encoded["inference"] = to_json_value(record.inference)
    if record.classifier is not None:
        encoded["classifier"] = to_json_value(record.classifier)
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    return encoded


def _decode_classification_abstention(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ClassificationAbstention:
    schema_id = ClassificationAbstention.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("reason", "classified_at", "library_version"),
        ("taxonomy", "prompt", "inference", "classifier", "subject_ref"),
    )
    return ClassificationAbstention(
        reason=_read_enum(schema_id, fields, "reason", ClassificationAbstentionReason),
        taxonomy=_read_optional_record(
            schema_id, fields, "taxonomy", nested, TaxonomyRef
        ),
        prompt=_read_optional_record(schema_id, fields, "prompt", nested, PromptRef),
        inference=_read_optional_record(
            schema_id, fields, "inference", nested, InferenceProvenance
        ),
        classifier=_read_optional_record(
            schema_id, fields, "classifier", nested, ComponentDeclaration
        ),
        classified_at=_read_timestamp(schema_id, fields, "classified_at"),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
        library_version=_read_str(schema_id, fields, "library_version"),
    )


def _encode_snapshot(
    record: TaskTaxonomySnapshot | JobTaxonomySnapshot,
) -> dict[str, JsonValue]:
    labels: list[JsonValue] = list(record.labels)
    return {
        "version": record.version,
        "labels": labels,
        "content_hash": record.content_hash,
    }


def _verify_content_hash(
    snapshot: TaskTaxonomySnapshot | JobTaxonomySnapshot, stored: str
) -> None:
    # T-02-04: the stored hash must equal the recomputed one, so a stored
    # snapshot cannot claim a hash for labels or a version it does not hold.
    if snapshot.content_hash != stored:
        raise RecordValidationError(
            snapshot.SCHEMA_ID,
            "content_hash",
            "does not match the recomputed hash of the namespace, version, and labels",
        )


def _decode_task_taxonomy_snapshot(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> TaskTaxonomySnapshot:
    schema_id = TaskTaxonomySnapshot.SCHEMA_ID
    _require_keys(schema_id, fields, ("version", "labels", "content_hash"))
    snapshot = TaskTaxonomySnapshot(
        version=_read_str(schema_id, fields, "version"),
        labels=_read_strs(schema_id, fields, "labels"),
    )
    _verify_content_hash(snapshot, _read_str(schema_id, fields, "content_hash"))
    return snapshot


def _decode_job_taxonomy_snapshot(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> JobTaxonomySnapshot:
    schema_id = JobTaxonomySnapshot.SCHEMA_ID
    _require_keys(schema_id, fields, ("version", "labels", "content_hash"))
    snapshot = JobTaxonomySnapshot(
        version=_read_str(schema_id, fields, "version"),
        labels=_read_strs(schema_id, fields, "labels"),
    )
    _verify_content_hash(snapshot, _read_str(schema_id, fields, "content_hash"))
    return snapshot


def _encode_label_proposal(record: LabelProposal) -> dict[str, JsonValue]:
    return {
        "namespace": record.namespace.value,
        "label": record.label,
        "taxonomy": to_json_value(record.taxonomy),
    }


def _decode_label_proposal(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> LabelProposal:
    schema_id = LabelProposal.SCHEMA_ID
    _require_keys(schema_id, fields, ("namespace", "label", "taxonomy"))
    return LabelProposal(
        namespace=_read_enum(schema_id, fields, "namespace", TaxonomyNamespace),
        label=_read_str(schema_id, fields, "label"),
        taxonomy=_read_record(schema_id, fields, "taxonomy", nested, TaxonomyRef),
    )


def _encode_completion_message(record: CompletionMessage) -> dict[str, JsonValue]:
    return {"role": record.role.value, "content": record.content}


def _decode_completion_message(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> CompletionMessage:
    schema_id = CompletionMessage.SCHEMA_ID
    _require_keys(schema_id, fields, ("role", "content"))
    return CompletionMessage(
        role=_read_enum(schema_id, fields, "role", MessageRole),
        content=_read_str(schema_id, fields, "content"),
    )


def _encode_completion_request(record: CompletionRequest) -> dict[str, JsonValue]:
    return {
        "messages": [to_json_value(message) for message in record.messages],
        "max_tokens": record.max_tokens,
        # Adding 0.0 turns -0.0 into 0.0: equal records encode to equal bytes.
        "temperature": record.temperature + 0.0,
        "purpose": record.purpose.value,
    }


def _decode_completion_request(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> CompletionRequest:
    schema_id = CompletionRequest.SCHEMA_ID
    _require_keys(
        schema_id, fields, ("messages", "max_tokens", "temperature", "purpose")
    )
    return CompletionRequest(
        messages=_read_records(
            schema_id, fields, "messages", nested, CompletionMessage
        ),
        max_tokens=_read_int(schema_id, fields, "max_tokens"),
        temperature=_read_float(schema_id, fields, "temperature"),
        purpose=_read_enum(schema_id, fields, "purpose", CompletionPurpose),
    )


def _encode_completion_result(record: CompletionResult) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "text": record.text,
        "finish_reason": record.finish_reason.value,
        "address_class": record.address_class.value,
    }
    if record.served_model is not None:
        encoded["served_model"] = record.served_model
    if record.provider is not None:
        encoded["provider"] = record.provider
    if record.usage is not None:
        encoded["usage"] = to_json_value(record.usage)
    if record.cost is not None:
        encoded["cost"] = to_json_value(record.cost)
    return encoded


def _decode_completion_result(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> CompletionResult:
    schema_id = CompletionResult.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("text", "finish_reason", "address_class"),
        ("served_model", "provider", "usage", "cost"),
    )
    return CompletionResult(
        text=_read_str(schema_id, fields, "text"),
        finish_reason=_read_enum(schema_id, fields, "finish_reason", FinishReason),
        served_model=_read_optional_str(schema_id, fields, "served_model"),
        provider=_read_optional_str(schema_id, fields, "provider"),
        address_class=_read_enum(schema_id, fields, "address_class", AddressClass),
        usage=_read_optional_record(schema_id, fields, "usage", nested, TokenUsage),
        cost=_read_optional_record(schema_id, fields, "cost", nested, Money),
    )


def _encode_task_classification_request(
    record: TaskClassificationRequest,
) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {}
    if record.user_message is not None:
        encoded["user_message"] = record.user_message
    if record.assistant_response is not None:
        encoded["assistant_response"] = record.assistant_response
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    return encoded


def _decode_task_classification_request(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> TaskClassificationRequest:
    schema_id = TaskClassificationRequest.SCHEMA_ID
    _require_keys(
        schema_id, fields, (), ("user_message", "assistant_response", "subject_ref")
    )
    return TaskClassificationRequest(
        user_message=_read_optional_str(schema_id, fields, "user_message"),
        assistant_response=_read_optional_str(schema_id, fields, "assistant_response"),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
    )


def _encode_task_classification(
    record: TaskClassification,
) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "label": record.label,
        "taxonomy": to_json_value(record.taxonomy),
        "classifier": to_json_value(record.classifier),
        "classified_at": format_utc_timestamp(record.classified_at),
        "library_version": record.library_version,
    }
    if record.prompt is not None:
        encoded["prompt"] = to_json_value(record.prompt)
    if record.inference is not None:
        encoded["inference"] = to_json_value(record.inference)
    if record.proposal is not None:
        encoded["proposal"] = to_json_value(record.proposal)
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    return encoded


def _decode_task_classification(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> TaskClassification:
    schema_id = TaskClassification.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("label", "taxonomy", "classifier", "classified_at", "library_version"),
        ("prompt", "inference", "proposal", "subject_ref"),
    )
    return TaskClassification(
        label=_read_str(schema_id, fields, "label"),
        taxonomy=_read_record(schema_id, fields, "taxonomy", nested, TaxonomyRef),
        prompt=_read_optional_record(schema_id, fields, "prompt", nested, PromptRef),
        inference=_read_optional_record(
            schema_id, fields, "inference", nested, InferenceProvenance
        ),
        classifier=_read_record(
            schema_id, fields, "classifier", nested, ComponentDeclaration
        ),
        proposal=_read_optional_record(
            schema_id, fields, "proposal", nested, LabelProposal
        ),
        classified_at=_read_timestamp(schema_id, fields, "classified_at"),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
        library_version=_read_str(schema_id, fields, "library_version"),
    )


def _encode_task_classification_input(
    record: TaskClassificationInput,
) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {"snapshot": to_json_value(record.snapshot)}
    if record.user_message is not None:
        encoded["user_message"] = record.user_message
    if record.assistant_response is not None:
        encoded["assistant_response"] = record.assistant_response
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    return encoded


def _decode_task_classification_input(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> TaskClassificationInput:
    schema_id = TaskClassificationInput.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("snapshot",),
        ("user_message", "assistant_response", "subject_ref"),
    )
    return TaskClassificationInput(
        user_message=_read_optional_str(schema_id, fields, "user_message"),
        assistant_response=_read_optional_str(schema_id, fields, "assistant_response"),
        snapshot=_read_record(
            schema_id, fields, "snapshot", nested, TaskTaxonomySnapshot
        ),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
    )


def _encode_job_segmentation_input(
    record: JobSegmentationInput,
) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "transcript_sample": to_json_value(record.transcript_sample),
        "snapshot": to_json_value(record.snapshot),
        "subject": to_json_value(record.subject),
        "host_display_name": record.host_display_name,
    }
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    return encoded


def _decode_job_segmentation_input(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> JobSegmentationInput:
    schema_id = JobSegmentationInput.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("transcript_sample", "snapshot", "subject", "host_display_name"),
        ("subject_ref",),
    )
    return JobSegmentationInput(
        transcript_sample=_read_record(
            schema_id, fields, "transcript_sample", nested, TextExcerpt
        ),
        snapshot=_read_record(
            schema_id, fields, "snapshot", nested, JobTaxonomySnapshot
        ),
        subject=_read_record(schema_id, fields, "subject", nested, JobSubject),
        host_display_name=_read_str(schema_id, fields, "host_display_name"),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
    )


def _encode_outcome_evaluation_input(
    record: OutcomeEvaluationInput,
) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "job_id": record.job_id,
        "job_type": record.job_type,
        "job_name": record.job_name,
        "transcript_sample": to_json_value(record.transcript_sample),
        "max_hours_saved": record.max_hours_saved,
        "max_loaded_rate": record.max_loaded_rate,
        "currency": record.currency.value,
    }
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    return encoded


def _decode_outcome_evaluation_input(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> OutcomeEvaluationInput:
    schema_id = OutcomeEvaluationInput.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            "job_id",
            "job_type",
            "job_name",
            "transcript_sample",
            "max_hours_saved",
            "max_loaded_rate",
            "currency",
        ),
        ("subject_ref",),
    )
    return OutcomeEvaluationInput(
        job_id=_read_str(schema_id, fields, "job_id"),
        job_type=_read_str(schema_id, fields, "job_type"),
        job_name=_read_str(schema_id, fields, "job_name"),
        transcript_sample=_read_record(
            schema_id, fields, "transcript_sample", nested, TextExcerpt
        ),
        max_hours_saved=_read_bound(schema_id, fields, "max_hours_saved"),
        max_loaded_rate=_read_bound(schema_id, fields, "max_loaded_rate"),
        currency=_read_enum(schema_id, fields, "currency", Currency),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
    )


def _encode_evidence_query(record: EvidenceQuery) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "job_id": record.job_id,
        "job_type": record.job_type,
    }
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    return encoded


def _decode_evidence_query(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> EvidenceQuery:
    schema_id = EvidenceQuery.SCHEMA_ID
    _require_keys(schema_id, fields, ("job_id", "job_type"), ("subject_ref",))
    return EvidenceQuery(
        job_id=_read_str(schema_id, fields, "job_id"),
        job_type=_read_str(schema_id, fields, "job_type"),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
    )


def _encode_reportability_query(record: ReportabilityQuery) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "abstained": record.abstained,
        "job_id": record.job_id,
        "job_type": record.job_type,
    }
    if record.confirmed is not None:
        encoded["confirmed"] = record.confirmed
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    return encoded


def _decode_reportability_query(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ReportabilityQuery:
    schema_id = ReportabilityQuery.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("abstained", "job_id", "job_type"),
        ("confirmed", "subject_ref"),
    )
    return ReportabilityQuery(
        abstained=_read_bool(schema_id, fields, "abstained"),
        job_id=_read_str(schema_id, fields, "job_id"),
        job_type=_read_str(schema_id, fields, "job_type"),
        confirmed=_read_optional_bool(schema_id, fields, "confirmed"),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
    )


def _encode_text_excerpt(record: TextExcerpt) -> dict[str, JsonValue]:
    return {
        "text": record.text,
        "original_char_length": record.original_char_length,
        "original_serialized_bytes": record.original_serialized_bytes,
        "truncated": record.truncated,
    }


def _decode_text_excerpt(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> TextExcerpt:
    schema_id = TextExcerpt.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("text", "original_char_length", "original_serialized_bytes", "truncated"),
    )
    return TextExcerpt(
        text=_read_str(schema_id, fields, "text"),
        original_char_length=_read_int(schema_id, fields, "original_char_length"),
        original_serialized_bytes=_read_int(
            schema_id, fields, "original_serialized_bytes"
        ),
        truncated=_read_bool(schema_id, fields, "truncated"),
    )


_IDENTITY_TEXT_KEYS: Final = (
    "session_id",
    "parent_session_id",
    "forked_from_session_id",
    "prompt_id",
    "turn_id",
    "task_id",
    "tool_call_id",
    "delegated_agent_id",
    "delegated_agent_type",
    "request_id",
)


def _read_optional_bool(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> bool | None:
    return _read_bool(schema_id, fields, key) if key in fields else None


def _encode_activity_identity(record: ActivityIdentity) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "session_origin": record.session_origin.value,
        "delegation_initiator": record.delegation_initiator.value,
        "delegation_mode": record.delegation_mode.value,
    }
    for key in _IDENTITY_TEXT_KEYS:
        value = getattr(record, key)
        if value is not None:
            encoded[key] = value
    return encoded


def _decode_activity_identity(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ActivityIdentity:
    schema_id = ActivityIdentity.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("session_origin", "delegation_initiator", "delegation_mode"),
        _IDENTITY_TEXT_KEYS,
    )
    return ActivityIdentity(
        session_id=_read_optional_str(schema_id, fields, "session_id"),
        parent_session_id=_read_optional_str(schema_id, fields, "parent_session_id"),
        session_origin=_read_enum(schema_id, fields, "session_origin", SessionOrigin),
        forked_from_session_id=_read_optional_str(
            schema_id, fields, "forked_from_session_id"
        ),
        prompt_id=_read_optional_str(schema_id, fields, "prompt_id"),
        turn_id=_read_optional_str(schema_id, fields, "turn_id"),
        task_id=_read_optional_str(schema_id, fields, "task_id"),
        tool_call_id=_read_optional_str(schema_id, fields, "tool_call_id"),
        delegated_agent_id=_read_optional_str(schema_id, fields, "delegated_agent_id"),
        delegated_agent_type=_read_optional_str(
            schema_id, fields, "delegated_agent_type"
        ),
        delegation_initiator=_read_enum(
            schema_id, fields, "delegation_initiator", DelegationInitiator
        ),
        delegation_mode=_read_enum(
            schema_id, fields, "delegation_mode", DelegationMode
        ),
        request_id=_read_optional_str(schema_id, fields, "request_id"),
    )


def _encode_tool_outcome(record: ToolOutcome) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {"succeeded": record.succeeded}
    if record.tool_name is not None:
        encoded["tool_name"] = record.tool_name
    if record.interrupted is not None:
        encoded["interrupted"] = record.interrupted
    return encoded


def _decode_tool_outcome(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ToolOutcome:
    schema_id = ToolOutcome.SCHEMA_ID
    _require_keys(schema_id, fields, ("succeeded",), ("tool_name", "interrupted"))
    return ToolOutcome(
        tool_name=_read_optional_str(schema_id, fields, "tool_name"),
        succeeded=_read_bool(schema_id, fields, "succeeded"),
        interrupted=_read_optional_bool(schema_id, fields, "interrupted"),
    )


def _encode_task_transition(record: TaskTransition) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {}
    if record.summary is not None:
        encoded["summary"] = to_json_value(record.summary)
    return encoded


def _decode_task_transition(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> TaskTransition:
    schema_id = TaskTransition.SCHEMA_ID
    _require_keys(schema_id, fields, (), ("summary",))
    return TaskTransition(
        summary=_read_optional_record(
            schema_id, fields, "summary", nested, TextExcerpt
        ),
    )


def _encode_usage_report(record: UsageReport) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {}
    if record.input_tokens is not None:
        encoded["input_tokens"] = record.input_tokens
    if record.output_tokens is not None:
        encoded["output_tokens"] = record.output_tokens
    if record.cost is not None:
        encoded["cost"] = to_json_value(record.cost)
    if record.model is not None:
        encoded["model"] = record.model
    return encoded


def _decode_usage_report(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> UsageReport:
    schema_id = UsageReport.SCHEMA_ID
    _require_keys(
        schema_id, fields, (), ("input_tokens", "output_tokens", "cost", "model")
    )
    return UsageReport(
        input_tokens=_read_optional_int(schema_id, fields, "input_tokens"),
        output_tokens=_read_optional_int(schema_id, fields, "output_tokens"),
        cost=_read_optional_record(schema_id, fields, "cost", nested, Money),
        model=_read_optional_str(schema_id, fields, "model"),
    )


def _encode_compaction_info(record: CompactionInfo) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {"trigger": record.trigger.value}
    if record.pre_tokens is not None:
        encoded["pre_tokens"] = record.pre_tokens
    if record.post_tokens is not None:
        encoded["post_tokens"] = record.post_tokens
    if record.succeeded is not None:
        encoded["succeeded"] = record.succeeded
    return encoded


def _decode_compaction_info(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> CompactionInfo:
    schema_id = CompactionInfo.SCHEMA_ID
    _require_keys(
        schema_id, fields, ("trigger",), ("pre_tokens", "post_tokens", "succeeded")
    )
    return CompactionInfo(
        trigger=_read_enum(schema_id, fields, "trigger", CompactionTrigger),
        pre_tokens=_read_optional_int(schema_id, fields, "pre_tokens"),
        post_tokens=_read_optional_int(schema_id, fields, "post_tokens"),
        succeeded=_read_optional_bool(schema_id, fields, "succeeded"),
    )


def _encode_session_end_info(record: SessionEndInfo) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {}
    if record.reason is not None:
        encoded["reason"] = record.reason
    return encoded


def _decode_session_end_info(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> SessionEndInfo:
    schema_id = SessionEndInfo.SCHEMA_ID
    _require_keys(schema_id, fields, (), ("reason",))
    return SessionEndInfo(reason=_read_optional_str(schema_id, fields, "reason"))


def _encode_delegation_result(record: DelegationResult) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {}
    if record.summary is not None:
        encoded["summary"] = to_json_value(record.summary)
    if record.succeeded is not None:
        encoded["succeeded"] = record.succeeded
    return encoded


def _decode_delegation_result(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> DelegationResult:
    schema_id = DelegationResult.SCHEMA_ID
    _require_keys(schema_id, fields, (), ("summary", "succeeded"))
    return DelegationResult(
        summary=_read_optional_record(
            schema_id, fields, "summary", nested, TextExcerpt
        ),
        succeeded=_read_optional_bool(schema_id, fields, "succeeded"),
    )


def _encode_no_payload(record: NoPayload) -> dict[str, JsonValue]:
    return {}


def _decode_no_payload(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> NoPayload:
    _require_keys(NoPayload.SCHEMA_ID, fields, ())
    return NoPayload()


def _read_payload(
    schema_id: str,
    fields: Mapping[str, JsonValue],
    key: str,
    nested: NestedDecoder,
) -> ActivityPayload:
    record = nested(fields[key])
    if type(record) not in _PAYLOAD_TYPES or not isinstance(
        record,
        TextExcerpt
        | ToolOutcome
        | TaskTransition
        | UsageReport
        | CompactionInfo
        | SessionEndInfo
        | DelegationResult
        | NoPayload,
    ):
        raise RecordValidationError(
            schema_id,
            key,
            f"a payload record required, got {type(record).__name__}",
        )
    return record


def _read_attributes(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> tuple[tuple[str, AttributeValue], ...]:
    value = fields[key]
    if type(value) is not list:
        raise RecordValidationError(
            schema_id, key, f"JSON array required, got {_json_type(value)}"
        )
    pairs: list[tuple[str, AttributeValue]] = []
    for index, item in enumerate(value):
        if type(item) is not list or len(item) != 2:
            raise RecordValidationError(
                schema_id, key, f"element {index} must be a [key, value] array"
            )
        name, scalar = item
        if type(name) is not str:
            raise RecordValidationError(
                schema_id,
                key,
                f"element {index} key must be a JSON string, got {_json_type(name)}",
            )
        if type(scalar) is str or type(scalar) is int or type(scalar) is bool:
            pairs.append((name, scalar))
        elif scalar is None:
            pairs.append((name, None))
        else:
            raise RecordValidationError(
                schema_id,
                key,
                f"element {index} value must be a JSON string, integer, boolean, "
                f"or null, got {_json_type(scalar)}",
            )
    return tuple(pairs)


def _encode_activity_event(record: ActivityEvent) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "kind": record.kind.value,
        "host": record.host,
        "identity": to_json_value(record.identity),
        "payload": to_json_value(record.payload),
        "observed_at": format_utc_timestamp(record.observed_at),
        "dedupe_key": record.dedupe_key,
        "source": record.source.value,
        "attributes": [[name, scalar] for name, scalar in record.attributes],
    }
    if record.occurred_at is not None:
        encoded["occurred_at"] = format_utc_timestamp(record.occurred_at)
    if record.host_sequence is not None:
        encoded["host_sequence"] = record.host_sequence
    if record.native_event_id is not None:
        encoded["native_event_id"] = record.native_event_id
    return encoded


def _decode_activity_event(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ActivityEvent:
    schema_id = ActivityEvent.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            "kind",
            "host",
            "identity",
            "payload",
            "observed_at",
            "dedupe_key",
            "source",
            "attributes",
        ),
        ("occurred_at", "host_sequence", "native_event_id"),
    )
    return ActivityEvent(
        kind=_read_enum(schema_id, fields, "kind", ActivityKind),
        host=_read_str(schema_id, fields, "host"),
        identity=_read_record(schema_id, fields, "identity", nested, ActivityIdentity),
        payload=_read_payload(schema_id, fields, "payload", nested),
        observed_at=_read_timestamp(schema_id, fields, "observed_at"),
        occurred_at=(
            _read_timestamp(schema_id, fields, "occurred_at")
            if "occurred_at" in fields
            else None
        ),
        host_sequence=_read_optional_int(schema_id, fields, "host_sequence"),
        native_event_id=_read_optional_str(schema_id, fields, "native_event_id"),
        dedupe_key=_read_str(schema_id, fields, "dedupe_key"),
        source=_read_enum(schema_id, fields, "source", EventSource),
        attributes=_read_attributes(schema_id, fields, "attributes"),
    )


def _encode_activity_log(record: ActivityLog) -> dict[str, JsonValue]:
    return {
        "events": [to_json_value(event) for event in record.events],
        "collision_count": record.collision_count,
    }


def _decode_activity_log(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ActivityLog:
    schema_id = ActivityLog.SCHEMA_ID
    _require_keys(schema_id, fields, ("events", "collision_count"))
    return ActivityLog(
        events=_read_records(schema_id, fields, "events", nested, ActivityEvent),
        collision_count=_read_int(schema_id, fields, "collision_count"),
    )


def _encode_lineage_node(record: LineageNode) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {"session_id": record.session_id}
    if record.agent_id is not None:
        encoded["agent_id"] = record.agent_id
    return encoded


def _decode_lineage_node(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> LineageNode:
    schema_id = LineageNode.SCHEMA_ID
    _require_keys(schema_id, fields, ("session_id",), ("agent_id",))
    return LineageNode(
        session_id=_read_str(schema_id, fields, "session_id"),
        agent_id=_read_optional_str(schema_id, fields, "agent_id"),
    )


def _encode_job_subject(record: JobSubject) -> dict[str, JsonValue]:
    return {
        "node": to_json_value(record.node),
        "root": to_json_value(record.root),
        "members": [to_json_value(member) for member in record.members],
        "delegation_initiator": record.delegation_initiator.value,
        "delegation_mode": record.delegation_mode.value,
        "cycle_detected": record.cycle_detected,
        "depth_exceeded": record.depth_exceeded,
        "parent_conflict": record.parent_conflict,
    }


def _decode_job_subject(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> JobSubject:
    schema_id = JobSubject.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            "node",
            "root",
            "members",
            "delegation_initiator",
            "delegation_mode",
            "cycle_detected",
            "depth_exceeded",
            "parent_conflict",
        ),
    )
    return JobSubject(
        node=_read_record(schema_id, fields, "node", nested, LineageNode),
        root=_read_record(schema_id, fields, "root", nested, LineageNode),
        members=_read_records(schema_id, fields, "members", nested, LineageNode),
        delegation_initiator=_read_enum(
            schema_id, fields, "delegation_initiator", DelegationInitiator
        ),
        delegation_mode=_read_enum(
            schema_id, fields, "delegation_mode", DelegationMode
        ),
        cycle_detected=_read_bool(schema_id, fields, "cycle_detected"),
        depth_exceeded=_read_bool(schema_id, fields, "depth_exceeded"),
        parent_conflict=_read_bool(schema_id, fields, "parent_conflict"),
    )


def _encode_lineage_entry(record: LineageEntry) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "node": to_json_value(record.node),
        "origin": record.origin.value,
        "root": to_json_value(record.root),
        "delegation_initiator": record.delegation_initiator.value,
        "delegation_mode": record.delegation_mode.value,
        "cycle_detected": record.cycle_detected,
        "depth_exceeded": record.depth_exceeded,
        "parent_conflict": record.parent_conflict,
    }
    if record.parent is not None:
        encoded["parent"] = to_json_value(record.parent)
    if record.edge is not None:
        encoded["edge"] = record.edge.value
    return encoded


def _decode_lineage_entry(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> LineageEntry:
    schema_id = LineageEntry.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            "node",
            "origin",
            "root",
            "delegation_initiator",
            "delegation_mode",
            "cycle_detected",
            "depth_exceeded",
            "parent_conflict",
        ),
        ("parent", "edge"),
    )
    return LineageEntry(
        node=_read_record(schema_id, fields, "node", nested, LineageNode),
        origin=_read_enum(schema_id, fields, "origin", SessionOrigin),
        parent=_read_optional_record(schema_id, fields, "parent", nested, LineageNode),
        edge=(
            _read_enum(schema_id, fields, "edge", LineageEdgeKind)
            if "edge" in fields
            else None
        ),
        root=_read_record(schema_id, fields, "root", nested, LineageNode),
        delegation_initiator=_read_enum(
            schema_id, fields, "delegation_initiator", DelegationInitiator
        ),
        delegation_mode=_read_enum(
            schema_id, fields, "delegation_mode", DelegationMode
        ),
        cycle_detected=_read_bool(schema_id, fields, "cycle_detected"),
        depth_exceeded=_read_bool(schema_id, fields, "depth_exceeded"),
        parent_conflict=_read_bool(schema_id, fields, "parent_conflict"),
    )


def _encode_session_lineage(record: SessionLineage) -> dict[str, JsonValue]:
    return {
        "entries": [to_json_value(entry) for entry in record.entries],
        "max_depth": record.max_depth,
    }


def _decode_session_lineage(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> SessionLineage:
    schema_id = SessionLineage.SCHEMA_ID
    _require_keys(schema_id, fields, ("entries", "max_depth"))
    return SessionLineage(
        entries=_read_records(schema_id, fields, "entries", nested, LineageEntry),
        max_depth=_read_int(schema_id, fields, "max_depth"),
    )


def _encode_job_boundary(record: JobBoundary) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "job_id": record.job_id,
        "job_name": record.job_name,
        "root": to_json_value(record.root),
        "members": [to_json_value(member) for member in record.members],
        "evidence_refs": list(record.evidence_refs),
    }
    if record.supersedes is not None:
        encoded["supersedes"] = record.supersedes
    return encoded


def _decode_job_boundary(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> JobBoundary:
    schema_id = JobBoundary.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("job_id", "job_name", "root", "members", "evidence_refs"),
        ("supersedes",),
    )
    return JobBoundary(
        job_id=_read_str(schema_id, fields, "job_id"),
        job_name=_read_str(schema_id, fields, "job_name"),
        root=_read_record(schema_id, fields, "root", nested, LineageNode),
        members=_read_records(schema_id, fields, "members", nested, LineageNode),
        evidence_refs=_read_strs(schema_id, fields, "evidence_refs"),
        supersedes=_read_optional_str(schema_id, fields, "supersedes"),
    )


def _encode_job_type_assignment(record: JobTypeAssignment) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "job_type": record.job_type,
        "taxonomy": to_json_value(record.taxonomy),
    }
    if record.proposal is not None:
        encoded["proposal"] = to_json_value(record.proposal)
    return encoded


def _decode_job_type_assignment(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> JobTypeAssignment:
    schema_id = JobTypeAssignment.SCHEMA_ID
    _require_keys(schema_id, fields, ("job_type", "taxonomy"), ("proposal",))
    return JobTypeAssignment(
        job_type=_read_str(schema_id, fields, "job_type"),
        taxonomy=_read_record(schema_id, fields, "taxonomy", nested, TaxonomyRef),
        proposal=_read_optional_record(
            schema_id, fields, "proposal", nested, LabelProposal
        ),
    )


def _encode_job_candidate(record: JobCandidate) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "boundary": to_json_value(record.boundary),
        "type_assignment": to_json_value(record.type_assignment),
        "outcome": record.outcome.value,
        "attribution_basis": record.attribution_basis.value,
        "delegation_initiator": record.delegation_initiator.value,
        "delegation_mode": record.delegation_mode.value,
    }
    if record.failure_reason is not None:
        encoded["failure_reason"] = record.failure_reason
    if record.proposal_index is not None:
        encoded["proposal_index"] = record.proposal_index
    if record.parent_job_id is not None:
        encoded["parent_job_id"] = record.parent_job_id
    if record.double_counting_group is not None:
        encoded["double_counting_group"] = record.double_counting_group
    return encoded


def _decode_job_candidate(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> JobCandidate:
    schema_id = JobCandidate.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            "boundary",
            "type_assignment",
            "outcome",
            "attribution_basis",
            "delegation_initiator",
            "delegation_mode",
        ),
        (
            "failure_reason",
            "proposal_index",
            "parent_job_id",
            "double_counting_group",
        ),
    )
    return JobCandidate(
        boundary=_read_record(schema_id, fields, "boundary", nested, JobBoundary),
        type_assignment=_read_record(
            schema_id, fields, "type_assignment", nested, JobTypeAssignment
        ),
        outcome=_read_enum(schema_id, fields, "outcome", JobOutcome),
        failure_reason=_read_optional_str(schema_id, fields, "failure_reason"),
        proposal_index=_read_optional_int(schema_id, fields, "proposal_index"),
        attribution_basis=_read_enum(
            schema_id, fields, "attribution_basis", AttributionBasis
        ),
        parent_job_id=_read_optional_str(schema_id, fields, "parent_job_id"),
        delegation_initiator=_read_enum(
            schema_id, fields, "delegation_initiator", DelegationInitiator
        ),
        delegation_mode=_read_enum(
            schema_id, fields, "delegation_mode", DelegationMode
        ),
        double_counting_group=_read_optional_str(
            schema_id, fields, "double_counting_group"
        ),
    )


def _encode_rejected_job_proposal(
    record: RejectedJobProposal,
) -> dict[str, JsonValue]:
    return {
        "index": record.index,
        "reason": record.reason.value,
        "value_repr": record.value_repr,
    }


def _decode_rejected_job_proposal(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> RejectedJobProposal:
    schema_id = RejectedJobProposal.SCHEMA_ID
    _require_keys(schema_id, fields, ("index", "reason", "value_repr"))
    return RejectedJobProposal(
        index=_read_int(schema_id, fields, "index"),
        reason=_read_enum(schema_id, fields, "reason", JobRejectionReason),
        value_repr=_read_str(schema_id, fields, "value_repr"),
    )


def _encode_job_inference_abstention(
    record: JobInferenceAbstention,
) -> dict[str, JsonValue]:
    return {"reason": record.reason.value}


def _decode_job_inference_abstention(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> JobInferenceAbstention:
    schema_id = JobInferenceAbstention.SCHEMA_ID
    _require_keys(schema_id, fields, ("reason",))
    return JobInferenceAbstention(
        reason=_read_enum(schema_id, fields, "reason", JobInferenceAbstentionReason)
    )


def _encode_job_inference(record: JobInference) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "candidates": [to_json_value(candidate) for candidate in record.candidates],
        "rejected": [to_json_value(rejected) for rejected in record.rejected],
        "subject": to_json_value(record.subject),
        "inferred_at": format_utc_timestamp(record.inferred_at),
        "library_version": record.library_version,
    }
    if record.abstention is not None:
        encoded["abstention"] = to_json_value(record.abstention)
    if record.taxonomy is not None:
        encoded["taxonomy"] = to_json_value(record.taxonomy)
    if record.prompt is not None:
        encoded["prompt"] = to_json_value(record.prompt)
    if record.inference is not None:
        encoded["inference"] = to_json_value(record.inference)
    if record.segmenter is not None:
        encoded["segmenter"] = to_json_value(record.segmenter)
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    return encoded


def _decode_job_inference(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> JobInference:
    schema_id = JobInference.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("candidates", "rejected", "subject", "inferred_at", "library_version"),
        ("abstention", "taxonomy", "prompt", "inference", "segmenter", "subject_ref"),
    )
    return JobInference(
        candidates=_read_records(schema_id, fields, "candidates", nested, JobCandidate),
        rejected=_read_records(
            schema_id, fields, "rejected", nested, RejectedJobProposal
        ),
        abstention=_read_optional_record(
            schema_id, fields, "abstention", nested, JobInferenceAbstention
        ),
        taxonomy=_read_optional_record(
            schema_id, fields, "taxonomy", nested, TaxonomyRef
        ),
        prompt=_read_optional_record(schema_id, fields, "prompt", nested, PromptRef),
        inference=_read_optional_record(
            schema_id, fields, "inference", nested, InferenceProvenance
        ),
        segmenter=_read_optional_record(
            schema_id, fields, "segmenter", nested, ComponentDeclaration
        ),
        subject=_read_record(schema_id, fields, "subject", nested, JobSubject),
        inferred_at=_read_timestamp(schema_id, fields, "inferred_at"),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
        library_version=_read_str(schema_id, fields, "library_version"),
    )


def _encode_job_inference_request(
    record: JobInferenceRequest,
) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "transcript_sample": to_json_value(record.transcript_sample),
        "subject": to_json_value(record.subject),
        "prior_candidates": [
            to_json_value(candidate) for candidate in record.prior_candidates
        ],
    }
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    if record.double_counting_group is not None:
        encoded["double_counting_group"] = record.double_counting_group
    # ADR 0044 decision 1: the default scope is omitted, so every request
    # written before the field existed keeps its bytes.
    if record.double_counting_scope is not DoubleCountingScope.INFERENCE:
        encoded["double_counting_scope"] = record.double_counting_scope.value
    if record.activity_log is not None:
        encoded["activity_log"] = to_json_value(record.activity_log)
    return encoded


def _decode_job_inference_request(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> JobInferenceRequest:
    schema_id = JobInferenceRequest.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("transcript_sample", "subject", "prior_candidates"),
        (
            "subject_ref",
            "double_counting_group",
            "double_counting_scope",
            "activity_log",
        ),
    )
    explicit = "double_counting_scope" in fields
    scope = (
        _read_enum(schema_id, fields, "double_counting_scope", DoubleCountingScope)
        if explicit
        else DoubleCountingScope.INFERENCE
    )
    record = JobInferenceRequest(
        transcript_sample=_read_record(
            schema_id, fields, "transcript_sample", nested, TextExcerpt
        ),
        subject=_read_record(schema_id, fields, "subject", nested, JobSubject),
        prior_candidates=_read_records(
            schema_id, fields, "prior_candidates", nested, JobCandidate
        ),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
        double_counting_group=_read_optional_str(
            schema_id, fields, "double_counting_group"
        ),
        double_counting_scope=scope,
        activity_log=_read_optional_record(
            schema_id, fields, "activity_log", nested, ActivityLog
        ),
    )
    if explicit and scope is DoubleCountingScope.INFERENCE:
        # ADR 0044 decision 1: the canonical form omits the default, so an
        # explicit one would not round-trip to the same bytes.
        raise RecordValidationError(
            schema_id, "double_counting_scope", "the default must be omitted"
        )
    return record


def _read_bound(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> int | float:
    # The int or float JSON type is kept, so 40.0 and 40 round-trip apart
    # (ADR 0022 decision 2).
    value = fields[key]
    if type(value) is not int and type(value) is not float:
        raise RecordValidationError(
            schema_id, key, f"JSON number required, got {_json_type(value)}"
        )
    return value


def _read_optional_scalar(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> int | float | bool | str | None:
    if key not in fields:
        return None
    value = fields[key]
    if (
        type(value) is not str
        and type(value) is not int
        and type(value) is not float
        and type(value) is not bool
    ):
        raise RecordValidationError(
            schema_id, key, f"JSON scalar required, got {_json_type(value)}"
        )
    return value


def _read_optional_timestamp(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> datetime | None:
    return _read_timestamp(schema_id, fields, key) if key in fields else None


def _encode_operand_bounds(record: OperandBounds) -> dict[str, JsonValue]:
    return {
        "max_hours_saved": record.max_hours_saved,
        "max_loaded_rate": record.max_loaded_rate,
    }


def _decode_operand_bounds(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> OperandBounds:
    schema_id = OperandBounds.SCHEMA_ID
    _require_keys(schema_id, fields, ("max_hours_saved", "max_loaded_rate"))
    return OperandBounds(
        max_hours_saved=_read_bound(schema_id, fields, "max_hours_saved"),
        max_loaded_rate=_read_bound(schema_id, fields, "max_loaded_rate"),
    )


def _encode_outcome_assertion(record: OutcomeAssertion) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "outcome": record.outcome.value,
        "source": record.source,
    }
    if record.observed_at is not None:
        encoded["observed_at"] = format_utc_timestamp(record.observed_at)
    return encoded


def _decode_outcome_assertion(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> OutcomeAssertion:
    schema_id = OutcomeAssertion.SCHEMA_ID
    _require_keys(schema_id, fields, ("outcome", "source"), ("observed_at",))
    return OutcomeAssertion(
        outcome=_read_enum(schema_id, fields, "outcome", JobOutcome),
        source=_read_str(schema_id, fields, "source"),
        observed_at=_read_optional_timestamp(schema_id, fields, "observed_at"),
    )


def _encode_proposed_operand(record: ProposedOperand) -> dict[str, JsonValue]:
    # NON_FINITE values are string tags, so canonical_json never sees NaN.
    encoded: dict[str, JsonValue] = {"kind": record.kind.value}
    if record.value is not None:
        encoded["value"] = record.value
    return encoded


def _decode_proposed_operand(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ProposedOperand:
    schema_id = ProposedOperand.SCHEMA_ID
    _require_keys(schema_id, fields, ("kind",), ("value",))
    return ProposedOperand(
        kind=_read_enum(schema_id, fields, "kind", OperandKind),
        value=_read_optional_scalar(schema_id, fields, "value"),
    )


def _encode_discarded_field(record: DiscardedField) -> dict[str, JsonValue]:
    return {"name": record.name, "value_repr": record.value_repr}


def _decode_discarded_field(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> DiscardedField:
    schema_id = DiscardedField.SCHEMA_ID
    _require_keys(schema_id, fields, ("name", "value_repr"))
    return DiscardedField(
        name=_read_str(schema_id, fields, "name"),
        value_repr=_read_str(schema_id, fields, "value_repr"),
    )


def _encode_outcome_request(record: OutcomeRequest) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "candidate": to_json_value(record.candidate),
        "transcript_sample": to_json_value(record.transcript_sample),
        "bounds": to_json_value(record.bounds),
        "currency": record.currency.value,
    }
    if record.outcome_assertion is not None:
        encoded["outcome_assertion"] = to_json_value(record.outcome_assertion)
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    if record.role_vocabulary is not None:
        encoded["role_vocabulary"] = to_json_value(record.role_vocabulary)
    return encoded


def _decode_outcome_request(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> OutcomeRequest:
    schema_id = OutcomeRequest.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("candidate", "transcript_sample", "bounds", "currency"),
        ("outcome_assertion", "subject_ref", "role_vocabulary"),
    )
    return OutcomeRequest(
        candidate=_read_record(schema_id, fields, "candidate", nested, JobCandidate),
        transcript_sample=_read_record(
            schema_id, fields, "transcript_sample", nested, TextExcerpt
        ),
        bounds=_read_record(schema_id, fields, "bounds", nested, OperandBounds),
        currency=_read_enum(schema_id, fields, "currency", Currency),
        outcome_assertion=_read_optional_record(
            schema_id, fields, "outcome_assertion", nested, OutcomeAssertion
        ),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
        role_vocabulary=_read_optional_record(
            schema_id, fields, "role_vocabulary", nested, RoleVocabulary
        ),
    )


def _encode_role_vocabulary_entry(
    record: RoleVocabularyEntry,
) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {"role": record.role}
    if record.amount is not None:
        encoded["amount"] = format_decimal(record.amount)
    return encoded


def _decode_role_vocabulary_entry(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> RoleVocabularyEntry:
    schema_id = RoleVocabularyEntry.SCHEMA_ID
    _require_keys(schema_id, fields, ("role",), ("amount",))
    return RoleVocabularyEntry(
        role=_read_str(schema_id, fields, "role"),
        amount=_read_optional_decimal(schema_id, fields, "amount"),
    )


def _encode_role_vocabulary(record: RoleVocabulary) -> dict[str, JsonValue]:
    return {"entries": [to_json_value(entry) for entry in record.entries]}


def _decode_role_vocabulary(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> RoleVocabulary:
    schema_id = RoleVocabulary.SCHEMA_ID
    _require_keys(schema_id, fields, ("entries",))
    return RoleVocabulary(
        entries=_read_records(schema_id, fields, "entries", nested, RoleVocabularyEntry)
    )


_OPERAND_KEYS: Final = (
    "economic_mechanism",
    "estimated_hours_saved",
    "assumed_loaded_rate",
    "confidence",
    "currency",
)
_NARRATIVE_KEYS: Final = (
    "inferred_role",
    "basis",
    "candidate_downstream_outcome",
    "counterfactual_assumption",
)


def _encode_outcome_proposal(record: OutcomeProposal) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "job_id": record.job_id,
        "job_type": record.job_type,
        "band_shape": record.band_shape.value,
        "discarded_fields": [
            to_json_value(discarded) for discarded in record.discarded_fields
        ],
        "evaluator": to_json_value(record.evaluator),
        "proposed_at": format_utc_timestamp(record.proposed_at),
        "library_version": record.library_version,
    }
    for key in _OPERAND_KEYS:
        encoded[key] = to_json_value(getattr(record, key))
    for key in _NARRATIVE_KEYS:
        encoded[key] = getattr(record, key)
    if record.prompt is not None:
        encoded["prompt"] = to_json_value(record.prompt)
    if record.inference is not None:
        encoded["inference"] = to_json_value(record.inference)
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    return encoded


def _decode_outcome_proposal(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> OutcomeProposal:
    schema_id = OutcomeProposal.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            "job_id",
            "job_type",
            *_OPERAND_KEYS,
            *_NARRATIVE_KEYS,
            "band_shape",
            "discarded_fields",
            "evaluator",
            "proposed_at",
            "library_version",
        ),
        ("prompt", "inference", "subject_ref"),
    )

    def operand(key: str) -> ProposedOperand:
        return _read_record(schema_id, fields, key, nested, ProposedOperand)

    return OutcomeProposal(
        job_id=_read_str(schema_id, fields, "job_id"),
        job_type=_read_str(schema_id, fields, "job_type"),
        economic_mechanism=operand("economic_mechanism"),
        estimated_hours_saved=operand("estimated_hours_saved"),
        assumed_loaded_rate=operand("assumed_loaded_rate"),
        confidence=operand("confidence"),
        currency=operand("currency"),
        inferred_role=_read_str(schema_id, fields, "inferred_role"),
        basis=_read_str(schema_id, fields, "basis"),
        candidate_downstream_outcome=_read_str(
            schema_id, fields, "candidate_downstream_outcome"
        ),
        counterfactual_assumption=_read_str(
            schema_id, fields, "counterfactual_assumption"
        ),
        band_shape=_read_enum(schema_id, fields, "band_shape", BandShape),
        discarded_fields=_read_records(
            schema_id, fields, "discarded_fields", nested, DiscardedField
        ),
        evaluator=_read_record(
            schema_id, fields, "evaluator", nested, ComponentDeclaration
        ),
        prompt=_read_optional_record(schema_id, fields, "prompt", nested, PromptRef),
        inference=_read_optional_record(
            schema_id, fields, "inference", nested, InferenceProvenance
        ),
        proposed_at=_read_timestamp(schema_id, fields, "proposed_at"),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
        library_version=_read_str(schema_id, fields, "library_version"),
    )


def _encode_outcome_abstention(record: OutcomeAbstention) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "reason": record.reason.value,
        "job_id": record.job_id,
        "job_type": record.job_type,
        "abstained_at": format_utc_timestamp(record.abstained_at),
        "library_version": record.library_version,
    }
    if record.evaluator is not None:
        encoded["evaluator"] = to_json_value(record.evaluator)
    if record.prompt is not None:
        encoded["prompt"] = to_json_value(record.prompt)
    if record.inference is not None:
        encoded["inference"] = to_json_value(record.inference)
    if record.value_repr is not None:
        encoded["value_repr"] = record.value_repr
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    return encoded


def _decode_outcome_abstention(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> OutcomeAbstention:
    schema_id = OutcomeAbstention.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("reason", "job_id", "job_type", "abstained_at", "library_version"),
        ("evaluator", "prompt", "inference", "value_repr", "subject_ref"),
    )
    return OutcomeAbstention(
        reason=_read_enum(schema_id, fields, "reason", OutcomeAbstentionReason),
        job_id=_read_str(schema_id, fields, "job_id"),
        job_type=_read_str(schema_id, fields, "job_type"),
        evaluator=_read_optional_record(
            schema_id, fields, "evaluator", nested, ComponentDeclaration
        ),
        prompt=_read_optional_record(schema_id, fields, "prompt", nested, PromptRef),
        inference=_read_optional_record(
            schema_id, fields, "inference", nested, InferenceProvenance
        ),
        value_repr=_read_optional_str(schema_id, fields, "value_repr"),
        abstained_at=_read_timestamp(schema_id, fields, "abstained_at"),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
        library_version=_read_str(schema_id, fields, "library_version"),
    )


def _read_optional_decimal(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> Decimal | None:
    return _read_decimal(schema_id, fields, key) if key in fields else None


def _encode_resolved_assumptions(
    record: ResolvedAssumptions,
) -> dict[str, JsonValue]:
    return {
        "job_type": record.job_type,
        "economic_mechanism": record.economic_mechanism.value,
        "estimated_hours_saved": format_decimal(record.estimated_hours_saved),
        "assumed_loaded_rate": format_decimal(record.assumed_loaded_rate),
        "currency": record.currency.value,
        "inferred_role": record.inferred_role,
        "hours_basis": record.hours_basis.value,
        "rate_basis": record.rate_basis.value,
    }


def _decode_resolved_assumptions(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ResolvedAssumptions:
    schema_id = ResolvedAssumptions.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            "job_type",
            "economic_mechanism",
            "estimated_hours_saved",
            "assumed_loaded_rate",
            "currency",
            "inferred_role",
            "hours_basis",
            "rate_basis",
        ),
    )
    return ResolvedAssumptions(
        job_type=_read_str(schema_id, fields, "job_type"),
        economic_mechanism=_read_enum(
            schema_id, fields, "economic_mechanism", EconomicMechanism
        ),
        estimated_hours_saved=_read_decimal(schema_id, fields, "estimated_hours_saved"),
        assumed_loaded_rate=_read_decimal(schema_id, fields, "assumed_loaded_rate"),
        currency=_read_enum(schema_id, fields, "currency", Currency),
        inferred_role=_read_str(schema_id, fields, "inferred_role"),
        hours_basis=_read_enum(schema_id, fields, "hours_basis", ClaimBasis),
        rate_basis=_read_enum(schema_id, fields, "rate_basis", ClaimBasis),
    )


def _encode_derived_band(record: DerivedBand) -> dict[str, JsonValue]:
    return {"spread": format_decimal(record.spread), "version": record.version}


def _decode_derived_band(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> DerivedBand:
    schema_id = DerivedBand.SCHEMA_ID
    _require_keys(schema_id, fields, ("spread", "version"))
    return DerivedBand(
        spread=_read_decimal(schema_id, fields, "spread"),
        version=_read_int(schema_id, fields, "version"),
    )


def _read_objects(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> tuple[tuple[str, Mapping[str, JsonValue]], ...]:
    # A JSON array of objects, each named "<key>[<index>]" in errors.
    value = fields[key]
    if type(value) is not list:
        raise RecordValidationError(
            schema_id, key, f"JSON array required, got {_json_type(value)}"
        )
    items: list[tuple[str, Mapping[str, JsonValue]]] = []
    for index, item in enumerate(value):
        if type(item) is not dict:
            raise RecordValidationError(
                schema_id,
                key,
                f"element {index} must be a JSON object, got {_json_type(item)}",
            )
        items.append((f"{key}[{index}]", item))
    return tuple(items)


def _encode_rate_card_figures(record: RateCardFigures) -> dict[str, JsonValue]:
    return {
        "amounts": [
            {"role": role, "amount": format_decimal(amount)}
            for role, amount in record.amounts
        ]
    }


def _decode_rate_card_figures(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> RateCardFigures:
    schema_id = RateCardFigures.SCHEMA_ID
    _require_keys(schema_id, fields, ("amounts",))
    amounts: list[tuple[str, Decimal]] = []
    for element, item in _read_objects(schema_id, fields, "amounts"):
        _require_keys(element, item, ("role", "amount"))
        amounts.append(
            (_read_str(element, item, "role"), _read_decimal(element, item, "amount"))
        )
    return RateCardFigures(amounts=tuple(amounts))


def _encode_revenue_card_entry(record: RevenueCardEntry) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "gross_per_job": format_decimal(record.gross_per_job)
    }
    if record.attribution_fraction is not None:
        encoded["attribution_fraction"] = format_decimal(record.attribution_fraction)
    if record.attribution_basis is not None:
        encoded["attribution_basis"] = record.attribution_basis
    return encoded


def _decode_revenue_card_entry(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> RevenueCardEntry:
    schema_id = RevenueCardEntry.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("gross_per_job",),
        ("attribution_fraction", "attribution_basis"),
    )
    return RevenueCardEntry(
        gross_per_job=_read_decimal(schema_id, fields, "gross_per_job"),
        attribution_fraction=_read_optional_decimal(
            schema_id, fields, "attribution_fraction"
        ),
        attribution_basis=_read_optional_str(schema_id, fields, "attribution_basis"),
    )


def _encode_revenue_card_figures(record: RevenueCardFigures) -> dict[str, JsonValue]:
    entries: list[JsonValue] = []
    for key, entry in record.entries:
        item: dict[str, JsonValue] = {"key": key}
        if entry is not None:
            item["entry"] = to_json_value(entry)
        entries.append(item)
    encoded: dict[str, JsonValue] = {"entries": entries}
    if record.key is not None:
        encoded["key"] = record.key
    return encoded


def _decode_revenue_card_figures(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> RevenueCardFigures:
    schema_id = RevenueCardFigures.SCHEMA_ID
    _require_keys(schema_id, fields, ("entries",), ("key",))
    entries: list[tuple[str, RevenueCardEntry | None]] = []
    for element, item in _read_objects(schema_id, fields, "entries"):
        _require_keys(element, item, ("key",), ("entry",))
        entries.append(
            (
                _read_str(element, item, "key"),
                _read_optional_record(element, item, "entry", nested, RevenueCardEntry),
            )
        )
    return RevenueCardFigures(
        key=_read_optional_str(schema_id, fields, "key"), entries=tuple(entries)
    )


def _encode_baseline_figures(record: BaselineFigures) -> dict[str, JsonValue]:
    return {
        "hourly_rate": format_decimal(record.hourly_rate),
        "minutes_per_unit": format_decimal(record.minutes_per_unit),
    }


def _decode_baseline_figures(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> BaselineFigures:
    schema_id = BaselineFigures.SCHEMA_ID
    _require_keys(schema_id, fields, ("hourly_rate", "minutes_per_unit"))
    return BaselineFigures(
        hourly_rate=_read_decimal(schema_id, fields, "hourly_rate"),
        minutes_per_unit=_read_decimal(schema_id, fields, "minutes_per_unit"),
    )


def _encode_valuation_figures(record: ValuationFigures) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {}
    if record.rate_card is not None:
        encoded["rate_card"] = to_json_value(record.rate_card)
    if record.revenue_card is not None:
        encoded["revenue_card"] = to_json_value(record.revenue_card)
    if record.baselines is not None:
        encoded["baselines"] = to_json_value(record.baselines)
    return encoded


def _decode_valuation_figures(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ValuationFigures:
    schema_id = ValuationFigures.SCHEMA_ID
    _require_keys(schema_id, fields, (), ("rate_card", "revenue_card", "baselines"))
    return ValuationFigures(
        rate_card=_read_optional_record(
            schema_id, fields, "rate_card", nested, RateCardFigures
        ),
        revenue_card=_read_optional_record(
            schema_id, fields, "revenue_card", nested, RevenueCardFigures
        ),
        baselines=_read_optional_record(
            schema_id, fields, "baselines", nested, BaselineFigures
        ),
    )


def _encode_resolved_evidence(record: ResolvedEvidence) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {}
    if record.confirmed is not None:
        encoded["confirmed"] = record.confirmed
    if record.study is not None:
        encoded["study"] = to_json_value(record.study)
    return encoded


def _decode_resolved_evidence(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ResolvedEvidence:
    schema_id = ResolvedEvidence.SCHEMA_ID
    _require_keys(schema_id, fields, (), ("confirmed", "study"))
    return ResolvedEvidence(
        confirmed=_read_optional_bool(schema_id, fields, "confirmed"),
        study=_read_optional_record(schema_id, fields, "study", nested, StudyReference),
    )


_COST_KEYS: Final[tuple[str, ...]] = tuple(
    category.value for category in COST_CATEGORIES
)


def _encode_supplied_costs(record: SuppliedCosts) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {"currency": record.currency.value}
    for category in COST_CATEGORIES:
        value = record.amount(category)
        if value is not None:
            encoded[category.value] = format_decimal(value)
    return encoded


def _decode_supplied_costs(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> SuppliedCosts:
    schema_id = SuppliedCosts.SCHEMA_ID
    _require_keys(schema_id, fields, ("currency",), _COST_KEYS)
    return SuppliedCosts(
        currency=_read_enum(schema_id, fields, "currency", Currency),
        human_review=_read_optional_decimal(schema_id, fields, "human_review"),
        rework_or_error=_read_optional_decimal(schema_id, fields, "rework_or_error"),
        handoff=_read_optional_decimal(schema_id, fields, "handoff"),
        training_or_change=_read_optional_decimal(
            schema_id, fields, "training_or_change"
        ),
    )


_COVERAGE_KEYS: Final = ("included", "known_zero", "unknown", "excluded")


def _encode_cost_coverage(record: CostCoverage) -> dict[str, JsonValue]:
    return {key: list(getattr(record, key)) for key in _COVERAGE_KEYS}


def _decode_cost_coverage(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> CostCoverage:
    schema_id = CostCoverage.SCHEMA_ID
    _require_keys(schema_id, fields, _COVERAGE_KEYS)
    return CostCoverage(
        included=_read_strs(schema_id, fields, "included"),
        known_zero=_read_strs(schema_id, fields, "known_zero"),
        unknown=_read_strs(schema_id, fields, "unknown"),
        excluded=_read_strs(schema_id, fields, "excluded"),
    )


def _encode_roi_operands(record: RoiOperands) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "value_state": record.value_state.value,
        "costs": to_json_value(record.costs),
        "coverage": to_json_value(record.coverage),
    }
    if record.value is not None:
        encoded["value"] = to_json_value(record.value)
    if record.value_basis is not None:
        encoded["value_basis"] = record.value_basis.value
    if record.metered_ai_cost is not None:
        encoded["metered_ai_cost"] = to_json_value(record.metered_ai_cost)
    if record.net_value is not None:
        encoded["net_value"] = to_json_value(record.net_value)
    return encoded


def _decode_roi_operands(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> RoiOperands:
    schema_id = RoiOperands.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("value_state", "costs", "coverage"),
        ("value", "value_basis", "metered_ai_cost", "net_value"),
    )
    return RoiOperands(
        value_state=_read_enum(schema_id, fields, "value_state", ValueSideState),
        value=_read_optional_record(schema_id, fields, "value", nested, Money),
        value_basis=(
            _read_enum(schema_id, fields, "value_basis", ClaimBasis)
            if "value_basis" in fields
            else None
        ),
        costs=_read_record(schema_id, fields, "costs", nested, SuppliedCosts),
        coverage=_read_record(schema_id, fields, "coverage", nested, CostCoverage),
        metered_ai_cost=_read_optional_record(
            schema_id, fields, "metered_ai_cost", nested, Money
        ),
        net_value=_read_optional_record(schema_id, fields, "net_value", nested, Money),
    )


def _encode_inference_locality(record: InferenceLocality) -> dict[str, JsonValue]:
    return {"provider": record.provider, "address_class": record.address_class.value}


def _decode_inference_locality(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> InferenceLocality:
    schema_id = InferenceLocality.SCHEMA_ID
    _require_keys(schema_id, fields, ("provider", "address_class"))
    return InferenceLocality(
        provider=_read_str(schema_id, fields, "provider"),
        address_class=_read_enum(schema_id, fields, "address_class", AddressClass),
    )


def _encode_assess_job_request(record: AssessJobRequest) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "candidate": to_json_value(record.candidate),
        "sequence": record.sequence,
    }
    if record.proposal is not None:
        encoded["proposal"] = to_json_value(record.proposal)
    if record.costs is not None:
        encoded["costs"] = to_json_value(record.costs)
    if record.locality is not None:
        encoded["locality"] = to_json_value(record.locality)
    if record.job_started_at is not None:
        encoded["job_started_at"] = format_utc_timestamp(record.job_started_at)
    if record.job_ended_at is not None:
        encoded["job_ended_at"] = format_utc_timestamp(record.job_ended_at)
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    encoded["attribution_certain"] = record.attribution_certain
    encoded["figures"] = to_json_value(record.figures)
    encoded["evidence"] = to_json_value(record.evidence)
    if record.outcome_assertion is not None:
        encoded["outcome_assertion"] = to_json_value(record.outcome_assertion)
    if record.metered_ai_cost is not None:
        encoded["metered_ai_cost"] = to_json_value(record.metered_ai_cost)
    return encoded


def _read_assessed_proposal(
    schema_id: str, fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> OutcomeProposal | OutcomeAbstention | None:
    # A union: the nested record's own schema_id selects the decoder.
    if "proposal" not in fields:
        return None
    record = nested(fields["proposal"])
    if type(record) is OutcomeProposal or type(record) is OutcomeAbstention:
        return record
    raise RecordValidationError(
        schema_id,
        "proposal",
        f"OutcomeProposal or OutcomeAbstention required, got {type(record).__name__}",
    )


def _decode_assess_job_request(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> AssessJobRequest:
    schema_id = AssessJobRequest.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("candidate", "sequence"),
        (
            "proposal",
            "costs",
            "locality",
            "job_started_at",
            "job_ended_at",
            "subject_ref",
            "attribution_certain",
            "figures",
            "evidence",
            "outcome_assertion",
            "metered_ai_cost",
        ),
    )
    certain = _read_optional_bool(schema_id, fields, "attribution_certain")
    figures = _read_optional_record(
        schema_id, fields, "figures", nested, ValuationFigures
    )
    evidence = _read_optional_record(
        schema_id, fields, "evidence", nested, ResolvedEvidence
    )
    return AssessJobRequest(
        candidate=_read_record(schema_id, fields, "candidate", nested, JobCandidate),
        proposal=_read_assessed_proposal(schema_id, fields, nested),
        sequence=_read_int(schema_id, fields, "sequence"),
        costs=_read_optional_record(schema_id, fields, "costs", nested, SuppliedCosts),
        locality=_read_optional_record(
            schema_id, fields, "locality", nested, InferenceLocality
        ),
        job_started_at=_read_optional_timestamp(schema_id, fields, "job_started_at"),
        job_ended_at=_read_optional_timestamp(schema_id, fields, "job_ended_at"),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
        attribution_certain=False if certain is None else certain,
        figures=ValuationFigures() if figures is None else figures,
        evidence=ResolvedEvidence() if evidence is None else evidence,
        outcome_assertion=_read_optional_record(
            schema_id, fields, "outcome_assertion", nested, OutcomeAssertion
        ),
        metered_ai_cost=_read_optional_record(
            schema_id, fields, "metered_ai_cost", nested, Money
        ),
    )


_ASSESSMENT_TEXT_KEYS: Final = (
    "assessment_id",
    "job_id",
    "job_type",
    "taxonomy_version",
    "candidate_downstream_outcome",
    "counterfactual_assumption",
    "basis",
    "economic_mechanism",
    "evaluator",
    "evaluator_version",
    "model",
    "inference_provider",
    "library_version",
)
_ASSESSMENT_TIME_KEYS: Final = (
    "assessed_at",
    "job_started_at",
    "job_ended_at",
    "observation_window_start",
    "observation_window_end",
)
_ASSESSMENT_KEYS: Final = (
    *_ASSESSMENT_TEXT_KEYS,
    *_ASSESSMENT_TIME_KEYS,
    "sequence",
    "execution_status",
    "evidence_class",
    "evidence_class_authority",
    "inference_address_class",
    "prompt_version",
    "policy_version",
    "reportability",
    "reportability_reason",
    "roi",
)
_ASSESSMENT_OPTIONAL_KEYS: Final = (
    "double_counting_group",
    "outcome_assertion",
    "study",
    "subject_ref",
)


def _encode_assessment_common(
    record: JobAssessment | AssessmentAbstention,
) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        key: getattr(record, key) for key in _ASSESSMENT_TEXT_KEYS
    }
    for key in _ASSESSMENT_TIME_KEYS:
        encoded[key] = format_utc_timestamp(getattr(record, key))
    encoded["sequence"] = record.sequence
    encoded["execution_status"] = record.execution_status.value
    encoded["evidence_class"] = record.evidence_class.value
    encoded["evidence_class_authority"] = record.evidence_class_authority.value
    encoded["inference_address_class"] = record.inference_address_class.value
    encoded["prompt_version"] = record.prompt_version
    encoded["policy_version"] = record.policy_version
    encoded["reportability"] = record.reportability.value
    encoded["reportability_reason"] = record.reportability_reason.value
    encoded["roi"] = to_json_value(record.roi)
    if record.double_counting_group is not None:
        encoded["double_counting_group"] = record.double_counting_group
    if record.outcome_assertion is not None:
        encoded["outcome_assertion"] = to_json_value(record.outcome_assertion)
    if record.study is not None:
        encoded["study"] = to_json_value(record.study)
    if record.subject_ref is not None:
        encoded["subject_ref"] = record.subject_ref
    return encoded


def _encode_job_assessment(record: JobAssessment) -> dict[str, JsonValue]:
    encoded = _encode_assessment_common(record)
    encoded["confidence"] = to_json_value(record.confidence)
    encoded["value_low"] = format_decimal(record.value_low)
    encoded["value_high"] = format_decimal(record.value_high)
    encoded["band"] = to_json_value(record.band)
    encoded["bounds_source"] = record.bounds_source
    encoded["assumptions"] = to_json_value(record.assumptions)
    encoded["produced_by"] = record.produced_by.value
    encoded["operand_bases"] = [
        {"operand": operand.value, "basis": basis.value}
        for operand, basis in record.operand_bases
    ]
    if record.attribution_fraction is not None:
        encoded["attribution_fraction"] = format_decimal(record.attribution_fraction)
    if record.attribution_basis is not None:
        encoded["attribution_basis"] = record.attribution_basis
    return encoded


def _read_operand_bases(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> OperandBases:
    value = fields[key]
    if type(value) is not list:
        raise RecordValidationError(
            schema_id, key, f"JSON array required, got {_json_type(value)}"
        )
    pairs: list[tuple[ValuationOperand, ClaimBasis]] = []
    for index, item in enumerate(value):
        if type(item) is not dict:
            raise RecordValidationError(
                schema_id,
                key,
                f"element {index} must be a JSON object, got {_json_type(item)}",
            )
        element = f"{key}[{index}]"
        _require_keys(element, item, ("operand", "basis"))
        pairs.append(
            (
                _read_enum(element, item, "operand", ValuationOperand),
                _read_enum(element, item, "basis", ClaimBasis),
            )
        )
    return tuple(pairs)


def _decode_job_assessment(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> JobAssessment:
    schema_id = JobAssessment.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            *_ASSESSMENT_KEYS,
            "confidence",
            "value_low",
            "value_high",
            "band",
            "bounds_source",
            "assumptions",
            "produced_by",
            "operand_bases",
        ),
        (*_ASSESSMENT_OPTIONAL_KEYS, "attribution_fraction", "attribution_basis"),
    )

    def text(key: str) -> str:
        return _read_str(schema_id, fields, key)

    def instant(key: str) -> datetime:
        return _read_timestamp(schema_id, fields, key)

    return JobAssessment(
        assessment_id=text("assessment_id"),
        sequence=_read_int(schema_id, fields, "sequence"),
        job_id=text("job_id"),
        job_type=text("job_type"),
        taxonomy_version=text("taxonomy_version"),
        execution_status=_read_enum(schema_id, fields, "execution_status", JobOutcome),
        outcome_assertion=_read_optional_record(
            schema_id, fields, "outcome_assertion", nested, OutcomeAssertion
        ),
        assessed_at=instant("assessed_at"),
        job_started_at=instant("job_started_at"),
        job_ended_at=instant("job_ended_at"),
        observation_window_start=instant("observation_window_start"),
        observation_window_end=instant("observation_window_end"),
        candidate_downstream_outcome=text("candidate_downstream_outcome"),
        counterfactual_assumption=text("counterfactual_assumption"),
        basis=text("basis"),
        economic_mechanism=text("economic_mechanism"),
        double_counting_group=_read_optional_str(
            schema_id, fields, "double_counting_group"
        ),
        evidence_class=_read_enum(schema_id, fields, "evidence_class", EvidenceClass),
        evidence_class_authority=_read_enum(
            schema_id, fields, "evidence_class_authority", EvidenceAuthority
        ),
        study=_read_optional_record(schema_id, fields, "study", nested, StudyReference),
        evaluator=text("evaluator"),
        evaluator_version=text("evaluator_version"),
        model=text("model"),
        inference_provider=text("inference_provider"),
        inference_address_class=_read_enum(
            schema_id, fields, "inference_address_class", AddressClass
        ),
        prompt_version=_read_int(schema_id, fields, "prompt_version"),
        policy_version=_read_int(schema_id, fields, "policy_version"),
        confidence=_read_record(schema_id, fields, "confidence", nested, Confidence),
        value_low=_read_decimal(schema_id, fields, "value_low"),
        value_high=_read_decimal(schema_id, fields, "value_high"),
        band=_read_record(schema_id, fields, "band", nested, DerivedBand),
        bounds_source=text("bounds_source"),
        assumptions=_read_record(
            schema_id, fields, "assumptions", nested, ResolvedAssumptions
        ),
        produced_by=_read_enum(schema_id, fields, "produced_by", ValuationMethod),
        operand_bases=_read_operand_bases(schema_id, fields, "operand_bases"),
        attribution_fraction=_read_optional_decimal(
            schema_id, fields, "attribution_fraction"
        ),
        attribution_basis=_read_optional_str(schema_id, fields, "attribution_basis"),
        reportability=_read_enum(
            schema_id, fields, "reportability", ReportabilityStatus
        ),
        reportability_reason=_read_enum(
            schema_id, fields, "reportability_reason", ReportabilityReason
        ),
        roi=_read_record(schema_id, fields, "roi", nested, RoiOperands),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
        library_version=text("library_version"),
    )


def _encode_assessment_abstention(
    record: AssessmentAbstention,
) -> dict[str, JsonValue]:
    encoded = _encode_assessment_common(record)
    encoded["abstention_reason"] = record.abstention_reason.value
    if record.refusal is not None:
        encoded["refusal"] = record.refusal.value
    return encoded


def _decode_assessment_abstention(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> AssessmentAbstention:
    schema_id = AssessmentAbstention.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (*_ASSESSMENT_KEYS, "abstention_reason"),
        (*_ASSESSMENT_OPTIONAL_KEYS, "refusal"),
    )

    def text(key: str) -> str:
        return _read_str(schema_id, fields, key)

    def instant(key: str) -> datetime:
        return _read_timestamp(schema_id, fields, key)

    return AssessmentAbstention(
        assessment_id=text("assessment_id"),
        sequence=_read_int(schema_id, fields, "sequence"),
        job_id=text("job_id"),
        job_type=text("job_type"),
        taxonomy_version=text("taxonomy_version"),
        execution_status=_read_enum(schema_id, fields, "execution_status", JobOutcome),
        outcome_assertion=_read_optional_record(
            schema_id, fields, "outcome_assertion", nested, OutcomeAssertion
        ),
        assessed_at=instant("assessed_at"),
        job_started_at=instant("job_started_at"),
        job_ended_at=instant("job_ended_at"),
        observation_window_start=instant("observation_window_start"),
        observation_window_end=instant("observation_window_end"),
        candidate_downstream_outcome=text("candidate_downstream_outcome"),
        counterfactual_assumption=text("counterfactual_assumption"),
        basis=text("basis"),
        economic_mechanism=text("economic_mechanism"),
        double_counting_group=_read_optional_str(
            schema_id, fields, "double_counting_group"
        ),
        evidence_class=_read_enum(schema_id, fields, "evidence_class", EvidenceClass),
        evidence_class_authority=_read_enum(
            schema_id, fields, "evidence_class_authority", EvidenceAuthority
        ),
        study=_read_optional_record(schema_id, fields, "study", nested, StudyReference),
        evaluator=text("evaluator"),
        evaluator_version=text("evaluator_version"),
        model=text("model"),
        inference_provider=text("inference_provider"),
        inference_address_class=_read_enum(
            schema_id, fields, "inference_address_class", AddressClass
        ),
        prompt_version=_read_int(schema_id, fields, "prompt_version"),
        policy_version=_read_int(schema_id, fields, "policy_version"),
        abstention_reason=_read_enum(
            schema_id, fields, "abstention_reason", AbstentionReason
        ),
        refusal=(
            _read_enum(schema_id, fields, "refusal", AssessmentRefusal)
            if "refusal" in fields
            else None
        ),
        reportability=_read_enum(
            schema_id, fields, "reportability", ReportabilityStatus
        ),
        reportability_reason=_read_enum(
            schema_id, fields, "reportability_reason", ReportabilityReason
        ),
        roi=_read_record(schema_id, fields, "roi", nested, RoiOperands),
        subject_ref=_read_optional_str(schema_id, fields, "subject_ref"),
        library_version=text("library_version"),
    )


def _encode_record_ref(record: RecordRef) -> dict[str, JsonValue]:
    # "schema_id" is the envelope key, so the target's is "target_schema_id",
    # as VersionStamp writes "stamped_schema_id".
    return {"target_schema_id": record.schema_id, "record_id": record.record_id}


def _decode_record_ref(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> RecordRef:
    schema_id = RecordRef.SCHEMA_ID
    _require_keys(schema_id, fields, ("target_schema_id", "record_id"))
    return RecordRef(
        schema_id=_read_str(schema_id, fields, "target_schema_id"),
        record_id=_read_str(schema_id, fields, "record_id"),
    )


_CORRECTION_DECIMAL_KEYS: Final = (
    "value",
    "value_low",
    "value_high",
    "attribution_fraction",
)
_CORRECTION_FIELD_KEYS: Final = tuple(field.value for field in CorrectableField)


def _encode_correction_fields(record: CorrectionFields) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {}
    if record.job_type is not None:
        encoded["job_type"] = record.job_type
    if record.job_started_at is not None:
        encoded["job_started_at"] = format_utc_timestamp(record.job_started_at)
    if record.job_ended_at is not None:
        encoded["job_ended_at"] = format_utc_timestamp(record.job_ended_at)
    if record.execution_status is not None:
        encoded["execution_status"] = record.execution_status.value
    for key in _CORRECTION_DECIMAL_KEYS:
        value = getattr(record, key)
        if value is not None:
            encoded[key] = format_decimal(value)
    if record.currency is not None:
        encoded["currency"] = record.currency.value
    if record.economic_mechanism is not None:
        encoded["economic_mechanism"] = record.economic_mechanism
    if record.attribution_basis is not None:
        encoded["attribution_basis"] = record.attribution_basis
    return encoded


def _decode_correction_fields(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> CorrectionFields:
    schema_id = CorrectionFields.SCHEMA_ID
    _require_keys(schema_id, fields, (), _CORRECTION_FIELD_KEYS)
    return CorrectionFields(
        job_type=_read_optional_str(schema_id, fields, "job_type"),
        job_started_at=_read_optional_timestamp(schema_id, fields, "job_started_at"),
        job_ended_at=_read_optional_timestamp(schema_id, fields, "job_ended_at"),
        execution_status=(
            _read_enum(schema_id, fields, "execution_status", JobOutcome)
            if "execution_status" in fields
            else None
        ),
        value=_read_optional_decimal(schema_id, fields, "value"),
        value_low=_read_optional_decimal(schema_id, fields, "value_low"),
        value_high=_read_optional_decimal(schema_id, fields, "value_high"),
        currency=(
            _read_enum(schema_id, fields, "currency", Currency)
            if "currency" in fields
            else None
        ),
        economic_mechanism=_read_optional_str(schema_id, fields, "economic_mechanism"),
        attribution_fraction=_read_optional_decimal(
            schema_id, fields, "attribution_fraction"
        ),
        attribution_basis=_read_optional_str(schema_id, fields, "attribution_basis"),
    )


def _encode_correction(record: Correction) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "correction_id": record.correction_id,
        "target": to_json_value(record.target),
        "sequence": record.sequence,
        "fields": to_json_value(record.fields),
        "reason": record.reason,
        "provenance": record.provenance,
        "recorded_at": format_utc_timestamp(record.recorded_at),
    }
    if record.expected_prior is not None:
        encoded["expected_prior"] = to_json_value(record.expected_prior)
    if record.actor is not None:
        encoded["actor"] = record.actor
    return encoded


def _decode_correction(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> Correction:
    schema_id = Correction.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            "correction_id",
            "target",
            "sequence",
            "fields",
            "reason",
            "provenance",
            "recorded_at",
        ),
        ("expected_prior", "actor"),
    )
    return Correction(
        correction_id=_read_str(schema_id, fields, "correction_id"),
        target=_read_record(schema_id, fields, "target", nested, RecordRef),
        sequence=_read_int(schema_id, fields, "sequence"),
        fields=_read_record(schema_id, fields, "fields", nested, CorrectionFields),
        expected_prior=_read_optional_record(
            schema_id, fields, "expected_prior", nested, CorrectionFields
        ),
        reason=_read_str(schema_id, fields, "reason"),
        provenance=_read_str(schema_id, fields, "provenance"),
        actor=_read_optional_str(schema_id, fields, "actor"),
        recorded_at=_read_timestamp(schema_id, fields, "recorded_at"),
    )


def _encode_correction_rejection(
    record: CorrectionRejection,
) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "correction_id": record.correction_id,
        "reason": record.reason.value,
    }
    if record.field is not None:
        encoded["field"] = record.field.value
    if record.expected is not None:
        encoded["expected"] = record.expected
    if record.actual is not None:
        encoded["actual"] = record.actual
    return encoded


def _decode_correction_rejection(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> CorrectionRejection:
    schema_id = CorrectionRejection.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("correction_id", "reason"),
        ("field", "expected", "actual"),
    )
    return CorrectionRejection(
        correction_id=_read_str(schema_id, fields, "correction_id"),
        reason=_read_enum(schema_id, fields, "reason", CorrectionRejectionReason),
        field=(
            _read_enum(schema_id, fields, "field", CorrectableField)
            if "field" in fields
            else None
        ),
        expected=_read_optional_str(schema_id, fields, "expected"),
        actual=_read_optional_str(schema_id, fields, "actual"),
    )


def _encode_effective_assessment(
    record: EffectiveAssessment,
) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "original": to_json_value(record.original),
        "corrections": [to_json_value(item) for item in record.corrections],
        "applied": list(record.applied),
        "superseded": list(record.superseded),
        "rejected": [to_json_value(item) for item in record.rejected],
        "field_sources": [
            {"field": field.value, "correction_id": correction_id}
            for field, correction_id in record.field_sources
        ],
        "assessment_id": record.assessment_id,
        "job_id": record.job_id,
        "job_type": record.job_type,
        "job_started_at": format_utc_timestamp(record.job_started_at),
        "job_ended_at": format_utc_timestamp(record.job_ended_at),
        "execution_status": record.execution_status.value,
        "economic_mechanism": record.economic_mechanism,
        "roi": to_json_value(record.roi),
        "evidence_class": record.evidence_class.value,
        "evidence_class_authority": record.evidence_class_authority.value,
        "reportability": record.reportability.value,
        "reportability_reason": record.reportability_reason.value,
        "library_version": record.library_version,
    }
    if record.double_counting_group is not None:
        encoded["double_counting_group"] = record.double_counting_group
    for key in ("value_low", "value_high", "attribution_fraction", "hours_saved"):
        value = getattr(record, key)
        if value is not None:
            encoded[key] = format_decimal(value)
    if record.attribution_basis is not None:
        encoded["attribution_basis"] = record.attribution_basis
    if record.confidence is not None:
        encoded["confidence"] = to_json_value(record.confidence)
    return encoded


def _read_effective_original(
    schema_id: str, fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> JobAssessment | AssessmentAbstention:
    # A union: the nested record's own schema_id selects the decoder.
    record = nested(fields["original"])
    if type(record) is JobAssessment or type(record) is AssessmentAbstention:
        return record
    raise RecordValidationError(
        schema_id,
        "original",
        f"JobAssessment or AssessmentAbstention required, got {type(record).__name__}",
    )


def _read_field_sources(
    schema_id: str, fields: Mapping[str, JsonValue], key: str
) -> tuple[tuple[CorrectableField, str], ...]:
    pairs: list[tuple[CorrectableField, str]] = []
    for element, item in _read_objects(schema_id, fields, key):
        _require_keys(element, item, ("field", "correction_id"))
        pairs.append(
            (
                _read_enum(element, item, "field", CorrectableField),
                _read_str(element, item, "correction_id"),
            )
        )
    return tuple(pairs)


def _decode_effective_assessment(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> EffectiveAssessment:
    schema_id = EffectiveAssessment.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            "original",
            "corrections",
            "applied",
            "superseded",
            "rejected",
            "field_sources",
            "assessment_id",
            "job_id",
            "job_type",
            "job_started_at",
            "job_ended_at",
            "execution_status",
            "economic_mechanism",
            "roi",
            "evidence_class",
            "evidence_class_authority",
            "reportability",
            "reportability_reason",
            "library_version",
        ),
        (
            "double_counting_group",
            "value_low",
            "value_high",
            "attribution_fraction",
            "attribution_basis",
            "confidence",
            "hours_saved",
        ),
    )
    return EffectiveAssessment(
        original=_read_effective_original(schema_id, fields, nested),
        corrections=_read_records(schema_id, fields, "corrections", nested, Correction),
        applied=_read_strs(schema_id, fields, "applied"),
        superseded=_read_strs(schema_id, fields, "superseded"),
        rejected=_read_records(
            schema_id, fields, "rejected", nested, CorrectionRejection
        ),
        field_sources=_read_field_sources(schema_id, fields, "field_sources"),
        assessment_id=_read_str(schema_id, fields, "assessment_id"),
        job_id=_read_str(schema_id, fields, "job_id"),
        double_counting_group=_read_optional_str(
            schema_id, fields, "double_counting_group"
        ),
        job_type=_read_str(schema_id, fields, "job_type"),
        job_started_at=_read_timestamp(schema_id, fields, "job_started_at"),
        job_ended_at=_read_timestamp(schema_id, fields, "job_ended_at"),
        execution_status=_read_enum(schema_id, fields, "execution_status", JobOutcome),
        economic_mechanism=_read_str(schema_id, fields, "economic_mechanism"),
        value_low=_read_optional_decimal(schema_id, fields, "value_low"),
        value_high=_read_optional_decimal(schema_id, fields, "value_high"),
        roi=_read_record(schema_id, fields, "roi", nested, RoiOperands),
        attribution_fraction=_read_optional_decimal(
            schema_id, fields, "attribution_fraction"
        ),
        attribution_basis=_read_optional_str(schema_id, fields, "attribution_basis"),
        confidence=_read_optional_record(
            schema_id, fields, "confidence", nested, Confidence
        ),
        hours_saved=_read_optional_decimal(schema_id, fields, "hours_saved"),
        evidence_class=_read_enum(schema_id, fields, "evidence_class", EvidenceClass),
        evidence_class_authority=_read_enum(
            schema_id, fields, "evidence_class_authority", EvidenceAuthority
        ),
        reportability=_read_enum(
            schema_id, fields, "reportability", ReportabilityStatus
        ),
        reportability_reason=_read_enum(
            schema_id, fields, "reportability_reason", ReportabilityReason
        ),
        library_version=_read_str(schema_id, fields, "library_version"),
    )


def _encode_metric_declaration(record: MetricDeclaration) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {"key": record.key}
    if record.metric_type is not None:
        encoded["metric_type"] = record.metric_type.value
    return encoded


def _decode_metric_declaration(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> MetricDeclaration:
    schema_id = MetricDeclaration.SCHEMA_ID
    _require_keys(schema_id, fields, ("key",), ("metric_type",))
    return MetricDeclaration(
        key=_read_str(schema_id, fields, "key"),
        metric_type=(
            _read_enum(schema_id, fields, "metric_type", MetricType)
            if "metric_type" in fields
            else None
        ),
    )


def _encode_economics_contract(record: EconomicsContract) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "job_type": record.job_type,
        "version": record.version,
        "metrics": [to_json_value(item) for item in record.metrics],
        "unit_metric_key": record.unit_metric_key,
    }
    if record.currency is not None:
        encoded["currency"] = record.currency.value
    if record.value_per_unit is not None:
        encoded["value_per_unit"] = format_decimal(record.value_per_unit)
    return encoded


def _decode_economics_contract(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> EconomicsContract:
    schema_id = EconomicsContract.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("job_type", "version", "metrics", "unit_metric_key"),
        ("currency", "value_per_unit"),
    )
    return EconomicsContract(
        job_type=_read_str(schema_id, fields, "job_type"),
        version=_read_str(schema_id, fields, "version"),
        currency=(
            _read_enum(schema_id, fields, "currency", Currency)
            if "currency" in fields
            else None
        ),
        metrics=_read_records(schema_id, fields, "metrics", nested, MetricDeclaration),
        unit_metric_key=_read_str(schema_id, fields, "unit_metric_key"),
        value_per_unit=(
            _read_decimal(schema_id, fields, "value_per_unit")
            if "value_per_unit" in fields
            else None
        ),
    )


def _encode_outcome_metric_intent(
    record: OutcomeMetricIntent,
) -> dict[str, JsonValue]:
    return {
        "key": record.key,
        "metric_type": record.metric_type.value,
        "value": format_decimal(record.value),
        "line_key": record.line_key,
    }


def _decode_outcome_metric_intent(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> OutcomeMetricIntent:
    schema_id = OutcomeMetricIntent.SCHEMA_ID
    _require_keys(schema_id, fields, ("key", "metric_type", "value", "line_key"))
    return OutcomeMetricIntent(
        key=_read_str(schema_id, fields, "key"),
        metric_type=_read_enum(schema_id, fields, "metric_type", MetricType),
        value=_read_decimal(schema_id, fields, "value"),
        line_key=_read_str(schema_id, fields, "line_key"),
    )


def _encode_outcome_metric_intents(
    record: OutcomeMetricIntents,
) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "assessment_id": record.assessment_id,
        "job_id": record.job_id,
        "job_type": record.job_type,
        "contract_job_type": record.contract_job_type,
        "contract_version": record.contract_version,
        "currency": record.currency.value,
        "intents": [to_json_value(item) for item in record.intents],
        "value_low": format_decimal(record.value_low),
        "value_high": format_decimal(record.value_high),
        "recorded_at": format_utc_timestamp(record.recorded_at),
        "built_at": format_utc_timestamp(record.built_at),
        "idempotency_key": record.idempotency_key,
        "applied_corrections": list(record.applied_corrections),
        "provenance": record.provenance,
        "library_version": record.library_version,
    }
    if record.double_counting_group is not None:
        encoded["double_counting_group"] = record.double_counting_group
    if record.allocation_share is not None:
        encoded["allocation_share"] = format_decimal(record.allocation_share)
    if record.shared_outcome is not None:
        encoded["shared_outcome"] = to_json_value(record.shared_outcome)
    return encoded


def _decode_outcome_metric_intents(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> OutcomeMetricIntents:
    schema_id = OutcomeMetricIntents.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            "assessment_id",
            "job_id",
            "job_type",
            "contract_job_type",
            "contract_version",
            "currency",
            "intents",
            "value_low",
            "value_high",
            "recorded_at",
            "built_at",
            "idempotency_key",
            "applied_corrections",
            "provenance",
            "library_version",
        ),
        ("double_counting_group", "allocation_share", "shared_outcome"),
    )
    return OutcomeMetricIntents(
        assessment_id=_read_str(schema_id, fields, "assessment_id"),
        job_id=_read_str(schema_id, fields, "job_id"),
        job_type=_read_str(schema_id, fields, "job_type"),
        contract_job_type=_read_str(schema_id, fields, "contract_job_type"),
        contract_version=_read_str(schema_id, fields, "contract_version"),
        currency=_read_enum(schema_id, fields, "currency", Currency),
        intents=_read_records(
            schema_id, fields, "intents", nested, OutcomeMetricIntent
        ),
        value_low=_read_decimal(schema_id, fields, "value_low"),
        value_high=_read_decimal(schema_id, fields, "value_high"),
        recorded_at=_read_timestamp(schema_id, fields, "recorded_at"),
        built_at=_read_timestamp(schema_id, fields, "built_at"),
        idempotency_key=_read_str(schema_id, fields, "idempotency_key"),
        applied_corrections=_read_strs(schema_id, fields, "applied_corrections"),
        provenance=_read_str(schema_id, fields, "provenance"),
        double_counting_group=_read_optional_str(
            schema_id, fields, "double_counting_group"
        ),
        allocation_share=_read_optional_decimal(schema_id, fields, "allocation_share"),
        shared_outcome=_read_optional_record(
            schema_id, fields, "shared_outcome", nested, SharedOutcomeFlag
        ),
        library_version=_read_str(schema_id, fields, "library_version"),
    )


def _encode_shared_outcome_flag(record: SharedOutcomeFlag) -> dict[str, JsonValue]:
    return {
        "reason": record.reason.value,
        "group": record.group,
        "members": list(record.members),
    }


def _decode_shared_outcome_flag(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> SharedOutcomeFlag:
    schema_id = SharedOutcomeFlag.SCHEMA_ID
    _require_keys(schema_id, fields, ("reason", "group", "members"))
    return SharedOutcomeFlag(
        reason=_read_enum(schema_id, fields, "reason", MetricRefusalReason),
        group=_read_str(schema_id, fields, "group"),
        members=_read_strs(schema_id, fields, "members"),
    )


def _encode_metric_refusal(record: MetricRefusal) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "assessment_id": record.assessment_id,
        "job_id": record.job_id,
        "job_type": record.job_type,
        "reason": record.reason.value,
        "details": list(record.details),
        "members": list(record.members),
        "built_at": format_utc_timestamp(record.built_at),
        "library_version": record.library_version,
    }
    if record.metric_key is not None:
        encoded["metric_key"] = record.metric_key
    if record.group is not None:
        encoded["group"] = record.group
    return encoded


def _decode_metric_refusal(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> MetricRefusal:
    schema_id = MetricRefusal.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            "assessment_id",
            "job_id",
            "job_type",
            "reason",
            "details",
            "members",
            "built_at",
            "library_version",
        ),
        ("metric_key", "group"),
    )
    return MetricRefusal(
        assessment_id=_read_str(schema_id, fields, "assessment_id"),
        job_id=_read_str(schema_id, fields, "job_id"),
        job_type=_read_str(schema_id, fields, "job_type"),
        reason=_read_enum(schema_id, fields, "reason", MetricRefusalReason),
        metric_key=_read_optional_str(schema_id, fields, "metric_key"),
        details=_read_strs(schema_id, fields, "details"),
        group=_read_optional_str(schema_id, fields, "group"),
        members=_read_strs(schema_id, fields, "members"),
        built_at=_read_timestamp(schema_id, fields, "built_at"),
        library_version=_read_str(schema_id, fields, "library_version"),
    )


def _encode_allocation_share(record: AllocationShare) -> dict[str, JsonValue]:
    return {
        "assessment_id": record.assessment_id,
        "share": format_decimal(record.share),
    }


def _decode_allocation_share(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> AllocationShare:
    schema_id = AllocationShare.SCHEMA_ID
    _require_keys(schema_id, fields, ("assessment_id", "share"))
    return AllocationShare(
        assessment_id=_read_str(schema_id, fields, "assessment_id"),
        share=_read_decimal(schema_id, fields, "share"),
    )


def _encode_group_allocation(record: GroupAllocation) -> dict[str, JsonValue]:
    return {
        "group": record.group,
        "shares": [to_json_value(item) for item in record.shares],
    }


def _decode_group_allocation(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> GroupAllocation:
    schema_id = GroupAllocation.SCHEMA_ID
    _require_keys(schema_id, fields, ("group", "shares"))
    return GroupAllocation(
        group=_read_str(schema_id, fields, "group"),
        shares=_read_records(schema_id, fields, "shares", nested, AllocationShare),
    )


def _encode_scenario_expectation(record: ScenarioExpectation) -> dict[str, JsonValue]:
    return {"kind": record.kind.value, "values": list(record.values)}


def _decode_scenario_expectation(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ScenarioExpectation:
    schema_id = ScenarioExpectation.SCHEMA_ID
    _require_keys(schema_id, fields, ("kind", "values"))
    return ScenarioExpectation(
        kind=_read_enum(schema_id, fields, "kind", ExpectationKind),
        values=_read_strs(schema_id, fields, "values"),
    )


def _encode_scenario(record: Scenario) -> dict[str, JsonValue]:
    encoded: dict[str, JsonValue] = {
        "name": record.name,
        "host_shape": record.host_shape.value,
        "summary": record.summary,
        "host_stream": list(record.host_stream),
        "inference_cuts": list(record.inference_cuts),
        "task_labels": list(record.task_labels),
        "job_labels": list(record.job_labels),
        "taxonomy_version": record.taxonomy_version,
        "job_source": record.job_source.value,
        "model_responses": list(record.model_responses),
        "policy": record.policy.value,
        "reportable_evidence": record.reportable_evidence,
        "clock_start": format_utc_timestamp(record.clock_start),
        "id_start": record.id_start,
        "expectations": [to_json_value(item) for item in record.expectations],
    }
    # ADR 0044 decision 6: the default scope is omitted, so every scenario
    # written before the field existed keeps its bytes and snapshot.
    if record.double_counting_scope is not DoubleCountingScope.INFERENCE:
        encoded["double_counting_scope"] = record.double_counting_scope.value
    return encoded


def _decode_scenario(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> Scenario:
    schema_id = Scenario.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        (
            "name",
            "host_shape",
            "summary",
            "host_stream",
            "inference_cuts",
            "task_labels",
            "job_labels",
            "taxonomy_version",
            "job_source",
            "model_responses",
            "policy",
            "reportable_evidence",
            "clock_start",
            "id_start",
            "expectations",
        ),
        ("double_counting_scope",),
    )
    explicit = "double_counting_scope" in fields
    scope = (
        _read_enum(schema_id, fields, "double_counting_scope", DoubleCountingScope)
        if explicit
        else DoubleCountingScope.INFERENCE
    )
    record = Scenario(
        name=_read_str(schema_id, fields, "name"),
        host_shape=_read_enum(schema_id, fields, "host_shape", HostShape),
        summary=_read_str(schema_id, fields, "summary"),
        host_stream=_read_strs(schema_id, fields, "host_stream"),
        inference_cuts=_read_ints(schema_id, fields, "inference_cuts"),
        task_labels=_read_strs(schema_id, fields, "task_labels"),
        job_labels=_read_strs(schema_id, fields, "job_labels"),
        taxonomy_version=_read_str(schema_id, fields, "taxonomy_version"),
        job_source=_read_enum(schema_id, fields, "job_source", JobSource),
        model_responses=_read_strs(schema_id, fields, "model_responses"),
        policy=_read_enum(schema_id, fields, "policy", PolicyPreset),
        reportable_evidence=_read_bool(schema_id, fields, "reportable_evidence"),
        clock_start=_read_timestamp(schema_id, fields, "clock_start"),
        id_start=_read_int(schema_id, fields, "id_start"),
        expectations=_read_records(
            schema_id, fields, "expectations", nested, ScenarioExpectation
        ),
        double_counting_scope=scope,
    )
    if explicit and scope is DoubleCountingScope.INFERENCE:
        # The canonical form omits the default; see the request codec.
        raise RecordValidationError(
            schema_id, "double_counting_scope", "the default must be omitted"
        )
    return record


def _encode_expectation_verdict(record: ExpectationVerdict) -> dict[str, JsonValue]:
    return {
        "kind": record.kind.value,
        "expected": list(record.expected),
        "actual": list(record.actual),
        "passed": record.passed,
    }


def _decode_expectation_verdict(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ExpectationVerdict:
    schema_id = ExpectationVerdict.SCHEMA_ID
    _require_keys(schema_id, fields, ("kind", "expected", "actual", "passed"))
    return ExpectationVerdict(
        kind=_read_enum(schema_id, fields, "kind", ExpectationKind),
        expected=_read_strs(schema_id, fields, "expected"),
        actual=_read_strs(schema_id, fields, "actual"),
        passed=_read_bool(schema_id, fields, "passed"),
    )


def _encode_scenario_result(record: ScenarioResult) -> dict[str, JsonValue]:
    return {
        "scenario": record.scenario,
        "host_shape": record.host_shape.value,
        "records": list(record.records),
        "verdicts": [to_json_value(item) for item in record.verdicts],
        "passed": record.passed,
        "library_version": record.library_version,
    }


def _decode_scenario_result(
    fields: Mapping[str, JsonValue], nested: NestedDecoder
) -> ScenarioResult:
    schema_id = ScenarioResult.SCHEMA_ID
    _require_keys(
        schema_id,
        fields,
        ("scenario", "host_shape", "records", "verdicts", "passed", "library_version"),
    )
    return ScenarioResult(
        scenario=_read_str(schema_id, fields, "scenario"),
        host_shape=_read_enum(schema_id, fields, "host_shape", HostShape),
        records=_read_strs(schema_id, fields, "records"),
        verdicts=_read_records(
            schema_id, fields, "verdicts", nested, ExpectationVerdict
        ),
        passed=_read_bool(schema_id, fields, "passed"),
        library_version=_read_str(schema_id, fields, "library_version"),
    )


SCHEMA_IDS: Final[tuple[SchemaEntry, ...]] = (
    SchemaEntry(
        schema_id=Money.SCHEMA_ID,
        schema_version=Money.SCHEMA_VERSION,
        record_type=Money,
        encode=_encode_money,
        decode=_decode_money,
    ),
    SchemaEntry(
        schema_id=Confidence.SCHEMA_ID,
        schema_version=Confidence.SCHEMA_VERSION,
        record_type=Confidence,
        encode=_encode_confidence,
        decode=_decode_confidence,
    ),
    SchemaEntry(
        schema_id=ComponentVersion.SCHEMA_ID,
        schema_version=ComponentVersion.SCHEMA_VERSION,
        record_type=ComponentVersion,
        encode=_encode_component_version,
        decode=_decode_component_version,
    ),
    SchemaEntry(
        schema_id=VersionStamp.SCHEMA_ID,
        schema_version=VersionStamp.SCHEMA_VERSION,
        record_type=VersionStamp,
        encode=_encode_version_stamp,
        decode=_decode_version_stamp,
    ),
    SchemaEntry(
        schema_id=Abstention.SCHEMA_ID,
        schema_version=Abstention.SCHEMA_VERSION,
        record_type=Abstention,
        encode=_encode_abstention,
        decode=_decode_abstention,
    ),
    SchemaEntry(
        schema_id=StudyReference.SCHEMA_ID,
        schema_version=StudyReference.SCHEMA_VERSION,
        record_type=StudyReference,
        encode=_encode_study_reference,
        decode=_decode_study_reference,
    ),
    SchemaEntry(
        schema_id=Diagnostic.SCHEMA_ID,
        schema_version=Diagnostic.SCHEMA_VERSION,
        record_type=Diagnostic,
        encode=_encode_diagnostic,
        decode=_decode_diagnostic,
    ),
    SchemaEntry(
        schema_id=TaxonomyRef.SCHEMA_ID,
        schema_version=TaxonomyRef.SCHEMA_VERSION,
        record_type=TaxonomyRef,
        encode=_encode_taxonomy_ref,
        decode=_decode_taxonomy_ref,
    ),
    SchemaEntry(
        schema_id=PromptRef.SCHEMA_ID,
        schema_version=PromptRef.SCHEMA_VERSION,
        record_type=PromptRef,
        encode=_encode_prompt_ref,
        decode=_decode_prompt_ref,
    ),
    SchemaEntry(
        schema_id=TokenUsage.SCHEMA_ID,
        schema_version=TokenUsage.SCHEMA_VERSION,
        record_type=TokenUsage,
        encode=_encode_token_usage,
        decode=_decode_token_usage,
    ),
    SchemaEntry(
        schema_id=InferenceProvenance.SCHEMA_ID,
        schema_version=InferenceProvenance.SCHEMA_VERSION,
        record_type=InferenceProvenance,
        encode=_encode_inference_provenance,
        decode=_decode_inference_provenance,
    ),
    SchemaEntry(
        schema_id=ComponentDeclaration.SCHEMA_ID,
        schema_version=ComponentDeclaration.SCHEMA_VERSION,
        record_type=ComponentDeclaration,
        encode=_encode_component_declaration,
        decode=_decode_component_declaration,
    ),
    SchemaEntry(
        schema_id=ClassificationAbstention.SCHEMA_ID,
        schema_version=ClassificationAbstention.SCHEMA_VERSION,
        record_type=ClassificationAbstention,
        encode=_encode_classification_abstention,
        decode=_decode_classification_abstention,
    ),
    SchemaEntry(
        schema_id=TaskTaxonomySnapshot.SCHEMA_ID,
        schema_version=TaskTaxonomySnapshot.SCHEMA_VERSION,
        record_type=TaskTaxonomySnapshot,
        encode=_encode_snapshot,
        decode=_decode_task_taxonomy_snapshot,
    ),
    SchemaEntry(
        schema_id=JobTaxonomySnapshot.SCHEMA_ID,
        schema_version=JobTaxonomySnapshot.SCHEMA_VERSION,
        record_type=JobTaxonomySnapshot,
        encode=_encode_snapshot,
        decode=_decode_job_taxonomy_snapshot,
    ),
    SchemaEntry(
        schema_id=LabelProposal.SCHEMA_ID,
        schema_version=LabelProposal.SCHEMA_VERSION,
        record_type=LabelProposal,
        encode=_encode_label_proposal,
        decode=_decode_label_proposal,
    ),
    SchemaEntry(
        schema_id=CompletionMessage.SCHEMA_ID,
        schema_version=CompletionMessage.SCHEMA_VERSION,
        record_type=CompletionMessage,
        encode=_encode_completion_message,
        decode=_decode_completion_message,
    ),
    SchemaEntry(
        schema_id=CompletionRequest.SCHEMA_ID,
        schema_version=CompletionRequest.SCHEMA_VERSION,
        record_type=CompletionRequest,
        encode=_encode_completion_request,
        decode=_decode_completion_request,
    ),
    SchemaEntry(
        schema_id=CompletionResult.SCHEMA_ID,
        schema_version=CompletionResult.SCHEMA_VERSION,
        record_type=CompletionResult,
        encode=_encode_completion_result,
        decode=_decode_completion_result,
    ),
    SchemaEntry(
        schema_id=TaskClassificationRequest.SCHEMA_ID,
        schema_version=TaskClassificationRequest.SCHEMA_VERSION,
        record_type=TaskClassificationRequest,
        encode=_encode_task_classification_request,
        decode=_decode_task_classification_request,
    ),
    SchemaEntry(
        schema_id=TaskClassification.SCHEMA_ID,
        schema_version=TaskClassification.SCHEMA_VERSION,
        record_type=TaskClassification,
        encode=_encode_task_classification,
        decode=_decode_task_classification,
    ),
    SchemaEntry(
        schema_id=TaskClassificationInput.SCHEMA_ID,
        schema_version=TaskClassificationInput.SCHEMA_VERSION,
        record_type=TaskClassificationInput,
        encode=_encode_task_classification_input,
        decode=_decode_task_classification_input,
    ),
    SchemaEntry(
        schema_id=JobSegmentationInput.SCHEMA_ID,
        schema_version=JobSegmentationInput.SCHEMA_VERSION,
        record_type=JobSegmentationInput,
        encode=_encode_job_segmentation_input,
        decode=_decode_job_segmentation_input,
    ),
    SchemaEntry(
        schema_id=OutcomeEvaluationInput.SCHEMA_ID,
        schema_version=OutcomeEvaluationInput.SCHEMA_VERSION,
        record_type=OutcomeEvaluationInput,
        encode=_encode_outcome_evaluation_input,
        decode=_decode_outcome_evaluation_input,
    ),
    SchemaEntry(
        schema_id=EvidenceQuery.SCHEMA_ID,
        schema_version=EvidenceQuery.SCHEMA_VERSION,
        record_type=EvidenceQuery,
        encode=_encode_evidence_query,
        decode=_decode_evidence_query,
    ),
    SchemaEntry(
        schema_id=ReportabilityQuery.SCHEMA_ID,
        schema_version=ReportabilityQuery.SCHEMA_VERSION,
        record_type=ReportabilityQuery,
        encode=_encode_reportability_query,
        decode=_decode_reportability_query,
    ),
    SchemaEntry(
        schema_id=TextExcerpt.SCHEMA_ID,
        schema_version=TextExcerpt.SCHEMA_VERSION,
        record_type=TextExcerpt,
        encode=_encode_text_excerpt,
        decode=_decode_text_excerpt,
    ),
    SchemaEntry(
        schema_id=LineageNode.SCHEMA_ID,
        schema_version=LineageNode.SCHEMA_VERSION,
        record_type=LineageNode,
        encode=_encode_lineage_node,
        decode=_decode_lineage_node,
    ),
    SchemaEntry(
        schema_id=JobSubject.SCHEMA_ID,
        schema_version=JobSubject.SCHEMA_VERSION,
        record_type=JobSubject,
        encode=_encode_job_subject,
        decode=_decode_job_subject,
    ),
    SchemaEntry(
        schema_id=LineageEntry.SCHEMA_ID,
        schema_version=LineageEntry.SCHEMA_VERSION,
        record_type=LineageEntry,
        encode=_encode_lineage_entry,
        decode=_decode_lineage_entry,
    ),
    SchemaEntry(
        schema_id=SessionLineage.SCHEMA_ID,
        schema_version=SessionLineage.SCHEMA_VERSION,
        record_type=SessionLineage,
        encode=_encode_session_lineage,
        decode=_decode_session_lineage,
    ),
    SchemaEntry(
        schema_id=JobBoundary.SCHEMA_ID,
        schema_version=JobBoundary.SCHEMA_VERSION,
        record_type=JobBoundary,
        encode=_encode_job_boundary,
        decode=_decode_job_boundary,
    ),
    SchemaEntry(
        schema_id=JobTypeAssignment.SCHEMA_ID,
        schema_version=JobTypeAssignment.SCHEMA_VERSION,
        record_type=JobTypeAssignment,
        encode=_encode_job_type_assignment,
        decode=_decode_job_type_assignment,
    ),
    SchemaEntry(
        schema_id=JobCandidate.SCHEMA_ID,
        schema_version=JobCandidate.SCHEMA_VERSION,
        record_type=JobCandidate,
        encode=_encode_job_candidate,
        decode=_decode_job_candidate,
    ),
    SchemaEntry(
        schema_id=RejectedJobProposal.SCHEMA_ID,
        schema_version=RejectedJobProposal.SCHEMA_VERSION,
        record_type=RejectedJobProposal,
        encode=_encode_rejected_job_proposal,
        decode=_decode_rejected_job_proposal,
    ),
    SchemaEntry(
        schema_id=JobInferenceAbstention.SCHEMA_ID,
        schema_version=JobInferenceAbstention.SCHEMA_VERSION,
        record_type=JobInferenceAbstention,
        encode=_encode_job_inference_abstention,
        decode=_decode_job_inference_abstention,
    ),
    SchemaEntry(
        schema_id=JobInference.SCHEMA_ID,
        schema_version=JobInference.SCHEMA_VERSION,
        record_type=JobInference,
        encode=_encode_job_inference,
        decode=_decode_job_inference,
    ),
    SchemaEntry(
        schema_id=JobInferenceRequest.SCHEMA_ID,
        schema_version=JobInferenceRequest.SCHEMA_VERSION,
        record_type=JobInferenceRequest,
        encode=_encode_job_inference_request,
        decode=_decode_job_inference_request,
    ),
    SchemaEntry(
        schema_id=ActivityIdentity.SCHEMA_ID,
        schema_version=ActivityIdentity.SCHEMA_VERSION,
        record_type=ActivityIdentity,
        encode=_encode_activity_identity,
        decode=_decode_activity_identity,
    ),
    SchemaEntry(
        schema_id=ToolOutcome.SCHEMA_ID,
        schema_version=ToolOutcome.SCHEMA_VERSION,
        record_type=ToolOutcome,
        encode=_encode_tool_outcome,
        decode=_decode_tool_outcome,
    ),
    SchemaEntry(
        schema_id=TaskTransition.SCHEMA_ID,
        schema_version=TaskTransition.SCHEMA_VERSION,
        record_type=TaskTransition,
        encode=_encode_task_transition,
        decode=_decode_task_transition,
    ),
    SchemaEntry(
        schema_id=UsageReport.SCHEMA_ID,
        schema_version=UsageReport.SCHEMA_VERSION,
        record_type=UsageReport,
        encode=_encode_usage_report,
        decode=_decode_usage_report,
    ),
    SchemaEntry(
        schema_id=CompactionInfo.SCHEMA_ID,
        schema_version=CompactionInfo.SCHEMA_VERSION,
        record_type=CompactionInfo,
        encode=_encode_compaction_info,
        decode=_decode_compaction_info,
    ),
    SchemaEntry(
        schema_id=SessionEndInfo.SCHEMA_ID,
        schema_version=SessionEndInfo.SCHEMA_VERSION,
        record_type=SessionEndInfo,
        encode=_encode_session_end_info,
        decode=_decode_session_end_info,
    ),
    SchemaEntry(
        schema_id=DelegationResult.SCHEMA_ID,
        schema_version=DelegationResult.SCHEMA_VERSION,
        record_type=DelegationResult,
        encode=_encode_delegation_result,
        decode=_decode_delegation_result,
    ),
    SchemaEntry(
        schema_id=NoPayload.SCHEMA_ID,
        schema_version=NoPayload.SCHEMA_VERSION,
        record_type=NoPayload,
        encode=_encode_no_payload,
        decode=_decode_no_payload,
    ),
    SchemaEntry(
        schema_id=ActivityEvent.SCHEMA_ID,
        schema_version=ActivityEvent.SCHEMA_VERSION,
        record_type=ActivityEvent,
        encode=_encode_activity_event,
        decode=_decode_activity_event,
    ),
    SchemaEntry(
        schema_id=ActivityLog.SCHEMA_ID,
        schema_version=ActivityLog.SCHEMA_VERSION,
        record_type=ActivityLog,
        encode=_encode_activity_log,
        decode=_decode_activity_log,
    ),
    SchemaEntry(
        schema_id=OperandBounds.SCHEMA_ID,
        schema_version=OperandBounds.SCHEMA_VERSION,
        record_type=OperandBounds,
        encode=_encode_operand_bounds,
        decode=_decode_operand_bounds,
    ),
    SchemaEntry(
        schema_id=OutcomeAssertion.SCHEMA_ID,
        schema_version=OutcomeAssertion.SCHEMA_VERSION,
        record_type=OutcomeAssertion,
        encode=_encode_outcome_assertion,
        decode=_decode_outcome_assertion,
    ),
    SchemaEntry(
        schema_id=ProposedOperand.SCHEMA_ID,
        schema_version=ProposedOperand.SCHEMA_VERSION,
        record_type=ProposedOperand,
        encode=_encode_proposed_operand,
        decode=_decode_proposed_operand,
    ),
    SchemaEntry(
        schema_id=DiscardedField.SCHEMA_ID,
        schema_version=DiscardedField.SCHEMA_VERSION,
        record_type=DiscardedField,
        encode=_encode_discarded_field,
        decode=_decode_discarded_field,
    ),
    SchemaEntry(
        schema_id=OutcomeRequest.SCHEMA_ID,
        schema_version=OutcomeRequest.SCHEMA_VERSION,
        record_type=OutcomeRequest,
        encode=_encode_outcome_request,
        decode=_decode_outcome_request,
    ),
    SchemaEntry(
        schema_id=OutcomeProposal.SCHEMA_ID,
        schema_version=OutcomeProposal.SCHEMA_VERSION,
        record_type=OutcomeProposal,
        encode=_encode_outcome_proposal,
        decode=_decode_outcome_proposal,
    ),
    SchemaEntry(
        schema_id=OutcomeAbstention.SCHEMA_ID,
        schema_version=OutcomeAbstention.SCHEMA_VERSION,
        record_type=OutcomeAbstention,
        encode=_encode_outcome_abstention,
        decode=_decode_outcome_abstention,
    ),
    SchemaEntry(
        schema_id=ResolvedAssumptions.SCHEMA_ID,
        schema_version=ResolvedAssumptions.SCHEMA_VERSION,
        record_type=ResolvedAssumptions,
        encode=_encode_resolved_assumptions,
        decode=_decode_resolved_assumptions,
    ),
    SchemaEntry(
        schema_id=DerivedBand.SCHEMA_ID,
        schema_version=DerivedBand.SCHEMA_VERSION,
        record_type=DerivedBand,
        encode=_encode_derived_band,
        decode=_decode_derived_band,
    ),
    SchemaEntry(
        schema_id=RateCardFigures.SCHEMA_ID,
        schema_version=RateCardFigures.SCHEMA_VERSION,
        record_type=RateCardFigures,
        encode=_encode_rate_card_figures,
        decode=_decode_rate_card_figures,
    ),
    SchemaEntry(
        schema_id=RevenueCardEntry.SCHEMA_ID,
        schema_version=RevenueCardEntry.SCHEMA_VERSION,
        record_type=RevenueCardEntry,
        encode=_encode_revenue_card_entry,
        decode=_decode_revenue_card_entry,
    ),
    SchemaEntry(
        schema_id=RevenueCardFigures.SCHEMA_ID,
        schema_version=RevenueCardFigures.SCHEMA_VERSION,
        record_type=RevenueCardFigures,
        encode=_encode_revenue_card_figures,
        decode=_decode_revenue_card_figures,
    ),
    SchemaEntry(
        schema_id=BaselineFigures.SCHEMA_ID,
        schema_version=BaselineFigures.SCHEMA_VERSION,
        record_type=BaselineFigures,
        encode=_encode_baseline_figures,
        decode=_decode_baseline_figures,
    ),
    SchemaEntry(
        schema_id=ValuationFigures.SCHEMA_ID,
        schema_version=ValuationFigures.SCHEMA_VERSION,
        record_type=ValuationFigures,
        encode=_encode_valuation_figures,
        decode=_decode_valuation_figures,
    ),
    SchemaEntry(
        schema_id=ResolvedEvidence.SCHEMA_ID,
        schema_version=ResolvedEvidence.SCHEMA_VERSION,
        record_type=ResolvedEvidence,
        encode=_encode_resolved_evidence,
        decode=_decode_resolved_evidence,
    ),
    SchemaEntry(
        schema_id=SuppliedCosts.SCHEMA_ID,
        schema_version=SuppliedCosts.SCHEMA_VERSION,
        record_type=SuppliedCosts,
        encode=_encode_supplied_costs,
        decode=_decode_supplied_costs,
    ),
    SchemaEntry(
        schema_id=CostCoverage.SCHEMA_ID,
        schema_version=CostCoverage.SCHEMA_VERSION,
        record_type=CostCoverage,
        encode=_encode_cost_coverage,
        decode=_decode_cost_coverage,
    ),
    SchemaEntry(
        schema_id=RoiOperands.SCHEMA_ID,
        schema_version=RoiOperands.SCHEMA_VERSION,
        record_type=RoiOperands,
        encode=_encode_roi_operands,
        decode=_decode_roi_operands,
    ),
    SchemaEntry(
        schema_id=InferenceLocality.SCHEMA_ID,
        schema_version=InferenceLocality.SCHEMA_VERSION,
        record_type=InferenceLocality,
        encode=_encode_inference_locality,
        decode=_decode_inference_locality,
    ),
    SchemaEntry(
        schema_id=AssessJobRequest.SCHEMA_ID,
        schema_version=AssessJobRequest.SCHEMA_VERSION,
        record_type=AssessJobRequest,
        encode=_encode_assess_job_request,
        decode=_decode_assess_job_request,
    ),
    SchemaEntry(
        schema_id=JobAssessment.SCHEMA_ID,
        schema_version=JobAssessment.SCHEMA_VERSION,
        record_type=JobAssessment,
        encode=_encode_job_assessment,
        decode=_decode_job_assessment,
    ),
    SchemaEntry(
        schema_id=AssessmentAbstention.SCHEMA_ID,
        schema_version=AssessmentAbstention.SCHEMA_VERSION,
        record_type=AssessmentAbstention,
        encode=_encode_assessment_abstention,
        decode=_decode_assessment_abstention,
    ),
    SchemaEntry(
        schema_id=RecordRef.SCHEMA_ID,
        schema_version=RecordRef.SCHEMA_VERSION,
        record_type=RecordRef,
        encode=_encode_record_ref,
        decode=_decode_record_ref,
    ),
    SchemaEntry(
        schema_id=CorrectionFields.SCHEMA_ID,
        schema_version=CorrectionFields.SCHEMA_VERSION,
        record_type=CorrectionFields,
        encode=_encode_correction_fields,
        decode=_decode_correction_fields,
    ),
    SchemaEntry(
        schema_id=Correction.SCHEMA_ID,
        schema_version=Correction.SCHEMA_VERSION,
        record_type=Correction,
        encode=_encode_correction,
        decode=_decode_correction,
    ),
    SchemaEntry(
        schema_id=CorrectionRejection.SCHEMA_ID,
        schema_version=CorrectionRejection.SCHEMA_VERSION,
        record_type=CorrectionRejection,
        encode=_encode_correction_rejection,
        decode=_decode_correction_rejection,
    ),
    SchemaEntry(
        schema_id=EffectiveAssessment.SCHEMA_ID,
        schema_version=EffectiveAssessment.SCHEMA_VERSION,
        record_type=EffectiveAssessment,
        encode=_encode_effective_assessment,
        decode=_decode_effective_assessment,
    ),
    SchemaEntry(
        schema_id=MetricDeclaration.SCHEMA_ID,
        schema_version=MetricDeclaration.SCHEMA_VERSION,
        record_type=MetricDeclaration,
        encode=_encode_metric_declaration,
        decode=_decode_metric_declaration,
    ),
    SchemaEntry(
        schema_id=EconomicsContract.SCHEMA_ID,
        schema_version=EconomicsContract.SCHEMA_VERSION,
        record_type=EconomicsContract,
        encode=_encode_economics_contract,
        decode=_decode_economics_contract,
    ),
    SchemaEntry(
        schema_id=OutcomeMetricIntent.SCHEMA_ID,
        schema_version=OutcomeMetricIntent.SCHEMA_VERSION,
        record_type=OutcomeMetricIntent,
        encode=_encode_outcome_metric_intent,
        decode=_decode_outcome_metric_intent,
    ),
    SchemaEntry(
        schema_id=OutcomeMetricIntents.SCHEMA_ID,
        schema_version=OutcomeMetricIntents.SCHEMA_VERSION,
        record_type=OutcomeMetricIntents,
        encode=_encode_outcome_metric_intents,
        decode=_decode_outcome_metric_intents,
    ),
    SchemaEntry(
        schema_id=SharedOutcomeFlag.SCHEMA_ID,
        schema_version=SharedOutcomeFlag.SCHEMA_VERSION,
        record_type=SharedOutcomeFlag,
        encode=_encode_shared_outcome_flag,
        decode=_decode_shared_outcome_flag,
    ),
    SchemaEntry(
        schema_id=MetricRefusal.SCHEMA_ID,
        schema_version=MetricRefusal.SCHEMA_VERSION,
        record_type=MetricRefusal,
        encode=_encode_metric_refusal,
        decode=_decode_metric_refusal,
    ),
    SchemaEntry(
        schema_id=AllocationShare.SCHEMA_ID,
        schema_version=AllocationShare.SCHEMA_VERSION,
        record_type=AllocationShare,
        encode=_encode_allocation_share,
        decode=_decode_allocation_share,
    ),
    SchemaEntry(
        schema_id=GroupAllocation.SCHEMA_ID,
        schema_version=GroupAllocation.SCHEMA_VERSION,
        record_type=GroupAllocation,
        encode=_encode_group_allocation,
        decode=_decode_group_allocation,
    ),
    SchemaEntry(
        schema_id=ScenarioExpectation.SCHEMA_ID,
        schema_version=ScenarioExpectation.SCHEMA_VERSION,
        record_type=ScenarioExpectation,
        encode=_encode_scenario_expectation,
        decode=_decode_scenario_expectation,
    ),
    SchemaEntry(
        schema_id=Scenario.SCHEMA_ID,
        schema_version=Scenario.SCHEMA_VERSION,
        record_type=Scenario,
        encode=_encode_scenario,
        decode=_decode_scenario,
    ),
    SchemaEntry(
        schema_id=ExpectationVerdict.SCHEMA_ID,
        schema_version=ExpectationVerdict.SCHEMA_VERSION,
        record_type=ExpectationVerdict,
        encode=_encode_expectation_verdict,
        decode=_decode_expectation_verdict,
    ),
    SchemaEntry(
        schema_id=ScenarioResult.SCHEMA_ID,
        schema_version=ScenarioResult.SCHEMA_VERSION,
        record_type=ScenarioResult,
        encode=_encode_scenario_result,
        decode=_decode_scenario_result,
    ),
    SchemaEntry(
        schema_id=RoleVocabularyEntry.SCHEMA_ID,
        schema_version=RoleVocabularyEntry.SCHEMA_VERSION,
        record_type=RoleVocabularyEntry,
        encode=_encode_role_vocabulary_entry,
        decode=_decode_role_vocabulary_entry,
    ),
    SchemaEntry(
        schema_id=RoleVocabulary.SCHEMA_ID,
        schema_version=RoleVocabulary.SCHEMA_VERSION,
        record_type=RoleVocabulary,
        encode=_encode_role_vocabulary,
        decode=_decode_role_vocabulary,
    ),
)
MIGRATIONS: Final[tuple[Migration, ...]] = ()


def to_json_value(record: Record) -> dict[str, JsonValue]:
    """Convert a record to JSON-native values, including its schema keys.

    Args:
        record: An instance of a record type listed in ``SCHEMA_IDS``.

    Returns:
        A dict of the record's fields plus ``schema_id`` and ``schema_version``.
        Money is a string, enum members are their values, nested records are
        objects with their own schema keys, and ``None`` optionals are absent.

    Raises:
        CanonicalizationError: If ``record``'s exact type has no schema entry.
    """
    entry = _entry_for_type(type(record))
    encoded = entry.encode(record)
    encoded["schema_id"] = entry.schema_id
    encoded["schema_version"] = entry.schema_version
    return encoded


def encode_record(record: Record) -> bytes:
    """Encode a record as canonical JSON bytes.

    Args:
        record: An instance of a record type listed in ``SCHEMA_IDS``.

    Returns:
        ``canonical_json(to_json_value(record))``.
    """
    return canonical_json(to_json_value(record))


def decode_record(
    data: bytes,
    *,
    schemas: tuple[SchemaEntry, ...] = SCHEMA_IDS,
    migrations: tuple[Migration, ...] = MIGRATIONS,
) -> Record:
    """Decode canonical bytes into a record, validating every field.

    Args:
        data: Bytes produced by :func:`encode_record`.
        schemas: The decodable schemas.
        migrations: The allowed upgrades, applied in chain order.

    Returns:
        The decoded record, constructed so its own validation runs.

    Raises:
        CanonicalizationError: If ``data`` is not canonical JSON.
        RecordValidationError: If the value is not an object with a string
            ``schema_id`` and integer ``schema_version``, or any field is
            unknown, missing, an explicit null, or invalid.
        UnsupportedSchemaError: If no schema entry matches and no migration
            chain reaches one.
    """
    return _decode_value(parse_json_strict(data), schemas, migrations)


def _decode_value(
    value: JsonValue,
    schemas: tuple[SchemaEntry, ...],
    migrations: tuple[Migration, ...],
) -> Record:
    if type(value) is not dict:
        raise RecordValidationError(
            _UNKNOWN_SCHEMA, "$", f"JSON object required, got {_json_type(value)}"
        )
    schema_id = value.get("schema_id")
    if type(schema_id) is not str:
        raise RecordValidationError(
            _UNKNOWN_SCHEMA,
            "schema_id",
            f"JSON string required, got {_json_type(schema_id)}",
        )
    schema_version = value.get("schema_version")
    if type(schema_version) is not int:
        raise RecordValidationError(
            schema_id,
            "schema_version",
            f"JSON integer required, got {_json_type(schema_version)}",
        )
    fields = {key: item for key, item in value.items() if key not in _SCHEMA_KEYS}
    entry, fields = _resolve(schema_id, schema_version, fields, schemas, migrations)

    def nested(item: JsonValue) -> Record:
        return _decode_value(item, schemas, migrations)

    return entry.decode(fields, nested)


def _resolve(
    schema_id: str,
    schema_version: int,
    fields: dict[str, JsonValue],
    schemas: tuple[SchemaEntry, ...],
    migrations: tuple[Migration, ...],
) -> tuple[SchemaEntry, dict[str, JsonValue]]:
    known = {
        entry.schema_version: entry for entry in schemas if entry.schema_id == schema_id
    }
    current = schema_version
    visited = {current}
    while current not in known:
        steps = [
            step
            for step in migrations
            if step.schema_id == schema_id and step.from_version == current
        ]
        if len(steps) != 1 or steps[0].to_version in visited:
            raise UnsupportedSchemaError(schema_id, schema_version)
        upgraded = steps[0].upgrade(fields)
        if type(upgraded) is not dict:
            raise RecordValidationError(schema_id, "$", "migration must return a dict")
        fields = upgraded
        current = steps[0].to_version
        visited.add(current)
    return known[current], fields


def _entry_for_type(record_type: type) -> SchemaEntry:
    for entry in SCHEMA_IDS:
        if entry.record_type is record_type:
            return entry
    raise CanonicalizationError(f"{record_type.__name__} has no schema entry")
