"""An optional bridge from engine diagnostics to stdlib logging (D-26, ADR 0012).

The core never imports :mod:`logging`. A host that wants diagnostics in its
stdlib logging pipeline imports this module and passes a
:class:`LoggingDiagnosticSink` as ``EngineDependencies.diagnostics``. The
package root does not import this module.

Every field value arrives already ``repr()``-escaped and printable from
:class:`~revenium_agent_economics.diagnostics.Diagnostic`. This adapter passes
those values as log arguments, never as the format string, so an untrusted
label can neither forge a second log line nor inject a format directive.
"""

import logging
from collections.abc import Mapping
from types import MappingProxyType
from typing import Final

from revenium_agent_economics.diagnostics import Diagnostic, DiagnosticLevel

__all__ = ["LOGGER_NAME", "LoggingDiagnosticSink"]

LOGGER_NAME: Final = "revenium_agent_economics"
"""The logger :class:`LoggingDiagnosticSink` uses when none is injected."""

_MESSAGE: Final = "%s %s"

_LEVELS: Final[Mapping[DiagnosticLevel, int]] = MappingProxyType(
    {
        DiagnosticLevel.INFO: logging.INFO,
        DiagnosticLevel.WARNING: logging.WARNING,
        DiagnosticLevel.ERROR: logging.ERROR,
    }
)


def _attach_null_handler() -> None:
    """Give the library logger one ``NullHandler``, and only once.

    A reload or a second call finds the existing handler and adds nothing. The
    check matches the exact type, so a host handler that subclasses
    ``NullHandler`` does not count. The root logger, the level, and
    ``propagate`` are left alone, and ``logging.basicConfig`` is never called.
    """
    logger = logging.getLogger(LOGGER_NAME)
    if not any(type(handler) is logging.NullHandler for handler in logger.handlers):
        logger.addHandler(logging.NullHandler())


_attach_null_handler()


def _render_fields(diagnostic: Diagnostic) -> str:
    """Render the fields as space-separated ``key=value`` pairs.

    The values are already escaped by :class:`Diagnostic`, so they are not
    escaped again.

    Args:
        diagnostic: The diagnostic to render.

    Returns:
        The rendered fields, or an empty string when there are none.
    """
    return " ".join(f"{key}={value}" for key, value in diagnostic.fields)


class LoggingDiagnosticSink:
    """A diagnostic sink that writes each diagnostic as one stdlib log record.

    The record's message template is always ``"%s %s"``. Its arguments are the
    diagnostic code value and the rendered ``key=value`` fields. The record
    also carries two structured attributes, ``rae_diagnostic_code`` and
    ``rae_diagnostic_fields``, for formatters that read ``extra`` values.
    """

    __slots__ = ("_logger",)

    def __init__(self, logger: logging.Logger | None = None) -> None:
        """Bind the sink to a logger.

        Args:
            logger: The host logger. When omitted, the sink uses the
                ``revenium_agent_economics`` logger.
        """
        self._logger: logging.Logger = (
            logging.getLogger(LOGGER_NAME) if logger is None else logger
        )

    @property
    def logger(self) -> logging.Logger:
        """The logger this sink writes to."""
        return self._logger

    def emit(self, diagnostic: Diagnostic) -> None:
        """Write ``diagnostic`` as one log record.

        Nothing is rendered when the logger is not enabled for the level.

        Args:
            diagnostic: The diagnostic to write.
        """
        level = _LEVELS[diagnostic.level]
        if not self._logger.isEnabledFor(level):
            return
        self._logger.log(
            level,
            _MESSAGE,
            diagnostic.code.value,
            _render_fields(diagnostic),
            extra={
                "rae_diagnostic_code": diagnostic.code.value,
                "rae_diagnostic_fields": dict(diagnostic.fields),
            },
        )
