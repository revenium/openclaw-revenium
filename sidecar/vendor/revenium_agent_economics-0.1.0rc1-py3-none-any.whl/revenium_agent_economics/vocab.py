"""Closed vocabularies and partitions matching the pinned Hermes reference.

Every module constant is immutable: tuples where Hermes order matters,
frozensets for Hermes sets, and read-only mappings.
"""

import enum
from collections.abc import Mapping
from types import MappingProxyType
from typing import Final

LABEL_PATTERN: Final = r"^[a-z][a-z0-9_]{1,47}$"
TRIVIAL_LABELS: Final[frozenset[str]] = frozenset(
    {"ack", "acknowledgment", "greeting", "confirmation", "hello", "thanks"}
)
UNCLASSIFIED_LABEL: Final = "unclassified"


class EvidenceClass(enum.Enum):
    """How strongly a claim is evidenced.

    A plain ``Enum`` rather than ``StrEnum`` so members cannot be ordered:
    evidence classes are categories, never a ranking.
    """

    ACTIVITY_MEASURED = "ACTIVITY_MEASURED"
    OUTPUT_OBSERVED = "OUTPUT_OBSERVED"
    OUTCOME_OBSERVED = "OUTCOME_OBSERVED"
    MODEL_ESTIMATED = "MODEL_ESTIMATED"
    CUSTOMER_CONFIGURED = "CUSTOMER_CONFIGURED"
    CUSTOMER_CONFIRMED = "CUSTOMER_CONFIRMED"
    ASSOCIATIONAL = "ASSOCIATIONAL"
    QUASI_EXPERIMENTAL_IMPACT = "QUASI_EXPERIMENTAL_IMPACT"
    EXPERIMENTAL_IMPACT = "EXPERIMENTAL_IMPACT"


STUDY_EVIDENCE_CLASSES: Final[frozenset[EvidenceClass]] = frozenset(
    {
        EvidenceClass.ASSOCIATIONAL,
        EvidenceClass.QUASI_EXPERIMENTAL_IMPACT,
        EvidenceClass.EXPERIMENTAL_IMPACT,
    }
)
DECLARABLE_EVIDENCE_CLASSES: Final[frozenset[EvidenceClass]] = (
    frozenset(EvidenceClass) - STUDY_EVIDENCE_CLASSES
)
EVIDENCE_CLASS_MODEL_ESTIMATED: Final = EvidenceClass.MODEL_ESTIMATED
REPORTABLE_EVIDENCE_CLASSES: Final[frozenset[EvidenceClass]] = (
    DECLARABLE_EVIDENCE_CLASSES - {EVIDENCE_CLASS_MODEL_ESTIMATED}
)
EVIDENCE_CLASS_AUTHORITIES: Final[tuple[str, ...]] = (
    "evidence",
    "valuation",
    "classification",
    "evaluator",
)


class EconomicMechanism(enum.StrEnum):
    """How agent work creates economic value."""

    LABOR_SUBSTITUTION = "labor_substitution"
    AUGMENTATION_CAPACITY_EXPANSION = "augmentation_capacity_expansion"
    NEWLY_ENABLED_WORK = "newly_enabled_work"
    QUALITY_DECISION_IMPROVEMENT = "quality_decision_improvement"
    RISK_AVOIDANCE = "risk_avoidance"
    INCREMENTAL_REVENUE = "incremental_revenue"


EVALUATOR_MECHANISMS: Final[frozenset[EconomicMechanism]] = frozenset(
    {
        EconomicMechanism.LABOR_SUBSTITUTION,
        EconomicMechanism.AUGMENTATION_CAPACITY_EXPANSION,
        EconomicMechanism.NEWLY_ENABLED_WORK,
    }
)
OPERATOR_ONLY_MECHANISMS: Final[frozenset[EconomicMechanism]] = (
    frozenset(EconomicMechanism) - EVALUATOR_MECHANISMS
)
ECONOMIC_MECHANISM_UNKNOWN: Final = "unknown"


class CostCategory(enum.StrEnum):
    """Categories of human-side cost a caller may supply."""

    HUMAN_REVIEW = "human_review"
    REWORK_OR_ERROR = "rework_or_error"
    HANDOFF = "handoff"
    TRAINING_OR_CHANGE = "training_or_change"


COST_CATEGORIES: Final[tuple[CostCategory, ...]] = (
    CostCategory.HUMAN_REVIEW,
    CostCategory.REWORK_OR_ERROR,
    CostCategory.HANDOFF,
    CostCategory.TRAINING_OR_CHANGE,
)
COST_COVERAGE_EXCLUDED_AI: Final = "metered_ai_cost"


class Currency(enum.StrEnum):
    """Supported ISO 4217 currency codes."""

    USD = "USD"
    EUR = "EUR"
    GBP = "GBP"
    CAD = "CAD"
    AUD = "AUD"
    JPY = "JPY"
    CHF = "CHF"


class AbstentionReason(enum.StrEnum):
    """Why a component declined to produce a decision."""

    UNKNOWN_EVALUATOR = "unknown_evaluator"
    INVALID = "invalid"
    TIMED_OUT = "timed_out"
    ABSTAINED = "abstained"
    MECHANISM_ABSTAINS_FROM_VALUE = "mechanism_abstains_from_value"
    REJECTED = "rejected"
    FAILED = "failed"
    NOT_EVALUATED_NON_SUCCESS = "not_evaluated_non_success"


class MetricType(enum.StrEnum):
    """Types an outcome metric value can take."""

    MONEY = "MONEY"
    DURATION = "DURATION"
    SCORE = "SCORE"
    COUNT = "COUNT"
    PERCENT = "PERCENT"


UNIT_INTERVAL_METRIC_TYPES: Final[frozenset[MetricType]] = frozenset(
    {MetricType.SCORE, MetricType.PERCENT}
)
UNIT_METRIC_TYPE: Final = MetricType.COUNT
REQUIRED_METRIC_TYPES: Final[Mapping[str, MetricType]] = MappingProxyType(
    {
        "estimated_value": MetricType.MONEY,
        "hours_saved": MetricType.DURATION,
        "assessment_confidence": MetricType.SCORE,
    }
)


class ClaimBasis(enum.Enum):
    """Where one number in an assessment came from (ADR 0024).

    A plain ``Enum`` with no ordering, and never compared with
    :class:`EvidenceClass` (OUT-06): evidence class says who vouches for a
    claim, claim basis says where its number came from. The strength order
    lives only in :data:`CLAIM_BASIS_STRENGTH`.
    """

    ESTIMATED = "estimated"
    CONFIGURED = "configured"
    OBSERVED = "observed"
    CUSTOMER_CONFIRMED = "customer_confirmed"
    CORRECTED = "corrected"
    UNVERIFIED = "unverified"


# ADR 0024 decision 2: weakest first.
CLAIM_BASIS_STRENGTH: Final[tuple[ClaimBasis, ...]] = (
    ClaimBasis.UNVERIFIED,
    ClaimBasis.ESTIMATED,
    ClaimBasis.CONFIGURED,
    ClaimBasis.CORRECTED,
    ClaimBasis.CUSTOMER_CONFIRMED,
    ClaimBasis.OBSERVED,
)


class ReportabilityStatus(enum.Enum):
    """Whether an assessment's value may be reported (ADR 0025 decision 4)."""

    UNCOMPUTED = "uncomputed"
    COMPUTED_NOT_REPORTABLE = "computed_not_reportable"
    REPORTABLE = "reportable"


class ReportabilityReason(enum.Enum):
    """Which reportability rule decided the status (ADR 0025 decision 4)."""

    ABSTAINED = "abstained"
    EVIDENCE_CLASS_NOT_REPORTABLE = "evidence_class_not_reportable"
    DECIDER_REPORTABLE = "decider_reportable"
    DECIDER_CANDIDATE = "decider_candidate"
    DECIDER_FAILED = "decider_failed"
    DECIDER_FALLBACK_OPT_IN = "decider_fallback_opt_in"
    DECIDER_FALLBACK_NOT_OPTED_IN = "decider_fallback_not_opted_in"
    CONFIG_OPT_IN = "config_opt_in"
    NOT_OPTED_IN = "not_opted_in"


class EvidenceAuthority(enum.Enum):
    """Which walk leg set an evidence class (ADR 0025 decision 2).

    ``EVIDENCE_CLASS_AUTHORITIES`` keeps Hermes' ``"classification"`` for the
    partitions golden only; the library walk never emits it (ID-11).
    """

    EVIDENCE = "evidence"
    VALUATION = "valuation"
    EVALUATOR = "evaluator"


class AssessmentRefusal(enum.Enum):
    """Why an assessment was refused, in Hermes check order (ADR 0028 decision 1).

    Codes 1 to 8 are the operand gates of Hermes ``_validate_assessment``
    (classifier.py:L2042-L2133). Codes 9 to 15 are the valuation checks; 10 to
    15 all project to Hermes' single gate-10 template (L2372-L2381).
    """

    NOT_AN_OBJECT = "not_an_object"
    MECHANISM_NOT_ALLOWED = "mechanism_not_allowed"
    OPERAND_NOT_NUMERIC = "operand_not_numeric"
    OPERAND_OUT_OF_BOUNDS = "operand_out_of_bounds"
    CONFIDENCE_INVALID = "confidence_invalid"
    VALUE_BAND_INVALID = "value_band_invalid"
    CURRENCY_NOT_TEXT = "currency_not_text"
    CURRENCY_MISMATCH = "currency_mismatch"
    REVENUE_ATTRIBUTION_UNCERTAIN = "revenue_attribution_uncertain"
    VALUATION_DECLINED = "valuation_declined"
    VALUATION_AMOUNT_INVALID = "valuation_amount_invalid"
    VALUATION_CURRENCY_MISMATCH = "valuation_currency_mismatch"
    VALUATION_BELOW_LOWER_BOUND = "valuation_below_lower_bound"
    VALUATION_ABOVE_CEILING = "valuation_above_ceiling"
    VALUATION_POLICY_FAILED = "valuation_policy_failed"


# Hermes classifier.py:L1937-L1938. The library only ever writes "derived";
# "evaluator" exists so the compat projection can name Hermes' other value
# (ADR 0027 decision 3, ledger ID-04).
BOUNDS_SOURCE_DERIVED: Final = "derived"
BOUNDS_SOURCE_EVALUATOR: Final = "evaluator"
