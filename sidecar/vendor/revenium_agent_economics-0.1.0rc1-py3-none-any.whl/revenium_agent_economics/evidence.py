"""The evidence-class walk and the reportability rules (ADR 0025).

Both come only from trusted code (OUT-04, VAL-08). The walk takes
engine-checked declarations and library constants, never a proposal, so an
evaluator's answer can never change an evidence class. Reportability rules
1, 2, and 4 are pure here, and so is reading the decider's result for rule
3. Calling the host's decider is the engine's job, and only after rules 1
and 2 have passed. A model estimate passes rule 2 only when the caller's
policy admits model estimates with both opt-in flags (ADR 0039).
"""

import enum
from dataclasses import dataclass
from types import MappingProxyType
from typing import ClassVar, Final

from revenium_agent_economics._canonical import JsonValue
from revenium_agent_economics.errors import ConfigurationError
from revenium_agent_economics.primitives import StudyReference, _require_exact_type
from revenium_agent_economics.protocols import ComponentDeclaration
from revenium_agent_economics.vocab import (
    DECLARABLE_EVIDENCE_CLASSES,
    REPORTABLE_EVIDENCE_CLASSES,
    EvidenceAuthority,
    EvidenceClass,
    ReportabilityReason,
    ReportabilityStatus,
)

# Hermes REPORTABILITY_REPORTABLE and REPORTABILITY_CANDIDATE: the only two
# literals a decider's result may carry (classifier.py:L3069-L3072).
_DECIDER_STATUSES: Final[
    MappingProxyType[str, tuple[ReportabilityStatus, ReportabilityReason]]
] = MappingProxyType(
    {
        "reportable": (
            ReportabilityStatus.REPORTABLE,
            ReportabilityReason.DECIDER_REPORTABLE,
        ),
        "candidate": (
            ReportabilityStatus.COMPUTED_NOT_REPORTABLE,
            ReportabilityReason.DECIDER_CANDIDATE,
        ),
    }
)


class DeciderFailureMode(enum.Enum):
    """What a failed reportability decider produces (ADR 0025 decision 4, D-10).

    A decider fails when it raises, returns ``None``, returns a non-object,
    or returns any status other than ``"reportable"`` or ``"candidate"``.
    FAIL_CLOSED, the default, gives COMPUTED_NOT_REPORTABLE with reason
    DECIDER_FAILED, whatever the opt-in says (ledger ID-30).
    HERMES_CONFIG_FALLBACK reproduces Hermes' fallback to the inline config
    rule (classifier.py:L3079-L3089), so the opt-in decides.
    """

    FAIL_CLOSED = "fail_closed"
    HERMES_CONFIG_FALLBACK = "hermes_config_fallback"


def resolve_evidence_class(
    *,
    evidence: ComponentDeclaration | None,
    valuation: ComponentDeclaration | None,
    evaluator: ComponentDeclaration | None,
) -> tuple[EvidenceClass, EvidenceAuthority]:
    """Walk the legs in precedence order and return the winning class.

    A port of Hermes ``_evidence_class_precedence`` (classifier.py:L1620-L1745)
    without the classification leg (ledger ID-11). A leg votes when it is
    not ``None`` and its class is not MODEL_ESTIMATED. The first vote
    wins when its class is declarable. A refused winner stops the walk and is
    never retried at a lower priority.

    Args:
        evidence: The stored evidence decider's declaration, or ``None``.
        valuation: The producing valuation's declaration, or ``None`` for a
            non-voting method such as HoursTimesRate.
        evaluator: The stored outcome evaluator's declaration, or ``None``.

    Returns:
        The class and the leg that set it, or
        ``(MODEL_ESTIMATED, EVALUATOR)`` when no leg votes or the winner
        is refused.
    """
    for declaration, authority in (
        (evidence, EvidenceAuthority.EVIDENCE),
        (valuation, EvidenceAuthority.VALUATION),
        (evaluator, EvidenceAuthority.EVALUATOR),
    ):
        if declaration is None:
            continue
        evidence_class = declaration.evidence_class
        if evidence_class is EvidenceClass.MODEL_ESTIMATED:
            continue
        if evidence_class in DECLARABLE_EVIDENCE_CLASSES:
            return evidence_class, authority
        break
    return EvidenceClass.MODEL_ESTIMATED, EvidenceAuthority.EVALUATOR


@dataclass(frozen=True, slots=True, kw_only=True)
class ReportabilityPolicy:
    """The caller's reportability configuration (ADR 0025 decision 4).

    Configuration, not a schema record.

    Attributes:
        experimental_report_estimates: Rule 4's opt-in, an exact ``bool``
            matching Hermes' ``is True`` test (classifier.py:L3084-L3088). It
            never widens ``REPORTABLE_EVIDENCE_CLASSES``.
        report_model_estimates: The model-estimate opt-in (ADR 0039), an
            exact ``bool``. It takes effect only together with
            ``experimental_report_estimates``; see
            :attr:`admits_model_estimates`. Set alone, it has no effect.
        on_decider_failure: What a failed decider produces. The default,
            FAIL_CLOSED, never lets the opt-in rescue a broken confirmation
            workflow (D-10).
    """

    experimental_report_estimates: bool = False
    report_model_estimates: bool = False
    on_decider_failure: DeciderFailureMode = DeciderFailureMode.FAIL_CLOSED

    def __post_init__(self) -> None:
        """Validate both opt-ins and the failure mode.

        Raises:
            ConfigurationError: If ``experimental_report_estimates`` or
                ``report_model_estimates`` is not exactly a ``bool``, or
                ``on_decider_failure`` is not a ``DeciderFailureMode``.
        """
        if type(self.experimental_report_estimates) is not bool:
            raise ConfigurationError(
                "experimental_report_estimates must be a bool, got "
                f"{self.experimental_report_estimates!r}"
            )
        if type(self.report_model_estimates) is not bool:
            raise ConfigurationError(
                "report_model_estimates must be a bool, got "
                f"{self.report_model_estimates!r}"
            )
        if type(self.on_decider_failure) is not DeciderFailureMode:
            raise ConfigurationError(
                "on_decider_failure must be a DeciderFailureMode, got "
                f"{self.on_decider_failure!r}"
            )

    @property
    def admits_model_estimates(self) -> bool:
        """Whether a MODEL_ESTIMATED value may pass rule 2 (ADR 0039).

        True only when ``report_model_estimates`` and
        ``experimental_report_estimates`` are both True, as Hermes
        ``_model_estimates_opted_in`` requires both keys to be the literal
        JSON true (classifier.py L3219-L3239 at 532eeb3f). The metric
        builders read it again at metric time, so a stored reportable
        estimate is withheld once the caller turns the switch off.
        """
        return self.report_model_estimates and self.experimental_report_estimates


@dataclass(frozen=True, slots=True, kw_only=True)
class ResolvedEvidence:
    """The evidence a host resolved for one job before ``assess_job`` (D-01).

    ADR 0025 decision 4. The host fetches evidence (for example through
    ``host_protocols.EvidenceSource``) and hands the result in as plain
    data, so the decider decides without doing I/O.

    Attributes:
        confirmed: Whether a customer confirmed the job: ``True``, ``False``,
            or ``None`` when the host resolved nothing. It reaches the
            decider as ``ReportabilityQuery.confirmed``; it never sets an
            evidence class or a reportability status on its own.
        study: The study the host says the job relates to, built with
            ``studies.study_reference``, or ``None``. It is copied onto the
            assessment record, valued or abstained, and never changes the
            evidence class (ADR 0026 decision 2).
    """

    SCHEMA_ID: ClassVar[str] = "rae.resolved_evidence"
    SCHEMA_VERSION: ClassVar[int] = 1

    confirmed: bool | None = None
    study: StudyReference | None = None

    def __post_init__(self) -> None:
        """Validate ``confirmed`` as a ``bool`` or ``None`` and ``study``'s type.

        Raises:
            RecordValidationError: If either field has another type.
        """
        schema_id = ResolvedEvidence.SCHEMA_ID
        if self.confirmed is not None:
            _require_exact_type(self.confirmed, bool, schema_id, "confirmed")
        if self.study is not None:
            _require_exact_type(self.study, StudyReference, schema_id, "study")


def reportability_before_decider(
    *,
    abstained: bool,
    evidence_class: EvidenceClass,
    policy: ReportabilityPolicy,
) -> tuple[ReportabilityStatus, ReportabilityReason] | None:
    """Apply reportability rules 1 and 2, which run before any decider.

    Hermes runs both unconditionally, before any registrant is consulted
    (classifier.py:L3030-L3053). A decider may decide that a real estimate
    is reportable; it can never decide that an absent one is. Rule 2 has
    one exception (ADR 0039, Hermes classifier.py L3320-L3323 at 532eeb3f):
    a MODEL_ESTIMATED record passes when
    ``policy.admits_model_estimates``, and rule 3 or rule 4 then decides it
    exactly as it decides a reportable class. Study classes never pass.

    Args:
        abstained: Whether the record is an abstention.
        evidence_class: The class from :func:`resolve_evidence_class`.
        policy: The caller's reportability policy.

    Returns:
        The status and reason when rule 1 or rule 2 decides, else ``None``,
        meaning rule 3 (a decider) or rule 4 (the opt-in) decides.
    """
    if abstained:
        return ReportabilityStatus.UNCOMPUTED, ReportabilityReason.ABSTAINED
    if evidence_class not in REPORTABLE_EVIDENCE_CLASSES and not (
        evidence_class is EvidenceClass.MODEL_ESTIMATED
        and policy.admits_model_estimates
    ):
        return (
            ReportabilityStatus.COMPUTED_NOT_REPORTABLE,
            ReportabilityReason.EVIDENCE_CLASS_NOT_REPORTABLE,
        )
    return None


def reportability_without_decider(
    *,
    abstained: bool,
    evidence_class: EvidenceClass,
    policy: ReportabilityPolicy,
) -> tuple[ReportabilityStatus, ReportabilityReason]:
    """Apply reportability rules 1, 2, and 4, in Hermes order.

    Hermes ``_resolve_reportability_status`` (classifier.py:L2973-L3089).
    Rule 1 runs first, so an abstention is never reportable. Rule 2 runs
    before rule 4's opt-in, so a class outside
    ``REPORTABLE_EVIDENCE_CLASSES`` is never reportable, except a
    MODEL_ESTIMATED record under a policy that admits model estimates
    (ADR 0039), which rule 4 then decides.

    Args:
        abstained: Whether the record is an abstention.
        evidence_class: The class from :func:`resolve_evidence_class`.
        policy: The caller's reportability policy.

    Returns:
        The status and the rule that decided it.
    """
    decided = reportability_before_decider(
        abstained=abstained, evidence_class=evidence_class, policy=policy
    )
    if decided is not None:
        return decided
    if policy.experimental_report_estimates is True:
        return ReportabilityStatus.REPORTABLE, ReportabilityReason.CONFIG_OPT_IN
    return (
        ReportabilityStatus.COMPUTED_NOT_REPORTABLE,
        ReportabilityReason.NOT_OPTED_IN,
    )


def decider_failure_reportability(
    *, policy: ReportabilityPolicy
) -> tuple[ReportabilityStatus, ReportabilityReason]:
    """Return what a failed decider produces under ``policy``.

    ADR 0025 decision 4, rule 3. Under FAIL_CLOSED the result is
    COMPUTED_NOT_REPORTABLE (DECIDER_FAILED), even with the opt-in set
    (ledger ID-30). Under HERMES_CONFIG_FALLBACK, rule 4 decides, as
    Hermes' inline fallback does (classifier.py:L3079-L3089).

    Args:
        policy: The caller's reportability policy.

    Returns:
        The status and the rule that decided it.
    """
    if policy.on_decider_failure is DeciderFailureMode.HERMES_CONFIG_FALLBACK:
        if policy.experimental_report_estimates is True:
            return (
                ReportabilityStatus.REPORTABLE,
                ReportabilityReason.DECIDER_FALLBACK_OPT_IN,
            )
        return (
            ReportabilityStatus.COMPUTED_NOT_REPORTABLE,
            ReportabilityReason.DECIDER_FALLBACK_NOT_OPTED_IN,
        )
    return (
        ReportabilityStatus.COMPUTED_NOT_REPORTABLE,
        ReportabilityReason.DECIDER_FAILED,
    )


def interpret_decider_result(
    value: JsonValue | None, *, policy: ReportabilityPolicy
) -> tuple[ReportabilityStatus, ReportabilityReason, str | None]:
    """Read a decider's untrusted result for reportability rule 3.

    Hermes accepts a result only when it is a dict whose
    ``reportability_status`` is one of its two literals
    (classifier.py:L3069-L3072). The library reads the same shape with exact
    types: an object (``dict``) whose ``reportability_status`` is exactly the
    ``str`` ``"reportable"`` or ``"candidate"``. Anything else is a failed
    decider, decided by :func:`decider_failure_reportability`.

    Args:
        value: What the decider returned.
        policy: The caller's reportability policy.

    Returns:
        The status, the rule that decided it, and, for a failed decider, the
        result's type name for the ``evidence.decider_failed`` diagnostic.
        The result itself is never returned for logging.
    """
    if type(value) is dict:
        status = value.get("reportability_status")
        if type(status) is str and status in _DECIDER_STATUSES:
            decided, reason = _DECIDER_STATUSES[status]
            return decided, reason, None
    failed, reason = decider_failure_reportability(policy=policy)
    return failed, reason, type(value).__qualname__
