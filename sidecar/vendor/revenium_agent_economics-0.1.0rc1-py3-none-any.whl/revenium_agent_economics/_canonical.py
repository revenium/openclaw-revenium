"""Canonical JSON encoding, strict decoding, and exact decimal and timestamp text.

Every encoded byte in the library comes from :func:`canonical_json`, and every
byte measurement and content hash uses it. This module sits at layer 1 so the
taxonomy and task modules can hash with it while ``serialization`` imports
their record types for its codec table.
"""

import json
import re
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Final, TypeAlias

from revenium_agent_economics.errors import CanonicalizationError

JsonValue: TypeAlias = (
    bool | int | float | str | Sequence["JsonValue"] | Mapping[str, "JsonValue"] | None
)

_SCALAR_TYPES: frozenset[type] = frozenset({type(None), bool, int, float, str})
_DECIMAL_TEXT: Final = re.compile(r"-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?", re.ASCII)
_UTC_TIMESTAMP_TEXT: Final = re.compile(
    r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{6}Z", re.ASCII
)


def canonical_json(value: JsonValue) -> bytes:
    """Encode ``value`` as canonical JSON bytes.

    The encoding is stdlib ``json`` with ``ensure_ascii=True``, compact
    separators, sorted keys, and no NaN or infinity literals. Only values whose
    exact type is ``dict``, ``list``, ``tuple``, ``str``, ``int``, ``float``,
    ``bool``, or ``None`` are accepted, and object keys must be exactly ``str``.

    Args:
        value: The JSON-native value to encode.

    Returns:
        The ASCII bytes of the canonical encoding.

    Raises:
        CanonicalizationError: If any nested value or key is not JSON-native,
            a container refers to itself, or a float is not finite.
    """
    _require_json_native(value, "$", set())
    try:
        text = json.dumps(
            value,
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
            allow_nan=False,
        )
    except ValueError as error:
        raise CanonicalizationError(str(error)) from error
    return text.encode("ascii")


def _require_json_native(value: object, path: str, ancestors: set[int]) -> None:
    if type(value) in _SCALAR_TYPES:
        return
    if type(value) is dict:
        _enter(value, path, ancestors)
        for key, item in value.items():
            if type(key) is not str:
                raise CanonicalizationError(
                    f"{path}: object key {key!r} is {type(key).__name__}, not str"
                )
            _require_json_native(item, f"{path}[{json.dumps(key)}]", ancestors)
        ancestors.discard(id(value))
        return
    if type(value) is list or type(value) is tuple:
        _enter(value, path, ancestors)
        for index, item in enumerate(value):
            _require_json_native(item, f"{path}[{index}]", ancestors)
        ancestors.discard(id(value))
        return
    raise CanonicalizationError(f"{path}: {type(value).__name__} is not JSON-native")


def _enter(container: object, path: str, ancestors: set[int]) -> None:
    if id(container) in ancestors:
        raise CanonicalizationError(f"{path}: container refers to itself")
    ancestors.add(id(container))


def parse_json_strict(data: bytes) -> JsonValue:
    """Parse bytes that must already be in canonical form.

    Args:
        data: The serialized bytes.

    Returns:
        The parsed JSON-native value.

    Raises:
        CanonicalizationError: If ``data`` is not ASCII bytes, is not valid JSON,
            nests too deeply, has a duplicate object key or a ``NaN`` or
            ``Infinity`` literal, or differs from ``canonical_json`` of its
            parsed value.
    """
    if type(data) is not bytes:
        raise CanonicalizationError(f"bytes required, got {type(data).__name__}")
    if not data.isascii():
        raise CanonicalizationError("input is not ASCII")
    try:
        value: JsonValue = json.loads(
            data,
            object_pairs_hook=_reject_duplicate_keys,
            parse_constant=_reject_non_finite_literal,
        )
        canonical = canonical_json(value)
    except RecursionError as error:
        raise CanonicalizationError("input nests too deeply") from error
    except ValueError as error:
        raise CanonicalizationError(f"invalid JSON: {error}") from error
    if canonical != data:
        raise CanonicalizationError("input is not in canonical form")
    return value


def _reject_duplicate_keys(pairs: list[tuple[str, JsonValue]]) -> dict[str, JsonValue]:
    result: dict[str, JsonValue] = {}
    for key, value in pairs:
        if key in result:
            raise CanonicalizationError(f"duplicate object key {key!r}")
        result[key] = value
    return result


def _reject_non_finite_literal(name: str) -> JsonValue:
    raise CanonicalizationError(f"non-finite literal {name}")


def format_decimal(value: Decimal) -> str:
    """Format a finite Decimal without an exponent or a negative zero.

    Args:
        value: The decimal to format.

    Returns:
        ``format(value, "f")``, with the sign removed from a negative zero.

    Raises:
        CanonicalizationError: If ``value`` is not a finite ``Decimal``.
    """
    if type(value) is not Decimal or not value.is_finite():
        raise CanonicalizationError(f"finite Decimal required, got {value!r}")
    text = format(value, "f")
    if value.is_zero() and value.is_signed():
        return text[1:]
    return text


def parse_decimal(text: str) -> Decimal:
    """Parse the canonical decimal text that :func:`format_decimal` emits.

    Args:
        text: Optional ``-``, an integer part without leading zeros, and an
            optional fraction. Negative zero is rejected.

    Returns:
        The exact decimal value, keeping the fraction's digits.

    Raises:
        CanonicalizationError: If ``text`` is not in that form.
    """
    if type(text) is not str or _DECIMAL_TEXT.fullmatch(text) is None:
        raise CanonicalizationError(f"not a canonical decimal: {text!r}")
    value = Decimal(text)
    if value.is_zero() and value.is_signed():
        raise CanonicalizationError(f"negative zero is not canonical: {text!r}")
    return value


def format_utc_timestamp(value: datetime) -> str:
    """Format an aware UTC datetime as RFC 3339 with microseconds and ``Z``.

    Args:
        value: A timezone-aware datetime whose UTC offset is zero.

    Returns:
        Text such as ``2026-09-27T00:00:00.000000Z``.

    Raises:
        CanonicalizationError: If ``value`` is not a datetime, is naive, or
            has a non-zero UTC offset.
    """
    if type(value) is not datetime:
        raise CanonicalizationError(f"datetime required, got {type(value).__name__}")
    offset = value.utcoffset()
    if offset is None:
        raise CanonicalizationError("naive datetime; a UTC datetime is required")
    if offset != timedelta(0):
        raise CanonicalizationError(f"UTC datetime required, got offset {offset}")
    text = value.replace(tzinfo=UTC).isoformat(timespec="microseconds")
    return text.removesuffix("+00:00") + "Z"


def parse_utc_timestamp(text: str) -> datetime:
    """Parse the exact timestamp shape :func:`format_utc_timestamp` emits.

    Args:
        text: ``YYYY-MM-DDTHH:MM:SS.ffffffZ``.

    Returns:
        The aware UTC datetime.

    Raises:
        CanonicalizationError: If ``text`` has any other shape or is not a
            valid calendar time.
    """
    if type(text) is not str or _UTC_TIMESTAMP_TEXT.fullmatch(text) is None:
        raise CanonicalizationError(f"not a canonical UTC timestamp: {text!r}")
    try:
        return datetime.fromisoformat(text.removesuffix("Z") + "+00:00")
    except ValueError as error:
        raise CanonicalizationError(f"invalid UTC timestamp: {text!r}") from error
