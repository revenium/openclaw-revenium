"""Contracts a host implements in its adapter; the core never calls them (ADR 0016).

These seven protocols describe the host side of the boundary: turning native
events into :class:`~revenium_agent_economics.envelope.ActivityEvent` records,
supplying evidence, storing taxonomies and decisions, reporting cost, storing
corrections, and delivering outcome metrics (D-25, ENV-05).

They differ from the ports in ``protocols``. The engine calls a port under a
deadline, and each port carries a ``ComponentDeclaration``. No library module
ever calls a contract defined here: the host calls the library, then calls its
own adapters with the results. None of these protocols has a ``declaration``,
because none of them makes a decision.

Only the package root imports this module, to re-export it. An architecture
test fails if any other package module imports it.

Hosts implement these protocols structurally, without importing a base class.
Payloads typed ``JsonValue`` are provisional: their owning phase settles them,
and until then their shape may change before 0.1.0 without a migration.
``CorrectionStore`` and ``OutcomeDelivery`` are final, typed against the v1
correction and metric records (ADR 0032 decision 4).
"""

from collections.abc import Iterable
from typing import Protocol

from revenium_agent_economics._canonical import JsonValue
from revenium_agent_economics.assessment import AssessmentAbstention, JobAssessment
from revenium_agent_economics.corrections import Correction, RecordRef
from revenium_agent_economics.envelope import ActivityEvent, UsageReport
from revenium_agent_economics.jobs import JobInference
from revenium_agent_economics.metrics import OutcomeMetricIntents
from revenium_agent_economics.outcomes import OutcomeAbstention, OutcomeProposal
from revenium_agent_economics.protocols import EvidenceQuery
from revenium_agent_economics.tasks import ClassificationAbstention, TaskClassification
from revenium_agent_economics.taxonomy import (
    JobTaxonomySnapshot,
    LabelProposal,
    TaskTaxonomySnapshot,
    TaxonomyNamespace,
)


class HostAdapter(Protocol):
    """Translate a host's native events into envelope events (ENV-05).

    The core never calls it. A host implements it in its adapter and passes
    the resulting events to ``normalize_stream``. Normalization is pure
    translation, so the method is synchronous: a host that must do I/O to
    translate does it before the call. Every envelope field it fills must
    trace to a documented host field (``compat/envelope_field_sources.toml``).
    """

    def normalize(self, native: object) -> Iterable[ActivityEvent]:
        """Return the envelope events for one batch of native host events."""
        ...


class EvidenceSource(Protocol):
    """Fetch the evidence for one job from the host's own stores (D-01).

    The core never calls it. ``assess_job`` is sync and pure, so the host
    resolves evidence ahead of the call: it fetches here, with any I/O and
    deadline it needs, then hands the library plain data as the request's
    ``ResolvedEvidence``. The host's injected ``EvidenceResolver`` decides
    reportability from that data without doing I/O (ADR 0025 decision 3).
    The returned payload is the host's own shape: the library never reads
    it, only the ``ResolvedEvidence`` the host builds from it.
    """

    async def evidence(self, query: EvidenceQuery) -> JsonValue:
        """Return the host's evidence for the job ``query`` names.

        Args:
            query: The job id, job type, and subject the evidence is about.

        Returns:
            The host's evidence payload, in the host's own shape.
        """
        ...


class TaxonomyStore(Protocol):
    """Persist taxonomies and label proposals in the host's store.

    The core never calls it. A host implements it in its adapter, loads a
    snapshot to hand to the engine through a taxonomy reader, and saves the
    proposals a decision carries.
    """

    async def load(
        self, namespace: TaxonomyNamespace
    ) -> TaskTaxonomySnapshot | JobTaxonomySnapshot:
        """Return the current snapshot for ``namespace``."""
        ...

    async def save_proposal(self, proposal: LabelProposal) -> None:
        """Store ``proposal`` in the host's taxonomy store."""
        ...


class DecisionStore(Protocol):
    """Persist the decisions the library returns.

    The core never calls it. A host implements it in its adapter and saves a
    decision after the library has returned it: a task classification or
    its abstention, a job inference, an outcome proposal or its abstention,
    and a job assessment or its abstention (ADR 0030 decision 11).
    """

    async def save(
        self,
        decision: TaskClassification
        | ClassificationAbstention
        | JobInference
        | OutcomeProposal
        | OutcomeAbstention
        | JobAssessment
        | AssessmentAbstention,
    ) -> None:
        """Store ``decision`` in the host's decision store."""
        ...


class CostTelemetrySource(Protocol):
    """Report metered usage for a subject from the host's telemetry.

    The core never calls it. A host implements it in its adapter. The shape
    is provisional until Phase 4 (cost), and may change before 0.1.0 without
    a migration.
    """

    async def usage(self, subject_ref: str) -> tuple[UsageReport, ...]:
        """Return the usage reports recorded for ``subject_ref``."""
        ...


class CorrectionStore(Protocol):
    """Persist and list corrections to earlier decisions (ADR 0032 decision 4).

    The core never calls it. A host implements it in its adapter: it appends
    each :class:`~revenium_agent_economics.corrections.Correction` that
    ``build_correction`` returns, and later lists a target's corrections to
    pass to ``resolve_effective``. Corrections are append-only history; the
    host never rewrites or deletes one.
    """

    async def append(self, correction: Correction) -> None:
        """Append ``correction`` to the host's correction store.

        An outcome-metric set's ``idempotency_key`` (D-12) commits to the
        assessment id and the applied correction ids, never to their content.
        The set key is unique only while the host
        never reuses an assessment sequence or a correction n for different
        content (D-10, ADR 0031 addendum item 6).
        """
        ...

    async def list_for(self, target: RecordRef) -> tuple[Correction, ...]:
        """Return the corrections recorded against ``target``, oldest first."""
        ...


class OutcomeDelivery(Protocol):
    """Deliver outcome-metric intents to the host's metering backend (ADR 0032).

    The core never calls it. A host implements it in its adapter and passes
    it each complete set that ``build_outcome_metrics_batch`` (or
    ``build_outcome_metrics``) returns. Delivery dedupes on the set's
    ``idempotency_key`` only (D-12). Each intent's ``line_key``, the ``OM:``
    key, is Hermes' parity label, which stays the same across a value,
    mechanism, currency, status, or allocation change, so a host never uses
    it alone to suppress a delivery (ADR 0034 WR-02 addendum).
    The set key is unique only while the host
    never reuses an assessment sequence or a correction n for different
    content (D-10, ADR 0031 addendum item 6).
    Mapping an execution status to a business-outcome state, throttling,
    deferring on a 429, handling a missing remote contract (404), locking,
    and keeping a delivery ledger all belong to the implementation, never
    to the core (METR-06, ADR 0032 decision 2).
    """

    async def deliver(self, intents: OutcomeMetricIntents) -> None:
        """Deliver the complete metric set ``intents`` to the host's backend."""
        ...
