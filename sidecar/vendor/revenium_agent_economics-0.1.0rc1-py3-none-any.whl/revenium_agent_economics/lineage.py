"""Lineage nodes and the job subject job inference receives (ADR 0015 decision 6).

A Claude Code subagent shares its parent's ``session_id`` and is named by
``agent_id`` (research F-9), so a lineage node is the pair
``(session_id, agent_id)`` rather than a bare session id (A-05). :func:`node_of`
places an event's identity on a node, :func:`fold_lineage` folds a normalized
activity log into a :class:`SessionLineage` (ADR 0015 decisions 6-7), and
:func:`subject_for` turns one of its nodes into a :class:`JobSubject`.

The module is pure: it reports cycles, depth cutoffs, and conflicting parents
as flags on its records and never emits diagnostics (ADR 0016).
"""

import enum
from collections.abc import Iterable
from dataclasses import dataclass
from typing import ClassVar, Final

from revenium_agent_economics._bounded import (
    IDENTIFIER_MAX_BYTES,
    is_bounded_printable,
)
from revenium_agent_economics.envelope import (
    ActivityIdentity,
    ActivityLog,
    DelegationInitiator,
    DelegationMode,
    SessionOrigin,
)
from revenium_agent_economics.errors import ConfigurationError, RecordValidationError
from revenium_agent_economics.primitives import _require_exact_type, _require_tuple_of


def _require_identifier(value: object, schema_id: str, field: str) -> None:
    _require_exact_type(value, str, schema_id, field)
    if not is_bounded_printable(str(value), IDENTIFIER_MAX_BYTES):
        raise RecordValidationError(
            schema_id,
            field,
            "must be non-empty printable text within "
            f"{IDENTIFIER_MAX_BYTES} serialized bytes",
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class LineageNode:
    """One place activity happens: a session, or a delegated agent inside one.

    Identifiers are rejected, never clamped, unless they are non-empty
    printable text within 128 serialized bytes.

    Attributes:
        session_id: The host session id.
        agent_id: The delegated agent id inside the session, or ``None`` for
            the session itself.
    """

    SCHEMA_ID: ClassVar[str] = "rae.lineage_node"
    SCHEMA_VERSION: ClassVar[int] = 1

    session_id: str
    agent_id: str | None = None

    def __post_init__(self) -> None:
        """Validate the identifier bounds.

        Raises:
            RecordValidationError: If an identifier is not bounded printable
                text.
        """
        schema_id = LineageNode.SCHEMA_ID
        _require_identifier(self.session_id, schema_id, "session_id")
        if self.agent_id is not None:
            _require_identifier(self.agent_id, schema_id, "agent_id")

    @property
    def sort_key(self) -> tuple[str, str]:
        """The node's total order: ``(session_id, agent_id or "")``.

        A session sorts before every agent inside it, since an agent id is
        never empty.
        """
        return (self.session_id, self.agent_id or "")


@dataclass(frozen=True, slots=True, kw_only=True)
class JobSubject:
    """The lineage-resolved scope a job inference call covers.

    Delegation facts are recorded as the host reported them and stay
    ``UNKNOWN`` otherwise (D-09). The flags carry what the lineage fold found
    so the engine can emit the matching ``lineage.*`` diagnostics.

    Attributes:
        node: The node the call is about.
        root: The node's lineage root.
        members: The nodes in scope, sorted by ``sort_key``, without
            duplicates, and containing ``node``.
        delegation_initiator: Who started the node's delegated work.
        delegation_mode: Whether the node's delegated work ran in the
            foreground or background.
        cycle_detected: Whether the node's parent chain contains a cycle.
        depth_exceeded: Whether the root walk stopped at its hop limit with a
            parent still ahead.
        parent_conflict: Whether a later event named a different parent.
    """

    SCHEMA_ID: ClassVar[str] = "rae.job_subject"
    SCHEMA_VERSION: ClassVar[int] = 1

    node: LineageNode
    root: LineageNode
    members: tuple[LineageNode, ...]
    delegation_initiator: DelegationInitiator = DelegationInitiator.UNKNOWN
    delegation_mode: DelegationMode = DelegationMode.UNKNOWN
    cycle_detected: bool = False
    depth_exceeded: bool = False
    parent_conflict: bool = False

    def __post_init__(self) -> None:
        """Validate exact types and the member ordering rules.

        Raises:
            RecordValidationError: If a field has the wrong type, the members
                are unsorted or repeated, or they do not contain ``node``.
        """
        schema_id = JobSubject.SCHEMA_ID
        _require_exact_type(self.node, LineageNode, schema_id, "node")
        _require_exact_type(self.root, LineageNode, schema_id, "root")
        _require_tuple_of(self.members, LineageNode, schema_id, "members")
        keys = [member.sort_key for member in self.members]
        if keys != sorted(set(keys)):
            raise RecordValidationError(
                schema_id, "members", "must be sorted by sort_key without duplicates"
            )
        if self.node not in self.members:
            raise RecordValidationError(schema_id, "members", "must contain node")
        _require_exact_type(
            self.delegation_initiator,
            DelegationInitiator,
            schema_id,
            "delegation_initiator",
        )
        _require_exact_type(
            self.delegation_mode, DelegationMode, schema_id, "delegation_mode"
        )
        for field, value in (
            ("cycle_detected", self.cycle_detected),
            ("depth_exceeded", self.depth_exceeded),
            ("parent_conflict", self.parent_conflict),
        ):
            _require_exact_type(value, bool, schema_id, field)


def root_subject(session_id: str, *, agent_id: str | None = None) -> JobSubject:
    """Return the subject of a node with no lineage: its own root and only member.

    Args:
        session_id: The host session id.
        agent_id: The delegated agent id, if the node is an agent.

    Returns:
        A subject whose node, root, and single member are the same node, with
        delegation facts ``UNKNOWN`` and no lineage flag set.

    Raises:
        RecordValidationError: If an identifier is not bounded printable text.
    """
    node = LineageNode(session_id=session_id, agent_id=agent_id)
    return JobSubject(node=node, root=node, members=(node,))


def node_of(identity: ActivityIdentity) -> LineageNode | None:
    """Return the lineage node an event with ``identity`` happens on (A-05).

    A Claude Code subagent shares its parent's ``session_id`` and is named by
    ``delegated_agent_id`` (research F-9), so the node is
    ``(session_id, delegated_agent_id)``.

    Args:
        identity: The event's identifiers.

    Returns:
        ``None`` when the identity has no ``session_id``, since an event with
        no session is not placed in lineage; otherwise the node.

    Raises:
        RecordValidationError: If ``identity`` is not an ``ActivityIdentity``.
    """
    _require_exact_type(identity, ActivityIdentity, LineageNode.SCHEMA_ID, "identity")
    if identity.session_id is None:
        return None
    return LineageNode(
        session_id=identity.session_id, agent_id=identity.delegated_agent_id
    )


DEFAULT_MAX_DEPTH: Final = 10
"""Hermes ``_walk_to_root_session`` hops at most 10 times (classifier.py:L364)."""


class LineageEdgeKind(enum.Enum):
    """How a node claims its parent (ADR 0015 decision 6)."""

    PARENT_SESSION = "parent_session"
    FORKED_FROM = "forked_from"
    DELEGATION = "delegation"


_SESSION_EDGES: Final = frozenset(
    {LineageEdgeKind.PARENT_SESSION, LineageEdgeKind.FORKED_FROM}
)


@dataclass(frozen=True, slots=True, kw_only=True)
class LineageEntry:
    """One lineage node, its winning parent claim, and its resolved root.

    Delegation facts are kept exactly as reported and stay ``UNKNOWN``
    otherwise (D-09). A self-parent and a cycle are valid: the fold records
    them as flags instead of refusing them.

    Attributes:
        node: The node this entry describes.
        origin: The first non-``UNKNOWN`` session origin reported for the node.
        parent: The first parent claimed for the node, or ``None``.
        edge: How ``parent`` was claimed. Set exactly when ``parent`` is. A
            ``DELEGATION`` edge links an agent to its own session; the other
            edges link a session to another session.
        root: The node reached by the Hermes hop walk (A-03).
        delegation_initiator: The first non-``UNKNOWN`` initiator reported.
        delegation_mode: The latest non-``UNKNOWN`` mode reported (A-06).
        cycle_detected: Whether a hop of the root walk revisited a node.
        depth_exceeded: Whether the node the walk stopped at still has a
            parent.
        parent_conflict: Whether a later event claimed a different parent.
    """

    SCHEMA_ID: ClassVar[str] = "rae.lineage_entry"
    SCHEMA_VERSION: ClassVar[int] = 1

    node: LineageNode
    origin: SessionOrigin = SessionOrigin.UNKNOWN
    parent: LineageNode | None = None
    edge: LineageEdgeKind | None = None
    root: LineageNode
    delegation_initiator: DelegationInitiator = DelegationInitiator.UNKNOWN
    delegation_mode: DelegationMode = DelegationMode.UNKNOWN
    cycle_detected: bool = False
    depth_exceeded: bool = False
    parent_conflict: bool = False

    def __post_init__(self) -> None:
        """Validate exact types and the parent, edge, and root invariants.

        Raises:
            RecordValidationError: If a field has the wrong type, ``parent``
                and ``edge`` are not both set or both unset, the edge does not
                fit the node, or a parentless node has a root or flag that
                only a parent can produce.
        """
        schema_id = LineageEntry.SCHEMA_ID
        _require_exact_type(self.node, LineageNode, schema_id, "node")
        _require_exact_type(self.origin, SessionOrigin, schema_id, "origin")
        _require_exact_type(self.root, LineageNode, schema_id, "root")
        _require_exact_type(
            self.delegation_initiator,
            DelegationInitiator,
            schema_id,
            "delegation_initiator",
        )
        _require_exact_type(
            self.delegation_mode, DelegationMode, schema_id, "delegation_mode"
        )
        for field, value in (
            ("cycle_detected", self.cycle_detected),
            ("depth_exceeded", self.depth_exceeded),
            ("parent_conflict", self.parent_conflict),
        ):
            _require_exact_type(value, bool, schema_id, field)
        if (self.parent is None) != (self.edge is None):
            raise RecordValidationError(
                schema_id, "edge", "must be set exactly when parent is set"
            )
        if self.parent is None:
            if (
                self.root != self.node
                or self.cycle_detected
                or self.depth_exceeded
                or self.parent_conflict
            ):
                raise RecordValidationError(
                    schema_id,
                    "parent",
                    "a node without a parent is its own root with no flag set",
                )
            return
        _require_exact_type(self.parent, LineageNode, schema_id, "parent")
        _require_exact_type(self.edge, LineageEdgeKind, schema_id, "edge")
        if self.edge is LineageEdgeKind.DELEGATION:
            if self.node.agent_id is None or self.parent != LineageNode(
                session_id=self.node.session_id
            ):
                raise RecordValidationError(
                    schema_id,
                    "edge",
                    "a delegation links an agent node to its own session node",
                )
        elif self.node.agent_id is not None or self.parent.agent_id is not None:
            raise RecordValidationError(
                schema_id,
                "edge",
                "a parent-session or fork edge links two session nodes",
            )


@dataclass(frozen=True, slots=True, kw_only=True)
class SessionLineage:
    """The lineage folded from one activity log (ADR 0015 decision 6).

    Attributes:
        entries: One entry per node, strictly sorted by ``node.sort_key``.
            Every parent and root names a node that has an entry.
        max_depth: The hop limit the roots were computed with, at least 1.
    """

    SCHEMA_ID: ClassVar[str] = "rae.session_lineage"
    SCHEMA_VERSION: ClassVar[int] = 1

    entries: tuple[LineageEntry, ...] = ()
    max_depth: int = DEFAULT_MAX_DEPTH

    def __post_init__(self) -> None:
        """Validate the ordering, closure, and hop limit.

        Raises:
            RecordValidationError: If the entries are not a tuple of
                ``LineageEntry`` strictly sorted by node, a parent or root
                has no entry, or ``max_depth`` is not an ``int`` of at least 1.
        """
        schema_id = SessionLineage.SCHEMA_ID
        _require_tuple_of(self.entries, LineageEntry, schema_id, "entries")
        keys = [entry.node.sort_key for entry in self.entries]
        if keys != sorted(set(keys)):
            raise RecordValidationError(
                schema_id, "entries", "must be strictly sorted by node sort_key"
            )
        nodes = {entry.node for entry in self.entries}
        for entry in self.entries:
            if entry.root not in nodes or (
                entry.parent is not None and entry.parent not in nodes
            ):
                raise RecordValidationError(
                    schema_id, "entries", "every parent and root must have an entry"
                )
        _require_exact_type(self.max_depth, int, schema_id, "max_depth")
        if self.max_depth < 1:
            raise RecordValidationError(schema_id, "max_depth", "must be at least 1")

    def entry(self, node: LineageNode) -> LineageEntry | None:
        """Return the entry for ``node``, or ``None`` when it has none.

        Args:
            node: The node to look up.

        Returns:
            The node's entry, or ``None``.
        """
        for candidate in self.entries:
            if candidate.node == node:
                return candidate
        return None


class _NodeFacts:
    """What the fold has seen for one node so far. Private and mutable."""

    __slots__ = (
        "conflict",
        "edge",
        "initiator",
        "mode",
        "origin",
        "parent",
    )

    def __init__(self) -> None:
        self.parent: LineageNode | None = None
        self.edge: LineageEdgeKind | None = None
        self.conflict = False
        self.origin = SessionOrigin.UNKNOWN
        self.initiator = DelegationInitiator.UNKNOWN
        self.mode = DelegationMode.UNKNOWN

    def claim(self, parent: LineageNode, edge: LineageEdgeKind) -> None:
        # ADR 0015 decision 6: the first claim wins; a different later parent
        # is a conflict, while the same parent by another edge is not.
        if self.parent is None:
            self.parent = parent
            self.edge = edge
        elif self.parent != parent:
            self.conflict = True

    def report(self, identity: ActivityIdentity) -> None:
        # ADR 0015 decision 7 (A-06): first known origin and initiator win,
        # the latest known mode wins, and UNKNOWN never overrides.
        if self.origin is SessionOrigin.UNKNOWN:
            self.origin = identity.session_origin
        if self.initiator is DelegationInitiator.UNKNOWN:
            self.initiator = identity.delegation_initiator
        if identity.delegation_mode is not DelegationMode.UNKNOWN:
            self.mode = identity.delegation_mode


def _root_of(
    node: LineageNode,
    parents: dict[LineageNode, LineageNode],
    max_depth: int,
) -> tuple[LineageNode, bool, bool]:
    # Hermes _walk_to_root_session (classifier.py:L372-L380 at 5c2bfea8):
    # at most max_depth hops, stopping at a node with no parent, with no
    # revisit stop. Cycle detection only sets the flag (research F-3).
    current = node
    seen = {node}
    cycle = False
    for _ in range(max_depth):
        parent = parents.get(current)
        if parent is None:
            return current, cycle, False
        cycle = cycle or parent in seen
        seen.add(parent)
        current = parent
    return current, cycle, current in parents


def fold_lineage(
    log: ActivityLog, *, max_depth: int = DEFAULT_MAX_DEPTH
) -> SessionLineage:
    """Fold a normalized activity log into its session lineage (ENV-03, D-08).

    Events are read in log order, and an event with no ``session_id`` is not
    placed. For an event on session S the node ``(S, None)`` is registered,
    and then, in this order:

    - ``parent_session_id`` P claims ``((P, None), PARENT_SESSION)`` for
      ``(S, None)``;
    - ``forked_from_session_id`` F claims ``((F, None), FORKED_FROM)`` for
      ``(S, None)``;
    - ``delegated_agent_id`` A registers ``(S, A)`` and claims
      ``((S, None), DELEGATION)`` for it.

    Parent nodes are registered too. The first claim for a node wins, and a
    later claim naming a different parent sets ``parent_conflict``. The
    event's own node, :func:`node_of` its identity, receives its origin,
    initiator, and mode reports: the first non-``UNKNOWN`` origin and
    initiator win, and the latest non-``UNKNOWN`` mode wins.

    Each root uses Hermes hop semantics: at most ``max_depth`` hops,
    stopping at a node with no parent. ``cycle_detected`` is set when a hop
    revisits a node, and ``depth_exceeded`` when the node reached after
    ``max_depth`` hops still has a parent. The fold never raises on a
    malformed chain.

    Args:
        log: The normalized activity stream.
        max_depth: The hop limit, an ``int`` of at least 1 that is not a
            ``bool``.

    Returns:
        One entry per registered node, sorted by node.

    Raises:
        ConfigurationError: If ``log`` is not an ``ActivityLog`` or
            ``max_depth`` is invalid.
    """
    if type(max_depth) is not int or max_depth < 1:
        raise ConfigurationError(
            f"max_depth must be an int of at least 1, got {max_depth!r}"
        )
    if type(log) is not ActivityLog:
        raise ConfigurationError(f"ActivityLog required, got {type(log).__name__!r}")
    facts: dict[LineageNode, _NodeFacts] = {}

    def register(node: LineageNode) -> _NodeFacts:
        return facts.setdefault(node, _NodeFacts())

    for event in log.events:
        identity = event.identity
        if identity.session_id is None:
            continue
        session = LineageNode(session_id=identity.session_id)
        session_facts = register(session)
        if identity.parent_session_id is not None:
            parent = LineageNode(session_id=identity.parent_session_id)
            register(parent)
            session_facts.claim(parent, LineageEdgeKind.PARENT_SESSION)
        if identity.forked_from_session_id is not None:
            source = LineageNode(session_id=identity.forked_from_session_id)
            register(source)
            session_facts.claim(source, LineageEdgeKind.FORKED_FROM)
        own = session_facts
        if identity.delegated_agent_id is not None:
            agent = LineageNode(
                session_id=identity.session_id, agent_id=identity.delegated_agent_id
            )
            own = register(agent)
            own.claim(session, LineageEdgeKind.DELEGATION)
        own.report(identity)

    parents = {
        node: node_facts.parent
        for node, node_facts in facts.items()
        if node_facts.parent is not None
    }
    entries: list[LineageEntry] = []
    for node in sorted(facts, key=lambda item: item.sort_key):
        node_facts = facts[node]
        root, cycle, exceeded = _root_of(node, parents, max_depth)
        entries.append(
            LineageEntry(
                node=node,
                origin=node_facts.origin,
                parent=node_facts.parent,
                edge=node_facts.edge,
                root=root,
                delegation_initiator=node_facts.initiator,
                delegation_mode=node_facts.mode,
                cycle_detected=cycle,
                depth_exceeded=exceeded,
                parent_conflict=node_facts.conflict,
            )
        )
    return SessionLineage(entries=tuple(entries), max_depth=max_depth)


def subject_for(
    lineage: SessionLineage,
    node: LineageNode,
    *,
    members: Iterable[LineageNode] | None = None,
) -> JobSubject:
    """Return the job subject for one lineage node (ADR 0015 decision 6).

    Args:
        lineage: The folded lineage.
        node: The node the job inference is about.
        members: The nodes in scope. ``None`` means ``(node,)``. The result
            is sorted by ``sort_key``, deduplicated, and always contains
            ``node``.

    Returns:
        A subject whose root, delegation initiator and mode, and lineage
        flags come from ``node``'s entry.

    Raises:
        ConfigurationError: If an argument has the wrong type, ``node`` or a
            member has no entry, or a member's root differs from ``node``'s.
    """
    if type(lineage) is not SessionLineage:
        raise ConfigurationError(
            f"SessionLineage required, got {type(lineage).__name__!r}"
        )
    if type(node) is not LineageNode:
        raise ConfigurationError(f"LineageNode required, got {type(node).__name__!r}")
    entry = lineage.entry(node)
    if entry is None:
        raise ConfigurationError(f"node {node.sort_key!r} has no lineage entry")
    scope = {node}
    for member in () if members is None else members:
        if type(member) is not LineageNode:
            raise ConfigurationError(
                f"members must be LineageNode values, got {type(member).__name__!r}"
            )
        member_entry = lineage.entry(member)
        if member_entry is None:
            raise ConfigurationError(f"member {member.sort_key!r} has no lineage entry")
        if member_entry.root != entry.root:
            raise ConfigurationError(
                f"member {member.sort_key!r} has root {member_entry.root.sort_key!r}, "
                f"not {entry.root.sort_key!r}"
            )
        scope.add(member)
    return JobSubject(
        node=node,
        root=entry.root,
        members=tuple(sorted(scope, key=lambda item: item.sort_key)),
        delegation_initiator=entry.delegation_initiator,
        delegation_mode=entry.delegation_mode,
        cycle_detected=entry.cycle_detected,
        depth_exceeded=entry.depth_exceeded,
        parent_conflict=entry.parent_conflict,
    )
